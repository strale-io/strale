# Publishing Design System — Component Specifications

> **Authority:** This file defines component rules for the Publishing design system.
> Project-specific extensions go in `docs/3-design.md`.

---

## Component Philosophy

1. **Content-first** — Components serve the content, never compete with it
2. **Generous breathing room** — White space is a feature, not wasted space
3. **Progressive disclosure via tabs** — Reduce page sprawl; reveal depth on demand
4. **Purposeful empty states** — Every screen has a designed empty state with icon, text, and CTA
5. **Status at a glance** — Colored badges and indicators, not text-only labels

---

## 1. Buttons

### Variants

| Variant | Use Case | Appearance |
|---------|----------|------------|
| **Primary** | Main actions (1 per view) | Solid primary blue, white text, rounded (6px) |
| **Secondary** | Supporting actions | White background, gray border, dark text |
| **Ghost** | Tertiary actions, inline actions | No background, no border, primary blue text |
| **Danger** | Destructive actions | Solid error red, white text |
| **Upsell** | Upgrade prompts | Outlined with amber/gold accent |

### Sizes

| Size | Height | Padding H | Font Size | Use Case |
|------|--------|-----------|-----------|----------|
| `sm` | 32px | 12px | 13px | Inline actions, table rows |
| `md` | 36px | 16px | 14px | Default — most contexts |
| `lg` | 44px | 24px | 15px | Hero sections, primary CTA in empty states |

### States

| State | Visual Change |
|-------|---------------|
| Default | Base appearance |
| Hover | Background darkens 5% — no movement, no shadow change |
| Active | Darken (10%) |
| Focus | 2px focus ring (primary blue + light blue outer) |
| Disabled | 40% opacity, no pointer events |
| Loading | Spinner replaces text, button disabled |

### Rules

- Maximum ONE primary button per view section
- Button text is sentence case ("Save changes" not "Save Changes")
- Icons: leading only, 16px size, 8px gap to text
- Minimum touch target: 44x44px on mobile
- Border radius: 6px (slightly less than card radius)

---

## 2. Cards

### Standard Card

| Property | Value |
|----------|-------|
| Background | White (#FFFFFF) |
| Border | 1px `border.default` (#E6E4E0) |
| Shadow | None (flat surface) |
| Border radius | 8px |
| Padding | 24px |
| Hover | Border darkens to `secondary.300` — no shadow, no movement |

### Accent Feature Card

Used for: Learning resources, onboarding highlights, feature promotions.
Uses a tinted background instead of gradients for featured content.

| Property | Value |
|----------|-------|
| Background | `primary.50` (#EDF2FB) light tint |
| Border | 1px `primary.200` (#A9C4EB) |
| Border radius | 8px |
| Padding | 24px |
| Text color | `primary.700` for headings, `primary.600` for body |
| Content | Icon + title + description |

### Shortcut Tile Card

Used for: Navigation between sections, quick-access links within pages.

| Property | Value |
|----------|-------|
| Background | White |
| Border | 1px `border.default` |
| Border radius | 8px |
| Padding | 20px |
| Icon | 32px, monochrome, centered above text |
| Title | `typography.base`, medium weight |
| Description | `typography.sm`, muted text |
| Link indicator | Small external link icon or chevron |

### Dashboard Metric Card

| Property | Value |
|----------|-------|
| Layout | Icon/number left, label right (or stacked) |
| Background | White |
| Border | 1px `border.default` |
| Border radius | 8px |
| Padding | 20px |

---

## 3. Tabs

Tabs are a first-class pattern — used within content pages to organize related information without creating separate routes.

### Page-Level Tabs

Used for: Content organization within a documentation page (e.g., Design / Code / Usage on a component page; Spacing / Grid / Breakpoints on a layout page).

| Property | Value |
|----------|-------|
| Position | Below page header, above content |
| Active indicator | 2px bottom border, primary blue |
| Inactive text | `text.secondary` |
| Active text | `text.primary`, medium weight |
| Font size | `typography.base` (14px) |
| Spacing between tabs | 24px |
| Bottom border | Full-width 1px `border.default` under tab row |
| "+ Add tab" | Ghost button at end of tab row |

### Rules

- Maximum 5–6 tabs per page before considering a different pattern
- First tab is always active by default
- Tab labels are short (1–2 words)
- Tab content area has no additional top padding beyond the section gap

---

## 4. Status Badges

Colored background badges for visual scanning — never text-only status labels.

### Variants

| Status | Background | Text | Border Radius |
|--------|------------|------|---------------|
| Ready / Up to date | `success.light` | `success.dark` | 4px |
| In Progress | `info.light` | `info.dark` | 4px |
| Draft | `secondary.100` | `secondary.700` | 4px |
| Warning / Out of date | `error.light` | `error.dark` | 4px |
| Not used | `secondary.100` | `secondary.500` | 4px |

### Size

| Property | Value |
|----------|-------|
| Font size | 12px |
| Font weight | 500 (medium) |
| Padding | 2px 8px |
| Line height | 20px |
| Border radius | 4px |

### Inline Status Indicators

Used next to repository names, component names in lists.

| Property | Value |
|----------|-------|
| Indicator | 8px colored circle + text label |
| Circle colors | Match badge variant colors |
| Gap | 6px between circle and label |

---

## 5. Do / Don't Blocks

Side-by-side usage guidance blocks — a key documentation pattern for showing correct and incorrect usage.

### Structure

```
┌──────────────────────────┐  ┌──────────────────────────┐
│                          │  │                          │
│      [Image/Example]     │  │      [Image/Example]     │
│                          │  │                          │
├──────────────────────────┤  ├──────────────────────────┤
│ ✓ Do                     │  │ ✗ Don't                  │
│ Description of correct   │  │ Description of incorrect │
│ usage.                   │  │ usage.                   │
└──────────────────────────┘  └──────────────────────────┘
```

### Properties

| Element | Do Block | Don't Block | Caution Block |
|---------|----------|-------------|---------------|
| Label background | `success.light` | `error.light` | `warning.light` |
| Label text | "Do" | "Don't" | "Caution" |
| Label icon | ✓ checkmark | ✗ cross | ! exclamation |
| Label icon color | `success.default` | `error.default` | `warning.default` |
| Card background | White | White | White |
| Card border | 1px `border.default` | 1px `border.default` | 1px `border.default` |
| Border radius | 8px | 8px | 8px |
| Image area | Gray background placeholder | Gray background placeholder | Gray background placeholder |

### Rules

- Always appear in pairs (Do + Don't) or triples (Do + Don't + Caution)
- Side-by-side on desktop, stacked on mobile
- Description text is 1–2 sentences maximum
- Image area has consistent aspect ratio (16:9 or 4:3)

---

## 6. Navigation Sidebar

### Structure

| Element | Style |
|---------|-------|
| Background | `background.muted` (#F3F2EF) |
| Width | 240px (desktop), collapsed on tablet, overlay on mobile |
| Logo area | Top, 64px height, upload placeholder |
| Search | Below logo, full-width input with icon |
| Category labels | Uppercase, 11px, semibold, `secondary.600`, 0.05em tracking |
| Page items | 14px, normal weight, `secondary.800` |
| Active item | `primary.50` background, `primary.600` text, left accent |
| Hover item | `secondary.100` background |
| Subcategory toggle | Chevron right (collapsed) / down (expanded) |
| "+ Add" links | Ghost style, primary blue, 12px |

### Category Groups

Organizes the sidebar into collapsible category groups:
- OVERVIEW (Introduction, Principles, Release notes)
- STYLE (Colors, Typography, Icons, Layout)
- COMPONENTS (Button, etc.)
- RESOURCES (Design tokens, Downloads)

Each category has "Add subcategory" and "Add page" actions at the bottom.

---

## 7. Table of Contents (Right Sidebar)

A right-aligned navigation panel showing section headings within the current page.

| Property | Value |
|----------|-------|
| Position | Right side, sticky |
| Width | ~200px |
| Font size | 13px |
| Active item | Bold weight, `text.primary` |
| Inactive items | Normal weight, `text.secondary` |
| Spacing | 8px between items |
| Visibility | Desktop only; hidden on tablet/mobile |

---

## 8. Code Blocks

| Property | Value |
|----------|-------|
| Background | `secondary.50` (#FAFAF9) |
| Border | 1px `border.default` |
| Border radius | 8px |
| Padding | 16px |
| Font family | Monospace from typography tokens |
| Font size | 13px |
| Line height | 20px |
| Language label | Top-left, 11px, uppercase, muted |
| Copy button | Top-right, ghost icon button |
| Syntax highlighting | Standard theme (keywords blue, strings green, comments gray) |

---

## 9. File Download Cards

Used in the Downloads section for hosting UI kits, fonts, and utilities.

| Property | Value |
|----------|-------|
| Layout | Icon (left) + filename + metadata (right) |
| Icon | File type icon (32px) — document, font, or generic |
| Filename | `typography.base`, medium weight |
| Metadata | `typography.sm`, muted — date, size, type |
| Background | White |
| Border | 1px `border.default` |
| Border radius | 8px |
| Padding | 16px |
| "Upload more files" | Full-width ghost button below card group |

---

## 10. Cover Page

A hero section for the styleguide's landing page.

| Property | Value |
|----------|-------|
| Title | `typography.3xl` or `4xl`, semibold |
| Subtitle | "Styleguide updated X ago" — `typography.sm`, muted |
| Description | Optional, `typography.md`, `text.secondary` |
| Style selector | "Cover style" dropdown for template options |
| Background | Configurable — white, `primary.50` tint, or brand color |
| Padding | 48px vertical, standard horizontal |

---

## 11. Upsell / Upgrade Banner

Persistent contextual upgrade prompts integrated naturally into the UI.

| Property | Value |
|----------|-------|
| Banner background | `upsell.background` (warm yellow) |
| Text | `upsell.text`, `typography.sm` |
| Border | 1px `upsell.border` |
| Position | Top of page, full width |
| Counter format | "1/1 styleguides in your plan. Upgrade →" next to feature header |
| Dismissible | Optional close button (×) |

---

## 12. Progress Indicator (Onboarding)

Persistent, non-intrusive progress tracker visible during onboarding.

| Property | Value |
|----------|-------|
| Position | Fixed, bottom-right corner |
| Z-index | `z_index.progress_indicator` (800) |
| Shape | Circular or pill badge |
| Content | Percentage (e.g., "60%") or step count |
| Background | Primary blue |
| Text | White |
| Size | ~48px diameter (circular) |
| Shadow | `shadow.md` (floating element — exception to flat rule) |
| Interaction | Click to expand onboarding checklist |

### Onboarding Checklist (Expanded)

| Property | Value |
|----------|-------|
| Position | Above progress indicator, bottom-right |
| Background | White |
| Shadow | `shadow.lg` (floating overlay — exception to flat rule) |
| Border radius | 12px |
| Width | 320px |
| Items | Checkbox + task description |
| Completed items | Strikethrough text, muted color |
