# Publishing Design System — UI States

> **Authority:** This file defines rules for loading, empty, and error states.
> Publishing states are distinguished by purposeful empty states with
> generous illustrations and clear calls to action.

---

## State Philosophy

1. **Never leave users wondering** — Always communicate system status
2. **Every empty state is an opportunity** — Guide users toward their first action
3. **Design the zero state** — The first experience matters most; empty states are onboarding
4. **Warm, encouraging tone** — Not clinical or technical

---

## 1. Loading States

### When to Show What

| Expected Wait | Loading Pattern |
|---------------|-----------------|
| < 200ms | No indicator (feels instant) |
| 200ms – 1s | Subtle indicator (skeleton, spinner in button) |
| 1s – 10s | Prominent indicator (full skeleton, progress) |
| > 10s | Progress with status updates |

### Skeleton Loading

**Use for:** Page content, cards, sidebar navigation, documentation blocks

**Structure:** Mirror actual content layout with animated placeholders.

```
┌─────────────────────────────────────────┐
│ ████████ (category label, short)        │
│ ████████████████████ (page title)       │
│ ████████████████████████████ (desc)     │
│                                         │
│ [Tab 1]  [Tab 2]  [Tab 3]              │
├─────────────────────────────────────────┤
│                                         │
│ ████████████████ (section heading)      │
│                                         │
│ ██████████████████████████████████████  │
│ ██████████████████████████████████████  │
│ █████████████████████████ (body text)   │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ │
│ │░░░░░░░ (content block placeholder) ░│ │
│ │░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│ │
│ └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

**Rules:**
- Match dimensions of actual content (headers wider than body text)
- Animation: subtle pulse (opacity 0.5 → 1.0), NOT shimmer
- Minimum display time: 200ms (prevents flash)
- Transition to real content: 200ms fade
- Skeleton color: `secondary.200` (#EEEEEE)
- Skeleton radius: 4px

### Spinner Loading

**Use for:** Buttons, inline actions, small components

| Context | Spinner Size | Position |
|---------|--------------|----------|
| Button | 16px | Replaces text, centered |
| Inline | 16px | After label |
| Card center | 24px | Center of card content area |
| Section | 32px | Center of section |

**Rules:**
- Always disable interaction during loading
- Maintain layout stability (no content shift)
- Spinner color: `primary.600` for interactive, `secondary.400` for passive
- Animation: smooth rotation, 0.8s per revolution

### Progress Loading

**Use for:** File uploads, Figma sync, bulk operations

| Type | Use Case |
|------|----------|
| Determinate | File upload, import progress |
| Indeterminate | Processing, "connecting to Figma…" |
| Stepped | Multi-stage setup (connect source → scan → match) |

**Progress Bar Rules:**
- Height: 4px inline, 8px prominent
- Border radius: full (rounded ends)
- Color: `primary.600` fill, `secondary.200` track
- Show percentage text for determinate progress
- Animate fill smoothly (no jumps)

---

## 2. Empty States

### Empty State Structure

Publishing empty states use generous whitespace,
clear icons, and warm copy that guides users forward.

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│            [ Icon / Illustration ]       │
│               (muted primary)           │
│                                         │
│         Headline (concise, warm)        │
│                                         │
│    Description (1–2 sentences, guides   │
│    the user toward what to do next)     │
│                                         │
│          [ Primary Action CTA ]         │
│                                         │
│      Optional secondary text link       │
│                                         │
│                                         │
└─────────────────────────────────────────┘
```

### Empty State Types

| Type | Tone | Icon Style | Example |
|------|------|------------|---------|
| **First use** | Encouraging, warm | Feature-relevant icon | "Create your first styleguide" |
| **No results** | Helpful, suggests alternatives | Search icon | "No results for 'xyz'. Try different keywords." |
| **No data** | Explanatory | Empty container icon | "No components connected yet" |
| **Filtered empty** | Clear about filter state | Filter icon | "No items match your current filters" |
| **Connect source** | Inviting, shows value | Integration logo cluster | "Upload components and styles from your favorite design tools" |

### Content Guidelines

#### Headlines

| Do | Don't |
|----|-------|
| "No projects yet" | "Error: Empty" |
| "Add a design file" | "Nothing to display" |
| "Create your first component" | "0 results found" |
| "Connect a Storybook" | "Data unavailable" |

#### Descriptions

| Do | Don't |
|----|-------|
| Explain what would appear here | Apologize |
| Guide user to resolve it | Use technical jargon |
| Keep to 1–2 sentences max | Write paragraphs |
| Reference the value they'll get | Blame the user |

#### Actions

| State | Primary Action | Secondary Action |
|-------|----------------|------------------|
| First use | Create / Add first item | Learn more / Watch tutorial |
| Connect source | "Add a design file" | "or upload an image" |
| No search results | Clear search | Modify filters |
| No filtered results | Clear filters | Reset to defaults |
| No connected code | Paste Storybook URL | "Find out how in the Help Center" |

### Design File Connection Empty State

A distinctive pattern: green-tinted card with tool logos inviting connection.

```
┌─────────────────────────────────────────────────────────┐
│  ┌─────────────────────────────────────────────────┐    │
│  │      (green-tinted background)                  │    │
│  │                                                 │    │
│  │  🟣🟡🔵🟢  Upload components and styles from   │    │
│  │  (tool      your favorite design tools and      │    │
│  │   logos)    insert them here                     │    │
│  │                                                 │    │
│  │              [ Add a design file ]               │    │
│  │                                                 │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
```

| Property | Value |
|----------|-------|
| Background | Soft green tint (`#E8F5E9` or similar) |
| Border radius | 8px |
| Padding | 24px |
| Tool logos | Figma, Sketch, XD, Zeplin icons at 24px |
| CTA | Secondary button style (dark background, white text) |

### Illustration Rules

- Style: Simple line icons or monochrome illustrations (not colorful/playful)
- Max size: 120px width × 80px height (smaller than Professional)
- Color: `secondary.400` (muted gray) — doesn't compete with content
- Placement: Centered above headline
- Can omit for inline/compact empty states

---

## 3. Error States

### Error Levels

| Level | Visual | When to Use |
|-------|--------|-------------|
| **Field** | Inline red text + red border | Form validation |
| **Component** | Warning banner within component | Component-level failure |
| **Section** | Error card replacing section content | Section failed to load |
| **Page** | Full-page error with illustration | Entire page failed |
| **Toast** | Non-blocking notification | Background action failed |

### Field Errors

```
┌─────────────────────────────────────────┐
│ Label                                   │
│ ┌─────────────────────────────────────┐ │
│ │ Input value                     [!] │ │ ← red border
│ └─────────────────────────────────────┘ │
│ Error message in red                    │ ← typography.sm, error.default
└─────────────────────────────────────────┘
```

| Property | Value |
|----------|-------|
| Border color | `error.default` (#E53E3E) |
| Error icon | Exclamation in circle, 16px, `error.default` |
| Error text | `typography.sm`, `error.default` |
| Spacing | 4px below input |
| Animation | Subtle shake (optional, 200ms) |

### Section Errors

```
┌─────────────────────────────────────────┐
│                                         │
│  ⚠ Unable to load this section          │
│                                         │
│  Something went wrong. Try refreshing   │
│  or check your connection.              │
│                                         │
│           [ Try again ]                 │
│                                         │
└─────────────────────────────────────────┘
```

| Property | Value |
|----------|-------|
| Background | `error.light` |
| Border | 1px `error.default` (left border accent) |
| Border radius | 8px |
| Icon | Warning triangle, `error.default` |
| Headline | `typography.base`, semibold |
| Description | `typography.sm`, `text.secondary` |
| Action | Secondary button "Try again" |

### Toast Notifications

Non-blocking feedback for completed or failed actions.

| Property | Value |
|----------|-------|
| Position | Top-center, 16px from top |
| Width | Auto (max 480px) |
| Background | White |
| Shadow | `shadow.md` (floating element — exception to flat rule) |
| Border radius | 8px |
| Border-left | 4px accent (green success, red error, blue info) |
| Duration | 5s auto-dismiss (errors persist until dismissed) |
| Dismiss | × close button, right side |
| Animation | Slide down 200ms, fade out 200ms |

### Toast Variants

| Variant | Left Border | Icon | Example |
|---------|-------------|------|---------|
| Success | `success.default` | ✓ checkmark | "Changes saved" |
| Error | `error.default` | ✗ cross | "Couldn't save. Try again." |
| Warning | `warning.default` | ! exclamation | "You're approaching your plan limit" |
| Info | `info.default` | ℹ info | "New version available" |

---

## 4. Success States

### Inline Success

Brief confirmation after an action completes.

| Property | Value |
|----------|-------|
| Format | Toast (see above) or inline text |
| Inline text | `typography.sm`, `success.dark`, with ✓ icon |
| Duration | 3s then fade |
| Tone | Brief, matter-of-fact ("Saved", "Published", "Connected") |

### Completion State

When a major workflow completes (e.g., styleguide published, source connected).

```
┌─────────────────────────────────────────┐
│                                         │
│              ✓ (large icon)             │
│                                         │
│     Your styleguide has been shared.    │
│                                         │
│        [ View published page ]          │
│                                         │
└─────────────────────────────────────────┘
```

---

## 5. Partial States

### Partial Loading

When some content is ready but other parts are still loading:

```
┌─────────────────────────────────────────┐
│ Page Title (loaded)                     │
│ Description (loaded)                    │
│                                         │
│ [Tab 1]  [Tab 2]  [Tab 3]              │
├─────────────────────────────────────────┤
│ Section 1 (loaded — real content)       │
│                                         │
│ ████████████████ (loading section 2)    │
│ ░░░░░░░░░░░░░░░░ (loading)              │
│                                         │
│ Section 3 (loaded — real content)       │
└─────────────────────────────────────────┘
```

**Rules:**
- Show what you have immediately; skeleton what's pending
- Never show partial data without indicating more is coming
- If critical data fails, show section-level error (don't break the whole page)

### Partial Errors

When some sections succeeded but others failed:

```
┌─────────────────────────────────────────┐
│ [Working Section]                       │
│ Content that loaded successfully        │
├─────────────────────────────────────────┤
│ ⚠ Unable to load activity  [ Retry ]    │
├─────────────────────────────────────────┤
│ [Another Working Section]               │
│ More content that loaded fine           │
└─────────────────────────────────────────┘
```

---

## 6. Connection / Integration States

Specific to documentation platforms that connect external sources.

### Source Connection States

| State | Visual | Description |
|-------|--------|-------------|
| Not connected | Empty state with "Add" CTA | Tool logos + invitation |
| Connecting | Spinner + "Connecting to Figma…" | Indeterminate progress |
| Connected | Green badge "Connected" + source info | Shows last sync time |
| Sync in progress | Spinning sync icon + "Syncing…" | Shows progress if possible |
| Sync failed | Red badge "Sync failed" + retry | Error message + action |
| Out of date | Amber badge "Update available" | Shows version difference |

### Package Version States (Adoption)

| State | Badge Color | Label |
|-------|-------------|-------|
| Up to date | `success.light` bg, `success.dark` text | "Up to date" |
| Minor update available | `warning.light` bg, `warning.dark` text | "Update available" |
| Out of date (major) | `error.light` bg, `error.dark` text | "Out of date" |
| Not using package | `secondary.100` bg, `secondary.500` text | "Not installed" |

---

## State Transition Rules

### Loading → Success

```
Skeleton → Fade to content (200ms ease-out)
Spinner → Replace with content (immediate)
Progress → Show completion state, then hide (500ms delay)
```

### Loading → Error

```
Skeleton → Fade to error state (200ms ease-out)
Spinner → Replace with inline error (immediate)
Progress → Show failure state with retry button
```

### Error → Retry → Loading

```
Error state → User clicks retry → Immediate transition to loading
Loading shows in same position as error (no layout shift)
```

---

## Checklist

When implementing any feature, verify:

- [ ] Loading state exists for all async operations
- [ ] Empty state designed with icon + headline + description + CTA
- [ ] Error states exist at appropriate levels (field, section, page)
- [ ] Success feedback exists for user actions
- [ ] Partial loading/error doesn't break the full page
- [ ] States transition smoothly (200ms minimum display, no flashing)
- [ ] Error messages are warm, actionable, and non-technical
- [ ] Empty states guide toward the first meaningful action
- [ ] Connection states cover the full lifecycle (not connected → syncing → synced → error)
- [ ] Toast notifications auto-dismiss for success, persist for errors
