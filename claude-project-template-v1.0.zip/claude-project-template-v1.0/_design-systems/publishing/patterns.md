# Publishing Design System — Layout & Interaction Patterns

> **Authority:** This file defines layout and interaction patterns for the Publishing design system.
> Navigation STRUCTURE (what sections exist) belongs in `docs/2-product.md`.
> This file covers HOW navigation and layouts BEHAVE.

---

## 1. Page Layout

### Three-Column Documentation Shell

The defining layout pattern — sidebar navigation, main content, and a right-side table of contents.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           Top Bar (56px)                                │
├──────────┬─────────────────────────────────────────────┬───────────────┤
│          │                                             │               │
│ Sidebar  │              Main Content                   │  Table of     │
│ (240px)  │              (flex: 1)                      │  Contents     │
│          │              max-width: 720px               │  (~200px)     │
│          │                                             │               │
│ #F3F2EF  │              #FFFFFF                        │  #FFFFFF      │
│          │                                             │               │
│          │                                             │               │
└──────────┴─────────────────────────────────────────────┴───────────────┘
```

### Dimensions

| Element | Desktop (≥1280px) | Large Tablet (1024–1279px) | Tablet (768–1023px) | Mobile (<768px) |
|---------|-------------------|---------------------------|---------------------|-----------------|
| Top bar height | 56px | 56px | 56px | 48px |
| Sidebar width | 240px | 200px | 0 (overlay) | 0 (overlay) |
| Content max-width | 720px | 720px | 100% | 100% |
| Content padding | 48px L/R, 32px T | 32px | 24px | 16px |
| ToC width | 200px | 0 (hidden) | 0 (hidden) | 0 (hidden) |

### Key Difference from Professional

The Professional preset uses a two-zone layout (sidebar + content) optimized for data-dense interfaces. The Publishing preset uses a three-column layout optimized for reading. Content has a narrower max-width for readability, and the right column provides in-page navigation.

### Responsive Behavior

| Breakpoint | Sidebar | ToC | Content |
|------------|---------|-----|---------|
| Desktop (≥1280px) | Expanded (240px) | Visible (200px) | Centered, max-width 720px |
| Large tablet (1024–1279px) | Condensed (200px) | Hidden | Fills remaining space |
| Tablet (768–1023px) | Hidden (hamburger overlay) | Hidden | Full width, 24px padding |
| Mobile (<768px) | Hidden (hamburger overlay) | Hidden | Full width, 16px padding |

---

## 2. Page Types

### Dashboard Page

The personalized home page with last-viewed items, metrics, and recommendations.

```
┌─────────────────────────────────────────────────────────────────┐
│ Greeting: "Good morning, [Name]"                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ LAST VIEWED                                                     │
│ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐             │
│ │  Page Card   │ │  Page Card   │ │  Page Card   │             │
│ │  (bordered)   │ │  (bordered)   │ │  (bordered)   │             │
│ └──────────────┘ └──────────────┘ └──────────────┘             │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│ METRICS                                                         │
│ ┌─────────────────────────────────────┐                         │
│ │ Missing blocks: 3 pages without     │                         │
│ │ design or code blocks               │                         │
│ └─────────────────────────────────────┘                         │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│ RECOMMENDATIONS                                                 │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ Suggestion 1 — actionable description            [Action]  │ │
│ │ Suggestion 2 — actionable description            [Action]  │ │
│ └─────────────────────────────────────────────────────────────┘ │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│ LEARNING RESOURCES                                              │
│ ┌────────────────────┐ ┌────────────────────┐                   │
│ │  Accent Card 1     │ │  Accent Card 2     │                   │
│ │  (primary.50 tint) │ │  (primary.50 tint) │                   │
│ └────────────────────┘ └────────────────────┘                   │
└─────────────────────────────────────────────────────────────────┘
```

### Documentation Page (Content)

The primary authoring/reading surface. Uses three-column layout.

```
┌─────────────────────────────────────────────────────────────────┐
│ Category Label (uppercase, muted)                   ToC:        │
│ Page Title (large)  ● Status tag                    Section 1   │
│ Description (optional, muted)                       Section 2   │
│ Created/Updated metadata                            Section 3   │
├─────────────────────────────────────────────────────────────────┤
│ [Tab 1] [Tab 2] [Tab 3] [+ Add tab]                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Section heading                                                 │
│                                                                 │
│ Content block (text, image, embed, code, Do/Don't, etc.)        │
│                                                                 │
│ Content block                                                   │
│                                                                 │
│ Content block                                                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Cover Page

The landing/home page with hero layout and shortcut tiles.

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│            [Cover style selector]                               │
│                                                                 │
│            Styleguide Title (display size)                       │
│            "Styleguide updated 4 minutes ago"                   │
│            Description placeholder                              │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐    │
│  │   🔲 Design    │  │   </> Code     │  │  + Add shortcut│    │
│  │   Link to      │  │   Link to      │  │                │    │
│  │   internal pg  │  │   internal pg  │  │                │    │
│  └────────────────┘  └────────────────┘  └────────────────┘    │
│                                                                 │
│  [+ Add tab]                                                    │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Get started                                                    │
│  ☐ Click anywhere and just start typing.                        │
│  ☐ Hit / to see all the types of contents you can add.          │
│  ☐ Add design styles and components from your design files.     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Resources Page

Grid-based presentation of connected external sources.

```
┌─────────────────────────────────────────────────────────────────┐
│ RESOURCES                                                       │
│ Page Title (e.g., "Design tokens")  ● Status tag                │
│ Description                                                     │
├─────────────────────────────────────────────────────────────────┤
│ [Tab 1] [Tab 2] [Tab 3]                                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Section heading                                                 │
│ Introductory paragraph                                          │
│                                                                 │
│ ┌─────────────────────────────┐                                 │
│ │ Diagram / illustration      │                                 │
│ │ (e.g., token flow diagram)  │                                 │
│ │ Caption below               │                                 │
│ └─────────────────────────────┘                                 │
│                                                                 │
│ Code block (JSON token example)                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Navigation Patterns

### Top Bar

| Element | Position | Behavior |
|---------|----------|----------|
| Back arrow | Left | Returns to styleguide list |
| Styleguide name + "Updated X ago" | Center-left | Informational |
| "+ Add navigation" | Right | Adds top-level navigation |
| Notification bell | Right | Alerts |
| Preview (eye icon) | Right | View as published |
| More options (⋯) | Right | Settings dropdown |
| Share button | Right | Primary CTA — blue filled button |
| Avatar | Far right | User menu |

### Sidebar Navigation

See Components § Navigation Sidebar for visual specification.

**Interaction rules:**
- Category groups are collapsible (chevron toggle)
- Active page has highlighted background + left accent bar
- Drag to reorder pages within a category
- Right-click for context menu (rename, delete, duplicate)
- Double-click to inline rename

### Page-Internal Navigation

- **Tabs** for organizing content within a page (primary pattern)
- **Table of Contents** (right sidebar) for scrolling within a tab
- **Shortcut tiles** for cross-linking between pages

---

## 4. Content Block Patterns

The editor supports a variety of content blocks. These are the patterns for how blocks compose into pages.

### Block Spacing

| Between blocks | Spacing |
|----------------|---------|
| Heading → content | 16px (spacing.4) |
| Content → content | 24px (spacing.6) |
| Content → heading | 40px (spacing.10) |
| Section → section | 48px (spacing.12) |

### Block Types (Ordered by frequency of use)

1. **Rich text** — Paragraphs with inline formatting
2. **Headings** — H1 (page title, auto), H2 (sections), H3 (subsections)
3. **Code blocks** — Syntax highlighted, copyable
4. **Images** — With optional caption, layout options
5. **Design file sync** — Figma/Sketch component preview
6. **Do/Don't blocks** — Side-by-side usage guidance
7. **Tables** — Data with optional Sass variable references
8. **Embeds** — YouTube, Figma prototype, external URLs
9. **File downloads** — Hosted assets with metadata
10. **Shortcut tiles** — Card-based internal/external links

### Slash Command Pattern

Typing `/` reveals a block picker dropdown — similar to Notion's slash command.

| Property | Value |
|----------|-------|
| Trigger | `/` at start of new line |
| Dropdown width | 320px |
| Max visible items | 8 (scroll for more) |
| Search | Fuzzy filter as you type |
| Categories | Basic, Media, Embed, Advanced |

---

## 5. Interaction Patterns

### Search

| Property | Value |
|----------|-------|
| Position | Top of sidebar |
| Style | Input with search icon, full sidebar width |
| Behavior | Fuzzy search across page names |
| Results | Inline dropdown below search field |

### Form Submission

Same as Professional pattern — validate, disable, submit, feedback.

### Confirmation Pattern

Same as Professional — dialog with clear consequences described.

---

## 6. Grid System

### Container

| Property | Value |
|----------|-------|
| Content max-width | 720px (narrower than Professional's 1280px) |
| Page max-width | No max (fills between sidebar and ToC) |
| Padding | 48px horizontal (desktop) |
| Centering | Left-aligned within content area (not centered) |

### Content Width Philosophy

The 720px content width is intentional — optimized for reading rather than data display. Long lines of text (>80 characters) reduce readability. The narrower column keeps prose comfortable.

For data-heavy content (tables, charts), content can break out to full available width between sidebar and ToC.

---

## 7. Spacing Patterns

### Page Spacing

| Element | Spacing |
|---------|---------|
| Top bar to page content | 32px |
| Category label to page title | 4px |
| Page title to description | 8px |
| Description to metadata | 4px |
| Metadata to tab row | 24px |
| Tab row to content | 32px |
| Between page sections | 48px |
| Between content blocks | 24px |

### Card Grid Spacing

| Element | Spacing |
|---------|---------|
| Between cards (horizontal) | 24px |
| Between cards (vertical) | 24px |
| Card to section heading | 16px |

---

## 8. Data Visualization Patterns

### Chart Styles

| Property | Value |
|----------|-------|
| Line charts | 2px stroke, primary blue + secondary colors |
| Chart background | White (no grid background) |
| Grid lines | `border.subtle`, horizontal only |
| Axis labels | `typography.xs`, muted |
| Legend | Below chart, inline, dot + label |
| Tooltip | White card with border, shadow.sm (floating exception) |

### Table Styles

| Property | Value |
|----------|-------|
| Header background | `secondary.50` (#FAFAF9) |
| Header text | `typography.sm`, semibold, `text.secondary` |
| Row background | White, alternating `secondary.50` |
| Cell padding | 12px vertical, 16px horizontal |
| Border | Bottom border only (`border.default`) |
| Hover | Full row `secondary.50` background |

---

## 9. Responsive Patterns

### Content Reflow

| Element | Desktop | Tablet | Mobile |
|---------|---------|--------|--------|
| Do/Don't blocks | Side by side | Side by side | Stacked |
| Shortcut tiles | 3 across | 2 across | Stacked |
| Dashboard cards | 3–4 across | 2 across | Stacked |
| File download cards | 2 across | 2 across | Stacked |
| Tab row | Scrollable | Scrollable | Scrollable |
