# Professional Design System — Layout Patterns

> Layout and interaction patterns for professional SaaS applications.

---

## Core Layout: Two-Panel App

The Professional design system uses a two-panel app layout optimized for daily professional use.

```
┌─────────────────────────────────────────────────────────────┐
│ Header (56px)                                      [User] [?]│
├─────────────┬───────────────────────────────────────────────┤
│             │                                               │
│  Sidebar    │  Main Content                                 │
│  (240px)    │  (flex)                                       │
│             │                                               │
│  - Nav      │  ┌─────────────────────────────────────────┐  │
│  - Quick    │  │ Page Header                             │  │
│    actions  │  │ [Breadcrumb] / [Title] / [Actions]      │  │
│             │  ├─────────────────────────────────────────┤  │
│             │  │                                         │  │
│             │  │ Content Area                            │  │
│             │  │                                         │  │
│             │  └─────────────────────────────────────────┘  │
│             │                                               │
└─────────────┴───────────────────────────────────────────────┘
```

### Key Dimensions

| Element | Width/Height | Notes |
|---------|--------------|-------|
| Header | 56px height | Fixed, always visible |
| Sidebar collapsed | 56px | Icon-only mode |
| Sidebar expanded | 240px | Full navigation |
| Content max-width | 1280px | Centered in larger viewports |
| Page padding | 24px | Desktop; 16px mobile |

---

## Navigation Patterns

### Primary Navigation (Sidebar)

- Vertical list in sidebar
- Collapsible to icon-only
- Hover reveals labels when collapsed
- Active state: background highlight + bold text
- Max 2 levels of nesting

### Secondary Navigation (Tabs)

- Route-based (URL changes)
- Horizontal tabs below page header
- Max 7 tabs; overflow to dropdown
- Active tab: bottom border indicator

### Tertiary Navigation (Breadcrumbs)

- Shows hierarchy, not history
- Max 4 visible items
- Current page not clickable
- Truncate middle items when needed

---

## Data Display Patterns

### Table-First

Tables are the primary data display pattern for collections.

| Pattern | Use When |
|---------|----------|
| Table | >5 items, multiple attributes per item |
| Card grid | Visual items (images, rich content) |
| List | Simple items, single primary attribute |

### Table Features

- Sticky header on scroll
- Row hover highlight
- Selection via checkbox column
- Bulk actions in header when selected
- Sort by single column (click header)
- Virtualization for 100+ rows

### Card Grid

- 2-4 columns depending on viewport
- Consistent card heights per row
- Interactive variant: hover shadow lift
- Click navigates to detail

---

## Page Patterns

### Overview Page

Summarizes status across multiple items. Must answer:

1. **State** — What's the current situation?
2. **Action** — What can I do right now?
3. **Attention** — Where should focus go?
4. **Risk** — What's blocking or at risk?
5. **Consequence** — What happens if I do nothing?

### Detail Page

Shows single item in depth.

```
┌─────────────────────────────────────────┐
│ [← Back]  Item Title           [Actions]│
├─────────────────────────────────────────┤
│ [Tabs: Overview | Details | Activity]   │
├─────────────────────────────────────────┤
│                                         │
│ Content based on active tab             │
│                                         │
└─────────────────────────────────────────┘
```

### Settings Page

Grouped form sections with clear hierarchy.

```
┌─────────────────────────────────────────┐
│ Settings                                │
├─────────────────────────────────────────┤
│ [Sidebar: Categories]  │  Form Section  │
│                        │                │
│   General             │  Section Title │
│   Notifications       │  [Field]       │
│   Integrations        │  [Field]       │
│   Billing             │                │
│                        │  [Save]        │
└─────────────────────────────────────────┘
```

---

## Interaction Patterns

### Hover States

- Background color change (subtle darkening)
- Shadow lift on interactive cards
- Border color change on inputs
- Cursor change to pointer

### Focus States

- Visible focus ring (2px brand blue)
- White offset for contrast
- Never remove focus indicator

### Selection States

- Checkbox for multi-select
- Background tint for selected rows
- Bulk action bar appears when selection exists

### Feedback Patterns

| Feedback Type | Pattern |
|---------------|---------|
| Success | Toast (bottom-right, auto-dismiss) |
| Error | Inline (near source) + Toast if page-level |
| Loading | Skeleton for known layout, spinner for unknown |
| Progress | Linear bar for file uploads, steps for workflows |

---

## Responsive Behavior

### Breakpoints

| Breakpoint | Width | Behavior |
|------------|-------|----------|
| Mobile | <768px | Sidebar hidden, hamburger menu |
| Tablet | 768-1024px | Sidebar collapsed by default |
| Desktop | >1024px | Sidebar expanded by default |

### Mobile Adaptations

- Sidebar becomes overlay drawer
- Tables become card lists
- Horizontal tabs become dropdown select
- Actions move to bottom sheet or action menu

---

## Anti-Patterns

| Pattern | Problem | Fix |
|---------|---------|-----|
| Nested navigation >2 levels | Disorientation | Flatten or use breadcrumbs |
| Cards for data tables | Inefficient scanning | Use tables for tabular data |
| Modal for primary content | Blocks context | Use full page or drawer |
| Fixed header + fixed footer | Reduced content area | Choose one fixed element |
| Sidebar for settings | Inconsistent | Settings get their own page |

---

## Related Files

- `_model/patterns/overview.md` — Overview page deep dive
- `_model/patterns/data-display.md` — Table and card patterns
- `_model/patterns/forms.md` — Form layout patterns
- `_model/patterns/navigation.md` — Navigation patterns
