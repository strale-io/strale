# Professional Design System — UI States

> How to handle loading, empty, and error states.

---

## The Law

> **LAW-004:** Every screen handles loading, empty, and error states.

---

## Loading States

### Skeleton Loading
- Show within 100ms
- Match final layout exactly
- Fade content in when ready
- Use subtle pulse animation

### Spinner Loading
- Show after 300ms (longer delay)
- Use for indeterminate duration
- Center in containing area
- Brand blue color

---

## Empty States

### First-Time Empty
```
[Illustration - optional]
No {entities} yet
{Explanation of what goes here}
[Create First]
```

### Filtered Empty
```
No matching results
Try adjusting your filters.
[Clear Filters]
```

### Empty State Requirements
- Always include title + action
- Illustration optional but helpful
- Tone: Helpful, not apologetic
- Action should resolve the empty state

---

## Error States

### Inline Error
- Below field, not above
- Red text, red border on input
- Explain how to fix
- Don't just say "Invalid"

### Section Error
```
Couldn't load {section}
[Try Again]
```

### Page Error
```
Something went wrong
We couldn't load this page.
[Try Again] [Go Home]
```

### Error Display Rules
- Show near the source of error
- Provide recovery action
- Don't blame the user
- Include technical details in collapsed section (for support)

---

## State Transitions

| From | To | Transition |
|------|-----|------------|
| Skeleton | Content | Fade (150ms) |
| Skeleton | Empty | Fade (150ms) |
| Loading | Error | Replace (150ms) |
| Content | Refresh | Keep content, overlay indicator |

**Rule:** Never flash loading states. If content loads in <100ms, don't show skeleton.

---

## State Disambiguation

Avoid ambiguous aggregate states like "pending" or "incomplete."

| Ambiguous | Disambiguated |
|-----------|---------------|
| Pending | Not started / In progress / Needs review / Blocked |
| Incomplete | Not started / Partially complete / Blocked |
| In progress | Active / Paused / Waiting on dependency |
| Done | Completed / Approved / Shipped |

**Rule:** If a state could mean multiple things, split it.

Users need to know *why* something isn't done, not just *that* it isn't.

### State Granularity by Context

| Context | Granularity |
|---------|-------------|
| Summary/header | Coarse (3-4 states max) |
| List/table | Medium (show actionable distinctions) |
| Detail view | Fine (full state + history) |

The same entity may show different state granularity depending on where it appears.

---

## ARIA State Patterns

For accessibility, UI states must map to appropriate ARIA attributes.

### Loading States

| UI State | ARIA Pattern |
|----------|--------------|
| Content loading | `aria-busy="true"` on container |
| Skeleton visible | `aria-hidden="true"` on skeleton, live region for content |
| Spinner loading | `role="status"` with `aria-label="Loading"` |
| Progress bar | `role="progressbar"` with `aria-valuenow`, `aria-valuemin`, `aria-valuemax` |

### Empty States

| UI State | ARIA Pattern |
|----------|--------------|
| Empty collection | `aria-label` on container describing empty state |
| Filtered empty | Live region announces "No results" |

### Error States

| UI State | ARIA Pattern |
|----------|--------------|
| Inline field error | `aria-invalid="true"`, `aria-describedby` pointing to error message |
| Section error | `role="alert"` on error container |
| Page error | `role="alert"` or focus management to error |

### Interactive States

| UI State | ARIA Pattern |
|----------|--------------|
| Selected | `aria-selected="true"` |
| Expanded | `aria-expanded="true/false"` |
| Pressed (toggle) | `aria-pressed="true/false"` |
| Checked | `aria-checked="true/false/mixed"` |
| Disabled | `aria-disabled="true"` (with explanation) |
| Current (navigation) | `aria-current="page/step/location"` |

### Live Regions

| Content Type | ARIA Live Setting |
|--------------|-------------------|
| Error messages | `aria-live="assertive"` |
| Status updates | `aria-live="polite"` |
| Progress updates | `aria-live="polite"` with `aria-atomic="true"` |
| Toast notifications | `role="status"` or `role="alert"` |

### Focus Management

| State Change | Focus Behavior |
|--------------|----------------|
| Modal opens | Focus moves to modal (first focusable or heading) |
| Modal closes | Focus returns to trigger element |
| Content loads | Focus stays unless user navigated |
| Error occurs | Focus moves to error (for critical errors) |
| Item deleted | Focus moves to next item or parent |

---

## Related Invariants

- UI-002: Focus is never lost
- XP-004: Tooltips are accessible
- A11Y-001: Focus indicators visible in all color schemes
