# Expectation Invention Loop (EIL) Artifacts

> Store EIL artifacts here when introducing new capabilities.

---

## When to Create an EIL Artifact

Create an artifact when introducing:
- New data (something now tracked/saved/remembered)
- New state (something users can now see)
- New affordances (something users can now do)

**Do NOT create** for:
- New surfaces for existing capabilities
- Cosmetic changes
- Bug fixes

---

## Artifact Format

Use the following template:

```yaml
capability: "[name of the capability]"
date: "[YYYY-MM-DD]"
trigger: "[what made this a new capability — new data/state/affordance?]"

immediate_expectations:
  - expectation: "[what users now assume they can see]"
    classification: "build_now | defer | prevent"
    rationale: "[why this classification]"
  - expectation: "[what users now assume they can do]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[what users assume is tracked/saved]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"

secondary_expectations:
  - expectation: "[history — can I see previous uses?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[undo — can I reverse this?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[explanation — can I understand what happened?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[comparison — can I compare instances?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[consistency — does this work the same elsewhere?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"

trust_expectations:
  - expectation: "[status indicator — does user know the state?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[provenance — does user know where this came from?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[constraints — does user know the limits?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[error states — does user know what can go wrong?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"
  - expectation: "[definitions — does user know what this means?]"
    classification: "build_now | defer | prevent"
    rationale: "[why]"

non_goals:
  - assumption: "[what user might wrongly assume]"
    prevention: "[how we prevent this assumption — UI copy, constraints, absence]"
  - assumption: "[another false assumption to prevent]"
    prevention: "[prevention method]"

decision_summary:
  build_now:
    - "[expectation 1]"
    - "[expectation 2]"
  defer:
    - expectation: "[deferred expectation]"
      planned_phase: "[when it will be addressed]"
      reasoning: "[why deferred]"
  prevent:
    - assumption: "[prevented assumption]"
      mechanism: "[how prevented in UI]"
```

---

## Naming Convention

`[capability-name].yaml`

Examples:
- `time-tracking.yaml`
- `bulk-export.yaml`
- `ai-suggestions.yaml`

---

## Integration

EIL outputs feed directly into Pre-Build:
- `build_now` items → become Expected features in Feature Classification
- `defer` items → pre-populate Expectation Debt (UE-007)
- `prevent` items → inform Restraint Gate + become Prevented features

---

## Invariants

| ID | Invariant |
|----|-----------|
| EIL-001 | New capabilities run Expectation Invention Loop |
| EIL-002 | Prevented assumptions are documented |
| EIL-003 | Secondary expectations are examined |
| EIL-004 | Trust expectations are examined |
| EIL-005 | EIL outputs feed Pre-Build |

**New capability without EIL artifact = P0.**
