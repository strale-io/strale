# Decision Registry

> System memory that compounds velocity and prevents re-litigation.

---

## Enforcement (Non-Negotiable)

This registry is a **gate, not a log**.

Any change that:
- Loosens a constraint
- Adds a variant
- Introduces an exception
- Expands surface area

**must have a corresponding Decision Registry entry before implementation.**

If a change alters system behavior without a registry entry, **the change is invalid**.

---

## Amendment Rule: Tighten First

Before proposing any change that adds flexibility:

1. **First attempt to solve by tightening constraints**
2. Document why tightening was insufficient
3. Only then propose loosening

Changes that add flexibility without demonstrating tightening was tried first are invalid.

This rule exists because Tier-1 systems improve by removing degrees of freedom, not adding them.

---

## Purpose

Every significant decision is logged here. This prevents:
- Re-litigating settled ground
- Contradicting past reasoning
- Losing institutional knowledge
- Long-term entropy (drift)

---

## Required Fields

Every entry must include:

| Field | Required | Description |
|-------|----------|-------------|
| `id` | Yes | Unique identifier (DEC-001, DEC-002, etc.) |
| `decision` | Yes | Brief statement of what was decided |
| `date` | Yes | When decided (YYYY-MM-DD) |
| `owner` | Yes | Who owns this decision |
| `context` | Yes | Why this came up |
| `chosen` | Yes | What we decided |
| `rejected` | Yes | Options not chosen and why |
| `stability` | Yes | `hard` / `soft` / `revisitable` |
| `evidence` | No | Link to PR, test, exemplar proving it works |
| `review_by` | No | Date to revisit (for `revisitable` decisions) |
| `references` | No | Related laws, rules, or other decisions |
| `promote` | Yes | `candidate` / `local` / `uncertain` — is this learning generic? |

---

## Stability Levels

| Level | Meaning | Can Change When |
|-------|---------|-----------------|
| `hard` | Foundational, load-bearing | Major version only, with migration |
| `soft` | Strong preference | With documented justification |
| `revisitable` | Open to change | New evidence, set `review_by` date |

---

## Promote Classification

Every decision must be classified for upstream propagation potential.

| Value | Meaning | Action |
|-------|---------|--------|
| `candidate` | Believed to be generic — would help any new project | Claude creates Learning Queue entry in Notion |
| `local` | Project-specific — not applicable to other projects | No action |
| `uncertain` | Needs more evidence before deciding | Revisit during reconciliation |

**Test:** Would this decision help a brand new project starting from the template?
If yes → `candidate`. If it references project-specific entities → `local`.

See `EVOLUTION.md` for the full upstream propagation protocol.

---

## Entry Format

```yaml
- id: DEC-001
  decision: "Brief statement"
  date: 2025-01-31
  owner: "@handle or name"
  context: "Why this came up"
  chosen: "What we decided"
  rejected:
    - "Option A — why not"
    - "Option B — why not"
  stability: hard | soft | revisitable
  promote: candidate | local | uncertain
  promote_rationale: "Why this is/isn't generic"  # Optional, for candidates
  evidence: "link to PR, test, or exemplar"
  review_by: 2025-06-01  # Optional, for revisitable
  references: [LAW-001, DEC-002]  # Optional
```

---

## Decisions

<!-- Add decisions below this line -->

- id: DEC-001
  decision: "Split FRAMEWORK.md into principles (FRAMEWORK.md) and operations (PRE-BUILD.md)"
  date: 2026-02-05
  owner: "@system"
  context: "FRAMEWORK.md exceeded 1200 lines. File size was impacting readability and maintenance. Needed clear separation between 'what to think' (principles) and 'how to execute' (operations)."
  chosen: "Create PRE-BUILD.md for operational protocols (Pre-Build Flow, templates, gates, change management). Keep FRAMEWORK.md for principles (Feature Classification, EIL, Invariants, Stickiness Assessment, User Intelligence Graph, Momentum)."
  rejected:
    - "Keep everything in one file — rejected because file was too large and mixing concerns"
    - "Split by topic (e.g., separate files for each major section) — rejected because it would fragment related content and increase navigation overhead"
  stability: hard
  evidence: "v12.10.0 structural split implementation"
  references: [LAW-012]

- id: DEC-003
  decision: "Added CONSTRAINTS_INDEX.yaml as a reference-only constraint locator"
  date: 2025-02-05
  owner: "system"
  context: "AI agents cannot reliably hold 21k+ lines in context. Need a lightweight way to identify which files contain relevant constraints for a given task."
  chosen: "Reference-only YAML index with id/file/topic triplets — no rule restatements"
  rejected:
    - "Embedding constraints in RUNBOOK.md — would bloat the entry point"
    - "Reducing system size — loses valuable guidance"
  stability: soft
  references: [LAW-001]

- id: DEC-004
  decision: "Tightened 6 quality checks from boolean (yes/no) to evidence-based (show me)"
  date: 2025-02-05
  owner: "system"
  context: "Red team simulation showed lazy agent could pass all gates with template compliance. Converted self-assessed checks to fill-in-the-blank accountability."
  chosen: "Transform yes/no self-assessment into named-evidence requirements across 6 mechanisms"
  rejected:
    - "Adding new verification gates — violates LAW-009 (tighten before adding)"
    - "External review requirement — increases process overhead without addressing root cause"
  stability: locked
  references: [LAW-009]
  changes:
    - "QUALITY_PROTOCOL.md: Falsifiable assumptions in Gate 0"
    - "RUBRIC.md: Named focal point in Visual Craft Score 4"
    - "LOOP.md: Action field in Surprise Test"
    - "QUALITY_PROTOCOL.md: Named comparator in Agency Test"
    - "QUALITY_PROTOCOL.md: Copy/avoid extraction in Peer Context"
    - "PROMPT.md: Generic CTA copy classified as P1"

- id: DEC-005
  decision: "Added degraded mode protocols for stress conditions"
  date: 2025-02-05
  owner: "system"
  context: "Stress test revealed system deadlocks under simultaneous time pressure, late requirements, and incomplete specs. All gates were binary pass/fail with no graceful degradation."
  chosen: "Add EIL-Lite, Single-Cycle Mode, Sanctioned Expansion, and Hard Stop criteria — tracked debt instead of hidden shortcuts"
  rejected:
    - "Removing gates under stress — weakens guarantees without accountability"
    - "Adding more buffer time — doesn't address fundamental binary pass/fail problem"
  stability: locked
  references: [LAW-009, LAW-010, LAW-012]
  changes:
    - "QUALITY_PROTOCOL.md: Gate 0 Degraded Mode with EIL-Lite"
    - "QUALITY_PROTOCOL.md: Sanctioned Expansion Exception in Gate 4"
    - "QUALITY_PROTOCOL.md: Hard Stop Criteria"
    - "LOOP.md: Single-Cycle Mode protocol"

- id: DEC-006
  decision: "Declared stability freeze on foundational structures"
  date: 2025-02-05
  owner: "system"
  context: "System has reached structural maturity at 13 laws, 8 gates, 5-phase critique loop, and 5 meta-rules. Continued structural churn prevents compounding. Freezing foundations while keeping intelligence layer open for evolution."
  chosen: "Freeze laws, gates, loop phases, Three Absolutes, and meta-rules against structural change. Allow internal refinement (tightening checks, adding degraded modes, improving definitions)."
  rejected:
    - "Continuing structural evolution — prevents agents from building stable mental models"
    - "Freezing everything — blocks legitimate quality improvements within existing structures"
  stability: locked
  references: [GOVERNANCE.md]
  changes:
    - "GOVERNANCE.md: Added Stability Declaration with frozen structures table, amendment process, and open evolution list"

- id: DEC-007
  decision: "Cross-surface coherence enforced via gate, not critique dimension"
  date: 2026-02-05
  owner: "Petter"
  context: "Stress test #6 revealed that surfaces can individually pass critique while contradicting each other. No enforcement mechanism exists for cross-surface consistency."
  chosen: "New quality gate (Gate 8) that audits all surfaces together before release, plus lightweight awareness flags in per-screen critique"
  rejected:
    - "New critique dimension — cross-surface coherence is a relationship between surfaces, not a property of one surface. Adding it to per-screen critique fights the design of the critique loop and requires loading sibling screens that may not exist yet."
    - "Both gate and dimension — would create redundancy without proportional benefit. The gate catches everything; awareness flags in critique provide early warning."
  stability: hard
  references: [LAW-005, LAW-001]
  changes:
    - "QUALITY_PROTOCOL.md: Added Gate 8: Cross-Surface Coherence"
    - "_invariants/REGISTRY.md: Added CS-001 to CS-005"
    - "PROMPT.md: Added P1 awareness flags for cross-surface issues"
    - "_quality/LEARNING.md: New file with predictive patterns"
    - "QUALITY_PROTOCOL.md: Added Completeness Target to Gate 0"
    - "LOOP.md: Added Completeness Target to critique card"

- id: DEC-008
  decision: "Add generic Workflow Protocol to starter kit as .claude/PROTOCOL.md"
  date: 2026-02-05
  owner: "Petter"
  context: |
    The Unified Workflow System v8 defines a complete operational protocol
    for multi-actor development (human + AI chat + AI code). It governs
    session management, decision tracking, handoff between actors,
    degraded mode recovery, naming conventions, authority thresholds,
    and audit/integrity mechanisms.

    Currently v8 exists as a standalone document outside the starter kit.
    This creates three problems:
    1. Claude Code (which reads from the repo, not Claude.ai project
       knowledge) only gets a condensed CLAUDE.md checklist — it has
       no access to the full protocol definitions, rationale, or
       worked examples.
    2. Every new project requires manually re-uploading v8 to project
       knowledge, with no version control or governance.
    3. v8's migration plan is a passive 21-step checklist with no actor
       assignments. Nobody drives the setup, nothing enforces
       prerequisites, and there is no verification that infrastructure
       is correctly configured before work begins.

  chosen: |
    Add the protocol as `.claude/PROTOCOL.md` — a single, self-contained
    file in the `.claude/` operational folder. The document will be
    genericized (all project-specific references replaced with __FILL__
    and __SELECT__ placeholders) to comply with "Generic Over Specific."

    Key changes:
    - Workflow protocol: outside starter kit → `.claude/PROTOCOL.md`
      (version-controlled, governance-protected)
    - Initialization: passive 21-step checklist → Bootstrap Mode
      (Claude Code drives the interactive setup)
    - Human role in setup: drive every step manually → copy files,
      answer questions, follow instructions
    - Claude Code role in setup: none → active driver (interviews,
      instructs, gates, verifies)
    - NOTION.md: defines workflow databases → references PROTOCOL.md
      for database structure, retains boundary rules
    - REGISTRY.md: no entries → DEC-008 + dual ID scheme documentation
    - Delegated decisions: not addressed → Bootstrap Delegation Rule

    Bootstrap Mode is an interactive, Claude Code-driven setup process.
    Claude Code checks for `.claude/PROJECT_INITIALIZED` marker. If absent,
    Bootstrap Mode activates. Normal sessions are blocked until complete.

    Bootstrap Procedure:
    Step 1 — Product Identity: Claude Code asks questions, human answers
    Step 2 — External Tool Setup: Claude Code instructs, human executes
    Step 3 — Repo Initialization: Claude Code creates files and commits
    Step 4 — Verification: Claude Code runs connectivity checks

    Bootstrap Delegation Rule: If the human delegates ("you decide"),
    Claude Code must state the specific choice before writing it.
    Delegation authorizes proceeding without confirmation, but NOT
    silent decisions. All bootstrap decisions are backfilled to the
    Decisions database once it exists.

    PROTOCOL.md becomes authority on workflow database structure.
    NOTION.md retains authority on boundary rules, conflict resolution,
    context loading order, and general Notion guidance.

    Decision Registry Amendment: Product-level decision IDs
    (DEC-YYYYMMDD-A-XXXX) are a parallel ID scheme for product
    decisions tracked in the project management tool. System-level
    decisions continue to use DEC-NNN in REGISTRY.md. Two registries,
    two scopes — no conflict.

  rejected:
    - "Keep v8 as Claude.ai project knowledge only — Problem: Claude
       Code has no access. The condensed CLAUDE.md checklist loses
       rationale, worked examples, detection heuristics, and protocol
       definitions."
    - "Distribute v8 content across existing files (WORKFLOW.md,
       NOTION.md, RUNBOOK.md, REGISTRY.md) — Problem: v8 is heavily
       self-referential. Distributing it breaks cross-references and
       makes version tracking difficult."
    - "Add v8 at repo root as WORKFLOW_PROTOCOL.md — Problem: Root-
       level files are reserved for system-level contracts."
    - "Create a new _workflow/ folder — Problem: Introducing a new
       top-level folder requires its own governance amendment."
    - "Passive 21-step migration checklist — Problem: No actor
       assignments, no enforcement, no verification. The human must
       drive every step manually and nothing catches missed steps."
    - "Silent AI decisions during bootstrap delegation — Problem:
       Even when the human says 'you decide', silent decisions
       violate the audit trail principle. Claude Code must always
       state the choice before writing it."

  stability: hard
  review_by: null
  references:
    - "SYSTEM_CONTRACT.md — Closed World Assumption (preserved)"
    - "SYSTEM_CONTRACT.md — One Home Per Concept (enforced)"
    - "SYSTEM_CONTRACT.md — Generic Over Specific (enforced)"
    - "GOVERNANCE.md — Amendment Rule: Tighten First (this tightens
       operational discipline)"

- id: DEC-009
  decision: "v2.0.0 Structural Expansion — 16 amendments adding enterprise capabilities"
  date: 2026-02-06
  owner: "Petter"
  context: |
    The starter kit had gaps in operational infrastructure that became apparent
    as the system matured. Missing: surface registration, traceability mapping,
    non-functional requirements, automation enablement, failure mode planning,
    user research templates, responsive/i18n guidance, and documentation
    delivery protocols.

    These gaps were identified through systematic analysis and would become
    blockers for enterprise-grade use of the documentation system.

  chosen: |
    Implement all 16 amendments as additive changes:
    - AMD-001: _surfaces/ with REGISTRY.yaml and SPEC_TEMPLATE.md
    - AMD-002: _quality/TRACE.yaml + Gate 4 traceability checks
    - AMD-003: _nfr/ with 4 YAML files + gate references
    - AMD-004: _artifacts/gates/ with template
    - AMD-005: _runs/ with README and template
    - AMD-006: Gate 8 automation guidance
    - AMD-007: _resilience/FAILURE_MODES.md
    - AMD-008: _research/ with 4 template files
    - AMD-009: _ui/RESPONSIVE.md
    - AMD-010: _ui/I18N.md
    - AMD-011: _artifacts/ subdirectories and README
    - AMD-012: _artifacts/DELIVERY.md
    - AMD-013: QUICKREF.md at root
    - AMD-014: MIGRATION_TEMPLATE.md at root
    - AMD-015: Authority boundary in RUNBOOK.md (Option B — RUNBOOK only)
    - AMD-016: Lesson promotion protocol in WORKFLOW.md

    Version reset to v2.0.0 given scope of structural additions.

  rejected:
    - "Incremental additions across multiple minor versions — would fragment
       the coherent structural expansion"
    - "Adding fewer amendments — all 16 address distinct gaps"
    - "AMD-015 Option A (modify SYSTEM_CONTRACT.md) — conflicts with frozen
       file list in implementation instructions"

  stability: hard
  references:
    - "GOVERNANCE.md — Stability Declaration (all amendments comply)"
    - "SYSTEM_CONTRACT.md — Closed World Assumption (new directories explicitly defined)"
    - "SYSTEM_CONTRACT.md — Generic Over Specific (all templates use __FILL__)"

- id: DEC-010
  decision: "Added worked examples using fictional product Beacon"
  date: 2026-02-16
  owner: "Petter"
  context: |
    External review graded template B on developer ergonomics, citing lack of
    concrete examples. Only tokens.example.yaml existed. Ratio of rules to
    examples was heavily skewed toward rules.

  chosen: |
    5-file example set using a B2B SaaS strategic planning tool (Beacon) that
    exercises all archetypes, deep entity hierarchies, state machines, and
    cross-surface coherence. Files cross-reference each other to show system
    integration.

  rejected:
    - "Simple recipe app examples — didn't exercise enough complexity (shallow hierarchy, few archetypes)"
    - "Inline examples within existing docs — would bloat framework files and violate separation of concerns"
    - "Video walkthrough — not searchable, not versionable, different medium than the system itself"

  stability: soft
  promote: candidate
  promote_rationale: "Any project using this template benefits from seeing worked examples. The Beacon product is fictional and generic."
  references: [LAW-003]

- id: DEC-011
  decision: "Added Jobs Architecture module — job hierarchy, traceability, and completeness analysis"
  date: 2026-02-16
  owner: "Petter"
  context: |
    The system had no structured way to express WHY the product exists. Surfaces,
    flows, and gates could all pass without answering the fundamental question:
    "What progress is the user trying to make?" Jobs-to-be-Done thinking was
    implicit but never formalized. This created a gap between strategy and
    execution — features could be well-built but disconnected from user needs.

  chosen: |
    New `_jobs/` directory with three files:
    - FRAMEWORK.md — Job hierarchy, statement format, competing jobs, completeness
      tests, and traceability rules (job-to-surface via flows)
    - REGISTRY.yaml — JOB-NNN entries with core/sub hierarchy, served status,
      and flow mappings
    - TEMPLATES.md — Discovery tools (Core Job Discovery, Sub-Job Decomposition,
      Feature-to-Job Validation, Interview Question Bank, Completeness Audit)

    Integration: soft enforcement via conditional Gate 0/Gate 5 checklists,
    optional jobs field in Surface Registry, job alignment check in critique.
    Traceability is encouraged but not gated — teams adopt jobs gradually.

  rejected:
    - "Embedding jobs in _model/ — jobs are strategy, not truth model. Different authority level and lifecycle."
    - "Hard-gating on job traceability — would block teams that haven't done job discovery yet. Soft enforcement allows gradual adoption."
    - "Flat job list without hierarchy — misses the core insight that one product serves one core job with sub-jobs"

  stability: hard
  promote: candidate
  promote_rationale: "Jobs architecture is product-agnostic. Any project benefits from structured job discovery and traceability."
  references: [LAW-003, LAW-001]

- id: DEC-012
  date: 2026-02-16
  title: "Flow Design Module"
  status: accepted
  context: |
    Jobs describe *what* users want to accomplish. Surfaces describe *where* they do it.
    But the *sequence* — how users move through surfaces to complete a job — was undocumented.
    Flow design bridges jobs and surfaces with purposeful sequences, emotional arcs, and handoff design.

  decision: |
    Create `_flows/` directory with FRAMEWORK.md (flow anatomy, types, emotional arcs, handoff design,
    abandonment strategies), REGISTRY.yaml (FLOW-NNN entries linking jobs to surface sequences),
    QUALITY.md (Flow Gate checklist and critique dimensions), and TEMPLATES.md (flow mapping and review tools).
    Add Flow Gate as conditional gate in QUALITY_PROTOCOL.md. Add Flow Continuity as conditional
    critique dimension. Soft enforcement: flow checks only fire when _flows/REGISTRY.yaml is populated.

  rejected:
    - "Embedding flows in _jobs/ — flows are design artifacts, not strategy. Different lifecycle and authority."
    - "Embedding flows in _surfaces/ — flows span multiple surfaces. They need their own namespace."
    - "Hard-gating on flow registration — would block teams building single-surface products. Soft enforcement allows gradual adoption."

  stability: hard
  promote: candidate
  promote_rationale: "Flow design is product-agnostic. Any multi-surface product benefits from structured flow design and emotional arc planning."
  references: [LAW-003, LAW-001, DEC-011]

- id: DEC-013
  date: 2026-02-16
  title: "Progressive Disclosure Protocol + Capability Extensions Mechanism"
  status: accepted
  context: |
    System has within-surface disclosure (PROGRESSION.md — expand/collapse, tabs) but no strategic
    framework for lifecycle-level disclosure. Products need guidance on what to show at first use vs.
    after 20 uses. Additionally, existing extension model only supports mutually exclusive product-class
    extensions. Cross-cutting capabilities need a new mechanism.

  decision: |
    New capability extension type activated via `capability_extensions` list in manifest.yaml.
    First capability extension: disclosure (3 files in _extensions/disclosure/). Capability extensions
    are additive-only, cross-compatible with all product classes, and multiple can be active simultaneously.
    Loading order: Core → Product Class → Capability Extensions → Project Overrides.

  rejected:
    - "Embed in PROGRESSION.md — rejected because lifecycle strategy is a different concern from within-surface mechanics"
    - "Make disclosure part of core — rejected because not all products need lifecycle-stage thinking (simple single-surface tools don't)"
    - "Use product-class extension mechanism — rejected because disclosure is cross-cutting, not class-specific"

  stability: hard
  promote: candidate
  promote_rationale: "Capability extension mechanism is a schema-level addition enabling Modules 3-5"
  references: [LAW-003, LAW-012]

- id: DEC-014
  date: 2026-02-16
  title: "Collaboration Patterns Extension"
  status: accepted
  context: |
    System has permissions.yaml (access control) but no guidance for the experience of working
    together — presence, commenting, activity feeds, notifications, shared vs. personal state,
    conflict resolution. These patterns separate solo tools from team products.

  decision: |
    New capability extension: collaboration (4 files in _extensions/collaboration/). Covers four
    layers: Awareness, Communication, Coordination, Co-creation. Notifications get their own file
    due to complexity. 19 invariants (CO-001 through CO-019). Collaboration Contract added as
    conditional contract #11. Surfaces declare collaboration_layer.

  rejected:
    - "Embed in core — rejected because not all products are multi-user"
    - "Notifications in core — rejected because notification patterns depend on collaboration context"
    - "Merge with permissions.yaml — rejected because permissions is access control, collaboration is experience design"

  stability: hard
  promote: candidate
  promote_rationale: "Universal for multi-user products — nearly every SaaS needs collaboration patterns"
  references: [LAW-003, LAW-012]

- id: DEC-015
  decision: "Added Intelligence Design Framework as third capability extension"
  date: 2026-02-16
  owner: "@petter"
  context: "System classifies all AI/intelligence features as 'Dangerous' by default. This is too blunt — some intelligence is genuinely valuable (Superhuman pre-loading responses, Linear auto-assigning, Notion suggesting schemas). System needs a framework to distinguish agency-enhancing intelligence from agency-reducing intelligence."
  chosen: "New capability extension: intelligence (4 files in _extensions/intelligence/). Introduces intelligence spectrum (insight → suggestion → smart_default → automation → autonomy), confidence display calibration, suggestion design rules, Intelligence Restraint Gate (10-item checklist). 13 invariants (IN-001 through IN-013). When active, intelligence features go through the gate instead of automatic 'Dangerous' classification — but features that fail the gate are still Dangerous."
  rejected:
    - "Keep all intelligence as 'Dangerous' — rejected because valuable intelligence exists and the system should help design it responsibly"
    - "Embed intelligence rules in core — rejected because not all products have smart features"
    - "Separate extension per intelligence level — rejected because the spectrum is a continuum, not separate concerns"
  stability: hard
  promote: candidate
  promote_rationale: "AI/ML features are increasingly standard in modern products — this framework will be activated frequently"
  references: [LAW-003, LAW-012]

- id: DEC-016
  decision: "Added Cross-Surface Expectation Framework"
  date: 2026-02-16
  owner: "@petter"
  context: "System catches cross-surface inconsistencies reactively (Gate 8, COHERENCE.md) but has no proactive mechanism for preventing mental model breaks during design. New surfaces built in isolation frequently violate expectations users built from existing surfaces."
  chosen: "New file _surfaces/EXPECTATIONS.md. Five propagation rules (entity identity, interaction pattern, hierarchy, vocabulary, capability scope). Mental Model Audit for pre-build. Conflict detection with severity levels. Feeds into existing coherence audit and expectation debt tracking."
  rejected:
    - "New _cognition/ directory — rejected as too abstract; expectation propagation is concrete and actionable"
    - "Embed in COHERENCE.md — rejected because proactive (pre-build) and reactive (audit) serve different moments"
  stability: hard
  promote: candidate
  references: [LAW-003]

- id: DEC-017
  decision: "Added Content Design System"
  date: 2026-02-16
  owner: "@petter"
  context: "System has strong visual and interaction governance but no equivalent for product writing. Error messages, empty states, CTAs, tooltips, confirmations, and notifications all rely on builder judgment. Copy-First Gate exists but no rules for what good copy looks like."
  chosen: "New _content/ directory with SYSTEM.md (rules and voice execution) and PATTERNS.md (reusable writing templates). New critique dimension 'Content Quality' added to scoring. Integration with existing vocabulary governance, voice configuration, and Copy-First Gate."
  rejected:
    - "Embed in _ui/states.md — rejected because writing governance is broader than state-specific text"
    - "Add to _expectations/ — rejected because content rules are execution guidance, not pre-build"
  stability: hard
  promote: candidate
  references: [LAW-003, LAW-001]

- id: DEC-018
  decision: "Added Design Tradeoff Heuristics"
  date: 2026-02-16
  owner: "@petter"
  context: "System has strong rules (laws, invariants) and strong evaluation (critique, gates) but no guidance for resolving design judgment conflicts where multiple valid principles compete. Builders face clarity-vs-density, speed-vs-safety, consistency-vs-context tradeoffs with no framework for resolution."
  chosen: "New file _quality/HEURISTICS.md. Priority Ladder with 4 tiers (12 priorities), 7 common tradeoff resolutions with defaults and exceptions, tradeoff documentation template. Integration with critique (Tradeoff Evaluation section), pre-build (Tradeoff Anticipation), and build intelligence (warning signal)."
  rejected:
    - "Embed in SYSTEM_CONTRACT.md — rejected because tradeoff heuristics are judgment guidance, not structural rules"
    - "Add as laws — rejected because tradeoffs require context-sensitive judgment, not absolute rules"
    - "Per-project only — rejected because the Priority Ladder and common resolutions are universal"
  stability: hard
  promote: candidate
  promote_rationale: "Design tradeoff resolution is universal — every product faces clarity-vs-density, speed-vs-safety, consistency-vs-context tensions"
  references: [LAW-003]

- id: DEC-019
  decision: "Add Build Conductor — central build orchestration"
  date: 2026-02-16
  owner: "Petter"
  context: |
    The build process was scattered across 6+ files (RUNBOOK, WORKFLOW, PROTOCOL,
    QUALITY_PROTOCOL, PRE-BUILD, explore.md). Claude Code had to mentally assemble
    the correct sequence, leading to skipped steps, underutilized infrastructure,
    and inconsistent process application across task types.

  chosen: |
    Add `.claude/BUILD.md` as a central orchestration file that:
    - Classifies tasks into 4 tiers (Micro/Targeted/Standard/Complex)
    - Provides a linear build path for each tier
    - Right-sizes pre-build requirements to task complexity
    - Includes a file reference map so nothing gets overlooked
    - References existing files rather than duplicating content

  rejected:
    - "Add orchestration to RUNBOOK.md — would make RUNBOOK too long and mix
       entry-point concerns with sequencing concerns"
    - "Add orchestration to WORKFLOW.md — WORKFLOW covers execution patterns,
       not sequencing; mixing them would blur the scope boundary"
    - "Embed sequence in CLAUDE.md template — too much content for the condensed
       operational checklist"

  stability: hard
  promote: candidate
  promote_rationale: "Build orchestration is universal — every project needs task classification and right-sized process"
  references: [LAW-003]

- id: DEC-020
  decision: "Add Reference Analysis Protocol and extend Exploration Phase"
  date: 2026-02-16
  owner: "Petter"
  context: |
    The system had peer comparison in evaluation (critique's Peer Test) but not
    in preparation. Claude Code would build based on system rules alone, without
    understanding current conventions or how excellent products solve the same
    class of problem. This led to technically correct but craft-deficient builds.

  chosen: |
    Extend _modes/explore.md with Reference Analysis as Step 0 of exploration.
    Add _quality/REFERENCE_ANALYSIS.md as the detailed protocol.
    Reference analysis extracts transferable principles (not implementation
    details) from 2-3 products excellent at the specific pattern type.
    Principles are then applied through the system's own constraints.

  rejected:
    - "Add reference URLs to archetype files — would rot quickly, violates
       durable-over-volatile principle"
    - "Make reference analysis a standalone pre-build gate — too heavy as
       a separate gate; better integrated into exploration flow"

  stability: hard
  promote: candidate
  promote_rationale: "Reference analysis is universal — every product benefits from studying how the best solve similar problems"
  references: [LAW-003]

- id: DEC-021
  decision: "Add Visual Verification Protocol — concrete operational process for visual quality evaluation"
  date: 2026-02-16
  owner: "Petter"
  context: |
    WORKFLOW.md stated "Rendering in a browser is not optional for visual scoring"
    but provided no operational protocol. The critique loop scored visual dimensions
    based on code analysis rather than rendered output, meaning visual bugs were
    not systematically caught.

  chosen: |
    Add `_quality/VISUAL_VERIFICATION.md` with:
    - Concrete capture protocol (breakpoints, states, realistic data)
    - Screenshot storage conventions
    - Quick and Full evaluation checklists
    - Integration into critique loop as required input
    - Score capping rule: without visual verification, visual dimensions capped at 3
    - Playwright script template for automation
    - Degraded mode for when automation isn't available

  rejected:
    - "Add to WORKFLOW.md — WORKFLOW.md was already too long; separate file
       follows the pattern of other quality files"
    - "Make visual verification optional — 'optional' means 'never done';
       score capping enforces compliance without blocking builds"

  stability: hard
  promote: candidate
  promote_rationale: "Visual verification is universal — every UI product needs rendered output evaluation, not just code review"
  references: [LAW-003]

- id: DEC-022
  decision: "Added Value Loop Mapping framework to _jobs/ directory"
  date: 2026-02-16
  owner: "@petter"
  context: "The system had moat thinking (what to defend) and expectation thinking (what to build) but no framework for understanding how product usage creates compounding value — the engine behind retention and stickiness."
  chosen: "New _jobs/VALUE_LOOPS.md with 4 loop types (Data, Learning, Integration, Network), loop-to-job mapping, visibility guidelines, and value loop audit protocol. Integrated with MOATS.md (loop-to-moat mapping), README, and QUICKREF."
  rejected:
    - "Embed in MOATS.md — rejected because value loops are operational (how value compounds) while moats are strategic (what to defend). Different audiences."
    - "Add to _expectations/ — rejected because expectations are about what users expect, not about how the product creates compounding value."
  stability: soft
  promote: candidate
  promote_rationale: "Every product benefits from understanding its value loops, regardless of domain."
  references: [LAW-012, LAW-013]

- id: DEC-023
  decision: "Added Adaptive Layout Governance alongside existing Responsive spec"
  date: 2026-02-16
  owner: "@petter"
  context: "RESPONSIVE.md handles breakpoints and reflow but not content priority, navigation transformation, or touch interaction model differences across form factors."
  chosen: "New _ui/ADAPTIVE.md with content priority framework, navigation transformation rules, touch adaptation checklist, and form factor declaration. Integrated into Pre-Build flow, critique loop, and surface spec template."
  rejected:
    - "Merge into RESPONSIVE.md — rejected because the file would become too large and mixes two concerns (breakpoint mechanics vs. priority/transformation strategy)"
    - "Add to archetypes — rejected because adaptive behavior is surface-specific, not archetype-specific"
  stability: soft
  promote: candidate
  promote_rationale: "Every multi-form-factor product needs adaptive governance, not just responsive breakpoints."
  references: [LAW-001, LAW-006]

- id: DEC-024
  decision: "Added Design Tooling Governance framework"
  date: 2026-02-16
  owner: "@petter"
  context: "Tool selection was ad hoc — no framework for evaluating or governing design and development tools. Each project made tool choices without criteria or documentation."
  chosen: "New config/TOOLING.md with universal selection criteria (8 dimensions), 8 tool categories, evaluation workflow, verdict system (adopt/trial/hold/reject). Integrated into tech-foundation.yaml, RUNBOOK.md authority rules, and quality gates."
  rejected:
    - "Add to tech-foundation.yaml directly — rejected because the evaluation framework and categories are too detailed for a config file"
    - "Per-project tool docs — rejected because tool governance should be a system-level concern"
  stability: soft
  promote: candidate
  promote_rationale: "Every project benefits from deliberate tool selection, regardless of domain."
  references: [LAW-001]

- id: DEC-025
  decision: "Added Information Surfacing Framework to pattern library"
  date: 2026-02-16
  owner: "@petter"
  context: "Surfaces showed either too much information (data dumps) or hid critical information behind navigation. No framework existed for deciding what information appears where and at what prominence."
  chosen: "New _model/patterns/SURFACING.md with Action-Change Test (if-changed-would-user-act-differently), 4-tier importance model (Prominent/Accessible/On Demand/Remove), Surfacing Audit protocol (inventory, test, validate, cross-surface check), and surface-type-specific surfacing patterns. New critique dimension 'Information Surfacing' added to scoring. Integrated into Pre-Build flow and Gate 0."
  rejected:
    - "Embed in data-display.md — rejected because surfacing decisions precede display decisions. Surfacing is about WHAT to show; data-display is about HOW to show it."
    - "Add to _expectations/ — rejected because surfacing is a pattern (reusable across surfaces), not an expectation protocol"
  stability: soft
  promote: candidate
  promote_rationale: "Every product surface needs information prioritization. The Action-Change Test is universal."
  references: [LAW-003, LAW-001]

- id: DEC-026
  decision: "Added Product Thesis declaration and Feature Multiplication framework for directional coherence"
  date: 2026-02-16
  owner: "system"
  context: "Products could pass all quality gates while being a grab-bag of unrelated features. manifest.yaml defined product identity but not product direction. COHERENCE.md checked visual unity but not strategic unity."
  chosen: "Thesis declaration in manifest.yaml + DIRECTIONAL_COHERENCE.md with multiplication test, orphan detection, and directional audit. Integrated into Pre-Build flow (steps 3-4) and critique (conditional dimension)."
  rejected:
    - "Adding thesis to Notion Strategy page only — would not be available to Claude Code during builds"
    - "Making multiplication test a hard gate — too restrictive for early-stage products with few features"
    - "Creating a standalone product-strategy directory — thesis is a quality concern, not a strategy document"
  stability: soft
  promote: candidate
  promote_rationale: "Every product benefits from a falsifiable thesis and feature multiplication thinking."
  references: [LAW-009, DEC-006]

- id: DEC-027
  decision: "Added conditional design checkpoint to session checklists — Claude Code loads DESIGN_ROUTER.yaml when session touches UI"
  date: 2026-02-16
  owner: "system"
  context: "Sessions that modify UI had no structured way to load the correct design files. Claude Code would build surfaces without reading the relevant layout specs, pattern files, or design system rules — leading to inconsistent implementations that required post-hoc critique to catch."
  chosen: "Conditional step in both Quick (step 5) and Full (step 9) session checklists: 'If session touches UI: Read DESIGN_ROUTER.yaml → load referenced design files for affected surface types.' Same step added to narrative protocol sections."
  rejected:
    - "Always loading all design files — wasteful for non-UI sessions, bloats context"
    - "Relying on critique to catch design misses — too late in the cycle"
  stability: soft
  promote: candidate
  promote_rationale: "Every UI session benefits from loading the right design context upfront."
  references: [DEC-028, DEC-029]

- id: DEC-028
  decision: "Added Design Brief template to handoff system — structured format for communicating visual identity and surface requirements"
  date: 2026-02-16
  owner: "system"
  context: "from-chat/ handoffs for UI work contained unstructured design context. Claude Code had to infer visual identity, surface types, and constraints from prose — leading to inconsistent interpretation and missing state coverage."
  chosen: "Design Brief template added to PROTOCOL.md handoff section. Includes surface type(s), design system preset, peer benchmarks, visual identity details (typeface, color, radius, spacing, key trait), constraints, and required states checklist."
  rejected:
    - "Free-form design notes — no structure means no consistency"
    - "Separate design handoff file format — adds a new file type without clear benefit over a section template"
  stability: soft
  promote: candidate
  promote_rationale: "Structured design communication eliminates the most common source of UI implementation drift."
  references: [DEC-027, DEC-029]

- id: DEC-029
  decision: "Created DESIGN_ROUTER.yaml — surface-type routing file mapping 8 surface types to design files"
  date: 2026-02-16
  owner: "system"
  context: "The design system spans multiple files across _ui/, _model/patterns/, and config/. Without a routing mechanism, Claude Code had to know which files are relevant to which surface type — knowledge that was implicit and often incomplete."
  chosen: "DESIGN_ROUTER.yaml at repo root. Maps 8 surface types (table, detail, form, dashboard, settings, wizard, empty_state, modal) to file+section references. Includes 'always load' section for universal files and 'cross_cutting' section for conditional concerns (navigation, adaptive, i18n, tooling)."
  rejected:
    - "Embedding routing in manifest.yaml — manifest is identity, not routing"
    - "Hardcoding file lists in PROTOCOL.md — not maintainable as design files evolve"
    - "Per-surface YAML files — over-fragmented, harder to scan"
  stability: soft
  promote: candidate
  promote_rationale: "Any project with UI surfaces benefits from explicit design file routing."
  references: [DEC-027, DEC-028]

- id: DEC-030
  decision: "Add DISPATCH.yaml as task-aware routing and trigger system for AI agents"
  date: 2026-02-16
  owner: "Petter"
  context: |
    Context loading guidance was spread across three files (RUNBOOK.md,
    govern.md, SYSTEM_CONTRACT.md) with vague instructions like
    "UI work → + _ui/*, relevant archetype". Claude Code had no way
    to know WHICH archetype, whether it also needed _interaction/PHYSICS.md,
    or that _quality/TRACE.yaml existed at all.

    Result: v2.0 features (_surfaces/, _nfr/, _resilience/, _artifacts/,
    _quality/TRACE.yaml, _quality/COHERENCE.md, _quality/LEARNING.md)
    sat dormant because nothing directed Claude Code to read them.

  chosen: |
    New file .claude/DISPATCH.yaml providing:
    - 13 task types with exact must_read file lists and reasons
    - should_read conditional lists
    - before/after triggers with blocking flags
    - applicable quality gate references
    - cross-cutting triggers that apply to all task types

    Existing vague loading tables in RUNBOOK.md, govern.md, and
    SYSTEM_CONTRACT.md replaced with pointers to DISPATCH.yaml
    (Single Source of Truth compliance).

    Follows same pattern as CONSTRAINTS_INDEX.yaml (DEC-003):
    reference-only routing index that points to authoritative files.
    Not a configuration mechanism — task types are universal, not
    project-specific or preset-dependent.

  rejected:
    - "Expand existing RUNBOOK.md table with more detail — would bloat
       the entry point file and still not provide triggers or gates"
    - "Add loading guidance to each feature file individually — would
       fragment the routing logic across 40+ files with no central view"
    - "Make CONSTRAINTS_INDEX.yaml more comprehensive — CONSTRAINTS_INDEX
       is a flat lookup ('what rules exist'), not task-aware routing
       ('what to read for THIS task'). Different purpose."
    - "Embed in CLAUDE.md bootstrap — CLAUDE.md is read once at session
       start. DISPATCH needs to be consulted per-task during a session."

  stability: hard
  references:
    - "DEC-003 — CONSTRAINTS_INDEX.yaml precedent for reference-only routing files"
    - "DEC-009 — v2.0 structural expansion that added the dormant features"
    - "GOVERNANCE.md — Single Source of Truth (loading guidance consolidated)"
    - "SYSTEM_CONTRACT.md — Closed World Assumption (preserved)"
    - "SYSTEM_CONTRACT.md — Generic Over Specific (all paths use placeholders)"
  changes:
    - "NEW: .claude/DISPATCH.yaml — task-aware routing and triggers"
    - "EDIT: .claude/RUNBOOK.md — replaced starter kit loading table with DISPATCH reference"
    - "EDIT: .claude/RUNBOOK.md — added DISPATCH to Related Files table"
    - "EDIT: _modes/govern.md — replaced YAML load sets with DISPATCH reference"
    - "EDIT: SYSTEM_CONTRACT.md — replaced starter kit loading table with DISPATCH reference"
    - "EDIT: SYSTEM_CONTRACT.md — updated .claude/ folder responsibility description"

- id: DEC-031
  decision: "Enhance DISPATCH.yaml with attention-directing metadata, session workflow bridge, and BUILD.md integration"
  date: 2026-02-17
  owner: "Petter"
  context: |
    DEC-030 established DISPATCH.yaml with 13 task types and must_read lists.
    Three gaps remained: (1) Claude Code had no way to know which rules mattered
    most without opening files, (2) session workflow (Notion/Linear/handoffs) was
    disconnected from task types, (3) BUILD.md's 4-tier classification had no
    mapping to DISPATCH's 13 task types.

    Infrastructure files referenced by PROTOCOL.md and WORKFLOW.md (handoff/,
    tasks/, CLAUDE.md) did not exist in the template.

  chosen: |
    Four rounds of enhancements to DISPATCH.yaml and related files:

    Round 1: key_signals (critical rules per task), depth tiers (full/scan/verify),
    context_budget, priority_if_constrained, file_digests (8 files), Loading Protocol.

    Round 2: session_workflow per task type (session_mode, notion_read, notion_write,
    linear_actions, handoff_weight), expanded cross-cutting triggers (4 specific
    blocking + 1 periodic replacing 1 vague), PROTOCOL.md and NOTION.md digests,
    Session Workflow Essentials in RUNBOOK.md.

    Round 3: build_classification per task type (typical tier, range, pre_build),
    BUILD.md digest, infrastructure scaffolding (handoff/, tasks/, CLAUDE.md),
    RUNBOOK Task Flow rewrite with interconnection diagram.

    Round 4: Cross-reference integrity — updated header documentation in
    DISPATCH.yaml, BUILD.md, and WORKFLOW.md to make the dependency chain
    discoverable.

  rejected:
    - "Merge BUILD.md into DISPATCH.yaml — would make DISPATCH too large and
       violate One Home Rule (build sequencing lives in BUILD.md)"
    - "Create a separate INTEGRATION.md file — adds another file to the system
       when surgical edits to existing headers achieve the same result"
    - "Auto-generate cross-references — over-engineering for a 5-file system"

  stability: hard
  references:
    - "DEC-030 — DISPATCH.yaml initial installation"
  changes:
    - "EDIT: .claude/DISPATCH.yaml — 4 rounds adding key_signals, session_workflow, build_classification, file_digests, expanded triggers, updated header docs"
    - "EDIT: .claude/RUNBOOK.md — Loading Protocol, Session Workflow Essentials, Task Flow rewrite, Template State note"
    - "EDIT: .claude/BUILD.md — Added DISPATCH.yaml to Related table, cross-cutting note"
    - "EDIT: .claude/WORKFLOW.md — Added upstream context references"
    - "NEW: CLAUDE.md — stub from PROTOCOL.md template"
    - "NEW: handoff/ — directory structure with README"
    - "NEW: tasks/todo.md, tasks/lessons.md — build tracking starters"
    - "EDIT: README.md — added handoff/, tasks/, CLAUDE.md to directory tree"
    - "EDIT: CHANGELOG.md — documented 4 enhancement rounds"

- id: DEC-032
  decision: "Added handoff/ and tasks/ to SYSTEM_CONTRACT.md folder responsibilities table"
  date: 2026-02-17
  owner: "Petter"
  context: |
    DEC-031 authorized creation of handoff/ and tasks/ directories as
    infrastructure scaffolding. README.md was updated with both folders.
    However, SYSTEM_CONTRACT.md's folder responsibilities table (the
    foundational definition of all folders) was not updated because the
    file is Frozen (DEC-006).

  chosen: |
    Add two rows to the folder table under DEC-006's "improving definitions"
    exception. This is internal refinement: documenting folders that already
    exist, not introducing new structural concepts.

  rejected:
    - "Leave the gap — acceptable but creates a completeness issue in the
       system's foundational table"

  stability: locked
  references:
    - "DEC-006 — Stability freeze, allows 'improving definitions'"
    - "DEC-031 — Authorized creation of handoff/ and tasks/"
  changes:
    - "EDIT: SYSTEM_CONTRACT.md — Added handoff/ and tasks/ to folder table"

- id: DEC-033
  decision: "Route quality-loop inputs through DISPATCH.yaml and complete archetype set"
  date: 2026-02-17
  owner: "Petter"
  context: |
    The critique system (_critique/LOOP.md) declares formal input files it reads
    during scoring, and PRE-BUILD.md references files for its 14-step flow. But
    DISPATCH.yaml — the file that tells agents what to load — never routed to
    most of these files. An agent following DISPATCH perfectly would still fail
    critique because it never loaded what critique needs.

    Additionally, the system claims 5 archetypes in 9 locations but only 3
    budget files existed. BUILD.md had a broken reference to _quality/RUBRIC.md
    (correct path: _critique/RUBRIC.md). DESIGN_ROUTER.yaml was disconnected
    from DISPATCH.yaml task routing. README.md Bootstrap Order was missing
    DISPATCH.yaml and BUILD.md.

  chosen: |
    Round 5 of DISPATCH enhancements:
    - Added should_read entries with conditions to 5 task types (new_screen,
      full_feature, review_audit, data_display, modify_screen) for 7 critique
      inputs and 6 pre-build dependencies
    - Bridged DESIGN_ROUTER.yaml with single should_read per UI task type
      (reference pattern, not route duplication)
    - Created provisional archetype stubs (configuration.yaml, transient.yaml)
    - Fixed broken BUILD.md reference, README Bootstrap Order, RUNBOOK Related table

  rejected:
    - "Add critique inputs to must_read — would bloat context for every task"
    - "Duplicate DESIGN_ROUTER routes into DISPATCH — violates One Home Rule"
    - "Skip archetype stubs — agents building settings/modal surfaces would fail silently"

  stability: hard
  references:
    - "DEC-031 — DISPATCH enhancement rounds 1-4"
    - "DEC-006 — Frozen files (critique files are frozen; we add routing TO them, not edits)"
  changes:
    - "EDIT: .claude/DISPATCH.yaml — Added should_read entries to 5 task types, fixed archetype digest, added EVOLUTION.md digest"
    - "EDIT: .claude/BUILD.md — Fixed _quality/RUBRIC.md → _critique/RUBRIC.md"
    - "EDIT: .claude/RUNBOOK.md — Added DESIGN_ROUTER.yaml to Related table"
    - "EDIT: README.md — Fixed Bootstrap Order, updated archetypes line in directory tree"
    - "EDIT: CHANGELOG.md — Added Round 5 entry"
    - "NEW: _quality/archetypes/configuration.yaml — Provisional archetype stub"
    - "NEW: _quality/archetypes/transient.yaml — Provisional archetype stub"

- id: DEC-034
  decision: "Route _flows/ and _jobs/ through DISPATCH.yaml conditional routing and fix design system reference"
  date: 2026-02-17
  owner: "Petter"
  context: |
    The quality gates (Gate 0 job traceability, Gate 5 job completeness, Flow Gate)
    conditionally check _flows/REGISTRY.yaml and _jobs/REGISTRY.yaml — but
    DISPATCH.yaml only routed to them from full_feature. Agents building new
    screens, running reviews, modifying screens, or exploring capabilities would
    never load flow/job context, causing silent gate failures when registries
    are populated.

    Additionally, new_component referenced components.yaml but the publishing
    design system uses components.md. new_component was the only UI task type
    without a should_read section. RUNBOOK.md Template State warning was stale.

  chosen: |
    Round 6 of DISPATCH enhancements:
    - Added conditional should_read entries (all use "If file is populated")
      to new_screen, modify_screen, review_audit, exploration for _flows/ and _jobs/
    - Added _jobs/VALUE_LOOPS.md and design-time templates to relevant task types
    - Fixed new_component: added note for components.yaml/md variance, added
      should_read section, updated context_budget
    - Added _examples/ file digest for discoverability
    - Reworded RUNBOOK.md Template State warning, added EVOLUTION.md to Related table

  rejected:
    - "Add as must_read — would bloat context; conditional routing matches conditional enforcement"
    - "Skip routing because registries are empty in template — agents in live projects with populated registries would fail silently"

  stability: hard
  references:
    - "DEC-033 — Round 5 quality-loop routing"
    - "DEC-031 — DISPATCH enhancement rounds 1-4"
  changes:
    - "EDIT: .claude/DISPATCH.yaml — Routed _flows/ and _jobs/ to 4+ task types, added VALUE_LOOPS.md, fixed new_component, added _examples/ digest"
    - "EDIT: .claude/RUNBOOK.md — Reworded Template State warning, added EVOLUTION.md to Related table"
    - "EDIT: README.md — Added overview to _model/patterns/ description"
    - "EDIT: CHANGELOG.md — Added Round 6 entry"

- id: DEC-035
  decision: "Round 7 DISPATCH routing gap closure — 8 targeted fixes across 10 task types"
  date: 2026-02-17
  owner: "Petter"
  context: |
    Systematic audit of DISPATCH.yaml after Round 6 identified 8 routing gaps:
    1. token_work had no visual verification or calibration reference despite
       affecting visual quality scores globally
    2. model_change was missing _flows/ and _jobs/ routing added to all other
       major task types in Round 6
    3. CONSTRAINTS_INDEX.yaml (DEC-003) was only routed to token_work despite
       RUNBOOK.md recommending it as a load-first constraint locator
    4. config_change had empty should_read despite affecting flows, jobs, and content
    5. refactor had empty should_read despite UI-touching refactors needing
       traceability verification
    6. _critique/CALIBRATION.md was absent from DISPATCH entirely — the scoring
       companion to RUBRIC.md (already routed in review_audit)
    7. modify_screen had a blocking before-trigger referencing _decisions/REGISTRY.md
       but that file was not in must_read or should_read
    8. exploration loaded _modes/explore.md (Step 0 = Reference Analysis) but did
       not route to _quality/REFERENCE_ANALYSIS.md containing the full protocol

    Additionally, QUICKREF.md invariant prefix table listed 9 of 27 categories.

  chosen: |
    8 targeted additions to DISPATCH.yaml should_read sections, 1 after-trigger:
    - All entries use condition: field per DISPATCH conditional routing pattern
    - No deletions; no modifications to frozen _critique/ files (DEC-006)
    - Context budgets updated for all 10 affected task types
    - QUICKREF.md expanded: invariant table to 27 categories, new Entry Points
      rows, new Workflow Modes and Routing & Dispatch sections

  rejected:
    - "Add to must_read — would bloat context for every execution; conditional
       should_read matches conditional relevance"
    - "Fix token_work critique gap by adding a new gate — DEC-006 freezes gate
       structure; should_read + after-trigger is the correct mechanism"
    - "Skip QUICKREF.md — the invariant table is a primary navigation aid;
       incomplete table defeats its purpose for live-world use"

  stability: hard
  references:
    - "DEC-003 — CONSTRAINTS_INDEX.yaml origin"
    - "DEC-006 — critique files frozen; routing only"
    - "DEC-034 — Round 6"
    - "DEC-033 — Round 5"
    - "DEC-031 — Rounds 1-4"
  changes:
    - "EDIT: .claude/DISPATCH.yaml — 8 should_read additions, 1 after-trigger, 10 context budget updates"
    - "EDIT: QUICKREF.md — Invariant table 9→27, Entry Points +2 rows, new Modes and Routing sections"
    - "EDIT: CHANGELOG.md — Round 7 entry, heading update"

- id: DEC-036
  decision: "Round 8 DISPATCH trigger-load mismatch fix — systemic pattern across 10 task types"
  date: 2026-02-17
  owner: "Petter"
  context: |
    Post-Round-7 audit revealed a systemic class of bug: before/after triggers
    reference files that aren't in must_read or should_read. An agent following
    DISPATCH routing loads its read lists at task start, then encounters triggers
    that assume files are available — but they aren't. _critique/LOOP.md was
    referenced in 6 task type after-triggers but loaded by none. _decisions/REGISTRY.md
    was referenced in 3 more task type before-triggers (Round 7 fixed modify_screen
    but not new_component, full_feature, config_change). Additionally, bug_fix,
    data_display, and accessibility had thin should_read sections relative to their
    responsibilities, and 4 high-frequency files lacked digests.

  chosen: |
    Systematic fix of all trigger-load mismatches plus targeted should_read fills:
    - Pattern A: _critique/LOOP.md added to 6 task types (conditional should_read)
    - Pattern B: _decisions/REGISTRY.md added to 3 task types
    - Pattern C: 3 one-off trigger fixes (_ui/states.md, QUALITY_PROTOCOL.md, COHERENCE.md)
    - Pattern D: 5 thin-section fills (bug_fix, data_display, accessibility, token_work, config_change)
    - Pattern E: 4 new file digests (17 total)
    - Pattern F: govern.md canonical name fix, QUICKREF.md +4 Quality & Critique rows
    - All additions are conditional should_read; no deletions

  rejected:
    - "Add trigger-referenced files to must_read — would bloat context for
       every execution; conditional should_read correctly matches conditional triggers"
    - "Remove triggers that reference unloaded files — triggers are correct
       behavior; the routing gap is in the loading, not the triggers"
    - "Skip thin-section fills — these task types would continue to miss
       commonly-needed context, reducing build quality"

  stability: hard
  references:
    - "DEC-035 — Round 7"
    - "DEC-006 — critique files frozen; routing only"
    - "DEC-003 — CONSTRAINTS_INDEX.yaml origin"
  changes:
    - "EDIT: .claude/DISPATCH.yaml — 6x _critique/LOOP.md, 3x _decisions/REGISTRY.md, 3 one-off fixes, 5 thin-section fills, 1 must_read addition, 4 file digests, ~15 context_budget updates"
    - "EDIT: _modes/govern.md — 'Open Questions' → 'Deferred' (line 39)"
    - "EDIT: QUICKREF.md — +4 rows in Quality & Critique table"
    - "EDIT: CHANGELOG.md — Round 8 entry, heading update"

- id: DEC-037
  decision: "Round 9 DISPATCH structural documentation + digests + state routing gaps"
  date: 2026-02-17
  owner: "Petter"
  context: |
    Post-Round-8 audit (0 P0, 8 P1, 18 P2) revealed two remaining gap classes:
    1. Structural documentation: _design-systems/ (routed by 4 DISPATCH task types)
       was entirely absent from README.md and SYSTEM_CONTRACT.md. GOVERNANCE.md,
       EVOLUTION.md, CONSTRAINTS_INDEX.yaml also missing from README.md. 11 directories
       existed on filesystem but were absent from SYSTEM_CONTRACT.md folder table.
    2. _ui/states.md routing: modify_screen and new_component were the only two UI
       task types without states.md — both commonly need it (LAW-004).
    3. High-frequency files without digests: _critique/LOOP.md (7 task types),
       VISUAL_VERIFICATION.md (6+), _flows/REGISTRY.yaml (7), _jobs/REGISTRY.yaml (6),
       _ui/tokens.yaml (6+).

  chosen: |
    Close all P1 structural documentation gaps and add highest-value digests:
    - README.md: +_design-systems/ tree (14 lines), +3 root files
    - SYSTEM_CONTRACT.md: +11 rows in Folder Responsibilities table
    - DISPATCH.yaml: +_ui/states.md to modify_screen and new_component, 5 file
      digests (22 total), data_display key_signal improvement, new_screen budget fix
    - QUICKREF.md: +EVOLUTION.md, +exemplars/
    - All additions; no deletions

  rejected:
    - "Add _design-systems/ to must_read for more task types — it's already in
       must_read for 4 task types via _contract.yaml, tokens.yaml, etc.; structural
       documentation fixes don't require routing changes"
    - "Skip SYSTEM_CONTRACT.md — the folder table is the authoritative governance
       reference; 11 missing directories is a significant authority gap"
    - "Add _ui/states.md to must_read instead of should_read — states.md is needed
       conditionally for modify_screen and always for new_component, but should_read
       keeps context lean for simple modifications"

  stability: hard
  references:
    - "DEC-036 — Round 8"
    - "DEC-006 — critique files frozen; routing only"
  changes:
    - "EDIT: README.md — +_design-systems/ tree, +GOVERNANCE.md, +EVOLUTION.md, +CONSTRAINTS_INDEX.yaml"
    - "EDIT: SYSTEM_CONTRACT.md — +11 rows in Folder Responsibilities table"
    - "EDIT: .claude/DISPATCH.yaml — 2x _ui/states.md should_read, 5 file digests, 1 key_signal improvement, 3 context_budget updates"
    - "EDIT: QUICKREF.md — +EVOLUTION.md row, +exemplars/ row"
    - "EDIT: CHANGELOG.md — Round 9 entry, heading update"

# ============================================================
# [DRAFT — REQUIRES APPROVAL] — Remove this marker after approval
# ============================================================

- id: DEC-038
  decision: "Add implementation bridge documents — translation guide, verification protocol, and task decomposition patterns"
  date: 2026-02-17
  owner: "Petter"
  context: |
    The system produces excellent governance artifacts (surface specs, entity models,
    token mappings, archetype budgets, interaction laws, invariants) but provides no
    guidance for translating those artifacts into implementation work. A developer
    completing governance has 15+ files of specifications scattered across directories
    with no map connecting them to implementation questions, no post-implementation
    verification checklist, and no templates for decomposing specs into ordered tasks.

    This gap was identified as the primary barrier between "spec complete" and
    "implementation starts" — the system scored B+ as governance framework but C+
    as a build tool.

  chosen: |
    Three new files closing the spec-to-implementation gap:

    1. `_guides/IMPLEMENTATION_MAP.md` — Reference map connecting each governance
       artifact to the implementation questions it answers. Structured as "Your X
       tells you..." sections covering: surface spec, entity model, token mapping,
       interaction laws, archetype budgets, invariants, user contracts, component
       registry, interaction specs, states spec, tech foundation. Includes cross-
       reference lookup table and recommended reading order.

    2. `_quality/VERIFICATION.md` — Post-implementation checklist verifying code
       against governance artifacts. 8 sections: token traceability, mandatory state
       coverage, archetype budget compliance, interaction law compliance, entity/data
       integrity, keyboard/accessibility, affordance integrity, tech foundation
       compliance. Scoped by build tier (micro=skip, targeted=sections 1-3,
       standard/complex=all). Includes output template for recording results.
       Complements critique loop (critique checks design, this checks code).

    3. `_model/patterns/decomposition.md` — Stack-agnostic templates for breaking
       surface specs into ordered implementation tasks, one template per archetype
       (overview, workspace, detail, configuration, transient). Each template has
       6 phases: structure → data → states → content → interaction → polish.
       Universal decomposition rules applied before archetype patterns. Includes
       cross-archetype composition guidance and task sizing guide.

    All files use __FILL__ for project-specific values, reference existing files
    rather than duplicating content, and are stack-agnostic.

  rejected:
    - "Embed in WORKFLOW.md — WORKFLOW.md is already 550+ lines and focuses on
       execution patterns, not artifact-to-implementation mapping. Adding 300+
       lines of reference content would blur its scope."
    - "Add to RUNBOOK.md — RUNBOOK is the AI entry point. Implementation details
       would bloat the first file agents read."
    - "Single implementation guide combining all three — different audiences and
       use timings. The map is read pre-implementation, verification is post-
       implementation, decomposition is at task planning. Separate files allow
       targeted loading."
    - "Skip decomposition patterns (items 1 and 2 only) — without decomposition
       templates, developers still need to invent task breakdown per archetype,
       which is the most error-prone step."

  stability: soft
  promote: candidate
  promote_rationale: "Every project using this template faces the same spec-to-implementation gap. These bridge documents are generic and use __FILL__ for all project-specific values."
  references:
    - "DEC-019 — BUILD.md central orchestration (this extends build support)"
    - "DEC-006 — Stability freeze (new files, no changes to frozen structures)"
  changes:
    - "NEW: _guides/IMPLEMENTATION_MAP.md — Artifact-to-implementation reference map"
    - "NEW: _quality/VERIFICATION.md — Post-implementation code verification checklist"
    - "NEW: _model/patterns/decomposition.md — Archetype-specific task decomposition templates"
