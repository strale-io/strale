# Divergence Ledger

> Intentional differences between this project and the canonical starter kit template.
> Part of the Evolution Protocol. See `EVOLUTION.md` in the template repository.

---

## Template Version at Copy

- **Copied from:** __FILL__ <!-- e.g., v12.7.0 -->
- **Copy date:** __FILL__ <!-- e.g., 2026-02-01 -->
- **Last synced to:** __FILL__ <!-- Updated when upstream changes are applied -->

---

## Intentional Divergences

Track any deliberate changes from the template here. This helps during upgrades —
Claude can distinguish "changed on purpose" from "out of date."

| ID | What Changed | Why | Reversible? |
|----|-------------|-----|-------------|
| <!-- DIV-001 | Example: Removed Gate 7 | Not using moat-conscious preset | Yes --> |

---

## Upstream Sync Log

Record when this project pulls changes from a newer template version.

| Date | Template Version | Changes Applied | Changes Skipped (and why) |
|------|-----------------|-----------------|---------------------------|
| <!-- 2026-03-01 | v12.8.0 | IX-007, cascade warning | Filter persistence — not relevant yet --> |
