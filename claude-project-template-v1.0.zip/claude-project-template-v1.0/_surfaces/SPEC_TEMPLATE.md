# Surface Specification: __FILL__

> **Surface ID:** SURF-__FILL__
> **Archetype:** __FILL__ (workspace | detail | overview | configuration | transient)
> **Status:** __FILL__ (draft | active | deprecated)
> **Owner:** __FILL__
> **Last Updated:** __FILL__

---

## Purpose

__FILL__: One paragraph describing what this surface enables users to accomplish.

---

## Screen Intent Declaration

| Field | Value |
|-------|-------|
| **Primary UI Object** | __FILL__ |
| **Role Intent** | __FILL__ (Action | Information | Orientation | Review) |
| **Outcome** | __FILL__ (User state change this surface achieves) |
| **Vocabulary Gating** | __FILL__ (Allowed/forbidden terms) |

---

## Truth Model References

### Entities

| Entity | Role on Surface | Source |
|--------|-----------------|--------|
| __FILL__ | __FILL__ (primary | secondary | reference) | `_model/truth/entities.yaml` |

### Actions

| Action | Trigger | Constraints |
|--------|---------|-------------|
| __FILL__ | __FILL__ (button | menu | keyboard) | __FILL__ |

### States

| State | Display | Transitions Available |
|-------|---------|----------------------|
| __FILL__ | __FILL__ (badge | row styling | filter) | __FILL__ |

---

## Layout & Zones

**Archetype Budget:** (from `_quality/archetypes/__FILL__.md`)

| Budget | Limit | Actual |
|--------|-------|--------|
| Decision points | __FILL__ | __FILL__ |
| Components | __FILL__ | __FILL__ |
| Primary actions | __FILL__ | __FILL__ |

**Zone Usage:**

```
┌─────────────────────────────────────────────┐
│  __FILL__: Zone layout diagram              │
│                                             │
│  ┌─────────┬───────────────────────────┐   │
│  │ __FILL__│        __FILL__           │   │
│  │         │                           │   │
│  └─────────┴───────────────────────────┘   │
└─────────────────────────────────────────────┘
```

---

## Navigation

### Incoming (surfaces that link here)

| Source Surface | Trigger | Context Passed |
|----------------|---------|----------------|
| SURF-__FILL__ | __FILL__ | __FILL__ |

### Outgoing (surfaces this links to)

| Target Surface | Trigger | Context Passed |
|----------------|---------|----------------|
| SURF-__FILL__ | __FILL__ | __FILL__ |

---

## Cross-Surface Coherence

### Shared Vocabulary

| Term | Definition | Also Appears On |
|------|------------|-----------------|
| __FILL__ | __FILL__ | SURF-__FILL__ |

### Shared Counts/Metrics

| Metric | Calculation | Must Match |
|--------|-------------|------------|
| __FILL__ | __FILL__ | SURF-__FILL__ |

### Coherence Checklist (Gate 8)

- [ ] Terminology matches sibling surfaces (CS-001, CS-002)
- [ ] Navigation promises are fulfilled by targets (CS-003)
- [ ] Counts reconcile with dashboard/overview surfaces (CS-004)
- [ ] Permission visibility is consistent (CS-005)

---

## User Expectations

### Pre-Build Checklist

- [ ] Peer context specified (comparable products reviewed)
- [ ] Feature Category Checklist completed
- [ ] Expected actions enumerated
- [ ] Inner Monologue Test passed

### Expected Features (must have)

| Feature | Rationale | Status |
|---------|-----------|--------|
| __FILL__ | __FILL__ | __FILL__ |

### Helpful Features (should have)

| Feature | Rationale | Status |
|---------|-----------|--------|
| __FILL__ | __FILL__ | __FILL__ |

### Expectation Debt (intentionally deferred)

| Feature | Deferral Reason | Planned Version |
|---------|-----------------|-----------------|
| __FILL__ | __FILL__ | __FILL__ |

---

## Edge Cases

| Scenario | Expected Behavior | Invariant |
|----------|-------------------|-----------|
| Empty state | __FILL__ | UI-006 |
| Error state | __FILL__ | UI-004, FB-002 |
| Loading state | __FILL__ | UI-003 |
| Permission denied | __FILL__ | PM-001 |
| __FILL__ | __FILL__ | __FILL__ |

---

## Responsive Behavior

| Breakpoint | Adaptation |
|------------|------------|
| Desktop (≥1024px) | __FILL__ |
| Tablet (768-1023px) | __FILL__ |
| Mobile (<768px) | __FILL__ |

### Form Factor Declaration
```yaml
form_factor_declaration:
  supported_form_factors:
    desktop: true
    tablet: __FILL__
    mobile: __FILL__
  primary_form_factor: __FILL__
  adaptation_strategy:
    tablet: __FILL__  # reflow | collapse | dedicated
    mobile: __FILL__  # reflow | collapse | dedicated | not-supported
```

### Content Priority
```yaml
content_priority:
  desktop:
    primary: "__FILL__"
    secondary: "__FILL__"
    tertiary: "__FILL__"
  mobile:
    primary: "__FILL__"
    secondary: "__FILL__ | collapsed"
    tertiary: "hidden"
```

See `_ui/ADAPTIVE.md` for full adaptive governance guidelines.

---

## Accessibility

- [ ] Keyboard navigation complete
- [ ] Focus order logical
- [ ] Screen reader landmarks defined
- [ ] Color contrast meets AA
- [ ] Touch targets ≥44px on touch devices

---

## Test Coverage

| Test Type | File/ID | Status |
|-----------|---------|--------|
| Unit | __FILL__ | __FILL__ |
| Integration | __FILL__ | __FILL__ |
| E2E | __FILL__ | __FILL__ |
| Visual regression | __FILL__ | __FILL__ |

---

## Traceability

| Type | Reference |
|------|-----------|
| Requirements | REQ-__FILL__ |
| Decisions | DEC-__FILL__ |
| Invariants | __FILL__ |

---

## Revision History

| Date | Version | Change | Author |
|------|---------|--------|--------|
| __FILL__ | 1.0 | Initial specification | __FILL__ |
