# Cross-Surface Expectation Framework

> Proactive mental model consistency across surfaces.

**Authority:** This framework extends `_quality/COHERENCE.md` (reactive audit) with proactive design rules. Coherence catches drift after building; this prevents drift before building.

---

## Purpose

Users build mental models as they use your product. Every surface they interact with teaches them rules: "this is how things work here." When a new surface violates those learned rules, the user experiences cognitive friction — even if the new surface is individually well-designed.

**The coherence audit catches this.** But it catches it late — after surfaces are built. This framework provides rules and templates for preventing mental model breaks during pre-build and design.

---

## The Propagation Principle

> **Every surface the user has already seen becomes a constraint on every surface they see next.**

This is not about visual consistency (that's coherence). It's about conceptual consistency — the rules the user has internalized about how the product works.

---

## Expectation Propagation Rules

### Rule 1: Entity Identity Continuity

If an entity appears on multiple surfaces, users expect it to be the same entity — same name, same key properties, same state representation.

| Check | Violation Example | Fix |
|-------|------------------|-----|
| Same label everywhere | "Project" on list, "Workspace" on detail | Pick one. Use vocabulary.yaml. |
| Same status representation | Green dot on list, "Active" text badge on detail | Standardize per `_model/truth/states.yaml` |
| Same key properties visible | List shows owner + date; detail shows date + priority (no owner) | Declare "always-visible properties" per entity |
| Same action availability | "Archive" on list, no "Archive" on detail | Actions available everywhere the entity appears (or documented exception) |

**Declaration template:**
```yaml
entity_identity:
  entity: "__FILL__"

  always_visible_properties:
    - "__FILL__"   # Properties that appear wherever this entity appears

  canonical_label: "__FILL__"   # The one name used everywhere (from vocabulary.yaml)

  state_representation:
    - state: "__FILL__"
      visual: "__FILL__"         # The one visual treatment used everywhere

  universal_actions:
    - "__FILL__"   # Actions available on every surface where this entity appears

  surface_specific_actions:
    - surface: "SURF-__FILL__"
      additional_actions: ["__FILL__"]
      rationale: "__FILL__"      # Why this action only appears here
```

### Rule 2: Interaction Pattern Consistency

If the user learns a pattern on one surface, they expect the same pattern on structurally similar surfaces.

| Pattern Type | Expectation | Violation |
|-------------|-------------|-----------|
| **Selection** | Same gesture selects everywhere | Click selects in list A, checkbox selects in list B |
| **Creation** | Same trigger creates everywhere | "+" button in section A, "New" menu in section B |
| **Navigation** | Same structure navigates the same way | Clicking entity name opens detail in list A, opens edit in list B |
| **Deletion** | Same flow deletes everywhere | Direct delete in list A, archive-then-delete in list B |
| **Filtering** | Same mechanism filters everywhere | Dropdowns in list A, text search in list B |

**Declaration template:**
```yaml
interaction_patterns:
  pattern: "__FILL__"           # e.g., "entity creation", "list filtering"
  canonical_implementation:
    trigger: "__FILL__"         # What the user does
    behavior: "__FILL__"        # What happens
    feedback: "__FILL__"        # How user knows it worked

  surfaces_using:
    - "SURF-__FILL__"

  exceptions:
    - surface: "SURF-__FILL__"
      deviation: "__FILL__"
      rationale: "__FILL__"     # Why this surface is different
```

### Rule 3: Hierarchy Consistency

If Surface A shows entity B as a child of entity A, no other surface should show B as independent or as a child of something else.

| Check | What to Verify |
|-------|---------------|
| **Parent-child** | If A contains B on surface X, B is never shown independently on surface Y |
| **Sibling order** | If items are ordered by date on surface X, the same items appear in the same order on surface Y (unless user explicitly re-sorted) |
| **Containment depth** | If the product has 3 hierarchy levels, no surface implies 4 or 2 |

### Rule 4: Vocabulary Propagation

Every term the user encounters teaches them a definition. That definition must hold everywhere.

| Check | What to Verify |
|-------|---------------|
| **Same concept, same word** | "Project" is always "Project" (never "Workspace" on some screens) |
| **Same word, same concept** | "Status" always means workflow status (never used for "active/inactive" on another screen) |
| **Same metaphor, same behavior** | If "Archive" means "soft delete" on surface A, it means "soft delete" everywhere |

**Reference:** `_model/truth/vocabulary.yaml` is the authoritative source. This rule extends vocabulary.yaml from a registry to a propagation constraint.

### Rule 5: Capability Scope Honesty

If a surface shows that something is possible, every other surface must honor that capability — or explicitly explain why not.

| Check | What to Verify |
|-------|---------------|
| **Promised actions** | If the overview shows "5 tasks" with an "Add task" button, the detail view also supports adding tasks |
| **Implied capabilities** | If the sidebar shows a search icon, search works from every location (not just some) |
| **Feature availability** | If a feature is visible on desktop, its mobile absence needs explanation (not just silent omission) |

---

## The Mental Model Audit (Pre-Build)

Run this for every new surface that will coexist with existing surfaces.

### Step 1: Surface Ancestry
```yaml
mental_model_audit:
  new_surface: "SURF-__FILL__"

  user_arrives_from:
    - surface: "SURF-__FILL__"
      learned_rules:
        - "__FILL__"            # What the user learned on that surface
        - "__FILL__"

  entities_shared_with:
    - entity: "__FILL__"
      also_appears_on: ["SURF-__FILL__"]

  patterns_inherited:
    - pattern: "__FILL__"       # e.g., "click to open detail"
      established_on: "SURF-__FILL__"
```

### Step 2: Conflict Detection

For each learned rule, ask: "Does the new surface honor this rule?"
```yaml
  conflict_check:
    - learned_rule: "__FILL__"
      honored_on_new_surface: __SELECT__  # yes | no | partial
      if_no:
        deviation: "__FILL__"
        severity: __SELECT__              # breaking | confusing | minor
        mitigation: "__FILL__"            # How to handle the deviation
```

### Step 3: Resolution

| Severity | Action |
|----------|--------|
| **Breaking** | Fix the new surface to honor the rule. No exceptions. |
| **Confusing** | Fix, or add explicit transition cue (label, tooltip, onboarding hint). |
| **Minor** | Document and accept. Review at Gate 8. |

---

## Expectation Debt Between Surfaces

When a surface creates expectations that another surface doesn't yet fulfill:
```yaml
cross_surface_debt:
  source_surface: "SURF-__FILL__"
  expectation_created: "__FILL__"     # What the user now expects
  target_surface: "SURF-__FILL__"     # Where they'll expect it
  currently_fulfilled: __SELECT__     # yes | no | partial
  if_no:
    planned_phase: "__FILL__"
    interim_handling: "__FILL__"       # How user is informed (or not)
```

This feeds into the existing Expectation Debt tracking in `_expectations/PRE-BUILD.md`.

---

## Integration with Existing System

| Existing Mechanism | How This Extends It |
|-------------------|-------------------|
| `_quality/COHERENCE.md` | Coherence audits reactively; this prevents proactively |
| `_expectations/PRE-BUILD.md` | Mental Model Audit runs during pre-build |
| `_surfaces/SPEC_TEMPLATE.md` | Entity Identity and Interaction Pattern declarations feed spec |
| `_model/truth/vocabulary.yaml` | Vocabulary propagation enforces vocabulary.yaml as constraint |
| Gate 8 | Conflict Detection feeds Gate 8 audit |
| Cross-Surface Decision Chain | Mental Model Audit is the expectation-focused companion |

---

## Anti-Patterns

| Anti-Pattern | Problem | Fix |
|-------------|---------|-----|
| **"But this surface is different"** | Every surface thinks it's special. Most aren't. | Apply the 5 rules. Document genuine exceptions. |
| **Partial entity** | Showing 3 properties on one surface and 5 different properties on another — same entity doesn't feel like same entity | Declare always-visible properties |
| **Interaction amnesia** | Each surface invents its own creation/deletion/filter pattern | Declare canonical patterns and inherit |
| **Vocabulary drift** | Gradual label changes across surfaces built months apart | Check vocabulary.yaml before every build |
| **Capability surprise** | Feature exists on surface A, doesn't on B, no explanation | Explicit capability scope declaration |

---

## Related Files

| File | Relationship |
|------|-------------|
| `_quality/COHERENCE.md` | Reactive counterpart (audit after build) |
| `_expectations/PRE-BUILD.md` | Mental Model Audit runs during pre-build |
| `_surfaces/REGISTRY.yaml` | Surface cross-references |
| `_surfaces/SPEC_TEMPLATE.md` | Surface specifications |
| `_model/truth/vocabulary.yaml` | Vocabulary authority |
| `_model/truth/entities.yaml` | Entity definitions |
| `_model/truth/actions.yaml` | Action definitions |
