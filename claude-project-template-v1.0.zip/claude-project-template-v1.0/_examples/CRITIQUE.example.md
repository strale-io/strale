# Critique: OKR Board — WORKED EXAMPLE (Beacon)

> DELETE THIS FILE when you understand the format.
> Your real critique scorecards go in `_artifacts/critique/`.

---

## What to Notice

1. **This is a FAIL.** Most first-cycle critiques fail — that's the system working. The value is in the specific, actionable issues and the patch plan.
2. **Pre-Critique Calibration is honest.** The builder admits bias toward wanting to pass after heavy investment.
3. **Every issue cites which rule is violated** — no vague "this doesn't feel right."
4. **P0 issues are real blockers.** A dead affordance (LAW-007) and a phantom action (actions.yaml violation) can't be shipped.
5. **The patch plan is scoped to max 5 fixes** per the rules. P2 items aren't in the plan.
6. **The Surprise Test catches something the dimension scores missed.**

---

# Critique: OKR Board (SURF-002)

**Cycle:** 1 of 3
**Date:** 2026-02-12
**Completeness Target:** Full

---

## Pre-Critique Calibration

```yaml
pre_critique_check:
  investment_level: "8 hours across 3 sessions — significant investment"
  wanting_to_pass: "yes — I've iterated heavily and want this to ship"
  fatigue_level: "Cycle 1 of 3, but I've been deep in this surface for days"
  comparison_anchor: "Comparing to Lattice OKRs and Asana Goals — professional standard"
```

**Bias detected.** Compensating: scoring Visual Craft first (hardest dimension for this surface). Looking for at least one problem before looking for passes.

---

## Scores

| # | Dimension | Score | Min | Notes |
|---|-----------|-------|-----|-------|
| 1 | Model Coherence | 4/5 | 4 | All entities match truth model. One phantom action found (see P0-2). |
| 2 | Information Architecture | 5/5 | 4 | URLs correct, breadcrumbs accurate, back navigation works. |
| 3 | Visual Craft | 3/5 | 4 | ❌ Missing hover states on objective rows. Spacing drift in KR section. No named focal point. |
| 4 | Interaction | 4/5 | 4 | Focus management correct. Drag-to-reorder keyboard accessible. Inline edit saves on blur. |
| 5 | Correctness | 5/5 | 5 | Data verified against API. Score calculations match DEC-002 thresholds. |
| 6 | Accessibility | 4/5 | 4 | Keyboard complete. Contrast passes AA. Screen reader announces health status changes. |
| 7 | Performance | 4/5 | 3 | Renders 20 objectives in 180ms. Within budget. |
| 8 | Completeness | 3/5 | 4 | ❌ "Export" button in overflow menu does nothing (see P0-1). Filter by health not wired. |
| 9 | Intent Alignment | 4/5 | 4 | Output type matches (Display + Decision). Core workflow completable. |
| 10 | Vocabulary | 4/5 | 4 | Terms match sibling surfaces. Tooltips present on score display. |
| 11 | Symbol Grammar | 4/5 | 4 | Single icon family. Consistent weight. Chevrons correct. |
| 12 | Progress & Status | 3/5 | 4 | ❌ Two KRs show bare "70%" instead of descriptive fraction — violates DEC-003. |
| 13 | User Expectations | 4/5 | 4 | Pre-build complete. Features match EIL. Filter is expected but not yet functional (P1). |
| 14 | Synthesis Artifact | 4/5 | 4 | Sections defined. Features traceable. |

---

## Surprise Test

> Before evaluating stop conditions: close your eyes, reopen, look at the screen for 3 seconds.

```yaml
surprise_test:
  first_impression: "Looks professional but the KR progress section feels cramped compared to the objective headers"
  something_unexpected: "The 'Export' button in the overflow menu — I didn't plan this, it's not in the spec, and it doesn't work"
  gut_vs_scores: "Scores feel accurate. Visual Craft at 3 matches — the row hover gap is noticeable."
  action: "P0-2 (phantom Export action) discovered via surprise test. Would have been missed by dimension-by-dimension scoring because Model Coherence focused on entity matching, not action completeness."
```

---

## Issues

### P0 (Block Ship)

**P0-1: Dead affordance — Export button does nothing**
- **Rule violated:** LAW-007 (Every button performs an action), AF-001
- **Location:** Objective overflow menu → "Export" option
- **Problem:** Clicking "Export" produces no response — no action, no error, no loading state. This is a dead affordance.
- **Fix:** Remove the Export button entirely. Export is deferred (not in SURF-002 scope per Gate 0 intent model). If the button exists, it must work.

**P0-2: Phantom action — "Export" not in actions.yaml**
- **Rule violated:** Behavioral Coherence — all UI actions must exist in `_model/truth/actions.yaml`
- **Location:** Same overflow menu
- **Problem:** `export_board` action appears in UI but is not defined in actions.yaml. This is a phantom action.
- **Fix:** Remove the button (see P0-1). Do not add `export_board` to actions.yaml — export is out of scope for this surface.

### P1 (Block Done)

**P1-1: Two KRs display bare percentage instead of descriptive fraction**
- **Rule violated:** DEC-003 (Progress displayed as descriptive fractions, not percentages)
- **Location:** KR rows for "Revenue target" and "Customer acquisition" under Objective 3
- **Problem:** Shows "70%" and "45%" instead of "35 of 50 customers acquired" or "35/50 acquired". Other KRs display correctly — this appears to be a rendering bug where KRs without a defined unit fall back to percentage.
- **Fix:** Add fallback: if unit is missing, display "N of M completed" using the generic unit. Investigate why these two KRs lack unit data.

**P1-2: Missing hover state on objective rows**
- **Rule violated:** `_ui/states.md` — interactive rows require hover state
- **Location:** All objective rows in the flat list
- **Problem:** Objective rows are clickable (expand/collapse) but have no hover feedback. User cannot distinguish clickable rows from static content.
- **Fix:** Add `hover:bg-gray-50` to objective row container. Match the hover pattern used on SURF-001 team cards.

**P1-3: Health filter not functional**
- **Rule violated:** Completeness — feature classified as "Helpful: build now" in Gate 0 EIL
- **Location:** Filter bar → "Needs attention" chip
- **Problem:** The filter chip is visible and clickable but does not filter the list. The chip toggles visually (selected state) but the objective list is unchanged.
- **Fix:** Wire the filter to show only objectives with health status `at_risk` or `behind`. If filtering logic is incomplete, hide the chip entirely until it works.

### P2 (Backlog)

1. **[POLISH]** KR progress section vertical spacing is 12px, should be 16px per tokens (`space-4` not `space-3`). Minor visual cramping.
2. **[POLISH]** Loading skeleton for expanded KR rows doesn't match final layout — skeleton shows 2 lines, actual KR row has 3 lines (value, target, updated-by).
3. **[POLISH]** Drag handle icon on objectives could use a tooltip ("Drag to reorder") for discoverability.

---

## Patch Plan

| # | Fix | Addresses | Effort |
|---|-----|-----------|--------|
| 1 | Remove "Export" button from overflow menu | P0-1, P0-2 | Trivial — delete the menu item |
| 2 | Add percentage-to-fraction fallback for KRs without unit | P1-1 | Small — rendering logic change |
| 3 | Add `hover:bg-gray-50` to objective rows | P1-2 | Trivial — CSS addition |
| 4 | Wire health filter or hide the chip | P1-3 | Medium — filter logic + list re-render |

*4 patches. Max 5 per cycle. P2 items deferred to next cycle if needed.*

---

## Stop Condition

**FAIL**

| Condition | Status |
|-----------|--------|
| P0 count = 0 | ❌ **2 P0 issues** (dead affordance + phantom action) |
| P1 count ≤ 2 | ❌ **3 P1 issues** |
| All scores meet minimums | ❌ Visual Craft 3/5 (needs 4), Completeness 3/5 (needs 4), Progress & Status 3/5 (needs 4) |

**Proceeding to Cycle 2 after executing patch plan.**

---

## Excellence Gap

```yaml
excellence_gap:
  dimension: "Visual Craft"
  current_score: 3
  what_would_make_it_5: "Intentional visual hierarchy with named focal point — the objective health summary row should be the clear anchor, with KRs visually subordinate. Currently both levels compete for attention."
  implementing: "no — fixing minimums first (hover states, spacing). Will reassess hierarchy in Cycle 2 if time permits."
```

---

## Learning Signals

### Template Gap Detected?
- [x] Yes — describe below

### If Yes:
- **Gap:** The critique dimensions don't explicitly check for "actions in UI that aren't in the spec." Model Coherence checks that entities and states match the truth model, but phantom actions in overflow menus were missed until the Surprise Test caught it.
- **Evidence:** P0-2 (phantom Export action) was not flagged by Model Coherence scoring (which gave 4/5). It was discovered via the Surprise Test's "something unexpected" prompt.
- **Generic?** Yes — any product could have UI actions that sneak in during implementation without being registered in actions.yaml.
- **Proposed fix:** Add explicit "phantom action check" to Model Coherence dimension: "For every interactive element, verify the triggered action exists in actions.yaml." (This may already be implied by the Behavioral Coherence verification dimension, but making it a named check in the critique dimension would catch it earlier.)
