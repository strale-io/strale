# Decision Registry — WORKED EXAMPLE (Beacon)

> DELETE THIS FILE when you understand the format.
> Your real decisions go in `_decisions/REGISTRY.md`.

---

## What to Notice

1. **These are product decisions, not system decisions.** The real `_decisions/REGISTRY.md` contains system-level decisions about the template itself (DEC-001 through DEC-008). This example shows what product-level decisions look like — the kind you'll log every day while building.

2. **Different stability levels.** DEC-001 is `hard` (foundational), DEC-002 is `soft` (strong preference), DEC-005 is `revisitable` (open to change with a review date).

3. **Rejected options have reasons.** Each rejected alternative explains *why* it was rejected, not just that it was.

4. **Cross-references are real.** DEC-002 is referenced by SURF-002, SURF-003, SURF-004, and SURF-005 in the Surface Registry example. DEC-003 is referenced in the Gate 0 and Critique examples.

5. **The `promote` field classifies upstream potential.** DEC-001 is `local` (specific to Beacon's hierarchy). DEC-003 is `candidate` (any product showing progress could use this pattern).

---

## Decisions

```yaml
- id: DEC-001
  decision: "OKR hierarchy displayed as flat list with expand/collapse, not nested tree"
  date: 2026-01-20
  owner: "Petter"
  context: |
    Beacon's entity hierarchy is 6 levels deep (Org → Team → Objective → KR → Initiative → Task).
    The OKR Board (SURF-002) needs to show Objectives with their Key Results. Two layout
    approaches were considered: a fully nested tree showing all levels, or a flat objective
    list where KRs expand inline under each objective.
  chosen: |
    Flat list with expand/collapse. Each objective is a row. Clicking the expand chevron
    reveals its key results inline. Initiatives and tasks are only visible on the Objective
    Detail surface (SURF-003), not on the board. This keeps the workspace archetype within
    its 10 decision-point budget.
  rejected:
    - "Nested tree view — exceeds workspace archetype budget (10 decision points) by exposing 4+ entity levels simultaneously. Also creates deep indentation that wastes horizontal space and makes drag-to-reorder confusing across nesting levels."
    - "Tabbed view (Objectives tab / KRs tab / Initiatives tab) — breaks the mental model of KRs belonging to objectives. Users would need to cross-reference tabs to understand relationships."
    - "Board/kanban view (columns per status) — works for tasks but not for OKRs. Objectives don't move linearly through statuses the way tasks do; 'at risk' is a health signal, not a workflow stage."
  stability: hard
  promote: local
  promote_rationale: "This decision depends on Beacon's specific 6-level hierarchy. Products with shallower hierarchies might benefit from a tree view."
  references: [REQ-002, REQ-003, REQ-006]
  changes:
    - "SURF-002: Archetype set to workspace with flat-list pattern"
    - "SURF-003: Designated as the place where initiatives and tasks become visible"

- id: DEC-002
  decision: "OKR scoring uses 0.0–1.0 scale (Google-style) as configurable default"
  date: 2026-01-22
  owner: "Petter"
  context: |
    OKR methodology has two common scoring approaches: percentage-based (0–100%)
    and the Google-style 0.0–1.0 scale where 0.7 is considered "healthy." The
    scoring methodology affects how progress is displayed across all surfaces
    and how health status is derived.
  chosen: |
    Default to 0.0–1.0 scale, configurable per team in Team Settings (SURF-004).
    Score thresholds: 0.0–0.3 = "at risk", 0.4–0.6 = "behind", 0.7–1.0 = "on track".
    Teams can switch to percentage-based scoring, which maps to equivalent thresholds.
    The system stores raw values and converts at display time.
  rejected:
    - "Percentage only — feels more intuitive but conflicts with OKR best practice where 70% completion of an ambitious goal is healthy. Percentage framing makes 70% look like underperformance."
    - "No default, force team to choose on setup — adds friction to onboarding. New teams shouldn't need to understand scoring methodology before they can create their first objective."
    - "Fixed 0.0–1.0, no configuration — some teams (especially those transitioning from KPI dashboards) strongly prefer percentages. Forcing the 0.0–1.0 scale causes adoption resistance."
  stability: soft
  promote: local
  promote_rationale: "OKR-specific scoring logic. Only relevant to products implementing OKR methodology."
  evidence: "Google re:Work OKR documentation; Measure What Matters (Doerr)"
  references: [REQ-011, SURF-002, SURF-003, SURF-004, SURF-005]
  changes:
    - "SURF-004: Added set_scoring_method action"
    - "_model/truth/entities.yaml: Objective entity includes score_method field"
    - "_model/truth/states.yaml: Health states derived from score thresholds"

- id: DEC-003
  decision: "Progress displayed as descriptive fractions, not percentages"
  date: 2026-01-25
  owner: "Petter"
  context: |
    Key Results track progress toward a target (e.g., "acquire 50 customers" with
    current value 35). The question is how to display this on surfaces: as a raw
    percentage ("70%"), a fraction ("35/50"), or a descriptive phrase ("35 of 50
    customers acquired"). This affects every surface showing progress: SURF-001,
    SURF-002, SURF-003, and SURF-005.
  chosen: |
    Descriptive fractions: "35 of 50 customers acquired" on detail surfaces (SURF-003),
    abbreviated to "35/50 acquired" on dense surfaces (SURF-002), and "35/50" with
    tooltip on dashboard cards (SURF-001). Never show bare percentages. The unit
    (customers, revenue, tasks, etc.) is always included when space permits.
  rejected:
    - "Bare percentages ('70%') — loses the human-readable context. '70%' of what? Users must remember the target to interpret the number. Violates the Sentence Test (can this be read as a complete thought?)."
    - "Progress bars only — visual but imprecise. A bar at ~70% could mean 35/50 or 7/10. Users in check-ins need exact numbers to report accurately."
    - "Configurable display format — adds complexity without proportional value. The descriptive fraction is strictly more informative than percentage in every context."
  stability: soft
  promote: candidate
  promote_rationale: "Descriptive fractions are a generic progress display pattern. Any product showing 'X of Y' progress benefits from including the unit and context rather than bare percentages."
  references: [SURF-001, SURF-002, SURF-003, SURF-005]
  changes:
    - "All surfaces: Progress display follows descriptive fraction pattern"
    - "_ui/components.yaml: ProgressIndicator component requires unit prop"
    - "CS-004 invariant: Fraction numerators must reconcile across surfaces"

- id: DEC-004
  decision: "Key Result progress edited inline, not via modal"
  date: 2026-01-25
  owner: "Petter"
  context: |
    Users update KR progress frequently — often several times per week during check-ins.
    The interaction pattern for updating a KR's current value needs to be fast and
    low-friction on both the OKR Board (SURF-002) and Objective Detail (SURF-003).
  chosen: |
    Click-to-edit inline on the current value field. Click the number, it becomes an
    input, type the new value, press Enter or blur to save. No modal, no confirmation
    dialog. Optimistic update with subtle save indicator. Same pattern on SURF-002
    and SURF-003 for consistency.
  rejected:
    - "Modal with form fields — too much friction for a single-field update. Users updating 5–10 KRs during a check-in would open and close 5–10 modals."
    - "Slider control — imprecise for specific values. If your target is 50 customers and you're at 37, a slider makes it hard to land on exactly 37."
    - "Inline edit with confirmation dialog — unnecessary for a non-destructive, easily reversible action. Previous values are visible in check-in history (SURF-003)."
  stability: soft
  promote: candidate
  promote_rationale: "Inline editing for frequently-updated single values is a generic interaction pattern. Any product with high-frequency numeric updates benefits from this over modals."
  references: [REQ-005, SURF-002, SURF-003]
  changes:
    - "_interaction/patterns/inline-edit.md: Added KR progress as exemplar use case"
    - "SURF-002 and SURF-003: update_kr_progress action uses inline-edit pattern"

- id: DEC-005
  decision: "Dashboard limits team cards to 4 visible, with expandable 'Show all teams'"
  date: 2026-02-01
  owner: "Petter"
  context: |
    The Strategy Dashboard (SURF-001) shows team-level OKR summaries. Organizations
    using Beacon could have anywhere from 2 to 50+ teams. Showing all teams creates
    an unbounded surface that violates the overview archetype's 8 decision-point budget.
  chosen: |
    Show top 4 teams (sorted by health — worst first, so problems are visible immediately).
    A "Show all N teams" link expands to reveal the rest. Collapsed state is the default
    on every visit — no persistence of expanded state. The 4-team limit applies to the
    team cards section only; the aggregate health ring at the top always reflects all teams.
  rejected:
    - "Show all teams always — violates overview archetype budget for organizations with 10+ teams. Dashboard becomes a workspace, not an overview."
    - "Paginated team list — pagination on a dashboard feels wrong. Dashboards are glanceable; pagination forces deliberate navigation."
    - "Configurable limit — adds a setting for something that should just work. 4 cards fits comfortably on all common viewports and shows enough to spot problems."
  stability: revisitable
  review_by: 2026-06-01
  promote: uncertain
  promote_rationale: "The 'limit visible cards with expand' pattern is generic, but the specific number (4) is Beacon-specific. Needs validation with real usage data."
  references: [REQ-001, REQ-015, SURF-001]
  changes:
    - "SURF-001: Team card section limited to 4 visible"
    - "_ui/components.yaml: TeamCard component specifies compact variant for dashboard"
```

---

## How This Connects to Other Examples

| Decision | Referenced In |
|----------|--------------|
| DEC-001 | `REGISTRY.example.yaml` → SURF-002 (flat list pattern) |
| DEC-002 | `REGISTRY.example.yaml` → SURF-002, SURF-003, SURF-004, SURF-005 |
| DEC-003 | `GATE-0.example.md` → shapes progress display on OKR Board |
| DEC-003 | `CRITIQUE.example.md` → P1 issue when bare percentage found |
| DEC-004 | `REGISTRY.example.yaml` → SURF-002, SURF-003 (inline edit action) |
| DEC-005 | `REGISTRY.example.yaml` → SURF-001 (team card limit) |
