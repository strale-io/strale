# Worked Examples

> Learn the system by seeing it used, not just defined.

---

## What This Is

These files demonstrate what properly completed system artifacts look like, using a fictional B2B SaaS product called **Beacon** — a strategic planning tool where teams manage OKRs (Objectives and Key Results), track initiatives, and run weekly check-ins.

**Beacon was chosen because it exercises every part of the template:**

- Deep entity hierarchy (Organization → Team → Objective → Key Result → Initiative → Task)
- All five archetypes (overview, workspace, detail, configuration, transient)
- Real state machines with upward cascading (KR health affects Objective health)
- Permission complexity (company-wide vs. team-scoped vs. individual)
- Cross-surface coherence challenges (progress percentages must reconcile across screens)

---

## The Examples

| File | What It Demonstrates | Lifecycle Phase |
|------|---------------------|-----------------|
| `REGISTRY.example.yaml` | Surface Registry with 5 interconnected surfaces | During build |
| `DECISIONS.example.md` | Decision Registry with 5 product-level decisions | Throughout |
| `GATE-0.example.md` | Completed Gate 0 for the OKR Board surface | Before build |
| `CRITIQUE.example.md` | Failing critique scorecard (Cycle 1) with patch plan | During review |

---

## How They Connect

The examples cross-reference each other the way real artifacts would:

```
GATE-0 (OKR Board)
  ↓ references
DECISIONS (DEC-002 scoring methodology, DEC-003 progress display)
  ↓ shapes
REGISTRY (SURF-002 OKR Board — actions, entities, states)
  ↓ reviewed by
CRITIQUE (OKR Board Cycle 1 — scores, issues, patch plan)
```

When reading, follow this order:

1. **GATE-0** — See how a surface is planned before building
2. **DECISIONS** — See the choices that shaped the design
3. **REGISTRY** — See how the built surface is documented
4. **CRITIQUE** — See how the built surface is evaluated

---

## Important

- **These are reference only.** Delete this entire folder when you understand the formats.
- **The product is fictional.** Entity names, paths, and requirements are illustrative.
- **The formats are real.** Field names, structure, and cross-references match the actual template exactly.
- **Generic over specific (LAW-003).** These examples teach the format, not a particular product domain.

---

## Beacon Entity Model (for context)

```
Organization
  └── Team
        └── Objective (has: status, health, score, owner, cycle)
              └── Key Result (has: status, progress%, target, current, unit)
                    └── Initiative (has: status, owner, due_date)
                          └── Task (has: status, assignee)

Supporting entities:
  - Cycle (quarterly planning period)
  - CheckIn (weekly progress update per Objective)
  - Comment (threaded, on any entity)
```

**State machines:**

| Entity | States |
|--------|--------|
| Objective | `draft` → `active` → `at_risk` → `completed` → `archived` |
| Key Result | `not_started` → `on_track` → `behind` → `at_risk` → `completed` |
| Initiative | `planned` → `in_progress` → `blocked` → `completed` |
| Task | `todo` → `in_progress` → `done` |
| Cycle | `planning` → `active` → `review` → `closed` |
| CheckIn | `pending` → `submitted` → `reviewed` |
