# Gate 0: Pre-Creation — WORKED EXAMPLE (Beacon)

> **Surface:** OKR Board (SURF-002)
> **Date:** 2026-01-20
> **Owner:** Petter
> **Completeness Target:** Full
>
> DELETE THIS FILE when you understand the format.
> Your real Gate 0 artifacts go in `_artifacts/gates/`.

---

## What to Notice

1. **Assumptions are falsifiable.** Each one could be proven wrong with evidence — no generic truths like "users want to see their data."
2. **At least one assumption contradicts the obvious interpretation.** Assumption 4 challenges whether users actually want to see all their OKRs on one screen.
3. **EIL is completed** because this is a new capability (OKR management didn't exist before).
4. **Edge cases are enumerated before building**, not discovered during critique.
5. **Peer context names specific patterns adopted AND avoided**, per the anti-gaming rules.

---

## Non-Functional Requirements

- [x] Performance targets defined → `_nfr/PERFORMANCE.yaml` (TTI < 2500ms, render < 16ms)
- [x] Reliability targets defined → `_nfr/RELIABILITY.yaml` (99.9% availability)
- [x] Security requirements defined → `_nfr/SECURITY.yaml` (team-scoped access control)
- [x] Privacy requirements defined → `_nfr/PRIVACY.yaml` (GDPR, data retention)
- [x] All NFR files have status "active"

---

## Spec Interrogation

**Spec source:** Notion Product Spec — "OKR Board"

### Explicit Claims

| Claim | Challenge |
|-------|-----------|
| "Users manage objectives and key results on a board" | What does "board" mean? Kanban columns? List? Grid? The word "board" implies different layouts to different users. |
| "Users can drag to reorder objectives" | Reorder within what scope? Within a team? Across teams? Does reorder persist per user or for the team? |
| "Progress is visible at a glance" | "At a glance" for whom? A team lead with 3 objectives or an exec with 30? The glanceability threshold depends on volume. |

### Implicit Assumptions

| Assumption | What Must Be True | Risk If Wrong |
|------------|-------------------|---------------|
| Teams have fewer than 20 active objectives per cycle | Layout fits on screen without pagination | If teams have 50+ objectives, the flat list becomes unwieldy and we need virtualization or grouping |
| Users access the OKR Board on desktop primarily | Layout optimized for wide viewports | If mobile usage is significant, the expand/collapse pattern needs touch-optimized targets |
| Key Result progress is updated manually | No automation or API integration needed | If teams expect Jira/Linear sync for task-based KRs, manual entry feels like busywork |

### Missing Perspectives

- **Individual contributor view.** The spec describes the team lead's experience but not the IC who only owns 1-2 KRs. Do they need a "My KRs" filter?
- **Cross-team dependencies.** When a KR in Team A depends on an initiative in Team B, neither team's board shows this relationship.
- **Historical comparison.** The spec shows current cycle only. Users reviewing past performance have no way to compare cycles.

### Unsupported Certainty

- "Users want to see all their objectives on one screen" — no evidence provided. This may be true for teams with 5 objectives and false for teams with 15.

### Problem Space Gaps

- **Check-in workflow.** The spec describes the board but not the process of weekly check-ins that update it. Check-ins are the primary input mechanism — the board is the output.
- **Scoring methodology.** The spec assumes a single scoring approach but doesn't define it. This became DEC-002.

### Falsifiable Assumptions

1. **"Expand/collapse is sufficient for OKR boards with up to 20 objectives."** Could be falsified by user testing showing that users lose context when more than 8 objectives are expanded simultaneously.

2. **"Drag-to-reorder is the expected interaction for prioritizing objectives."** Could be falsified by discovering that most users prioritize via numbering or manual sort fields, not spatial reordering.

3. **"Inline progress editing is faster than modal editing for check-in workflows."** Could be falsified by measuring that inline editing causes more accidental edits than modal editing, or that users prefer the deliberateness of a modal during check-ins.

4. **"Users want all objectives visible by default, not filtered to 'needs attention.'"** Could be falsified by analytics showing that the first action most users take is filtering to at-risk items — meaning the default view shows too much.

5. **"Team-scoped boards are the right granularity — not org-wide or individual-scoped."** Could be falsified if users consistently navigate away from the team board to find cross-team context, suggesting the team boundary is too narrow.

---

## Intent Modeling

| Field | Value |
|-------|-------|
| **Problem being solved** | Team leads need a single workspace to create, prioritize, and track their team's objectives and key results within a planning cycle |
| **Output type** | Display + Decision (shows current state, enables prioritization and progress updates) |
| **Scope — in** | Objective CRUD, KR CRUD, KR progress updates, drag-to-reorder, cycle switching, expand/collapse |
| **Scope — out** | Initiative management (SURF-003), check-in submission flow (SURF-005), team membership (SURF-004), cross-team views |
| **Success criteria** | A team lead can create an objective, add 3 key results, update progress on each, and reorder priorities — all without leaving this surface |
| **Audience** | Team leads (primary), team members (secondary — view and update their own KRs) |

---

## Expectation Invention Loop

**Trigger:** Yes — OKR management is a new capability. No prior surface exists.

### Immediate Expectations

| Expectation | Classification | Rationale |
|-------------|---------------|-----------|
| I can create, edit, and delete objectives | build_now | Core CRUD — the surface is meaningless without it |
| I can see how my team is doing overall | build_now | Primary value proposition of the board view |
| I can update KR progress without navigating away | build_now | High-frequency action — DEC-004 |
| I can reorder objectives to show priority | build_now | Explicitly in spec — REQ-006 |
| I can switch between planning cycles | build_now | Teams work in quarterly cycles — REQ-017 |

### Secondary Expectations

| Expectation | Classification | Rationale |
|-------------|---------------|-----------|
| I can see history of changes (who changed what, when) | defer | Valuable but not launch-critical. Planned for v2. |
| I can undo a progress update | defer | Low risk — values are easily re-entered. Planned for v2 with audit log. |
| I can compare this cycle to previous cycle | defer | Requires cycle archive feature. Planned for v3. |
| I can filter to "needs attention" objectives only | build_now | High value, low effort. Filter by health status. |
| I can export the board as a report | defer | Requires report generation infrastructure. Planned after SURF-001 ships. |

### Trust Expectations

| Expectation | Classification | Rationale |
|-------------|---------------|-----------|
| Progress numbers are current and accurate | build_now | Real-time or near-real-time. Stale data destroys trust. |
| I know who last updated each KR | build_now | Provenance for accountability. Shows "Updated by [name], [time ago]". |
| I know the scoring methodology being used | build_now | DEC-002 — visible in UI. Not hidden system behavior. |
| I understand why an objective is "at risk" | build_now | Health status must be explainable — show which KRs are driving the status. |
| Errors are clear when saves fail | build_now | Optimistic updates need visible error recovery. |

### Non-Goals

| False Assumption | Prevention Mechanism |
|------------------|---------------------|
| "This board shows all teams" | Board title shows team name. Sidebar shows team selector. No "all teams" option on this surface (that's SURF-001). |
| "I can manage team members here" | No member management affordances on this surface. Team settings link in sidebar goes to SURF-004. |
| "Dragging objectives between teams is possible" | Drag-to-reorder is vertical only within the current team. No cross-team drop targets. |
| "Deleting an objective deletes its KRs permanently" | Delete action shows confirmation listing affected KRs. Soft delete with 30-day recovery. |

### Cascade Decision Summary

**Build now:** 10 expectations → form the SURF-002 action list
**Defer:** 4 expectations → tracked in Feature Registry as expectation debt
**Prevent:** 4 false assumptions → addressed via UI constraints and copy

**EIL artifact:** `_decisions/eil/okr-management.yaml`

---

## User Expectation Framework

### Peer Context

**Products reviewed:** Asana Goals, Lattice OKRs, Ally.io (now Microsoft Viva Goals), Perdoo

**Pattern adopted:**
- **Inline progress updates** (from Lattice) — click a number, type the new value, save on blur. Fast for users updating multiple KRs in sequence. Adopted because it matches the high-frequency update pattern identified in EIL trust expectations.

**Pattern deliberately avoided:**
- **Kanban columns by status** (from Asana Goals) — objectives displayed as cards in "On Track" / "At Risk" / "Completed" columns. Avoided because OKR health is a derived signal (from KR scores), not a manually-set workflow stage. Dragging an objective to "On Track" column would imply you can manually override health status, which contradicts the truth model where health cascades from KR scores.

### Feature Classification

| Feature | Classification | Rationale |
|---------|---------------|-----------|
| Objective CRUD | Expected | Core — no OKR tool lacks this |
| KR CRUD | Expected | Core — KRs are definitional to OKRs |
| Inline progress editing | Expected | High-frequency action, peer standard |
| Drag-to-reorder | Helpful | Not all peers have this, but users expect spatial prioritization |
| Health status badges | Expected | Every peer shows objective health visually |
| Cycle switching | Expected | All peers support multiple cycles |
| "Needs attention" filter | Helpful | Not all peers have this, but high value at scale |
| Bulk status change | Speculative | No evidence users need this. Reject — individual status changes are sufficient. |
| AI-generated OKR suggestions | Dangerous | Undermines deliberate goal-setting process. Users may accept poor goals. Forbid. |

### Absence Detection

| Category | Check | Present? |
|----------|-------|----------|
| Navigation | Can I get here from the dashboard? | Yes — SURF-001 team card links here |
| Navigation | Can I get back to dashboard from here? | Yes — sidebar logo + breadcrumb |
| Creation | Can I create a new objective? | Yes — "New objective" button |
| Creation | Can I add KRs to an objective? | Yes — "Add key result" within expanded objective |
| Management | Can I edit an existing objective? | Yes — click title to edit inline |
| Management | Can I delete an objective? | Yes — overflow menu → Delete (with confirmation) |
| Understanding | Can I see why something is "at risk"? | Yes — expand objective to see KR-level health |
| Continuity | Can I resume where I left off? | Yes — last viewed team/cycle persists in URL |

### Inner Monologue Test

| Question | Answer |
|----------|--------|
| What is this? | My team's OKR board for the current cycle |
| What can I do? | Create/edit objectives, update KR progress, reorder priorities, filter by health |
| What would I click first? | The objective that needs attention (sorted by health, worst first) |
| What confuses me? | Nothing critical — but if this is my first visit, I need to understand the 0.0–1.0 scoring scale (addressed via tooltip on score display) |
| What builds trust? | Seeing "Updated by [name], 2 hours ago" on each KR — I know the data is current |

---

## Edge Cases

```yaml
edge_cases:
  - empty: "Team has no objectives yet. Show empty state with 'Create your first objective' CTA and brief OKR explanation."
  - error: "Failed to load objectives. Show error banner with retry button. Do not show stale cached data without staleness indicator."
  - loading: "Objectives loading. Show skeleton matching the final layout (rows with expand chevrons). Skeleton delay 100ms per _base.yaml."
  - partial: "Some objectives loaded, others failed. Show loaded objectives normally. Show failed objectives as error rows with individual retry."
  - stale: "WebSocket disconnected. Show subtle 'reconnecting' banner. Do not suppress user actions — queue optimistic updates for sync."
  - denied: "User has read-only access to this team. Hide create/edit/delete actions. Show 'View only' indicator. Do not show disabled buttons."
  - boundary: "Team has 50+ objectives. Virtualize the list. Ensure drag-to-reorder works with virtualization (test explicitly)."
  - concurrent: "Two users editing the same KR progress simultaneously. Last-write-wins with 'Updated by [other user]' toast notification."
```

- [x] Edge cases enumerated for this surface
- [x] Pattern choices accommodate all enumerated cases
- [x] Each case has a documented treatment

---

## Completeness Target

- [x] **Target: Full** — All affordances functional, all flows complete
- Primary flows: Objective CRUD, KR CRUD, progress update, reorder, cycle switch, health filter
- All Gate 5 checklist items apply

---

## Gate 0 Result: **PASS**

All checklists complete. Spec interrogation artifact exists. EIL artifact exists. Intent model defined. Edge cases enumerated. Proceeding to build.
