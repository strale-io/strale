# Flow Design

> How users accomplish jobs — the purposeful sequences across surfaces.

**Gravity:** Strategy & Intent
**Scope:**
  - RESPONSIBLE FOR: Flow anatomy, types, emotional arc, handoff design, abandonment strategy
  - MUST NOT CONTAIN: Surface specs, component details, technical orchestration
  - DECISIONS ALLOWED: Flow structure, step sequence, branching logic, abandonment policy
  - DECISIONS DEFERRED: Surface internals (`_surfaces/`), UI implementation (`_ui/`)

---

## Why Flows Exist in This System

The system's unit of quality is the surface. Gate 0 evaluates a surface. Critique scores a surface. But users don't experience surfaces — they experience flows.

Creating a project in Asana is a 4-step flow spanning multiple surfaces. Setting up a workspace in Notion is a 6-step journey. If each surface is individually excellent but the transitions between them are confusing, the user fails.

Flows sit between Jobs and Surfaces:
Jobs → "Why does this product exist?" (_jobs/)
↓
Flows → "How does the user accomplish the job?"
↓
Surfaces → "Where does each step happen?" (_surfaces/)
↓
Components → "What does the user interact with?" (_ui/)

A Job describes the progress users want to make. A Flow describes the path they take to make that progress. A Surface is a single stop along that path.

---

## What Is a Flow?

A **flow** is a purposeful sequence of interactions across one or more surfaces that accomplishes a user goal. Flows have:

- **A trigger** — what initiates the flow
- **Entry conditions** — what must be true before the flow starts
- **Steps** — ordered interactions, each on a specific surface
- **Branching** — conditional paths based on user input or state
- **Exit conditions** — how the user knows they're done (success and abandonment)
- **An emotional arc** — how the user's emotional state changes across the flow

Flows are not:

- **Navigation paths.** "User can go from A to B" is navigation. Flows describe purposeful sequences with entry, exit, and emotional trajectory.
- **Technical workflows.** API calls, state machines, and data pipelines are engineering concerns, not flow design.
- **Surface specs.** A flow references surfaces (SURF-NNN) but doesn't define what's on them.

---

## Flow Types

| Type | Characteristic | Example | Design Priority |
|------|---------------|---------|-----------------|
| **Linear** | Fixed sequence, no branching | Onboarding wizard, checkout | Momentum — every step propels forward |
| **Branching** | Conditional paths based on input or state | Error recovery, permission-gated features | Clarity — user always knows which path they're on |
| **Cyclical** | Repeats regularly | Weekly check-in, daily review | Efficiency — minimize friction on repeat visits |
| **Exploratory** | No fixed sequence, user navigates freely | Dashboard exploration, report building | Orientation — user always knows where they are |
| **Recovery** | Triggered by failure, goal is to restore good state | Payment retry, conflict resolution | Trust — acknowledge the problem, guide to resolution |

### Choosing a Flow Type

| If the user... | Use |
|----------------|-----|
| Must complete steps in order | Linear |
| Makes a choice that changes the path | Branching |
| Does this regularly (daily/weekly) | Cyclical |
| Browses without a fixed destination | Exploratory |
| Needs to fix something that went wrong | Recovery |

Most real flows are hybrids. An onboarding flow might be primarily linear with a branching step ("Do you want to import data or start fresh?"). Declare the primary type and note hybrid elements.

---

## Flow Anatomy

Every flow follows this structure:
```yaml
flow:
  id: FLOW-NNN
  name: "__FILL__"
  type: __SELECT__                   # linear | branching | cyclical | exploratory | recovery
  job: JOB-NNN                      # Which job this flow serves (from _jobs/REGISTRY.yaml)
  trigger: "__FILL__"               # What initiates the flow
  entry_conditions: "__FILL__"      # What must be true before flow starts
  frequency: __SELECT__             # once | per-cycle | weekly | daily | on-demand | on-failure

  steps:
    - step: 1
      surface: SURF-NNN            # Which surface this step uses
      action: "__FILL__"            # What the user does
      outcome: "__FILL__"           # What changes after this step
      optional: false               # Can user skip this step?
      has_unsaved_progress: false   # Does user create state that could be lost?
      branches:                     # Conditional paths (omit if none)
        - condition: "__FILL__"
          goto: step_N

  exit_conditions:
    success: "__FILL__"             # How the user knows they succeeded
    abandonment: "__FILL__"         # What happens if they quit mid-flow

  emotional_arc:
    start: "__FILL__"               # How user feels entering
    middle: "__FILL__"              # Emotional tension/effort peak
    end: "__FILL__"                 # How user feels after completion
```

See `_flows/REGISTRY.yaml` for the complete schema and `_examples/FLOWS.example.yaml` for a worked example.

---

## Emotional Arc

Every flow has an emotional trajectory. Users arrive in one state and should leave in a better one — even if the flow involves difficult tasks.

### The Emotional Arc Principle

> **Never leave the user in a worse emotional state than when they entered, even if the flow fails.**

A failed payment flow should leave the user understanding what happened and knowing what to do next — not confused and anxious.

### Common Emotional Arcs

| Flow Type | Typical Arc | Design Implication |
|-----------|------------|-------------------|
| **Creation** | Uncertain → Focused → Accomplished | Structure reduces ambiguity early; celebrate completion |
| **Review** | Curious → Informed → Decisive | Present information clearly; enable action from insight |
| **Check-in** | Dutiful → Efficient → Relieved | Minimize friction; confirm completion quickly |
| **Recovery** | Frustrated → Guided → Restored | Acknowledge the problem; guide step by step; confirm resolution |
| **Onboarding** | Overwhelmed → Curious → Capable | Reveal gradually; celebrate first success |

### Writing Emotional Arcs

Be specific. "Good → Good → Good" tells you nothing. "Anxious about getting it wrong → Guided by clear structure → Confident the objective is well-defined" tells you what the UI must do at each stage.

| Stage | Question to Answer |
|-------|-------------------|
| **Start** | What triggers this flow? What is the user feeling when they begin? |
| **Middle** | Where is the peak effort or tension? What might cause doubt or frustration? |
| **End** | What should the user feel when they finish? How do you confirm success? |

---

## Handoff Points

A **handoff point** is where one surface ends and another begins within a flow. These are the highest-risk moments for user confusion.

### What Must Carry Across a Handoff

| Category | Example | If Lost |
|----------|---------|---------|
| **Data context** | The entity the user was working on | User must re-find it |
| **Progress context** | Where they are in the flow | User loses their place |
| **Decision context** | Choices already made | User must re-decide |
| **Emotional context** | The tone/momentum of the experience | Jarring transition |

### Handoff Design Rules

| Rule | Description |
|------|-------------|
| **Context preservation** | Every handoff must declare what information carries forward. If context is lost, it must be justified. |
| **Visual continuity** | Surfaces within the same flow should feel like the same product. Drastic visual changes require re-orientation cost. |
| **Progress indication** | If the flow has 4 steps and the user is on step 3, they should know that — even after a handoff. |
| **Return path** | From any step, the user should be able to go back. One-way handoffs are permitted only with justification. |

### Handoff Quality

| Quality | Definition | When Appropriate |
|---------|------------|-----------------|
| **Seamless** | User barely notices the transition | Steps within the same task |
| **Smooth** | Context preserved, mild re-orientation | Moving between related surfaces |
| **Progressive** | Builds on previous context, adds depth | Drill-down from overview to detail |
| **Jarring** | Context lost, significant re-orientation | Requires justification and design mitigation |

This mirrors the `transition_quality` in `_expectations/PRE-BUILD.md` journey_context. When populating journey_context for a surface, reference the flow's handoff design.

---

## Abandonment Design

What happens when a user quits mid-flow? The system currently has no guidance on this. Every flow must declare its abandonment strategy.

### Abandonment Strategies

| Strategy | What Happens | Best For |
|----------|-------------|----------|
| **Save and resume** | Progress preserved, user can return to exact point | Complex creation flows, multi-session tasks |
| **Save draft** | Partial work saved as draft entity | Content creation, form-heavy flows |
| **Confirm and discard** | User warned, then progress lost | Simple flows where partial state has no value |
| **Auto-save continuous** | Every change saved immediately, no concept of "quitting" | Workspace/editor flows |
| **Graceful exit** | Flow completes with partial result (e.g., objective created without KRs) | Flows where partial completion has value |

### Abandonment Rules

| Rule | Description |
|------|-------------|
| **Declare per step** | Each step with `has_unsaved_progress: true` must have an abandonment strategy |
| **Default is save** | Unless explicitly justified, partial progress should be preserved |
| **No silent loss** | If progress will be lost, the user must be warned (Prediction Contract — PR-001) |
| **Recovery path** | If a user abandons and returns later, they should be able to find their partial work |

### Integration with Contracts

Abandonment design connects to:
- **Continuity Contract** (CN-002): Unsaved work prompts before loss
- **Prediction Contract** (PR-001): Destructive actions show consequences
- **Completion Contract** (CP-001): Multi-step flows show progress

---

## Flow Completeness

A flow is complete when the user can accomplish the full job without leaving the product.

### The Continuity Test

> "Does the user need to leave this product at any step to accomplish the job?"

If yes → the flow has a completeness gap. Document it:
```yaml
completeness_gap:
  step: N
  what_user_does_externally: "__FILL__"
  tool_used: "__FILL__"
  severity: __SELECT__  # critical | acceptable | intentional
  plan: "__FILL__"      # How/when this gap will be closed (or why it won't)
```

### Flow-Level vs. Surface-Level Completeness

| Level | Question | Evaluated By |
|-------|----------|-------------|
| **Surface** | Does this screen have everything it needs? | Gate 0, Critique |
| **Flow** | Does this sequence accomplish the full job? | Flow Gate |
| **Job** | Does the product serve the complete job? | Jobs Completeness Test |

You can have complete surfaces in an incomplete flow. You can have complete flows for an incomplete job. Each level matters independently.

---

## Multi-Flow Interactions

Some surfaces participate in multiple flows. A dashboard might be part of both the "Progress Review" flow and the "Risk Investigation" flow.

### Shared Surface Rules

| Rule | Description |
|------|-------------|
| **Primary flow** | Each surface declares which flow it primarily serves. Other flows are secondary. |
| **No conflicting requirements** | If two flows need contradictory things from the same surface, resolve the conflict explicitly in `_decisions/REGISTRY.md`. |
| **Context-sensitive behavior** | A surface may behave differently depending on which flow the user is in. If so, document the conditions. |

---

## When to Write Flows

### After Jobs, Before Surfaces

The ideal sequence:
1. Define jobs (`_jobs/REGISTRY.yaml`) — what progress users are trying to make
2. Define flows (`_flows/REGISTRY.yaml`) — how they make that progress
3. Define surfaces (`_surfaces/REGISTRY.yaml`) — where each step happens

But like jobs, flows don't need to be perfect before building starts. Back-filling is allowed.

| Product Stage | Flow Expectation |
|--------------|-----------------|
| **Exploration** | Key flows sketched, steps rough |
| **Definition** | Primary flows documented with surfaces assigned |
| **Build** | All flows complete, handoffs designed, abandonment declared |
| **Mature** | Flow completeness evaluated, gaps documented |

---

## What This Module Does NOT Do

- **Does not replace surface-level Gate 0.** Flows are validated at flow level; surfaces still get their own gates.
- **Does not prescribe UI for flow visualization.** Stepper components, progress bars, wizards — those are implementation decisions.
- **Does not model technical orchestration.** API calls, state machines, data pipelines — that's engineering.
- **Does not require all flows before building any surface.** Back-fill is allowed, but the registry must exist.
- **Does not replace journey_context.** It gives journey_context a structured source. When populating `journey_context` for a surface, reference the flow.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_flows/REGISTRY.yaml` | Flow entries |
| `_flows/QUALITY.md` | Flow Gate checklist and critique dimensions |
| `_flows/TEMPLATES.md` | Flow mapping and review tools |
| `_jobs/FRAMEWORK.md` | Jobs that flows serve |
| `_jobs/REGISTRY.yaml` | JOB-NNN references |
| `_surfaces/REGISTRY.yaml` | SURF-NNN references, optional `flows:` field |
| `_expectations/PRE-BUILD.md` | journey_context draws from flow definitions |
| `_expectations/CONTRACTS.md` | Completion Contract references flows |
| `_critique/PROMPT.md` | Flow Continuity critique dimension |
| `_examples/FLOWS.example.yaml` | Beacon worked example |
