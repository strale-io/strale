# Flow Gate

> Flow-level quality evaluation. Runs separately from the numbered gate sequence (Gate 0–8).

**Scope:** Evaluates flows as sequences, not individual surfaces. Fires conditionally — only when a surface participates in a multi-step flow (FLOW-NNN with 2+ steps).

**Relationship to existing gates:**
- Flow Gate evaluates the *journey*: does this sequence accomplish the job?
- Gate 0 evaluates the *surface*: is this screen ready to build?
- They are complementary, not sequential. A surface can pass Gate 0 while the flow it belongs to fails the Flow Gate.

---

## When to Run

| Situation | Run Flow Gate? |
|-----------|---------------|
| Building a surface that participates in a multi-step flow | Yes |
| Building a standalone surface (no flow) | No |
| Adding a new flow to the registry | Yes |
| Reviewing an existing flow after surface changes | Yes |
| Single-surface product | No |

---

## Flow Gate Checklist

For each flow under review:

### Structure (all required)

- [ ] Flow maps to a documented job (JOB-NNN exists in `_jobs/REGISTRY.yaml`)
- [ ] All steps have a surface assignment (SURF-NNN) or are explicitly marked `needs_surface`
- [ ] Entry conditions are specific and testable (not vague like "user wants to do something")
- [ ] Exit conditions include both success and abandonment paths
- [ ] Flow type is declared (linear / branching / cyclical / exploratory / recovery)
- [ ] Frequency is declared (once / per-cycle / weekly / daily / on-demand / on-failure)

### Branching (required if flow has branches)

- [ ] Branch conditions are mutually exclusive (no ambiguous paths)
- [ ] Branch conditions are exhaustive (every possible state is handled)
- [ ] No dead-end branches (every branch resolves to a step or exit)
- [ ] Branch complexity is justified (branches exist because user needs differ, not because design is unresolved)

### Continuity (all required)

- [ ] Handoff points between surfaces specify what context carries forward
- [ ] No jarring transitions without justification and mitigation
- [ ] Progress indication is maintained across steps (user always knows where they are)
- [ ] Return path exists from every step (user can go back) or one-way is justified

### Abandonment (all required)

- [ ] Abandonment strategy declared for each step where `has_unsaved_progress: true`
- [ ] No silent data loss (user warned if progress will be lost)
- [ ] Recovery path exists (user can find partial work if they return later)
- [ ] Default is save, not discard (unless explicitly justified)

### Emotional Coherence (all required)

- [ ] Emotional arc is declared with specific entries (not "good → good → good")
- [ ] Arc accounts for effort peaks and potential frustration points
- [ ] End state is positive even for difficult flows (resolution, not just completion)
- [ ] Failed flows leave user informed and able to act, not confused

### Completeness (all required)

- [ ] Flow covers the full job or gaps are documented with rationale
- [ ] Completeness gaps have severity and plan
- [ ] No step requires user to leave the product without documentation

---

## Flow Critique Dimensions

When evaluating multi-surface builds during critique, add these dimensions to the standard critique card. These fire conditionally — only when the surface under review participates in a multi-step flow.

| Dimension | What to Evaluate | Minimum Score |
|-----------|------------------|---------------|
| **Continuity** | Does context carry across steps without re-orientation? Does the user feel like they're in one journey, not jumping between screens? | 4 |
| **Momentum** | Does each step propel toward completion? Are there stalls where user doesn't know what to do next? Any dead ends in the flow? | 4 |
| **Recovery** | Can the user recover from errors at any step without restarting the entire flow? Is partial progress preserved? | 4 |
| **Completeness** | Does the flow cover the full job, or just part? Are completeness gaps documented and justified? | 3 |
| **Emotional Coherence** | Does the emotional arc feel intentional, not accidental? Does the end state match the declared arc? | 3 |

### Scoring Notes

- **Continuity 4+** means handoffs are smooth, context is preserved, and the flow feels unified.
- **Momentum 4+** means every step has a clear next action, and the user never stalls.
- **Recovery 4+** means errors at any step don't require restarting, and partial progress is safe.
- **Completeness 3+** means the flow covers the primary path; gaps are documented.
- **Emotional Coherence 3+** means the arc is intentional and the end state is positive.

---

## Flow Gate vs. Surface Gates

| Concern | Evaluated By | Example |
|---------|-------------|---------|
| "Does this screen have the right features?" | Gate 0 | Missing edit button |
| "Does this sequence accomplish the job?" | Flow Gate | OKR creation requires external spreadsheet |
| "Do these screens feel like the same product?" | Gate 8 | Terminology mismatch between steps |
| "Does this screen meet quality standards?" | Critique (Gate 2/3) | Poor visual craft |
| "Is the journey emotionally coherent?" | Flow Gate | User left anxious after error recovery |

---

## Related Files

| File | Relationship |
|------|-------------|
| `_flows/FRAMEWORK.md` | Concepts and rules |
| `_flows/REGISTRY.yaml` | Flow entries |
| `_quality/QUALITY_PROTOCOL.md` | Numbered gate sequence (Gate 0–8) |
| `_critique/PROMPT.md` | Standard critique dimensions |
| `_critique/LOOP.md` | Critique cycle mechanics |
| `_expectations/CONTRACTS.md` | Completion, Continuity, Prediction contracts |
