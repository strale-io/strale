# Flow Design Templates

> Tools for designing and reviewing flows. Use these to populate `_flows/REGISTRY.yaml`.

---

## When to Use These Templates

| Situation | Template |
|-----------|----------|
| Designing a new flow from a job | Flow Mapping |
| Reviewing an existing flow for quality | Flow Review Checklist |
| Analyzing where users abandon a flow | Abandonment Analysis |
| Comparing flows across products | Flow Comparison |

---

## Flow Mapping

Use when translating a job (JOB-NNN) into a concrete flow.

### Step 1: Start from the Job
```yaml
flow_source:
  job: JOB-__FILL__
  job_statement: "__FILL__"  # Copy from _jobs/REGISTRY.yaml
  trigger: "__FILL__"         # What event makes the user start this flow?
  end_state: "__FILL__"       # What is true when the flow succeeds?
```

### Step 2: Walk the Happy Path

Write the simplest successful path from trigger to end state. Don't worry about branches yet.
```yaml
happy_path:
  - step: 1
    what_user_does: "__FILL__"
    where: "__FILL__"           # Which surface (existing or new)
    what_changes: "__FILL__"    # System state change
  - step: 2
    what_user_does: "__FILL__"
    where: "__FILL__"
    what_changes: "__FILL__"
  # Continue until end state is reached
```

### Step 3: Identify Branches

For each step, ask: "What could make the user take a different path?"
```yaml
branches:
  - at_step: __FILL__
    condition: "__FILL__"
    what_happens: "__FILL__"
    rejoins_at: __FILL__  # Which step does this branch rejoin? Or does it exit?
```

### Step 4: Design the Emotional Arc
```yaml
emotional_arc:
  entering: "__FILL__"    # What is the user feeling when they start?
  peak_effort: "__FILL__" # Where is the hardest/most uncertain moment?
  completing: "__FILL__"  # What should the user feel when done?
```

### Step 5: Plan Abandonment

For each step where the user creates progress:
```yaml
abandonment:
  - step: __FILL__
    what_would_be_lost: "__FILL__"
    strategy: __SELECT__  # save_and_resume | save_draft | confirm_discard | auto_save | graceful_exit
    recovery: "__FILL__"  # How does the user find their work if they come back?
```

### Step 6: Convert to Registry Entry

Take your answers and fill in the schema from `_flows/REGISTRY.yaml`.

---

## Flow Review Checklist

Use when reviewing an existing flow for quality. This is a lighter version of the Flow Gate — use it for informal reviews during design, and the full Flow Gate for formal evaluation.

### Quick Review (5 minutes)

| Question | Answer |
|----------|--------|
| Can you explain this flow in one sentence? | |
| How many steps to success? | |
| Where might the user get confused? | |
| What happens if they quit halfway? | |
| Does the emotional arc feel right? | |

### Detailed Review (15 minutes)

| Category | Check | Pass? |
|----------|-------|-------|
| **Purpose** | Flow maps to a documented job | |
| **Purpose** | The flow is necessary (job can't be accomplished without it) | |
| **Structure** | Steps are in logical order | |
| **Structure** | No unnecessary steps (each step has a reason) | |
| **Transitions** | Handoffs preserve context | |
| **Transitions** | User always knows where they are in the flow | |
| **Branching** | Branch conditions are clear and exhaustive | |
| **Branching** | No dead ends | |
| **Abandonment** | Partial progress is preserved where possible | |
| **Abandonment** | User is warned before losing work | |
| **Emotion** | Arc is specific and intentional | |
| **Emotion** | End state is positive even for difficult tasks | |
| **Completeness** | Flow covers the full job or gaps are documented | |

---

## Abandonment Analysis

Use when you suspect users are dropping out of a flow and want to understand why.

### For Each Step
```yaml
abandonment_analysis:
  flow: FLOW-__FILL__

  steps:
    - step: __FILL__
      effort_required: __SELECT__  # low | medium | high
      clarity: __SELECT__          # clear | somewhat_clear | confusing
      value_visible: __SELECT__    # yes | partially | no
      abandonment_risk: __SELECT__ # low | medium | high
      if_high_risk: "__FILL__"     # What could reduce this risk?
```

### Common Abandonment Causes

| Cause | Signal | Mitigation |
|-------|--------|-----------|
| **Too many steps** | Users drop off at step 3+ | Combine steps, defer optional ones |
| **Unclear value** | Users don't see why this step matters | Show preview of outcome |
| **High effort** | Step requires significant input | Pre-fill, smart defaults, import |
| **Unclear progress** | Users don't know how far along they are | Add progress indicator |
| **Fear of commitment** | Users worry about irreversible choices | Make everything editable later |
| **External dependency** | Step requires info from outside the product | Let user skip and return |

---

## Flow Comparison

Use when reviewing how different products handle the same job, or comparing alternative flow designs.

### Comparison Template
```yaml
flow_comparison:
  job: "__FILL__"  # The shared job being accomplished

  flows:
    - product: "__FILL__"
      steps: __FILL__  # Count
      time_to_complete: "__FILL__"
      abandonment_points: "__FILL__"  # Where users likely drop off
      strengths: "__FILL__"
      weaknesses: "__FILL__"

    - product: "__FILL__"
      steps: __FILL__
      time_to_complete: "__FILL__"
      abandonment_points: "__FILL__"
      strengths: "__FILL__"
      weaknesses: "__FILL__"

  lessons:
    - "__FILL__"
    - "__FILL__"
```

---

## Related Files

| File | Relationship |
|------|-------------|
| `_flows/FRAMEWORK.md` | Concepts and rules |
| `_flows/REGISTRY.yaml` | Where flows are recorded |
| `_flows/QUALITY.md` | Flow Gate for formal evaluation |
| `_jobs/TEMPLATES.md` | Job discovery feeds flow design |
| `_examples/FLOWS.example.yaml` | Beacon worked example |
