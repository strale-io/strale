# System Contract

> The operating agreement for this documentation system.

---

## Closed World Assumption (Non-Negotiable)

This system operates under a **closed world assumption**.

If a concept, component, layout, token, interaction, or pattern is not explicitly defined in the starter kit, **it is forbidden**.

**Silence is prohibition.**

This applies to:
- Components not in `_ui/components.yaml`
- Tokens not in `_ui/tokens.yaml`
- Layouts not in `_ui/layouts/`
- Primitives not in `_primitives/`
- Interactions not in `_interaction/`
- Archetypes not in `_quality/archetypes/`

The following expansions require explicit amendment via `_decisions/REGISTRY.md`:
- New primitives
- New archetypes
- New component families
- New token categories
- New configuration mechanisms
- New layout zones

**Default behavior:** Compose from existing elements. Do not invent.

---

## Meta-Rules

These rules govern all other files:

1. **Every file defines its scope explicitly.** If not stated, it is prohibited.
2. **Authority collapses upward.** `_rules/laws.yaml` is the single source of non-negotiable law. All other files reference it, never restate it.
3. **One home per concept.** If something is defined in one place, it cannot be redefined elsewhere.
4. **Presets are the only configuration mechanism.** No other file may introduce configuration. The chain loads: `_base.yaml` → `{preset}.yaml` → `_project.yaml`.
5. **Single path to power.** Every capability has exactly one implementation path. Parallel patterns are system violations.

---

## Folder Responsibilities

| Folder | Contains | Authority Level |
|--------|----------|-----------------|
| `_rules/` | Laws (non-negotiable) | Highest |
| `_invariants/` | Absolute truths that must never break | Highest |
| `config/` | Project identity + tech foundation | High |
| `_presets/` | Configuration (overridable) | High |
| `_model/` | Truth (entities, actions, states) | High |
| `_jobs/` | Job hierarchy, traceability, completeness | High |
| `_flows/` | Flow design, emotional arc, handoff, abandonment | High |
| `_surfaces/` | Surface registry and specifications (SURF-NNN) | High |
| `_nfr/` | Non-functional requirements (performance, reliability, security, privacy) | High |
| `_ui/` | Visual system (components, tokens) | Medium |
| `_design-systems/` | Active design system files: contract, tokens, components, patterns, states, visual identity | Medium |
| `_content/` | Product writing governance (microcopy, messages, labels) | Medium |
| `_interaction/` | Behavior laws (focus, motion, disclosure) | Medium |
| `_primitives/` | Implementations conforming to `_interaction/*` | Medium |
| `_quality/` | Verification, archetypes | Medium |
| `_expectations/` | User expectation framework, pre-build exploration, contracts, tests | Medium |
| `_artifacts/` | Artifact-first design, delivery protocol, gate outputs, synthesis | Medium |
| `_critique/` | Review process | Medium |
| `_ia/` | Navigation grammar | Medium |
| `_extensions/` | Product class modules (data, creative, etc.) | Medium |
| `_runs/` | Immutable build logs (RUN-NNN) | Reference |
| `_resilience/` | Cross-cutting failure scenarios and recovery patterns | Medium |
| `_research/` | User research templates (interviews, usability tests, competitive analysis) | Reference |
| `_strategy/` | Competitive advantage and moat guidelines (optional) | Medium |
| `_examples/` | Worked examples using fictional "Beacon" (reference only) | Reference |
| `.claude/` | Operational guidance for AI agents: entry point (`RUNBOOK.md`), task-aware routing (`DISPATCH.yaml`), execution workflow (`WORKFLOW.md`), project management integration (`NOTION.md`), workflow protocol and bootstrap procedure (`PROTOCOL.md`) | Medium |
| `_modes/` | Execution modes | Low |
| `_decisions/` | Decision memory | Reference |
| `handoff/` | Cross-actor session handoffs (from-chat, from-code) | Medium |
| `tasks/` | Ephemeral build-level task tracking | Low |

---

## Boundary Clarifications

**`_interaction/` vs `_primitives/`:**
- `_interaction/*` = laws of behavior (what must be true)
- `_primitives/*` = implementations that conform to those laws

All primitives must comply with `_interaction/PHYSICS.md`, `_interaction/FOCUS.md`, and `_interaction/CHOREOGRAPHY.md`.

---

## Single Path to Power

Every capability has exactly one allowed implementation. Parallel patterns are system violations.

| Capability | Single Allowed Path |
|------------|---------------------|
| Data selection | `data-table` selection model |
| Detail editing | `detail` layout archetype |
| Bulk actions | Table selection → action bar |
| Global navigation | `navigation-shell` primitive only |
| Filtering | `omnibox-filter` primitive only |
| Quick actions | `command-palette` primitive only |
| Overlays | `modal-drawer` primitive only |
| Transient feedback | `toast` component only |
| Configuration | `settings` layout only |
| Multi-step flows | `onboarding` layout only |

If you need a capability not listed, you do not need a new path—you need to extend an existing one via `_decisions/REGISTRY.md`.

---

## Robustness Principles

These principles prevent system decay:

### Deletion Bias

When in doubt:
- **Delete** before adding
- **Merge** before extending  
- **Forbid** before permitting

### Tighten First

Any problem must first be solved by **tightening constraints**, not by adding flexibility. If tightening is insufficient, document why in `_decisions/REGISTRY.md` before loosening.

### Global Reasoning Rule

**If a change makes the system easier to use in the short term but harder to reason about globally, it is invalid.**

This single rule protects against 80% of long-term decay.

---

## Product Class Extensions

This system is optimized for **workflow applications** (Asana/Linear-style products). Other product types require extensions.

### Product Classes

| Class | Optimized For | Loads |
|-------|---------------|-------|
| `workflow_app` | Workflow + data products (default) | Core system only |
| `data_platform` | Complex data structures, time series, pipelines | Core + `_extensions/data/` |
| `creative_tool` | Canvas editors, generative workflows | Core + `_extensions/creative/` |
| `automation_platform` | DAGs, triggers, orchestration UIs | Core + `_extensions/automation/` |
| `observability_tool` | Diagnostics, time-based exploration | Core + `_extensions/observability/` |
| `marketplace` | Asset libraries, discovery, publishing | Core + `_extensions/marketplace/` |

Set in `config/manifest.yaml` via `product_class`.

### Product Class Traits

| Class | Core Traits |
|-------|-------------|
| `workflow_app` | Entities → actions → states, dense tables, permissions, correctness > novelty |
| `data_platform` | Hierarchies + graphs, provenance, lineage, vintages, schema evolution |
| `creative_tool` | Canvas physics, iteration + variants, undo/redo, exploration > efficiency |
| `automation_platform` | DAGs/pipelines, triggers + schedules, logs-as-UI, failure is expected |
| `observability_tool` | Time-based exploration, correlation, investigative UX, read-only power |
| `marketplace` | Assets as products, discovery + preview, trust + social proof, versioned publishing |

### Extension Rules

Extensions are **closed-world modules** with their own CONTRACT.md:
- Extensions do not weaken core system rules
- Extensions are only loaded when `product_class` matches
- Extensions are built when needed, not pre-emptively
- Each extension defines its own primitives, which do not pollute core

### Extension Exceptions

Product class extensions may declare exceptions to core rules in their CONTRACT.md file under "Exceptions to Core Rules."

**Constraints on exceptions:**
- Exceptions must include rationale
- Exceptions apply ONLY when the matching `product_class` is set in `config/manifest.yaml`
- Exceptions cannot override supreme laws (LAW-001 through LAW-008, LAW-011, LAW-012, LAW-013)
- Exceptions to locked rules require explicit rationale in the extension CONTRACT.md
- Workflow UI within any product class (settings, export, permissions) follows core rules — exceptions apply only to class-specific surfaces

See individual extension CONTRACT.md files for declared exceptions.

### Current Extensions

| Extension | Status | Location |
|-----------|--------|----------|
| Data Platform | Active | `_extensions/data/` |
| Creative Tool | Active | `_extensions/creative/` |
| Automation Platform | Active | `_extensions/automation/` |
| Observability Tool | Active | `_extensions/observability/` |
| Marketplace | Active | `_extensions/marketplace/` |

### Extension Status

| Status | Meaning |
|--------|---------|
| `active` | Ready for use, content is complete |
| `draft` | In progress, may have gaps |
| `stub` | Declared but not yet developed — do not use |

Extension status is declared in each extension's CONTRACT.md.

### Capability Extensions

Capability extensions are **cross-cutting modules** that can be activated on any product class. Unlike product class extensions (mutually exclusive), multiple capability extensions can be active simultaneously.

| Extension | Purpose | Location |
|-----------|---------|----------|
| `disclosure` | Progressive disclosure lifecycle design | `_extensions/disclosure/` |
| `collaboration` | Multi-user experience patterns | `_extensions/collaboration/` |
| `intelligence` | Smart feature design framework | `_extensions/intelligence/` |

**Activation:** Add to `capability_extensions` list in `config/manifest.yaml`.

**Loading Order:**
Core System → Product Class Extension → Capability Extensions → Project Overrides

**Rules:**
- Capability extensions cannot override core rules or product class rules
- Capability extensions add guidance; they do not weaken constraints
- Multiple capability extensions can be active simultaneously
- All capability extension checklist items fire conditionally (only when the extension is activated)

---

## Resolution Order

When in conflict:

```
Notion Constitution → laws.yaml → _base.yaml → {preset}.yaml → _project.yaml
```

Higher always wins. No exceptions.

**Note:** Notion Constitution contains project-specific laws that override starter kit defaults. See `.claude/NOTION.md` for details.

---

## AI Context Loading

### From Notion (Project-Specific)

See `.claude/NOTION.md` for database structure and `.claude/PROTOCOL.md` for workflow database definitions.

### From Starter Kit (System-Wide)

See `.claude/DISPATCH.yaml` for task-aware file loading. DISPATCH provides exact file lists per task type with reasons, before/after triggers, and applicable quality gates.

**Rule:** Starter kit defines *how* to build. Notion defines *what* to build.

---

## Evolution Protocol

To change this system:

1. Log decision in `_decisions/REGISTRY.md` with required fields
2. Update single source of truth
3. Remove any now-redundant references
4. Verify no duplication introduced

---

## Appendix: Glossary

| Term | Definition |
|------|------------|
| **Archetype** | Screen category with budgets (workspace, detail, overview, configuration, transient) |
| **Budget** | Hard limit on complexity (decision points, components, actions) |
| **Critique Loop** | Mandatory review cycle: build → critique → patch → verify |
| **Decision Point** | A place where user must choose or act |
| **Deprecation** | Lifecycle state where an element is discouraged for new work, with a named replacement and planned removal version |
| **Exemplar** | Reference example demonstrating quality |
| **Law** | Non-negotiable constraint in `laws.yaml` |
| **One Home Rule** | Every concept defined in exactly one place |
| **Phantom Action** | UI action not defined in `actions.yaml` (forbidden) |
| **Preset** | Configuration bundle; chain: `_base` → `{preset}` → `_project` |
| **Primitive** | Reference implementation conforming to `_interaction/*` laws |
| **P0/P1/P2** | Issue severity: blocks ship / blocks done / backlog |
| **Stop Condition** | Criteria for exiting critique loop |
| **Truth Model** | Authoritative definitions in `_model/truth/` |
