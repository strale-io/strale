# Content Design System

> Governance for product writing — microcopy, messages, labels, and instructional text.

**Authority:** This file governs product writing. It does not govern long-form documentation, marketing copy, or help center content. It governs the words inside the product UI.

**Relationship to voice:** `config/manifest.yaml` declares the product voice (emotional register, vocabulary level). This file provides rules for executing that voice in specific UI contexts.

---

## Purpose

Product writing is design material, not decoration. The words in a UI carry the same design weight as layout, color, and motion. Bad copy in a well-designed UI creates the same friction as bad spacing in well-written copy.

**The standard:** Every piece of product text should pass the First Encounter Test (from vocabulary governance): Can an intelligent, motivated new user understand it immediately or find explanation without leaving the surface?

---

## Content Principles

### 1. Clarity Over Cleverness

| Prefer | Avoid |
|--------|-------|
| "Project created" | "You’re all set\!" |
| "3 tasks remaining" | "Almost there\!" |
| "Could not save. Try again." | "Oops\! Something went wrong." |

**Rule:** Users scan UI text in milliseconds. Every word must earn its place.

### 2. Specific Over Generic

| Prefer | Avoid |
|--------|-------|
| "Enter your company name" | "Enter a value" |
| "No projects match your filter" | "No results found" |
| "Saved 2 seconds ago" | "Changes saved" |

**Rule:** Generic text forces the user to infer context. Specific text provides it.

### 3. Action-Oriented Over Descriptive

| Prefer | Avoid |
|--------|-------|
| "Create project" | "Project creation" |
| "Export as PDF" | "PDF export" |
| "Invite team members" | "Team invitation" |

**Rule:** Buttons and CTAs use verbs. Headings may use nouns. Labels describe; actions command.

### 4. Honest Over Reassuring

| Prefer | Avoid |
|--------|-------|
| "This will permanently delete 3 projects" | "Are you sure?" |
| "This may take up to 2 minutes" | "Loading..." |
| "You don’t have permission. Contact your admin." | "Something went wrong" |

**Rule:** Users trust products that tell the truth, even when the truth is uncomfortable. False reassurance ("Don’t worry!") undermines confidence.

### 5. Consistent Over Creative

| Prefer | Avoid |
|--------|-------|
| Same action label everywhere ("Create", not sometimes "Add" or "New") | Varying synonyms across surfaces |
| Same error structure everywhere | Different error formats per screen |
| Same empty state pattern everywhere | Unique empty states per surface |

**Rule:** Consistency builds muscle memory. Variation forces re-learning.

---

## Voice Execution

### Mapping Manifest Voice to Writing

The product voice in `config/manifest.yaml` declares emotional register, density posture, interaction philosophy, and vocabulary level. Here’s how each maps to writing:

| Voice Setting | Writing Impact |
|---------------|---------------|
| **emotional_register: confident** | Direct statements, no hedging. "Your project is ready." not "Your project should be ready now." |
| **emotional_register: welcoming** | Warmer phrasing, inclusive pronouns. "Let’s set up your first project." |
| **emotional_register: neutral** | Factual, no emotional coloring. "3 items selected." |
| **emotional_register: urgent** | Action-first, minimal preamble. "Review now — approval expires in 2 hours." |
| **density_posture: dense** | Shorter labels, abbreviations where standard (e.g., "qty", "avg"). |
| **density_posture: moderate** | Full words, concise sentences. |
| **density_posture: sparse** | Complete sentences, explanatory text inline. |
| **vocabulary_level: technical** | Domain terms used directly, no simplification. |
| **vocabulary_level: intermediate** | Domain terms with contextual explanation. |
| **vocabulary_level: simplified** | Plain language, all jargon has tooltips. |

### Contextual Shifts

When `manifest.yaml` declares contextual voice shifts (e.g., onboarding → welcoming), writing shifts accordingly. The writing rules in this file apply at every register — only tone changes, not clarity or honesty standards.

---

## Content Types

### Labels

UI labels for fields, sections, navigation items, and controls.

| Rule | Example |
|------|---------|
| Use sentence case, not title case | "Project settings" not "Project Settings" |
| No trailing punctuation | "Status" not "Status:" |
| Keep under 3 words where possible | "Due date" not "Expected completion date" |
| Match vocabulary.yaml exactly | If registry says "Project", never use "Workspace" |

**Template:**
```yaml
label_audit:
  label: "__FILL__"
  surface: "SURF-__FILL__"
  vocabulary_match: __SELECT__   # yes | no — cross-check vocabulary.yaml
  word_count: __FILL__
  case: __SELECT__               # sentence | title — must be sentence
```

### Buttons & CTAs

Action triggers — the most critical product text.

| Rule | Example |
|------|---------|
| Start with verb | "Create project", "Save changes", "Export report" |
| Be specific about what happens | "Delete 3 items" not "Delete" |
| Primary CTA is the desired action | "Send invitation" not "OK" |
| Destructive actions name the consequence | "Permanently delete" not "Remove" |
| Cancel is always available (not as primary) | "Cancel" label, never "No" or "Go back" |

**Button copy formula:**
[Verb] + [Object] + [Qualifier if needed]

Examples: "Create project", "Save draft", "Export as CSV", "Delete 3 tasks permanently"

### Error Messages

When something goes wrong.

**Structure:**
[What happened] + [Why it happened, if known] + [What to do next]

| Component | Required? | Example |
|-----------|-----------|---------|
| What happened | Yes | "Could not save your changes" |
| Why | If known | "The server is temporarily unavailable" |
| What to do | Yes | "Try again in a few minutes, or contact support" |

**Error copy rules:**

| Rule | Rationale |
|------|-----------|
| Never blame the user | "Invalid email" → "Enter a valid email address (e.g., name@company.com)" |
| Never use technical jargon in user-facing errors | "500 Internal Server Error" → "Something went wrong on our end" |
| Always provide a next step | Users need escape, not just diagnosis |
| Use the same structure everywhere | Consistency reduces panic |
| Never use "Oops", "Uh oh", or false friendliness | These trivialize the user’s frustration |

**Error severity mapping:**

| Severity | Tone | Example |
|----------|------|---------|
| Blocking (can’t proceed) | Direct, urgent | "Could not save. Your changes are preserved locally. Try again." |
| Warning (can proceed, risk) | Informative, cautious | "This will remove access for 3 team members." |
| Info (FYI, no action needed) | Neutral, brief | "Synced 30 seconds ago" |

### Empty States

When there’s no data to show.

**Structure:**
[What belongs here] + [Why it’s empty, if useful] + [How to populate it]

**Empty state rules:**

| Rule | Rationale |
|------|-----------|
| Name what’s missing, not that it’s empty | "No projects yet" not "Nothing to show" |
| Include a create action if the user can create | CTA is part of the empty state |
| Match the surface’s emotional register | Onboarding empty state is welcoming; admin empty state is neutral |
| Never use stock illustrations without purpose | Illustration must reinforce the message, not fill space |

**Empty state template:**
```yaml
empty_state:
  surface: "SURF-__FILL__"
  entity_missing: "__FILL__"
  heading: "__FILL__"           # What belongs here (e.g., "No projects yet")
  body: "__FILL__"              # Context or encouragement (optional)
  cta_label: "__FILL__"         # Action to populate (e.g., "Create project")
  cta_action: "__FILL__"        # What the CTA does
  emotional_register: __SELECT__ # Must match surface register
```

### Confirmation Dialogs

Before irreversible or high-impact actions.

**Structure:**
[Specific consequence] + [Scope of impact] + [Confirm / Cancel]

**Rules:**

| Rule | Example |
|------|---------|
| Name the specific consequence | "Permanently delete ‘Q3 Report’ and all its contents" |
| Quantify impact when possible | "This will affect 12 team members" |
| Confirm button matches the action verb | "Delete project" not "OK" or "Yes" |
| Cancel is always the safe default | Cancel button gets default focus |

**Never use:**
- "Are you sure?" (alone — always add what happens)
- "OK / Cancel" (use action verb / Cancel)
- "Yes / No" (ambiguous)

### Tooltips & Help Text

In-context explanation.

| Rule | Rationale |
|------|-----------|
| Explain, don’t repeat the label | If label says "Priority", tooltip explains *what priority means*, not "Set the priority" |
| Under 2 sentences | Tooltips are glanceable, not documentation |
| Include example where helpful | "e.g., marketing@company.com" |
| Only appear when term is non-obvious | Obvious labels don’t need tooltips (see VO-001) |

### Notifications & Alerts

In-product messages about events.

**Structure:**
[Who] + [did what] + [to what] + [when, if relevant]

Examples: "Alex commented on ‘Q3 Report’ — 2 min ago", "Build completed — 3 errors found"

**Rules:**
- Actor first (who did it)
- Specific action (not "updated" for everything)
- Link to source (deep link, not just notification center)
- Respect `_extensions/collaboration/NOTIFICATIONS.md` rules if collaboration extension active

### Loading & Progress Text

While the user waits.

| Duration | Text Strategy |
|----------|---------------|
| < 1s | No text (loading indicator only) |
| 1-5s | Brief status ("Loading projects...") |
| 5-30s | Specific progress ("Importing 24 of 150 records...") |
| > 30s | Progress + estimate ("About 2 minutes remaining...") |

**Rules:**
- Use present participle for ongoing ("Saving..." not "Save in progress")
- Be specific when possible ("Uploading 3 files" not "Processing...")
- Never show false progress (if you don’t know %, don’t show %)

---

## Content Quality Checklist

Run this for every surface before critique:
```yaml
content_quality:
  surface: "SURF-__FILL__"

  checks:
    vocabulary_match: __SELECT__         # yes | no — all terms match vocabulary.yaml
    first_encounter_pass: __SELECT__     # yes | no — all terms pass First Encounter Test
    error_messages_complete: __SELECT__  # yes | no — all errors have what/why/what-next
    empty_states_complete: __SELECT__    # yes | no — all empty states have heading/body/cta
    buttons_verb_first: __SELECT__       # yes | no — all CTAs start with verb
    no_generic_text: __SELECT__          # yes | no — no "Something went wrong", "No results"
    voice_match: __SELECT__              # yes | no — text matches manifest.yaml voice
    confirmation_specific: __SELECT__    # yes | no — all confirmations name consequences
```

---

## Anti-Patterns

| Anti-Pattern | Problem | Fix |
|-------------|---------|-----|
| **"Something went wrong"** | User has no idea what happened or what to do | Name the error and provide next step |
| **"Are you sure?"** | User has no idea what they’re confirming | Name the specific consequence |
| **"OK / Cancel"** | Ambiguous — OK to do what? | Use action verb for confirm button |
| **"No results found"** | Doesn’t help the user fix their search | "No projects match [filter]. Try adjusting your filters." |
| **Oops/Uh oh/Whoops** | False friendliness trivializes frustration | Direct, honest language |
| **"Click here"** | Meaningless link text, accessibility problem | "View project details" |
| **Title Case Everything** | Looks like a newspaper headline, not a product | Sentence case for labels and headings |
| **Varying action labels** | "Create" on one screen, "Add" on another, "New" on a third | Pick one verb per action, use everywhere |

---

## Related Files

| File | Relationship |
|------|-------------|
| `config/manifest.yaml` | Voice configuration (emotional register, vocabulary level) |
| `_model/truth/vocabulary.yaml` | Terminology authority |
| `_expectations/PRE-BUILD.md` | Copy-First Gate (write before layout for trigger surfaces) |
| `_critique/PROMPT.md` | Vocabulary dimensions in critique |
| `_extensions/collaboration/NOTIFICATIONS.md` | Notification content rules (if active) |
