# Content Patterns

> Reusable writing patterns for common UI situations.

**Authority:** This file provides templates. `_content/SYSTEM.md` provides rules. When in doubt, rules win.

---

## Error Message Patterns

### Validation Error (Inline)
[Field label]: [What's wrong]. [How to fix].

Examples:
- "Email: Enter a valid email address (e.g., name@company.com)"
- "Password: Must be at least 8 characters"
- "Name: Required"

### Action Error (Toast/Banner)
Could not [action]. [Reason, if known]. [Next step].

Examples:
- "Could not save changes. Server temporarily unavailable. Try again in a few minutes."
- "Could not send invitation. Email address not found. Check the address and try again."
- "Could not delete project. You don't have permission. Contact your workspace admin."

### System Error (Full Screen or Modal)
[Problem summary]
[Brief explanation — 1-2 sentences]
[Primary action: retry or navigate away]
[Secondary action: contact support or view details]

---

## Empty State Patterns

### First-Use (Nothing Created Yet)
[Heading: Name what belongs here]
[Body: Brief value statement — why create one?]
[CTA: Create action]

Example:
No projects yet
Projects help you organize tasks and track progress across your team.
[Create your first project]

### Filtered-Empty (Data Exists, Filter Excludes)
[Heading: No matches for current filter]
[Body: Suggest adjusting]
[CTA: Clear filters]

Example:
No tasks match your filters
Try adjusting the status or assignee filters, or clear all filters to see everything.
[Clear filters]

### Permission-Empty (Data Exists, No Access)
[Heading: State what they can't access]
[Body: Who to contact]

Example:
You don't have access to this project
Contact [admin name] to request access.

---

## Confirmation Patterns

### Destructive (Irreversible)
[Heading: Action + specific target]
[Body: What will be lost — quantified]
[Confirm: Action verb matching heading]
[Cancel: "Cancel"]

Example:
Delete "Q3 Marketing Report"
This will permanently delete the report and its 24 attachments. This action cannot be undone.
[Delete report]  [Cancel]

### High-Impact (Reversible But Significant)
[Heading: Action + scope]
[Body: Who/what is affected]
[Confirm: Action verb]
[Cancel: "Cancel"]

Example:
Archive 7 completed projects
These projects will move to your archive. Team members will lose quick access but can still find them in archived items.
[Archive projects]  [Cancel]

---

## Success Patterns

### Inline Success (Quick Confirmation)
[Action] completed.

Examples:
- "Changes saved"
- "Invitation sent to alex@company.com"
- "3 tasks moved to 'In Progress'"

**Rule:** Success messages are brief. The product returning to its normal state is the primary confirmation.

### Milestone Success (Significant Achievement)
[What was accomplished]
[What this enables — optional, 1 sentence]
[Next step — optional CTA]

Example:
Project published
Your team can now access the project at its shared link.
[Copy link]  [Go to project]

---

## Placeholder Text Patterns

### Input Placeholders
[Example of expected input]

Examples:
- "e.g., Q3 Marketing Campaign"
- "Search by name or email..."
- "https://example.com"

**Rules:**
- Use "e.g.," prefix for examples
- Use "..." suffix for search fields
- Never use placeholder as label (accessibility violation)

### Loading Placeholders

| Duration | Pattern |
|----------|---------|
| Brief (< 1s) | Skeleton screen, no text |
| Moderate (1-5s) | "[Verb]ing [object]..." (e.g., "Loading projects...") |
| Extended (5-30s) | "[Verb]ing [N] of [Total] [objects]..." |
| Long (> 30s) | "[Progress details]. About [time] remaining." |

---

## Instructional Text Patterns

### Onboarding Steps
[Step heading — action-oriented]
[1-2 sentences explaining why this matters]
[Input/action area]
[Help text if needed — under the input, not in tooltip]

### Feature Discovery
[What's new — specific feature name]
[What it does — 1 sentence]
[Try it — optional CTA]
[Dismiss — always available]

**Rules:**
- Never block the user's current task
- Always dismissable
- Max 1 feature discovery per session
- Respects `_extensions/disclosure/` lifecycle stages if active

---

## Related Files

| File | Relationship |
|------|-------------|
| `_content/SYSTEM.md` | Rules that govern these patterns |
| `_ui/states.md` | Visual design of error/empty/loading states |
| `_interaction/PROGRESSION.md` | Progressive disclosure mechanics |
