# Moat Guidelines

> Structural deterrences to competition through product design.

**Purpose:** Provide product and engineering guidelines that increase structural defensibility over time.

**Non-goal:** This document is not a strategy deck. It is an execution constraint.

---

## Core Principle

> Moats should come from value creation, not value extraction.

| Acceptable | Questionable |
|------------|--------------|
| Value that compounds for user | Artificial friction to leave |
| Genuine network effects | Data hostage (hard to export) |
| Deep integration that helps | Lock-in through obscurity |
| Institutional memory | Manufactured dependency |

**Rule:** If a moat mechanism would embarrass you when explained to the user, don't build it.

---

## Definitions

### Moat

A structural deterrence to competition created by:
- Compounding advantages that improve with usage/time
- Switching costs embedded in workflows/contracts/integrations
- Proprietary know-how encoded into the product's behavior
- Economies of scale or data advantages that improve value

### Moat-Building Rule

**Prefer** features and architectural choices that:
- Increase long-term user retention through genuine value
- Increase trust, reliability, and integration depth
- Create compounding improvements (quality improves with usage)

**Avoid** features that:
- Inflate scope without compounding value
- Create support burden disproportionate to defensibility
- Rely on temporary novelty or trend-driven differentiation
- Create artificial switching costs without user benefit

---

## Moat Types

### 1. Special Know-how (High Priority)

**Definition:** Proprietary workflows and encoded judgment that competitors cannot copy without rebuilding fundamentals.

**Product Levers:**

| Lever | Implementation |
|-------|----------------|
| Encode expert judgment into rules + defaults | Opinionated defaults, not blank slates |
| Build a "decision memory" layer | Track why, not just what (see `_decisions/`) |
| Create feedback loop from usage | System improves as user invests |
| Reduce degrees of freedom | Be opinionated where it matters |

**Checklist:**
- [ ] Does the product encode domain judgment in deterministic rules?
- [ ] Are key decisions stored with rationale and context?
- [ ] Can the system surface "what experts do here" in-context?
- [ ] Are we avoiding generic, commodity feature sets?

**Anti-Patterns:**
- Pure CRUD with a pretty UI
- Unlimited customization with no opinionated defaults
- No institutional memory (decisions without rationale)

---

### 2. System Rigidity (High Priority)

**Definition:** The product becomes structurally central; replacing it requires coordinated migration.

**Product Levers:**

| Lever | Implementation |
|-------|----------------|
| Make product the canonical source of truth | Single source, no shadow systems |
| Version everything | History and rollback are first-class |
| Provide stable export schemas | Downstream systems depend on outputs |
| Integrate into workflows | CI checks, automation, approvals |
| Make drift visible and painful | Users detect inconsistency immediately |

**Checklist:**
- [ ] Is there a canonical artifact that other systems consume?
- [ ] Is versioning immutable and auditable?
- [ ] Are exports stable and treated as contracts?
- [ ] Are integrations designed as dependencies, not conveniences?
- [ ] Can users detect drift immediately?

**Anti-Patterns:**
- Allowing partial truth in multiple places
- Silent auto-corrections that undermine trust
- Exports that change format frequently
- Breaking changes to schemas without migration path

---

### 3. Scale (Selective)

**Definition:** Not "more users" — scale is value that compounds or costs that decrease with usage.

**Three Mechanisms:**

| Mechanism | Meaning |
|-----------|---------|
| **Increasing unit value** | Product becomes more valuable as usage deepens |
| **Decreasing unit costs** | Support/compute costs fall with maturity |
| **Variance reduction** | Users can act with confidence; risk cost declines |

**Product Levers:**

| Lever | Implementation |
|-------|----------------|
| Deeper adoption unlocks disproportionate value | Compounding features |
| Reduce operational variance | Deterministic behavior, predictable exports |
| Make critical workflows fast, safe, repeatable | Reliability builds trust |
| Instrument quality | Defects detected early |

**Checklist:**
- [ ] Does value increase as the customer uses it more deeply?
- [ ] Can we operate at near-zero marginal support cost?
- [ ] Are outputs deterministic and reproducible?
- [ ] Are there explicit quality gates and automated tests?

**Anti-Patterns:**
- Feature breadth without depth
- Manual support as default
- Unbounded compute costs per user action
- Non-deterministic outputs in trust-critical paths

---

### 4. State Granted (Usually N/A)

**Definition:** Regulatory barriers, licensing, patents, standards capture.

**Guideline:** Do not rely on State Granted moats unless the product is explicitly compliance-native (healthcare, finance, legal).

If relevant:
- Treat compliance as an output artifact (audit bundles, certifications)
- Make compliance measurable and exportable
- Do not use legal complexity as product complexity

**For most products:** Skip this category.

---

## Moat Tests

Run these tests to evaluate moat contribution:

| Test | Question | Pass Criteria |
|------|----------|---------------|
| **Compounding Test** | Does this feature become more valuable with usage? | Value increases over time |
| **Replaceability Test** | How hard to recreate this value elsewhere? | Significant effort required |
| **Integration Test** | Does this create dependencies others rely on? | External systems consume outputs |
| **Memory Test** | Does this accumulate context lost if user left? | History/decisions would be lost |

---

## Moat Maturity Model

| Level | Description | Indicators |
|-------|-------------|------------|
| **0 - None** | Product is commodity; easily replaced | No switching friction |
| **1 - Emerging** | Some features create switching friction | Users would notice leaving |
| **2 - Established** | Clear moat in one category | Competitors can't easily replicate |
| **3 - Compounding** | Multiple moats reinforcing each other | Moats strengthen each other |
| **4 - Structural** | Leaving requires fundamental workflow change | Deeply embedded |

---

## Feature Assessment

### Moat Contribution Classification

Every feature has a moat contribution:

| Classification | Definition |
|----------------|------------|
| **Moat-Building** | Creates structural advantage (switching cost, compounding value, integration) |
| **Moat-Neutral** | Useful but doesn't affect competitive position |
| **Moat-Undermining** | Makes product easier to leave or replicate |

### Decision Matrix

Combine with Feature Classification from `_expectations/FRAMEWORK.md`:

| Feature Type | Moat-Building | Moat-Neutral | Moat-Undermining |
|--------------|---------------|--------------|------------------|
| **Expected** | ✅ Build (ideal) | ✅ Build | ✅ Build (reconsider design) |
| **Helpful** | ✅ Prioritize | ⚖️ Evaluate | ❌ Reject or redesign |
| **Speculative** | ⚖️ Consider | ❌ Reject | ❌ Reject |
| **Dangerous** | ❌ Forbidden | ❌ Forbidden | ❌ Forbidden |

**Key insight:** Expected features must be built regardless of moat contribution. Moat thinking influences prioritization and design, not whether to build Expected features.

---

## Connection to Value Loops

Value loops (`_jobs/VALUE_LOOPS.md`) are the operational mechanism behind moats:

| Loop Type | Moat Type |
|-----------|-----------|
| Data Loop | Special Know-how (accumulated context) |
| Learning Loop | Special Know-how (encoded judgment) |
| Integration Loop | System Rigidity (structural centrality) |
| Network Loop | Scale (compounding user value) |

**Implication:** If you can't identify which value loops your product feeds, your moat claims are aspirational, not structural. Map loops first, then assess moat maturity.

---

## Connection to Artifacts

Synthesis Artifacts (LAW-013) are inherently moat-building:

| Artifact Property | Moat Type |
|-------------------|-----------|
| Canonical output | System Rigidity |
| Decision history | Special Know-how |
| Quality standards | Scale (variance reduction) |
| Stable export format | System Rigidity |

**Implication:** Building good artifacts automatically builds moats.

---

## How Claude Should Apply This

### During Pre-Build

If moat-conscious preset is active, add stickiness assessment to Pre-Build flow:

- [ ] Does this feature create value that compounds with usage?
- [ ] Does this feature increase switching costs (integration, data, workflow)?
- [ ] Does this feature contribute to institutional memory?
- [ ] Does this feature undermine any existing moat? (If yes, justify)

### During Implementation

1. Prefer deterministic systems over probabilistic behavior in trust-critical paths
2. Avoid adding freeform customization unless governance exists
3. Treat exports and schemas as contracts; avoid breaking changes
4. Add automated tests for any logic that affects user trust
5. Flag any feature that weakens moat priorities with explicit warning

### During Review

Check for:
- Features that undermine existing moats (requires justification)
- Missed opportunities to strengthen moats
- Breaking changes to export formats
- Loss of decision rationale

---

## Severity Levels

| Severity | Condition |
|----------|-----------|
| **P1** | Feature undermines existing moat without justification |
| **P1** | Breaking change to export format without migration path |
| **P2** | Feature misses clear opportunity to strengthen moat |
| **P2** | Decision made without capturing rationale |

---

## Related Invariants

| ID | Invariant | Severity |
|----|-----------|----------|
| MT-001 | Features that undermine existing moats require explicit justification | P1 |
| MT-002 | Moat-building claims are testable, not marketing | P2 |
| MT-003 | Export formats are treated as contracts (no breaking changes without migration) | P1 |
| MT-004 | Decision rationale is captured (institutional memory) | P2 |

---

## Project Configuration

Declare moat priorities in `_strategy/priorities.yaml` or enable via `moat-conscious` preset.

**Not every project needs moat thinking.** Simple tools, internal utilities, and experiments can skip this. Enable when building products intended for long-term competitive positioning.
