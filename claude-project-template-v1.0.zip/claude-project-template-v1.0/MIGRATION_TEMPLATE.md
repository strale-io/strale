# Migration Guide: v__FILL__ → v__FILL__

> Template for documenting version migrations. Copy and customize per release.

---

## Overview

| Field | Value |
|-------|-------|
| **From Version** | v__FILL__ |
| **To Version** | v__FILL__ |
| **Release Date** | __FILL__ |
| **Migration Effort** | __FILL__ (trivial | low | medium | high) |
| **Breaking Changes** | __FILL__ (yes | no) |

---

## Summary of Changes

### New Features

- __FILL__

### Breaking Changes

- __FILL__

### Deprecations

- __FILL__

### Removals

- __FILL__

### Bug Fixes

- __FILL__

---

## Pre-Migration Checklist

- [ ] Backup current project
- [ ] Review breaking changes below
- [ ] Identify affected files in your project
- [ ] Schedule migration window

---

## Migration Steps

### Step 1: __FILL__

**What changed:** __FILL__

**Action required:**

```diff
- old code or config
+ new code or config
```

**Verification:** __FILL__

---

### Step 2: __FILL__

**What changed:** __FILL__

**Action required:**

```diff
- old code or config
+ new code or config
```

**Verification:** __FILL__

---

### Step 3: __FILL__

**What changed:** __FILL__

**Action required:**

```diff
- old code or config
+ new code or config
```

**Verification:** __FILL__

---

## New Files to Create

| File | Purpose | Template |
|------|---------|----------|
| __FILL__ | __FILL__ | __FILL__ |

---

## Files to Modify

| File | Change |
|------|--------|
| __FILL__ | __FILL__ |

---

## Files to Delete

| File | Reason |
|------|--------|
| __FILL__ | __FILL__ |

---

## Configuration Changes

### config/manifest.yaml

```yaml
# New fields
__FILL__: __FILL__

# Changed fields
# Was: __FILL__
# Now: __FILL__
```

### _presets/{preset}.yaml

```yaml
# New fields
__FILL__: __FILL__
```

---

## Decision Registry Entries

New decisions to add:

```yaml
- id: DEC-__FILL__
  decision: "__FILL__"
  date: __FILL__
  owner: "__FILL__"
  context: "__FILL__"
  chosen: "__FILL__"
  rejected:
    - "__FILL__"
  stability: __FILL__
  references: [__FILL__]
```

---

## Post-Migration Verification

- [ ] All YAML files pass lint
- [ ] No references to removed files
- [ ] Gate 0 checklist passes
- [ ] Drift Detection checklist passes
- [ ] No broken cross-references

---

## Rollback Procedure

If migration fails:

1. __FILL__
2. __FILL__
3. __FILL__

---

## Known Issues

| Issue | Workaround | Fix Expected |
|-------|------------|--------------|
| __FILL__ | __FILL__ | __FILL__ |

---

## FAQ

### Q: __FILL__?

A: __FILL__

### Q: __FILL__?

A: __FILL__

---

## Support

If you encounter issues during migration:
1. Check known issues above
2. Review CHANGELOG.md for detailed change descriptions
3. Consult `_decisions/REGISTRY.md` for decision rationale
