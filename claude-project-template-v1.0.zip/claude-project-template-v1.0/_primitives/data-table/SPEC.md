# Data Table Specification

> The workhorse of data-heavy applications.

**Compliance:** Must conform to `_interaction/PHYSICS.md` and `_interaction/FOCUS.md`.

---

## Purpose

The data table is where "almost great" products fall apart. It's the most-viewed component in B2B applications and requires:

- Performance under scale
- Consistent interaction patterns
- Complex accessibility support
- Flexible configuration

---

## Visual Structure

```
┌────┬────────────────────────┬──────────┬──────────┬─────────┬────┐
│ □  │ Name ▼                 │ Status   │ Owner    │ Updated │    │ ← Header
├────┼────────────────────────┼──────────┼──────────┼─────────┼────┤
│ □  │ Project Alpha          │ ● Active │ @jane    │ 2h ago  │ ⋮  │ ← Row
│ □  │ Project Beta           │ ○ Draft  │ @john    │ Jan 12  │ ⋮  │
│ ■  │ Project Gamma          │ ● Active │ @jane    │ Jan 10  │ ⋮  │ ← Selected
│ □  │ Project Delta          │ ○ Draft  │ @alex    │ Jan 8   │ ⋮  │
└────┴────────────────────────┴──────────┴──────────┴─────────┴────┘
     ↑ Selection               ↑ Sortable              ↑ Actions
```

---

## Dimensions

| Density | Row Height | Use Case |
|---------|------------|----------|
| Compact | 36px | Power users, maximum data density |
| Comfortable | 44px | Default, balanced readability |
| Spacious | 56px | Less experienced users, touch |

**Token references:**
- `dimensions.table.row_height_compact`
- `dimensions.table.row_height_comfortable`
- `dimensions.table.row_height_spacious`
- `dimensions.table.header_height` (40px)
- `dimensions.table.cell_padding_x` (16px)
- `dimensions.table.cell_padding_y` (12px)

---

## Column Types

### Text Column
- Left aligned
- Truncate with ellipsis
- Tooltip on truncation

### Number Column
- Right aligned
- Tabular figures for alignment
- Format with locale (commas, decimals)

### Date Column
- Relative when recent ("2h ago")
- Absolute when older ("Jan 15, 2025")
- Tooltip with full datetime

### Status Column
- Badge component
- Semantic colors
- Icon + text or icon only

### User Column
- Avatar + name
- Truncate name, not avatar
- Tooltip with full name/email

### Actions Column
- Right aligned
- Icon button or dropdown
- Always last column

### Selection Column
- Checkbox
- Always first column
- Header checkbox for select all

---

## Features

### Sorting

**Visual:**
- Active sort: Column header bold + arrow icon
- `▲` ascending, `▼` descending
- Hover: Shows sort affordance

**Behavior:**
- Single column sort (default)
- Click header to sort ascending
- Click again to sort descending
- Click again to clear sort
- Server-side for large datasets

**Keyboard:**
- `Enter` on focused header toggles sort

### Selection

**Visual:**
- Checkbox column (first)
- Selected row: `colors.interactive.selected` background
- Header checkbox: Select all visible / all matching

**Behavior:**
- Click checkbox: Toggle selection
- Click row: Navigate to detail (not select)
- Shift+click: Range selection
- Cmd/Ctrl+click: Add to selection

**Bulk Actions:**
- Appear when ≥1 selected
- Sticky bar at bottom
- Show count: "3 selected"
- Clear selection button

### Column Resizing

**Visual:**
- Drag handle on column border
- Cursor: `col-resize`
- Visual feedback during drag

**Behavior:**
- Minimum width: 80px
- Double-click: Auto-fit content
- Persist widths to localStorage

### Column Reordering

**Visual:**
- Drag column header
- Drop indicator between columns
- Ghost of column during drag

**Behavior:**
- Selection and actions columns: Not movable
- Persist order to localStorage

### Sticky Header

**Behavior:**
- Header sticks on vertical scroll
- Shadow appears when scrolled
- z-index: `z_index.sticky`

### Virtualization

**Trigger:** >100 rows

**Behavior:**
- Render only visible rows + buffer
- Maintain scroll position
- Preserve selection state
- Smooth scrolling

---

## States

### Loading (Initial)
```
┌────┬─────────────────────┬──────────┬──────────┐
│    │ ████████████        │ ████     │ ████     │
├────┼─────────────────────┼──────────┼──────────┤
│    │ ████████████████    │ ██████   │ ████     │
│    │ ██████████          │ ████     │ ██████   │
│    │ ████████████████    │ ██████   │ ████     │
└────┴─────────────────────┴──────────┴──────────┘
```
- Skeleton rows matching expected layout
- Show after 100ms delay
- 5-10 skeleton rows

### Loading (Refresh)
- Keep existing content visible
- Subtle loading indicator (top bar or header)
- Disable interactions during refresh

### Empty (No Data)
```
┌─────────────────────────────────────────────────┐
│                                                 │
│               [Illustration]                    │
│                                                 │
│            No projects yet                      │
│     Create your first project to get started   │
│                                                 │
│             [+ Create Project]                  │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Empty (No Results)
```
┌─────────────────────────────────────────────────┐
│                                                 │
│         No projects match your filters          │
│         Try adjusting your search criteria      │
│                                                 │
│              [Clear Filters]                    │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Error
```
┌─────────────────────────────────────────────────┐
│                                                 │
│        Couldn't load projects                   │
│        Something went wrong. Please try again.  │
│                                                 │
│              [Try Again]                        │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Row States

| State | Background | Border | Notes |
|-------|------------|--------|-------|
| Default | transparent | none | |
| Hover | `interactive.hover` | none | |
| Selected | `interactive.selected` | none | |
| Selected + Hover | `interactive.selected_strong` | none | |
| Focused | transparent | `border.focus` | Keyboard navigation |
| Disabled | `interactive.disabled_bg` | none | Muted text |

---

## Accessibility

### ARIA Pattern
```html
<table role="grid" aria-label="Projects">
  <thead>
    <tr>
      <th role="columnheader" aria-sort="ascending">Name</th>
      <th role="columnheader" aria-sort="none">Status</th>
    </tr>
  </thead>
  <tbody>
    <tr role="row" aria-selected="false">
      <td role="gridcell">Project Alpha</td>
      <td role="gridcell">Active</td>
    </tr>
  </tbody>
</table>
```

### Screen Reader Announcements
- Sort change: "Sorted by Name, ascending"
- Selection: "Project Alpha selected, 1 of 24 selected"
- Empty: "No projects found"
- Loading: "Loading projects"

### Focus Management
- Tab into table → first interactive element
- Arrow keys → cell navigation
- Focus visible on rows and cells
- Focus returns to table after action

---

## Keyboard Navigation

| Key | Action |
|-----|--------|
| `↓` | Move to next row |
| `↑` | Move to previous row |
| `→` | Move to next cell |
| `←` | Move to previous cell |
| `Home` | Move to first cell in row |
| `End` | Move to last cell in row |
| `Ctrl+Home` | Move to first cell in table |
| `Ctrl+End` | Move to last cell in table |
| `Space` | Toggle row selection |
| `Shift+Space` | Extend selection |
| `Ctrl+A` | Select all |
| `Enter` | Activate row (navigate to detail) |
| `Escape` | Clear selection |

---

## Responsive Behavior

| Breakpoint | Behavior |
|------------|----------|
| Desktop (lg+) | Full table, all columns |
| Tablet (md) | Hide less important columns, horizontal scroll |
| Mobile (sm) | Switch to card/list view or horizontal scroll |

**Column Priority:**
1. Selection (if enabled)
2. Primary identifier (name/title)
3. Key status
4. Actions
5. Secondary info (hide first on narrow)

---

## Performance

| Metric | Target |
|--------|--------|
| Initial render | <100ms for 25 rows |
| Scroll frame rate | 60fps |
| Sort response | <200ms (perceived) |
| Selection response | <50ms |

**Optimization:**
- Virtualize at 100+ rows
- Debounce resize handlers
- Memoize row rendering
- Lazy load images in cells

---

## Integration Points

- Entities from `_model/truth/entities.yaml`
- Actions from `_model/truth/actions.yaml`
- Permissions from `_model/truth/permissions.yaml`
- Follows `_ui/layouts/collection.md` recipe

---

## Anti-Patterns

- Nested tables
- More than 8 visible columns
- Actions in every row (use bulk)
- Client-side sorting of server data
- Pagination without total count
- Checkbox selection without bulk actions
- Horizontal scroll on desktop
- Custom row heights per row
- Inline editing without clear mode change


---

## Stability Status

**Status: STABLE**

This primitive is frozen. Breaking changes require:
1. Explicit decision entry in `_decisions/REGISTRY.md`
2. Demonstration that tightening was insufficient
3. System-wide impact audit
4. Human approval

Non-breaking tightening (removing variants, adding constraints) is always permitted.
