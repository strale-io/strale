# Navigation Shell Specification

> The sense-of-place engine that defines product feel.

**Compliance:** Must conform to `_interaction/PHYSICS.md` and `_interaction/FOCUS.md`.

---

## Purpose

The navigation shell is the skeleton of your application. It provides:

- Persistent orientation (where am I?)
- Efficient navigation (where can I go?)
- Workspace context (what's my current scope?)
- Consistent chrome across all views

---

## Visual Structure

### Expanded State

```
┌─────────────────────────────────────────────────────────────────────┐
│ ┌─────────────┐                                                     │
│ │             │ ┌─────────────────────────────────────────────────┐ │
│ │  [Logo]     │ │ Page Header                                     │ │
│ │             │ │ Breadcrumb · Title            [Actions]         │ │
│ │  ───────────│ ├─────────────────────────────────────────────────┤ │
│ │  ☰ Search   │ │                                                 │ │
│ │             │ │                                                 │ │
│ │  WORKSPACE  │ │                                                 │ │
│ │  ▸ Projects │ │           Page Content                          │ │
│ │    Tasks    │ │                                                 │ │
│ │    Calendar │ │                                                 │ │
│ │             │ │                                                 │ │
│ │  ───────────│ │                                                 │ │
│ │  SETTINGS   │ │                                                 │ │
│ │    Team     │ │                                                 │ │
│ │    Billing  │ │                                                 │ │
│ │             │ │                                                 │ │
│ │  ───────────│ └─────────────────────────────────────────────────┘ │
│ │  [Avatar]   │                                                     │
│ │  @username  │                                                     │
│ └─────────────┘                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Collapsed State

```
┌────────────────────────────────────────────────────────────────┐
│ ┌────┐                                                         │
│ │[Lg]│ ┌─────────────────────────────────────────────────────┐ │
│ │    │ │ Page Header                                         │ │
│ │────│ ├─────────────────────────────────────────────────────┤ │
│ │ 🔍 │ │                                                     │ │
│ │    │ │                                                     │ │
│ │ 📁 │ │           Page Content                              │ │
│ │ ✓  │ │           (More horizontal space)                   │ │
│ │ 📅 │ │                                                     │ │
│ │    │ │                                                     │ │
│ │────│ │                                                     │ │
│ │ ⚙️ │ │                                                     │ │
│ │    │ └─────────────────────────────────────────────────────┘ │
│ │────│                                                         │
│ │[Av]│                                                         │
│ └────┘                                                         │
└────────────────────────────────────────────────────────────────┘
```

---

## Dimensions

| Element | Expanded | Collapsed |
|---------|----------|-----------|
| Sidebar width | 240px | 56px |
| Header height | 56px | 56px |
| Logo area | 56×56px | 56×56px |
| Nav item height | 32px | 40px (larger click target) |

**Token references:**
- `dimensions.sidebar.width_expanded`
- `dimensions.sidebar.width_collapsed`
- `dimensions.sidebar.item_height`

---

## Sidebar Components

### Logo Area
- Company/product logo
- Clickable → home/dashboard
- Collapses to icon/monogram

### Search Trigger
- `Cmd+K` opens command palette
- Shows "Search" label when expanded
- Icon only when collapsed

### Navigation Sections

**Structure:**
```
SECTION LABEL          ← Uppercase, muted, 11px
├─ Active Item         ← Bold, brand background
├─ Item with Icon      ← Icon + label
├─ Item with Badge     ← Label + count badge
└─ Collapsible         ← Chevron, expandable
   ├─ Nested Item
   └─ Nested Item
```

**Section Types:**
- Primary (always visible)
- Secondary (can be collapsed)
- Pinned/Favorites (user-customized)

### User Area
- Avatar (always visible)
- Name/email (expanded only)
- Status indicator (optional)
- Click → user menu

---

## Navigation Item States

| State | Background | Text | Icon |
|-------|------------|------|------|
| Default | transparent | `text.secondary` | `text.muted` |
| Hover | `interactive.hover` | `text.primary` | `text.secondary` |
| Active | `brand.primary_light` | `brand.primary_dark` | `brand.primary` |
| Active + Hover | `brand.primary_light` | `brand.primary_dark` | `brand.primary` |
| Disabled | transparent | `text.muted` | `text.muted` |

---

## Collapse Behavior

### Toggle
- Button in sidebar footer or header
- Keyboard: `[` or `]` to toggle
- Persisted to localStorage

### Transition
- Duration: `transitions.duration.slow` (250ms)
- Easing: `transitions.easing.default`
- Content width adjusts smoothly

### Collapsed Interactions
- Hover item → show tooltip with label
- Click → navigate (no expand)
- Nested items → show in popover on hover

---

## Header Integration

### Breadcrumb
```
Home / Projects / Project Alpha / Tasks
  ↑       ↑           ↑            ↑
 Link   Link        Link       Current (not clickable)
```

- Max 4 visible segments
- Collapse middle with "..." menu
- Current page: bold, not clickable

### Page Actions
- Primary action (right side)
- Secondary actions in dropdown
- Contextual to current page

---

## Mobile Behavior

### Drawer Navigation
```
┌─────────────────────────────────────────┐
│ [×]  Navigation                         │
├─────────────────────────────────────────┤
│                                         │
│ 🔍 Search                               │
│                                         │
│ WORKSPACE                               │
│ ▸ Projects                              │
│   Tasks                                 │
│   Calendar                              │
│                                         │
│ ─────────────────────────────────────── │
│                                         │
│ SETTINGS                                │
│   Team                                  │
│   Billing                               │
│                                         │
├─────────────────────────────────────────┤
│ [Avatar] @username                      │
└─────────────────────────────────────────┘
```

**Trigger:**
- Hamburger icon in header
- Swipe from left edge

**Behavior:**
- Overlay (doesn't push content)
- Backdrop click closes
- Escape closes
- Auto-close on navigation

---

## States

### Loading
- Skeleton for dynamic sections (favorites, recent)
- Static sections render immediately
- Logo and user area always visible

### Offline
- Visual indicator in sidebar footer
- Disable actions requiring network
- Show last-known state

---

## Accessibility

### Landmarks
```html
<nav aria-label="Main navigation">
  <ul role="menubar">
    <li role="menuitem">...</li>
  </ul>
</nav>
```

### Keyboard Navigation

| Key | Action |
|-----|--------|
| `↓` | Next item |
| `↑` | Previous item |
| `→` | Expand section / Enter nested |
| `←` | Collapse section / Exit nested |
| `Enter` | Activate item |
| `Home` | First item |
| `End` | Last item |
| `[` or `]` | Toggle sidebar |

### Focus Management
- Tab into nav → first item
- Focus visible on all items
- Skip link available

### Screen Reader
- Announce current section
- Announce expanded/collapsed state
- Announce active item

---

## Integration Points

### From `_ia/grammar.yaml`
- URL patterns for navigation
- Breadcrumb generation rules
- Navigation hierarchy

### From `_model/truth/`
- Entities define nav structure
- Permissions hide/show items
- Actions generate quick-access

---

## Performance

| Metric | Target |
|--------|--------|
| Initial render | <50ms |
| Collapse animation | 60fps |
| Route change highlight | <16ms |

**Optimization:**
- Pre-render nav structure
- Lazy load user-specific sections
- Debounce collapse animation

---

## Configuration (via Presets)

```yaml
navigation:
  max_depth: 3           # Max nesting level
  sidebar_default: expanded | collapsed
  breadcrumbs: true
```

---

## Anti-Patterns

- Navigation deeper than 3 levels
- Sidebar wider than 280px
- Auto-collapse without user preference
- Different nav structure per page
- Horizontal scrolling in sidebar
- Navigation items without icons (collapsed state unusable)
- Logo that doesn't navigate home
- Mobile nav without close button
- Nested flyout menus (use command palette)


---

## Stability Status

**Status: STABLE**

This primitive is frozen. Breaking changes require:
1. Explicit decision entry in `_decisions/REGISTRY.md`
2. Demonstration that tightening was insufficient
3. System-wide impact audit
4. Human approval

Non-breaking tightening (removing variants, adding constraints) is always permitted.
