# Omnibox Filter Specification

> Universal filtering for data collections. Data apps live and die here.

**Compliance:** Must conform to `_interaction/PHYSICS.md` and `_interaction/FOCUS.md`.

---

## Purpose

The omnibox filter is the primary interface for narrowing down collections. It must:

- Enable quick filtering with minimal friction
- Support both simple and complex queries
- Persist filter state in URL
- Be keyboard-first

---

## Visual Structure

### Default State (No Filters)

```
┌─────────────────────────────────────────────────────────────────────┐
│ 🔍 Filter...                                      [+ Add Filter ▾]  │
└─────────────────────────────────────────────────────────────────────┘
```

### With Active Filters

```
┌─────────────────────────────────────────────────────────────────────┐
│ 🔍 Filter...  [Status: Active ×] [Owner: @jane ×] [Clear all]       │
└─────────────────────────────────────────────────────────────────────┘
```

### Filter Builder Open

```
┌─────────────────────────────────────────────────────────────────────┐
│ 🔍 Filter...  [Status: Active ×] [Owner: @jane ×]   [+ Add Filter]  │
├─────────────────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────────────────┐ │
│ │ Filter by...                                                    │ │
│ │                                                                 │ │
│ │ COMMON                                                          │ │
│ │ ├─ Status                                                       │ │
│ │ ├─ Owner                                                        │ │
│ │ ├─ Due Date                                                     │ │
│ │ └─ Priority                                                     │ │
│ │                                                                 │ │
│ │ MORE                                                            │ │
│ │ ├─ Created                                                      │ │
│ │ ├─ Updated                                                      │ │
│ │ └─ Tags                                                         │ │
│ └─────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Components

### Search Input
- Placeholder: "Filter..." or "Search {entities}..."
- Icon: 🔍 (search)
- Shortcut hint: "/ to focus" or "Cmd+F"
- Instant filtering (debounced 150ms)

### Filter Chips

**Structure:**
```
┌───────────────────┐
│ Status: Active  × │
└───────────────────┘
  ↑       ↑       ↑
Field   Value   Remove
```

**States:**
- Default: `background.muted`, `text.secondary`
- Hover: `interactive.hover`
- Active/focused: `border.focus`

**Behavior:**
- Click chip → edit filter
- Click × → remove filter
- Keyboard: Backspace removes last chip when input empty

### Add Filter Button

```
[+ Add Filter ▾]
```

- Opens filter field picker
- Dropdown with searchable list
- Grouped by category

### Clear All

```
[Clear all]
```

- Appears when ≥2 filters active
- Link style, not button
- Removes all filters, keeps search text

---

## Filter Types

### Select (Single Value)
```
┌─────────────────────────────────────────┐
│ Status                                  │
├─────────────────────────────────────────┤
│ ○ Active                                │
│ ○ Draft                                 │
│ ○ Archived                              │
│                                         │
│ [Apply]                [Cancel]         │
└─────────────────────────────────────────┘
```

### Multi-Select
```
┌─────────────────────────────────────────┐
│ Tags                                    │
├─────────────────────────────────────────┤
│ ☑ Design                                │
│ ☐ Engineering                           │
│ ☑ Marketing                             │
│ ☐ Sales                                 │
│                                         │
│ [Apply (2)]            [Cancel]         │
└─────────────────────────────────────────┘
```

### User/Assignee
```
┌─────────────────────────────────────────┐
│ Owner                                   │
├─────────────────────────────────────────┤
│ 🔍 Search people...                     │
├─────────────────────────────────────────┤
│ [👤] Me                                 │
│ [👤] Jane Smith                         │
│ [👤] John Doe                           │
│                                         │
│ [Apply]                [Cancel]         │
└─────────────────────────────────────────┘
```

### Date Range
```
┌─────────────────────────────────────────┐
│ Due Date                                │
├─────────────────────────────────────────┤
│ ○ Today                                 │
│ ○ This week                             │
│ ○ This month                            │
│ ○ Overdue                               │
│ ○ Custom range...                       │
│                                         │
│ [Apply]                [Cancel]         │
└─────────────────────────────────────────┘
```

### Number Range
```
┌─────────────────────────────────────────┐
│ Priority                                │
├─────────────────────────────────────────┤
│ Between  [___] and [___]                │
│                                         │
│ Quick: ○ High (1-2) ○ Medium ○ Low      │
│                                         │
│ [Apply]                [Cancel]         │
└─────────────────────────────────────────┘
```

### Boolean
```
┌─────────────────────────────────────────┐
│ Has attachments                         │
├─────────────────────────────────────────┤
│ ○ Yes                                   │
│ ○ No                                    │
│                                         │
│ [Apply]                [Cancel]         │
└─────────────────────────────────────────┘
```

---

## Behavior

### Text Search
- Searches across configured fields (title, description, etc.)
- Debounce: 150ms
- Minimum characters: 2
- Highlight matches in results

### Filter Application
- Filters apply immediately (or on "Apply" click)
- URL updates with filter state
- Result count updates: "Showing 12 of 156"

### Filter Persistence
- **URL:** All active filters encoded
- **Format:** `?status=active&owner=jane&q=search`
- **Restore:** Filters restored from URL on page load

### Saved Filters (Optional)
```
┌─────────────────────────────────────────┐
│ 💾 Save current filters                 │
├─────────────────────────────────────────┤
│ SAVED                                   │
│ ├─ My active tasks                      │
│ ├─ Overdue items                        │
│ └─ Team priorities                      │
└─────────────────────────────────────────┘
```

---

## States

### Loading
- Skeleton for filter options
- Disable filter interaction
- Show loading indicator on results

### No Results
```
┌─────────────────────────────────────────────────────────────────────┐
│ 🔍 budget  [Status: Active ×] [Owner: @jane ×]        [Clear all]   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│              No items match your filters                            │
│              Try removing some filters or broadening your search    │
│                                                                     │
│              [Clear all filters]                                    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Error
- Inline error message
- Retry option
- Keep filter state

---

## Accessibility

### ARIA Pattern
```html
<div role="search" aria-label="Filter projects">
  <input 
    type="search" 
    aria-label="Search"
    aria-describedby="filter-count"
  />
  <div role="group" aria-label="Active filters">
    <button aria-label="Status: Active. Click to edit, press delete to remove">
      Status: Active ×
    </button>
  </div>
</div>
<div id="filter-count" aria-live="polite">
  Showing 12 of 156 projects
</div>
```

### Keyboard Navigation

| Key | Action |
|-----|--------|
| `/` or `Cmd+F` | Focus search input |
| `Enter` | Apply filter (in builder) |
| `Escape` | Close filter builder |
| `Backspace` | Remove last filter (when input empty) |
| `↓` | Open filter builder / next option |
| `↑` | Previous option |
| `Tab` | Move between chips |
| `Delete` | Remove focused chip |

### Screen Reader
- Announce filter count: "3 filters active"
- Announce result count: "Showing 12 of 156 projects"
- Announce filter changes: "Filter removed: Status"

---

## Responsive Behavior

### Desktop (lg+)
- Full omnibox with chips inline
- Filter builder as dropdown

### Tablet (md)
- Chips may wrap to second line
- Filter builder as dropdown

### Mobile (sm)
```
┌─────────────────────────────────────────┐
│ 🔍 Filter...            [Filters (3)]   │
└─────────────────────────────────────────┘
```
- Chips hidden behind "Filters (N)" button
- Filter builder as bottom sheet
- Active filter count shown

---

## Performance

| Metric | Target |
|--------|--------|
| Filter application | <200ms (perceived) |
| Search debounce | 150ms |
| Filter builder open | <100ms |
| Chip render | <16ms |

**Optimization:**
- Debounce text input
- Virtualize long option lists
- Cache filter options
- Optimistic UI updates

---

## Integration Points

### URL Persistence
```
/projects?status=active&owner=user_123&q=budget&sort=updated
```

### From `_model/truth/entities.yaml`
- Filterable properties
- Property types → filter types
- Display names

### From `_model/truth/permissions.yaml`
- Filter by assignee: show permitted users only
- Filter by team: show accessible teams

---

## Configuration

```yaml
omnibox:
  debounce_ms: 150
  min_search_chars: 2
  max_chips_visible: 5
  persist_to_url: true
  saved_filters: true | false
```

---

## Anti-Patterns

- Filter without URL persistence
- Instant apply for expensive filters
- Filter options that never match anything
- Nested/grouped filters (keep flat)
- More than 10 filter fields exposed
- Filter builder that covers results
- Clearing filters loses search text
- Filter that requires submit button for every change


---

## Stability Status

**Status: STABLE**

This primitive is frozen. Breaking changes require:
1. Explicit decision entry in `_decisions/REGISTRY.md`
2. Demonstration that tightening was insufficient
3. System-wide impact audit
4. Human approval

Non-breaking tightening (removing variants, adding constraints) is always permitted.
