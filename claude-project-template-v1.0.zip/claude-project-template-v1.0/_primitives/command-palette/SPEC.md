# Command Palette Specification

> The definitive spec for the command palette primitive.

**Compliance:** Must conform to `_interaction/PHYSICS.md` and `_interaction/FOCUS.md`.

---

## Purpose

The command palette is the highest-leverage power user affordance. It provides:

- Quick access to any action
- Global navigation
- Search across entities
- Keyboard-first interaction

---

## Trigger

| Platform | Shortcut |
|----------|----------|
| macOS | `Cmd+K` |
| Windows/Linux | `Ctrl+K` |

**Behavior:**
- Opens palette from anywhere in app
- If palette open, focuses search input
- Works when focus is anywhere (including inputs)

---

## Visual Structure

```
┌─────────────────────────────────────────────────┐
│  🔍 [Search commands and pages...          ]    │
├─────────────────────────────────────────────────┤
│  RECENT                                         │
│  ├─ 🔵 Project Alpha                    → Open  │
│  └─ ✏️ Edit settings                    → Run   │
├─────────────────────────────────────────────────┤
│  ACTIONS                                        │
│  ├─ ➕ Create project              Cmd+Shift+P  │
│  ├─ 📋 Create task                 Cmd+Shift+T  │
│  └─ 👤 Invite team member                       │
├─────────────────────────────────────────────────┤
│  NAVIGATION                                     │
│  ├─ 📁 Projects                                 │
│  ├─ 📊 Dashboard                                │
│  └─ ⚙️ Settings                                 │
└─────────────────────────────────────────────────┘
```

---

## Dimensions

| Property | Value |
|----------|-------|
| Width | 600px max, 90vw on mobile |
| Max height | 400px (scrollable) |
| Position | Centered, 20% from top |
| Backdrop | Semi-transparent overlay |

---

## Default State (No Query)

Show in order:
1. **Recent** — Last 5 items interacted with
2. **Suggested Actions** — Context-aware actions
3. **Quick Navigation** — Top-level sections

---

## Search Behavior

### Input

| Property | Value |
|----------|-------|
| Debounce | 150ms |
| Min characters | 2 (before searching) |
| Placeholder | "Search commands and pages..." |

### Matching

- Fuzzy matching on titles
- Exact matching on shortcuts
- Substring matching on descriptions
- Case insensitive

### Result Ordering

1. **Exact matches** first
2. **Starts with** query
3. **Contains** query
4. **Fuzzy matches** last

Within each category, order by:
1. Frequency of use (recent first)
2. Alphabetical

---

## Result Types

### Navigation Results

```yaml
navigation:
  format: "Go to {destination}"
  icon: destination_icon
  action: navigate_to_url
  
  examples:
    - "Go to Projects"
    - "Go to Project Alpha"
    - "Go to Settings"
```

### Action Results

```yaml
action:
  format: "{Verb} {object}"
  icon: action_icon
  shortcut: if_defined
  action: execute_action
  
  examples:
    - "Create project"
    - "Invite team member"
    - "Export data"
```

### Search Results

```yaml
search:
  format: "{Entity}: {title}"
  icon: entity_icon
  subtitle: entity_type
  action: navigate_to_entity
  
  examples:
    - "Project: Alpha"
    - "Task: Fix login bug"
    - "User: Jane Smith"
```

---

## Result Item Anatomy

```
┌─────────────────────────────────────────────────┐
│  [Icon] Title                         [Shortcut]│
│         Subtitle/description                    │
└─────────────────────────────────────────────────┘
```

| Element | Required | Notes |
|---------|----------|-------|
| Icon | Yes | Entity or action icon |
| Title | Yes | Primary text, supports highlighting |
| Shortcut | No | Keyboard shortcut if exists |
| Subtitle | No | Additional context |

---

## Permissions

### Hidden Items

If user lacks permission:
- **Hide entirely** — Don't show in results

### Disabled Items

If item exists but is temporarily unavailable:
- **Show disabled** — Grayed out
- **Tooltip** — Explains why unavailable

### Destructive Actions

Destructive actions (delete, remove):
- **Red text** — Visual warning
- **Confirmation required** — Don't execute immediately
- **Never in recent** — Don't suggest destructive actions

---

## Keyboard Navigation

| Key | Action |
|-----|--------|
| `↓` / `↑` | Navigate results |
| `Enter` | Execute selected |
| `Escape` | Close palette |
| `Tab` | Stay in input (don't cycle) |
| `Cmd+K` | If open, focus input |

### Focus Behavior

- Input always has focus
- Arrow keys move visual selection
- Selection follows `aria-activedescendant` pattern
- No tab-cycling through results

---

## Timing

| Event | Duration | Easing |
|-------|----------|--------|
| Open | 150ms | ease-out |
| Close | 100ms | ease-in |
| Search debounce | 150ms | — |
| Result fade-in | 100ms | ease-out (staggered 20ms) |

---

## States

### Loading

```yaml
loading:
  trigger: Search query submitted
  display: Spinner in input or results area
  behavior: Keep previous results visible while loading
```

### Empty (No Results)

```yaml
empty:
  message: "No results for '{query}'"
  suggestion: "Try a different search term"
  show_after: Search completes with 0 results
```

### Error

```yaml
error:
  message: "Couldn't complete search"
  action: "Try again"
  behavior: Allow retry without closing
```

---

## Accessibility

### ARIA Pattern

Uses combobox pattern:

```html
<div role="combobox" aria-expanded="true" aria-haspopup="listbox">
  <input 
    type="text"
    aria-autocomplete="list"
    aria-controls="results-listbox"
    aria-activedescendant="result-{selected-id}"
  />
</div>
<ul id="results-listbox" role="listbox">
  <li role="option" id="result-1">...</li>
  <li role="option" id="result-2">...</li>
</ul>
```

### Screen Reader

- Announce result count on search: "5 results"
- Announce selected item on navigation
- Announce when no results found

### Focus

- Focus trapped in palette while open
- Focus returns to trigger on close
- All functionality keyboard accessible

---

## Mobile Behavior

| Property | Mobile Adaptation |
|----------|-------------------|
| Width | Full width (with padding) |
| Position | Top of screen |
| Trigger | Button in header (no keyboard shortcut) |
| Results | Larger touch targets (min 44px) |

---

## Integration Points

### With Navigation

- Navigation items come from `_ia/grammar.yaml`
- Respect navigation hierarchy
- Link to deep pages

### With Actions

- Actions come from `_model/truth/actions.yaml`
- Respect permissions from `_model/truth/permissions.yaml`
- Execute via action handlers

### With Search

- Search entities from `_model/truth/entities.yaml`
- Results link to entity detail pages
- Respect view permissions

---

## Test Cases

```yaml
test_cases:
  - name: "Opens on Cmd+K"
    action: Press Cmd+K
    expect: Palette opens, input focused
    
  - name: "Closes on Escape"
    action: Press Escape while open
    expect: Palette closes, focus returns
    
  - name: "Navigates with arrows"
    action: Press Down Arrow twice
    expect: Third result selected
    
  - name: "Executes on Enter"
    action: Select result, press Enter
    expect: Action executed, palette closes
    
  - name: "Shows no results state"
    action: Search "xyznonexistent"
    expect: "No results" message displayed
    
  - name: "Respects permissions"
    precondition: User lacks "delete" permission
    action: Search "delete"
    expect: Delete actions not shown
    
  - name: "Accessible via screen reader"
    action: Navigate with VoiceOver
    expect: All elements announced correctly
```


---

## Stability Status

**Status: STABLE**

This primitive is frozen. Breaking changes require:
1. Explicit decision entry in `_decisions/REGISTRY.md`
2. Demonstration that tightening was insufficient
3. System-wide impact audit
4. Human approval

Non-breaking tightening (removing variants, adding constraints) is always permitted.
