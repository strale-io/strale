# Golden Primitives

> Reference implementations that create gravitational pull toward quality.

---

## What Primitives Are

Primitives are **implemented code**, not just specs. They are:

- Working reference implementations
- Battle-tested patterns
- The "gravity" that pulls work toward coherence

**Key insight:** Specs tell you what to build. Primitives show you how good looks.

---

## The Five Primitives

| Primitive | Why Critical |
|-----------|-------------|
| **Command Palette** | Highest-leverage power user affordance; forces clean focus/search/action patterns |
| **Omnibox Filter** | Data apps live or die here; forces consistent query mental models |
| **Data Table** | Where "almost great" falls apart; must be fast, readable, consistent |
| **Navigation Shell** | The "sense of place" engine; sidebar + breadcrumbs + tabs |
| **Modal/Drawer** | Most overused pattern; elite apps use with discipline |

---

## Folder Structure

Each primitive contains:

```
_primitives/{primitive}/
├── SPEC.md              # Requirements and behavior
├── component.tsx        # Reference implementation
├── component.test.tsx   # Tests proving compliance
├── styles.css           # Styles (if not using Tailwind)
└── examples/            # Usage examples
    ├── basic.tsx
    └── advanced.tsx
```

---

## How to Use Primitives

### When Building

1. Read the SPEC.md for requirements
2. Look at component.tsx for implementation patterns
3. Run tests to understand expected behavior
4. Use examples as starting points

### When Reviewing

1. Compare implementation to primitive
2. Flag divergences without justification
3. Primitive is the standard; exceptions need documentation

---

## Current Status

| Primitive | Spec | Implementation | Tests |
|-----------|------|----------------|-------|
| Command Palette | ✅ Done | — Requires tech stack | — Requires tech stack |
| Omnibox Filter | ✅ Done | — Requires tech stack | — Requires tech stack |
| Data Table | ✅ Done | — Requires tech stack | — Requires tech stack |
| Navigation Shell | ✅ Done | — Requires tech stack | — Requires tech stack |
| Modal/Drawer | ✅ Done | — Requires tech stack | — Requires tech stack |

> **Note:** Implementation and tests activate after `config/tech-foundation.yaml` is
> populated with framework choices. The SPEC.md files are behavioral specifications
> that inform component design regardless of framework.

---

## Adding Primitives

To add a new primitive:

1. **Justify** — Why is this critical? What problem does it solve?
2. **Spec** — Write SPEC.md with complete requirements
3. **Implement** — Build reference implementation
4. **Test** — Prove it meets spec
5. **Document** — Add examples
6. **Critique** — Run critique loop on the primitive itself

---

## Primitive Quality Bar

Every primitive must:

- **Comply with `_interaction/PHYSICS.md` and `_interaction/FOCUS.md`**
- Pass critique loop with all 5s
- Handle all states (loading, empty, error)
- Meet accessibility requirements (keyboard, screen reader)
- Respect reduced motion preference
- Work across supported browsers
- Have tests proving each spec requirement

---

## Relationship to Components

Primitives are **not** the component library. They are:

- Reference implementations that inform component design
- Patterns for complex, high-leverage UI
- Teaching tools for taste and quality

The component library (`_ui/components.yaml`) may wrap or adapt primitives, but primitives remain the source of truth for how these patterns should work.

---

## Version Control

Primitives are versioned with the starter kit. Changes require:

1. Documented reason
2. Updated spec
3. Updated implementation
4. Updated tests
5. Review of downstream impact
