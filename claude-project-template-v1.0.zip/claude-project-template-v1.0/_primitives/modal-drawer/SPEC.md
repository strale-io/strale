# Modal & Drawer Specification

> Transient UI done right. The most overused pattern—elite products use with discipline.

**Compliance:** Must conform to `_interaction/PHYSICS.md` and `_interaction/FOCUS.md`.

---

## Core Principle

**Modals and drawers interrupt user flow. Use sparingly.**

Before using a modal or drawer, ask:
1. Can this be done inline?
2. Can this be a new page?
3. Is the interruption justified?

---

## When to Use

### Modal
- Focused task requiring completion
- Confirmation of destructive action
- Form that shouldn't lose context
- Important information requiring acknowledgment

### Drawer
- Detail view while preserving list context
- Supplementary information
- Filters/settings that need frequent access
- Split-view patterns

### Never Use For
- Simple alerts (use toast)
- Long forms (use page)
- Primary content (use page)
- Marketing/upsells (don't interrupt)

---

# MODAL

## Visual Structure

```
┌─────────────────────────────────────────────────────────────────────┐
│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░┌─────────────────────────────────────┐░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│ Header                          [×] │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│ Modal Title                         │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░├─────────────────────────────────────┤░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│                                     │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│ Body                                │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│ Content goes here. This area        │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│ scrolls if content overflows.       │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│                                     │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░├─────────────────────────────────────┤░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░│ Footer          [Cancel] [Confirm]  │░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░└─────────────────────────────────────┘░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│
│░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░│
└─────────────────────────────────────────────────────────────────────┘
  ↑ Backdrop (click to close, configurable)
```

## Dimensions

| Size | Width | Use Case |
|------|-------|----------|
| sm | 400px | Simple confirmation, single input |
| md | 560px | Standard forms, default |
| lg | 720px | Complex forms, preview content |
| xl | 900px | Rich content, multi-column |
| full | 100vw - 48px | Document editing, immersive task |

**Token references:**
- `dimensions.modal.width_*`
- `dimensions.modal.padding` (24px)
- `borders.radii.xl` (12px)
- `shadows.lg`

**Height:**
- Auto-height based on content
- Max height: 90vh
- Body scrolls when overflow

## Structure

### Header (Required)
```
┌─────────────────────────────────────────────────┐
│ Modal Title                               [×]   │
└─────────────────────────────────────────────────┘
```
- Title: H3 style, describes action
- Close button: Always present, top-right
- Divider below header

### Body
- Scrollable content area
- Padding: `dimensions.modal.padding`
- Form fields, text, or custom content

### Footer (Optional)
```
┌─────────────────────────────────────────────────┐
│                       [Cancel]  [Primary Action] │
└─────────────────────────────────────────────────┘
```
- Right-aligned actions
- Primary action on right
- Cancel/secondary on left
- Divider above footer

## Animation

### Enter
- Duration: `transitions.duration.slower` (350ms)
- Backdrop: Fade in
- Modal: Scale from 0.95 + fade in
- Easing: `transitions.easing.out`

### Exit
- Duration: `transitions.duration.slow` (250ms)
- Backdrop: Fade out
- Modal: Scale to 0.95 + fade out
- Easing: `transitions.easing.in`

---

# DRAWER

## Visual Structure

### Right Drawer (Default)

```
┌─────────────────────────────────┬───────────────────────────────────┐
│                                 │ ┌───────────────────────────────┐ │
│                                 │ │ Header                    [×] │ │
│                                 │ │ Drawer Title                  │ │
│  Page Content                   │ ├───────────────────────────────┤ │
│  (dimmed or interactive)        │ │                               │ │
│                                 │ │ Body                          │ │
│                                 │ │ Content here                  │ │
│                                 │ │                               │ │
│                                 │ ├───────────────────────────────┤ │
│                                 │ │ Footer (optional)             │ │
│                                 │ └───────────────────────────────┘ │
└─────────────────────────────────┴───────────────────────────────────┘
                                  ↑ Drawer (slides in from right)
```

### Left Drawer (Navigation)

```
┌───────────────────────────────────┬─────────────────────────────────┐
│ ┌───────────────────────────────┐ │                                 │
│ │ Header                    [×] │ │                                 │
│ │ Navigation                    │ │                                 │
│ ├───────────────────────────────┤ │  Page Content                   │
│ │                               │ │                                 │
│ │ Nav items                     │ │                                 │
│ │                               │ │                                 │
│ └───────────────────────────────┘ │                                 │
└───────────────────────────────────┴─────────────────────────────────┘
  ↑ Drawer (slides in from left)
```

## Dimensions

| Size | Width | Use Case |
|------|-------|----------|
| sm | 320px | Simple detail, mobile nav |
| md | 400px | Standard detail view |
| lg | 560px | Rich detail, forms |

**Token references:**
- `dimensions.drawer.width_*`

**Height:** Full viewport height

## Modes

### Overlay (Default)
- Backdrop behind drawer
- Page content non-interactive
- Click backdrop to close

### Push
- No backdrop
- Page content shifts
- Drawer part of layout

## Animation

### Enter
- Duration: `transitions.duration.slow` (250ms)
- Slide in from edge
- Easing: `transitions.easing.out`

### Exit
- Duration: `transitions.duration.normal` (150ms)
- Slide out to edge
- Easing: `transitions.easing.in`

---

# SHARED BEHAVIOR

## Backdrop

**Visual:**
- Color: `rgba(0, 0, 0, 0.4)`
- Blur: Optional, subtle (4px)

**Behavior:**
- Click to close (configurable)
- No scroll on backdrop

## Focus Management

### On Open
1. Store currently focused element
2. Focus first focusable in modal/drawer
3. If form: focus first input
4. If confirmation: focus primary action

### Focus Trap
- Tab cycles within modal/drawer
- Shift+Tab cycles backward
- Focus doesn't leave until closed

### On Close
1. Return focus to trigger element
2. If trigger gone: focus nearest logical element

## Scroll Locking

- Body scroll disabled when open
- Preserve scroll position
- Handle iOS Safari quirks

## Keyboard

| Key | Action |
|-----|--------|
| `Escape` | Close modal/drawer |
| `Tab` | Next focusable element (trapped) |
| `Shift+Tab` | Previous focusable element |
| `Enter` | Submit form / Primary action |

## Stacking

**Rule: Never nest modals or drawers.**

If a modal needs to open another modal:
1. Close the first modal
2. Open the second modal
3. On second close, reopen first if needed

Or: Use a different pattern (inline expansion, page navigation)

---

# STATES

## Loading
```
┌─────────────────────────────────────────┐
│ Modal Title                         [×] │
├─────────────────────────────────────────┤
│                                         │
│               [Spinner]                 │
│           Loading content...            │
│                                         │
├─────────────────────────────────────────┤
│                           [Cancel]      │
└─────────────────────────────────────────┘
```

## Error
```
┌─────────────────────────────────────────┐
│ Modal Title                         [×] │
├─────────────────────────────────────────┤
│ ┌─────────────────────────────────────┐ │
│ │ ⚠️ Error message with explanation   │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [Form content preserved]                │
│                                         │
├─────────────────────────────────────────┤
│                  [Cancel]  [Try Again]  │
└─────────────────────────────────────────┘
```

## Unsaved Changes
```
┌─────────────────────────────────────────┐
│ Unsaved Changes                     [×] │
├─────────────────────────────────────────┤
│                                         │
│ You have unsaved changes. Are you sure  │
│ you want to close without saving?       │
│                                         │
├─────────────────────────────────────────┤
│       [Discard]  [Cancel]  [Save]       │
└─────────────────────────────────────────┘
```

---

# ACCESSIBILITY

## ARIA Pattern

```html
<div 
  role="dialog" 
  aria-modal="true"
  aria-labelledby="modal-title"
  aria-describedby="modal-description"
>
  <h2 id="modal-title">Modal Title</h2>
  <p id="modal-description">Description of modal purpose</p>
  <!-- content -->
</div>
```

## Screen Reader

- Announce when opened: "Dialog opened: Modal Title"
- Announce when closed: "Dialog closed"
- Announce focus changes within

---

# CONFIRMATION DIALOG

Special case of modal for destructive confirmations.

```
┌─────────────────────────────────────────┐
│ Delete Project?                     [×] │
├─────────────────────────────────────────┤
│                                         │
│ This will permanently delete "Project   │
│ Alpha" and all its data. This action    │
│ cannot be undone.                       │
│                                         │
├─────────────────────────────────────────┤
│              [Cancel]  [Delete Project] │
└─────────────────────────────────────────┘
```

**Rules:**
- Destructive action in `danger` variant
- Describe what will be deleted
- Mention if irreversible
- Default focus on Cancel, not Delete
- For high-stakes: require typed confirmation

---

# RESPONSIVE

## Modal on Mobile

- Full width with padding
- Full height option for complex forms
- Slides up from bottom (sheet pattern)
- Swipe down to close

## Drawer on Mobile

- Full width
- Slides from bottom (sheet pattern)
- Handle for swipe dismiss

---

# ANTI-PATTERNS

## Modal
- Modal inside modal
- Modal for content that should be a page
- Auto-opening modals (marketing, upsells)
- Modal without close button
- Modal that can't be dismissed
- Long scrolling content (use page)

## Drawer
- Drawer wider than 50% of viewport
- Left drawer for right-to-left content
- Drawer without close affordance
- Drawer for primary actions

## Both
- Missing focus trap
- No keyboard dismiss
- Body scroll not locked
- Missing escape key handling
- No unsaved changes warning for forms
- Opening from hover (use click)


---

## Stability Status

**Status: STABLE**

This primitive is frozen. Breaking changes require:
1. Explicit decision entry in `_decisions/REGISTRY.md`
2. Demonstration that tightening was insufficient
3. System-wide impact audit
4. Human approval

Non-breaking tightening (removing variants, adding constraints) is always permitted.
