# Code Verification Protocol

> Post-implementation checklist. Verifies code against governance artifacts.

---

## Purpose

The critique loop (`_critique/LOOP.md`) evaluates **design quality** — hierarchy, rhythm, density, consistency, craft. This protocol evaluates **implementation correctness** — does the code faithfully implement the governance artifacts?

Run this after implementation, before (or alongside) the critique loop.

**This is not a new critique phase.** It's a verification gate that confirms the code matches what the governance system specified.

---

## When to Run

| Build Tier | Verification Scope |
|-----------|-------------------|
| Micro | Skip — too small to justify |
| Targeted | Sections 1-3 only (token, state, budget) |
| Standard | All sections |
| Complex | All sections + cross-surface checks |

---

## Verification Sections

### 1. Token Traceability

> Every visual value in code must trace to a token.

**Check:** No hardcoded colors, font sizes, spacing values, border radii, shadows, or z-indices.

| Verify | Source | Pass Criteria |
|--------|--------|---------------|
| Colors | `_ui/tokens.yaml` → color | Every color reference uses a token path, never a hex/rgb literal |
| Typography | `_ui/tokens.yaml` → typography | Font sizes, weights, line heights use token references |
| Spacing | `_ui/tokens.yaml` → spacing | Padding, margin, gap values use scale tokens |
| Borders | `_ui/tokens.yaml` → border, radius | Border widths and radii use token references |
| Shadows | `_ui/tokens.yaml` → shadow | Elevation values use shadow tokens |
| Motion | `_ui/tokens.yaml` → motion | Transition durations and easings use token references |

**How to check:**

```yaml
# Search code for hardcoded visual values that should use tokens.
# See _invariants/REGISTRY.md (TK-001 through TK-004) for token compliance rules.
# Acceptable exceptions depend on your token system — define in __FILL__.

flag_patterns:
  - Hardcoded color values (hex, rgb, hsl)
  - Hardcoded pixel/rem/em values for spacing, sizing, typography
  - Hardcoded timing values for transitions/animations
  - Any visual value not referencing a token path from _ui/tokens.yaml
```

**Failure:** Any hardcoded value not in the exceptions list. Fix by replacing with token reference.

---

### 2. Mandatory State Coverage

> Every async data boundary must handle loading, empty, and error states.

**Source:** `_ui/states.md`, LAW-004

| Verify | Pass Criteria |
|--------|---------------|
| Loading states exist | Every component that fetches data has a loading state |
| Skeleton matches layout | Skeleton structure mirrors the loaded content structure |
| Loading delay | Skeleton/spinner shows after delay (100ms skeleton, 300ms spinner), not immediately |
| Empty states exist | First-time empty and filtered-empty are distinct |
| Empty state has CTA | First-time empty includes an action to create content |
| Error states exist | Inline, section, and page-level errors as appropriate |
| Error recovery | Every error state offers at least one recovery action |
| Error preserves data | Form errors never clear user input |

**How to check:**

```yaml
# For each data-fetching component, verify these siblings exist:
component: __FILL__
data_source: __FILL__
states:
  loading:
    exists: __FILL__                  # yes/no
    type: __FILL__                    # skeleton | spinner
    delay: __FILL__                   # ms before showing
    matches_layout: __FILL__          # yes/no — skeleton shape matches content
  empty:
    first_time_exists: __FILL__       # yes/no
    filtered_exists: __FILL__         # yes/no (if filterable)
    has_cta: __FILL__                 # yes/no
  error:
    exists: __FILL__                  # yes/no
    has_recovery: __FILL__            # yes/no
    preserves_input: __FILL__         # yes/no (for forms)
```

**Failure:** Missing state for any async boundary. Fix by adding the missing state component.

---

### 3. Archetype Budget Compliance

> Component count and decision points must not exceed archetype limits.

**Source:** `_quality/archetypes/{archetype}.yaml`, LAW-003

| Verify | Pass Criteria |
|--------|---------------|
| Decision point count | Count ≤ `max_decision_points` for archetype |
| Component count | Unique instances ≤ `max_components` for archetype |
| Primary action count | Primary buttons/CTAs ≤ archetype `primary_actions` limit |
| Secondary action count | Secondary buttons ≤ archetype `secondary_actions` limit |
| Required patterns present | All `required_patterns` from archetype are implemented |
| Forbidden patterns absent | No `forbidden_patterns` from archetype appear |

**How to count:**

```yaml
# Decision points = interactive elements that require user choice
count_as_decision_points:
  - Buttons (each button = 1)
  - Links that navigate (each = 1)
  - Toggles/switches (each = 1)
  - Selects/dropdowns (each = 1)
  - Tabs (the tab bar = 1, not each tab)

do_not_count:
  - Pagination controls (navigation, not decision)
  - Scroll (passive)
  - Hover states (discovery, not decision)

# Components = unique component instances rendered
count_as_components:
  - Each rendered component instance (3 cards = 3 components)
  - Template components count once per variant used
```

**Failure:** Over budget. Fix by simplifying the surface — remove low-priority actions or split into sub-surfaces.

---

### 4. Interaction Law Compliance

> Code must satisfy all applicable laws from `_rules/laws.yaml`.

| Law | Verification |
|-----|-------------|
| LAW-001 (User Confidence) | Every mutation (create/update/delete) produces visible feedback (toast, inline, or state change) |
| LAW-002 (One Archetype) | Screen follows exactly one archetype layout pattern |
| LAW-004 (Mandatory States) | Covered by Section 2 above |
| LAW-005 (Data Accuracy) | Displayed data matches source; no stale cache rendered as current |
| LAW-006 (Accessibility) | See Section 6 below |
| LAW-007 (Affordance Integrity) | Everything clickable has `cursor: pointer` or button semantics; nothing static looks interactive |
| LAW-008 (Primary Flow Completion) | Main task can be completed start to finish without dead ends |
| LAW-011 (Intent Before Execution) | Destructive actions (delete, discard, overwrite) show confirmation before executing |

**How to check:**

```yaml
# LAW-001: Find all mutation calls, verify each has feedback
mutations: __FILL__                   # List all create/update/delete operations
feedback_per_mutation:
  - mutation: __FILL__
    feedback: __FILL__                # toast | inline_success | state_change
    missing: __FILL__                 # yes/no

# LAW-007: Find all elements with onClick/href, verify affordance
interactive_elements: __FILL__
affordance_per_element:
  - element: __FILL__
    looks_interactive: __FILL__       # yes/no — cursor, color, underline, etc.
    is_interactive: __FILL__          # yes/no — has handler
    mismatch: __FILL__                # yes/no — looks interactive but isn't, or vice versa

# LAW-011: Find all destructive operations
destructive_ops: __FILL__
confirmation_per_op:
  - operation: __FILL__
    has_confirmation: __FILL__        # yes/no — modal, inline confirm, etc.
```

**Failure:** Any law violation. Fix before proceeding — laws are non-negotiable.

---

### 5. Entity and Data Integrity

> Code must respect entity model constraints.

**Source:** `_model/truth/entities.yaml`, `_invariants/REGISTRY.md`

| Verify | Pass Criteria |
|--------|---------------|
| Required fields enforced | Form submission validates all required entity properties |
| State transitions valid | Code only allows transitions declared in entity state machine |
| Relationships respected | Parent-child constraints enforced (HIE-001 through HIE-005) |
| IDs immutable | No code path changes an entity's ID after creation (ID-002) |
| Soft delete default | Delete operations mark as deleted, not physically remove (ID-005) |
| Referential integrity | No dangling references created or left unresolved (ID-004) |

**How to check:**

```yaml
# For each entity type on this surface:
entity: __FILL__
checks:
  required_fields:
    fields: [__FILL__]               # List from entity model
    validated_in_form: __FILL__       # yes/no
    validated_on_submit: __FILL__     # yes/no
  state_machine:
    declared_transitions: [__FILL__]  # From entity model
    code_allows_only_declared: __FILL__  # yes/no
  relationships:
    parent: __FILL__
    orphan_prevention: __FILL__       # yes/no — can a child exist without parent?
```

**Failure:** Entity constraint violation. Fix by adding validation or correcting the code path.

---

### 6. Keyboard and Accessibility

> Code must meet WCAG 2.1 AA and keyboard navigation requirements.

**Source:** `_interaction/FOCUS.md`, `_invariants/REGISTRY.md` (A11Y-*, UI-002), LAW-006

| Verify | Pass Criteria |
|--------|---------------|
| Tab order logical | Focus moves through interactive elements in visual reading order |
| Focus visible | Every focusable element has a visible focus indicator |
| Focus trapped in modals | Opening a modal/drawer traps focus; closing restores focus to trigger |
| Escape closes overlays | Modals, drawers, dropdowns, popovers close on Escape |
| ARIA roles present | Interactive components have appropriate ARIA roles and labels |
| Color contrast | Text meets 4.5:1 ratio (normal) / 3:1 (large); UI elements meet 3:1 |
| No color-only meaning | Information is not conveyed by color alone (icons, text, patterns as supplements) |
| Screen reader labels | All images, icons, and non-text content have accessible labels |
| Reduced motion | `prefers-reduced-motion` disables or simplifies animations |

**How to check:**

```yaml
# Focus management audit:
focus_audit:
  tab_order_matches_visual: __FILL__  # yes/no
  all_interactive_focusable: __FILL__ # yes/no
  focus_indicator_visible: __FILL__   # yes/no — not just browser default
  modal_focus_trap: __FILL__          # yes/no | N/A
  escape_closes_overlays: __FILL__    # yes/no | N/A

# ARIA audit:
aria_audit:
  roles_present: __FILL__            # yes/no
  labels_present: __FILL__           # yes/no — aria-label or aria-labelledby
  live_regions: __FILL__             # yes/no — for dynamic content updates

# Color audit:
color_audit:
  text_contrast_passes: __FILL__     # yes/no — 4.5:1 normal, 3:1 large
  ui_contrast_passes: __FILL__       # yes/no — 3:1 for non-text UI
  no_color_only_meaning: __FILL__    # yes/no
```

**Failure:** Accessibility violation. Fix immediately — LAW-006 is non-negotiable.

---

### 7. Affordance Integrity

> Interactive elements must look interactive. Static elements must not.

**Source:** LAW-007, `_ui/components.yaml`

| Verify | Pass Criteria |
|--------|---------------|
| Buttons use button component | Interactive actions use the registered `button` component with correct semantic role, not unsemantic containers |
| Links use link component | Navigation uses the registered `link` component with correct navigation semantics |
| Disabled state visible | Disabled elements have reduced opacity, changed cursor, and `aria-disabled` |
| Hover states consistent | All interactive elements have hover feedback |
| No dead affordances | Nothing that looks clickable does nothing on click |
| No hidden affordances | Nothing interactive is invisible until hovered |

**Failure:** Affordance mismatch. Fix by correcting element semantics or visual treatment.

---

### 8. Tech Foundation Compliance

> Code must use the declared tech stack and respect non-goals.

**Source:** `config/tech-foundation.yaml`

| Verify | Pass Criteria |
|--------|---------------|
| `tech-foundation.yaml` status is `active` | Not `template` — stack must be declared before building |
| Framework matches | Code uses declared `stack.ui_framework` |
| Styling matches | Styles use declared `stack.styling` approach |
| State management matches | State uses declared `stack.state_management` |
| Non-goals respected | No code implements features listed in `non_goals_v1` |
| Dependencies justified | Every new dependency serves the declared stack, not a competing approach |

**Failure:** Stack violation. Fix by using declared tools or updating tech-foundation through governance.

---

## Verification Output Template

After running verification, record results:

```yaml
verification:
  surface: __FILL__                   # SURF-NNN
  date: __FILL__                      # YYYY-MM-DD
  build_tier: __FILL__                # micro | targeted | standard | complex

  results:
    token_traceability:
      status: __FILL__                # pass | fail | partial
      hardcoded_values_found: __FILL__  # count
      notes: __FILL__

    mandatory_states:
      status: __FILL__
      missing_states: __FILL__        # list
      notes: __FILL__

    budget_compliance:
      status: __FILL__
      decision_points: __FILL__       # count / max
      components: __FILL__            # count / max
      notes: __FILL__

    interaction_laws:
      status: __FILL__
      violations: __FILL__            # list
      notes: __FILL__

    entity_integrity:
      status: __FILL__
      violations: __FILL__            # list
      notes: __FILL__

    accessibility:
      status: __FILL__
      violations: __FILL__            # list
      notes: __FILL__

    affordance_integrity:
      status: __FILL__
      mismatches: __FILL__            # list
      notes: __FILL__

    tech_foundation:
      status: __FILL__
      violations: __FILL__            # list
      notes: __FILL__

  overall: __FILL__                   # pass | fail
  blocking_issues: __FILL__           # list of issues that must be fixed before merge

  # Store in: _artifacts/gates/VERIFY_{surface}_{date}.yaml
```

---

## Relationship to Other Quality Systems

| System | Checks | When |
|--------|--------|------|
| **Pre-Build** (`_expectations/PRE-BUILD.md`) | Requirements, features, scope | Before building |
| **Critique Loop** (`_critique/LOOP.md`) | Design quality (hierarchy, rhythm, density, consistency, craft) | During/after building |
| **This Protocol** | Implementation correctness against governance artifacts | After implementation |
| **Traceability** (`_quality/TRACE.yaml`) | Requirement → decision → surface → test → invariant links | Ongoing |
| **Release Review** (`_quality/RELEASE_REVIEW.md`) | Cross-surface coherence and holistic readiness | Before shipping |

These systems complement — not replace — each other. A surface can pass critique (good design) but fail verification (incorrect implementation).

---

## Related Files

- `_guides/IMPLEMENTATION_MAP.md` — Maps artifacts to implementation questions (read before building)
- `_critique/LOOP.md` — Critique loop for design quality
- `_quality/QUALITY_PROTOCOL.md` — Review gates and quality philosophy
- `_quality/TRACE.yaml` — Traceability graph
- `_rules/laws.yaml` — Interaction laws (non-negotiable)
- `_invariants/REGISTRY.md` — System invariants
