# Cross-Surface Coherence

> Product-level audit across all built screens. Run after individual surface critique passes.

**Authority:** This protocol extends the quality framework in `QUALITY_PROTOCOL.md`. Individual surfaces may pass critique but still fail coherence — this catches product-level drift.

---

## Purpose

Individual screen critique verifies that each surface is well-built. Cross-surface coherence verifies that they belong together. A product can have five excellent screens that feel like they came from five different products.

**Core test:** If you shuffled all screens randomly, would you know they belong to the same product?

**Companion:** This file checks coherence of *form* — do surfaces look, feel, and behave as a unified product? For coherence of *direction* — do features multiply each other toward the same thesis — see `DIRECTIONAL_COHERENCE.md`.

> **Proactive counterpart:** `_surfaces/EXPECTATIONS.md` prevents mental model breaks during pre-build. This file catches what slipped through during the audit after surfaces are built.

---

## Coherence Dimensions

### 1. Pattern Consistency

The same problem is solved the same way everywhere it appears.

| Check | What to Look For |
|-------|------------------|
| Navigation patterns | Same structure type uses same navigation model |
| Data display | Same entity type rendered with same density and layout logic |
| Form patterns | Same input types use same controls and validation feedback |
| Empty states | Consistent voice, structure, and guidance across all empty states |
| Error handling | Consistent severity signaling, recovery guidance, and tone |

**Failure signal:** Two screens solving the same problem in visually different ways without a structural reason for divergence.

---

### 2. Mental Model Continuity

The conceptual structure the user builds in one screen holds in every other.

| Check | What to Look For |
|-------|------------------|
| Hierarchy consistency | If A contains B on one screen, B never appears independent elsewhere |
| Relationship signals | Parent-child, peer, and grouped relationships use consistent visual grammar |
| State representation | The same state (active, draft, archived) uses the same visual treatment everywhere |
| Terminology alignment | Same concept uses same label across all surfaces (see below) |

**Failure signal:** The user must re-learn how the system works when moving between screens.

---

### 3. Visual Language Unity

Design decisions made for one screen apply to all screens at the same level.

| Check | What to Look For |
|-------|------------------|
| Spacing system | Consistent rhythm across equivalent structural levels |
| Typography hierarchy | Heading levels mean the same thing everywhere |
| Color semantics | Same color carries same meaning (status, action type, emphasis) across surfaces |
| Component treatment | Same component type styled identically everywhere it appears |
| Density balance | Screens serving similar roles have similar information density |

**Failure signal:** Screens at the same structural level feel visually unrelated.

---

### 4. Terminology Alignment

Words mean one thing and one thing only across the entire product.

| Check | What to Look For |
|-------|------------------|
| Entity names | One label per entity everywhere (not "Project" on one screen, "Workspace" on another) |
| Action labels | Same action uses same verb everywhere ("Create" not sometimes "Add" or "New") |
| Status labels | Same state uses same label everywhere ("Active" not sometimes "Live" or "Enabled") |
| Navigation labels | Destination names match the page title they navigate to |

**Failure signal:** Search for any term that appears with more than one label. Each instance is a terminology violation.

---

## Running the Audit

### When to Run

- After 3+ surfaces have passed individual critique
- Before any release that includes multiple new or revised screens
- After major design changes that affect shared patterns

### Process

```
1. Inventory all built screens
2. For each coherence dimension:
   a. Walk through every screen in sequence
   b. Note divergences from the pattern established by the first screen
   c. For each divergence: is it intentional (structural reason) or accidental (drift)?
3. Accidental divergences = P1 issues
4. Intentional divergences = document rationale in _decisions/REGISTRY.md
```

### Severity

| Finding | Severity |
|---------|----------|
| Terminology collision (same concept, different label) | P0 |
| Pattern inconsistency in primary flows | P1 |
| Visual treatment divergence at same structural level | P1 |
| Mental model contradiction between screens | P0 |
| Density mismatch between peer screens | P2 |

---

## Component Instance Audit

> Catch component drift before shared components fragment into variants.

### When to Run

At coherence checkpoints (Gates 2, 4, 6), audit shared components.

### The Audit

For each shared component, compare instances across surfaces:

```yaml
component_audit:
  component: "[Component name]"
  base_definition: "[Where the canonical version is defined]"

  instances:
    - surface: "[Where it appears]"
      variations: "[Any differences from base — props, styling, behavior]"
    - surface: "[Another surface]"
      variations: "[Any differences]"

  drift_detected: "[yes/no]"

  if_drift:
    intentional: "[yes/no]"
    if_intentional:
      justification: "[Why this variation exists]"
      action: "Declare as named variant in component system"
    if_unintentional:
      action: "Reconcile to single implementation"
```

### Drift Thresholds

| Finding | Severity |
|---------|----------|
| 1 unplanned variation | Note — may be fine |
| 2 unplanned variations | P2 — review whether variants are needed |
| 3+ unplanned variations | P1 — component is fragmenting, reconcile |

### Props Multiplication Warning

If you're adding boolean props to accommodate specific surfaces (`isCompact`, `hasIcon`, `showBorder`), the component may be trying to be too many things. Consider:

1. Is this a single component or multiple related components?
2. Should these be declared variants with clear use cases?
3. Is the base abstraction correct?

**Rule:** A component with 5+ boolean props is likely 2^5 components pretending to be one.

---

## Cross-References

- Individual screen quality: `QUALITY_PROTOCOL.md`
- Critique loop: `_critique/LOOP.md`
- Token consistency: `_ui/tokens.yaml`
- Pattern registry: `_model/patterns/`
