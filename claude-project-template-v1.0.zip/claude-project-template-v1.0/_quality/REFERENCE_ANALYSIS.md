# Reference Analysis Protocol

> Learn from the best before building. Extract principles, not pixels.

---

## Purpose

Before building any UI surface, understand how excellent products solve the same class of problem. This is not competitive analysis (strategic) — it's **craft calibration** (tactical). The goal is to understand:

1. What interaction conventions users have been trained on
2. What information architecture patterns work well for this problem type
3. What common mistakes the best products avoid
4. What the current quality bar looks like

---

## When Required

| Task Classification | Reference Analysis |
|--------------------|--------------------|
| Micro | Never |
| Targeted | Never |
| Standard (new surface) | Required (abbreviated) |
| Standard (modification) | Optional (if design decision exists) |
| Complex | Always required (full) |

---

## The Protocol

### Step 1: Identify the Pattern Type

Name the class of problem you're solving. Use specific, recognizable pattern names.

**Pattern Type Examples:**

| Category | Pattern Types |
|----------|--------------|
| Data display | Data table, card grid, list view, detail page, timeline, tree view |
| Data input | Form (single-page), form wizard (multi-step), inline editing, bulk editing |
| Navigation | Sidebar navigation, tab navigation, breadcrumb hierarchy, command palette |
| Organization | Kanban board, calendar view, folder tree, tag-based organization |
| Communication | Notification feed, activity log, comment thread, chat interface |
| Search & filter | Search with faceted filters, global search, scoped search, saved views |
| Configuration | Settings page, preference editor, permission management, role editor |
| Overview | Dashboard, overview/home page, summary view, report |
| Onboarding | Welcome flow, setup wizard, empty state guidance, feature tour |
| Status & progress | Progress tracker, status board, health monitor, audit log |

If your surface doesn't fit a known pattern type, describe it: "A [primary function] that [key characteristic] for [user context]."

### Step 2: Select Reference Products

Choose 2-3 products that are excellent at THIS SPECIFIC PATTERN. General product excellence doesn't guarantee pattern-specific excellence.

**Selection Criteria:**
```yaml
reference_selection:
  must_have:
    - Known for craft quality in this specific pattern type
    - Your target users likely use this product (convention source)
    - Sufficiently complex to be relevant (simple implementations won't teach much)

  prefer:
    - From the archetype reference list (Linear, Notion, Stripe, Figma, Framer, Webflow)
    - Similar data complexity to your use case
    - Similar user sophistication level
    - Different approaches to the same problem (diversity of solutions)

  avoid:
    - Products users don't interact with (no convention influence)
    - Products with dramatically different complexity levels
    - More than 3 references (diminishing returns)
```

**Reference Quality Check:**

For each selected reference, state:
```yaml
reference:
  product: "[Name]"
  specific_surface: "[Which screen/flow in the product]"
  why_this_reference: "[What makes them excellent at this pattern?]"
  relevance: "[How similar is their problem to ours?]"
```

### Step 3: Analyze Each Reference

For each reference product, examine these dimensions. You don't need deep analysis of every dimension — focus on what's most relevant to your problem.

**Information Structure:**
- How is information hierarchically organized?
- What's shown immediately vs. available on demand?
- How are groups/sections formed?
- What's the density level?

**Primary Task Flow:**
- How does the user accomplish the main task?
- How many steps/clicks?
- Where are decision points?
- How is feedback provided?

**State Handling:**
- What does the empty state look like?
- How are loading states handled?
- How are errors communicated?
- How are edge cases (many items, long text, missing data) handled?

**Conventions Established:**
- What interaction patterns does this product use that users will expect?
- What vocabulary is used?
- What visual conventions (iconography, color meaning, spatial patterns)?

### Step 4: Extract Transferable Principles

This is the critical step. Convert observations into principles that can be applied through your system's constraints.

**Format:**
```yaml
principles:
  - observation: "[What the reference product does]"
    principle: "[The generalizable insight]"
    application: "[How this applies to our build, through our constraints]"

  # Example:
  - observation: "Linear shows project status as a colored dot + text label,
                   not a progress bar"
    principle: "Status is best communicated through categorical signals
                (discrete states) rather than continuous ones (progress bars)
                when the states are meaningful and the transitions are
                user-driven rather than automatic"
    application: "Use our status token system (SY-001 to SY-004) with
                  semantic state labels rather than percentage-based
                  progress indicators"
```

**Quality check on principles:**
- Is it generalizable? (Not "use a blue dot" but "use categorical signals")
- Is it actionable? (Can it be applied through your constraints?)
- Is it distinct? (Not a restatement of an existing system rule)

### Step 5: Document Anti-Patterns

Note what excellent products specifically AVOID:
```yaml
anti_patterns_observed:
  - pattern: "[What they avoid doing]"
    why: "[Why they avoid it]"
    our_risk: "[Are we at risk of doing this?]"
```

---

## Output Template
```markdown
# Reference Analysis: [Surface Name]

**Pattern type:** [Category - specific pattern]
**Date:** [Date]
**Time spent:** [Minutes]

## References Analyzed

### 1. [Product] — [Specific surface]
**Why selected:** [One sentence]
**Key observations:**
- [Observation 1]
- [Observation 2]
- [Observation 3]

### 2. [Product] — [Specific surface]
**Why selected:** [One sentence]
**Key observations:**
- [Observation 1]
- [Observation 2]

### 3. [Product] — [Specific surface] (if applicable)
**Why selected:** [One sentence]
**Key observations:**
- [Observation 1]
- [Observation 2]

## Transferable Principles

1. **[Principle name]:** [Description]. Applies to our build as: [application].
2. **[Principle name]:** [Description]. Applies to our build as: [application].
3. **[Principle name]:** [Description]. Applies to our build as: [application].

## Anti-Patterns to Avoid

1. [What to avoid and why]
2. [What to avoid and why]

## Conventions Users Will Expect

1. [Convention and source]
2. [Convention and source]
```

---

## How Claude Code Performs Reference Analysis

Claude Code can perform reference analysis through several methods:

1. **From training knowledge.** Claude has detailed knowledge of products like Linear, Notion, Stripe, Figma, etc. This is sufficient for most reference analysis.

2. **From Notion Design Library.** If the project's Notion Design Library contains screenshots or notes about reference products, consult those.

3. **From web search.** If Claude Code has web access and needs current information about a product's interface, search for recent screenshots, reviews, or documentation.

4. **From the human.** If the human has specific preferences or knowledge about reference products ("check how Asana does this"), incorporate their guidance.

**What Claude Code cannot do:** Visit live product URLs and interact with them. Reference analysis relies on knowledge, documentation, and screenshots — not live product testing.

---

## Time Budget

| Classification | Time Budget | Depth |
|---------------|-------------|-------|
| Standard (new surface) | 15-30 minutes | 2 references, 2-3 principles each |
| Complex | 30-60 minutes | 2-3 references, 3-5 principles each |

**If you're spending more than 60 minutes:** You're over-analyzing. Extract the key principles and move to approach generation.

---

## Integration Points

| System Component | How Reference Analysis Connects |
|-----------------|-------------------------------|
| Explore Mode | Reference analysis is Step 0 of exploration |
| Critique Loop | Peer Test compares against reference products |
| Pre-Build | Supplements Screen Intent and Outcome declarations |
| Build Conductor | Triggered by Complex path step 5, Standard path step 5 |
| Decisions | Principles cited in approach selection rationale |

---

## Anti-Patterns

| Anti-Pattern | Why It Fails |
|--------------|-------------|
| "I already know how Linear does it" | Knowledge may be outdated or incomplete |
| Analyzing 5+ references | Diminishing returns, delays building |
| Extracting implementation details | "Use a 3-column grid" is not a principle |
| Skipping for "unique" problems | Even novel problems share pattern DNA with known solutions |
| Treating reference analysis as competitive analysis | This is craft calibration, not strategy |
| Copying without adaptation | Principles must pass through your constraint system |
