﻿import pathlib
print("script ready")