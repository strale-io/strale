# Release Readiness Review

> The mandatory ceremony before any product version ships. No exceptions.

---

## Purpose

Individual gates catch individual problems. This review ensures **all gates run, in order, with evidence, before a version reaches a user.**

Without this ceremony, it is possible to pass every critique loop on every screen and still ship a product that fails at the system level — because no one checked cross-surface coherence, ran the accessibility audit holistically, or verified the synthesis artifact against the actual build.

This review prevents that.

---

## The Law

> **No product version may be declared shipped until the Release Readiness Review passes and the human owner signs off.**

This review cannot be skipped, compressed into a critique loop, or self-certified by Claude Code. It is a distinct ceremony with its own trigger, sequence, and evidence requirements.

---

## Trigger

Claude Code initiates the Release Readiness Review **automatically** when:

1. All screens in the product have passed their individual critique loops (Gate 2)
2. No unresolved P0 or P1 issues exist in any critique scorecard

Claude Code prints:

```
═══════════════════════════════════════════════
  RELEASE READINESS REVIEW — TRIGGERED

  All [N] screens passed critique loops.
  Starting full release review sequence.

  This will take approximately [estimate].
  Results will be saved to:
    audit-output/{date}-release-review/
═══════════════════════════════════════════════
```

The human can also trigger manually by saying: **"Run release review."**

---

## Sequence

The review runs in strict order. Each phase must pass before the next begins. If any phase fails, the review halts and reports what needs fixing.

```
Phase 1: Evidence Collection     (Claude Code — automated)
Phase 2: Cross-Surface Audit     (Claude Code — automated)
Phase 3: System-Level Gates      (Claude Code — automated)
Phase 4: Synthesis Verification  (Claude Code — automated)
Phase 5: Human Review            (Human — manual)
Phase 6: Sign-Off                (Human — explicit)
```

---

## Phase 1: Evidence Collection

**Who:** Claude Code (automated)
**Purpose:** Gather and verify all prerequisite artifacts exist.

Claude Code checks that the following artifacts are present and current:

### 1.1 Pre-Build Evidence

| Check | Evidence Required | Location |
|-------|-------------------|----------|
| Intent modeled for every screen | Gate 0 checklist completed | `_decisions/eil/` or inline in specs |
| User expectations specified | Feature classifications documented | Notion Product Specs or `_decisions/` |
| EIL performed for new capabilities | EIL artifacts exist | `_decisions/eil/` |

### 1.2 Per-Screen Evidence

| Check | Evidence Required | Location |
|-------|-------------------|----------|
| Critique scorecard exists for every screen | Scorecard files | `_critique/scorecards/` |
| All scorecards show PASS | P0=0, P1≤2, all scores ≥4, Correctness=5 | Scorecard files |
| No unresolved escalations | Escalation reports resolved | `_critique/scorecards/` |

### 1.3 Decision Evidence

| Check | Evidence Required | Location |
|-------|-------------------|----------|
| Decision Registry current | All implementation decisions logged | `_decisions/REGISTRY.md` |
| No open questions blocking ship | Open Questions database checked | Notion |

**Output:** `phase-1-evidence.md` — lists every artifact found, flags any missing.

**Pass condition:** All evidence present. Any missing artifact = HALT.

---

## Phase 2: Cross-Surface Audit

**Who:** Claude Code (automated)
**Purpose:** Catch problems that only appear when screens are evaluated together, not individually.

Individual critique loops examine one screen at a time. This phase examines the product as a whole.

### 2.1 Navigation Coherence

| Check | What to Verify |
|-------|----------------|
| Every screen is reachable | No orphan pages (built but not linked) |
| Back behavior is consistent | Same pattern used across all screens |
| Breadcrumbs are accurate everywhere | No stale or missing breadcrumbs |
| URL patterns follow grammar | URLs match `_ia/grammar.yaml` consistently |

### 2.2 Visual Consistency

| Check | What to Verify |
|-------|----------------|
| Same component looks the same everywhere | Buttons, cards, tables rendered identically |
| Token usage is consistent | No screen using hardcoded values while others use tokens |
| Spacing rhythm is uniform | Same content density approach throughout |
| Empty states follow same pattern | Consistent illustration style, copy tone, action placement |

### 2.3 Vocabulary Consistency

| Check | What to Verify |
|-------|----------------|
| Same concept uses same term everywhere | "Project" is never also called "Campaign" |
| Status labels are consistent | Same states use same labels across screens |
| Action labels are consistent | Same action uses same verb everywhere |
| Explanation patterns are consistent | Tooltips, help text follow same style |

### 2.4 Interaction Consistency

| Check | What to Verify |
|-------|----------------|
| Same actions behave the same way | Delete confirmation pattern identical everywhere |
| Feedback patterns are uniform | Success/error messages follow same style |
| Loading states are consistent | Same skeleton/spinner approach throughout |
| Error handling follows same pattern | Error display, recovery, messaging uniform |

### 2.5 Flow Integrity

| Check | What to Verify |
|-------|----------------|
| Primary user flows work end-to-end | Walk through each flow start to finish |
| Cross-screen state is preserved | Filters, selections, scroll position survive navigation |
| No dead ends in any flow | Every screen has a clear "next" or "back" |
| Edge cases handled at boundaries | What happens at screen transitions? |

**Output:** `phase-2-cross-surface.md` — findings organized by category, issues ranked P0/P1/P2.

**Pass condition:** P0=0, P1≤3. Any P0 = HALT. P1s get logged for fix-then-re-review.

---

## Phase 3: System-Level Gates

**Who:** Claude Code (automated)
**Purpose:** Run the gates that are defined as "before release" or "before major release" — the ones that individual critique loops don't cover.

### 3.1 Gate 3: Accessibility Audit

Full WCAG 2.1 AA compliance check across the entire product, not per-screen.

| Check | Scope |
|-------|-------|
| Keyboard navigation | Every screen, every interactive element |
| Color contrast | All text, all states, all themes |
| Screen reader compatibility | Landmarks, headings, alt text, ARIA |
| Focus management | Tab order logical across all screens |
| Reduced motion | All animations respect `prefers-reduced-motion` |

**Output:** `phase-3a-accessibility.md`

### 3.2 Gate 4: Drift Detection

Check that implementation still matches the documented system.

| Check | What to Verify |
|-------|----------------|
| Truth model match | UI entities match `_model/truth/entities.yaml` |
| Action model match | UI actions match `_model/truth/actions.yaml` |
| State model match | UI states match `_model/truth/states.yaml` |
| Component compliance | All components from `_ui/components.yaml` |
| Token compliance | All values from `_ui/tokens.yaml` |
| Archetype compliance | Every screen within archetype budget |
| Invariant compliance | Spot-check against `_invariants/REGISTRY.md` |

**Output:** `phase-3b-drift.md`

### 3.3 Gate 5: Completeness Audit (Holistic)

Run the completeness checklist from QUALITY_PROTOCOL.md across the entire product:

| Check | Scope |
|-------|-------|
| Every button performs an action | All screens |
| Every link navigates somewhere | All screens |
| Every chevron/arrow navigates | All screens |
| Primary user flows work end-to-end | All flows |
| Breadcrumbs are clickable and functional | All screens |
| No "coming soon" on primary actions | All screens |
| No dead ends in main navigation | All paths |
| Progress indicators explain what they measure | All indicators |

**Output:** `phase-3c-completeness.md`

### 3.4 Gate 7: Stickiness Audit (if `moat-conscious` preset active)

| Check | Scope |
|-------|-------|
| Features contribute to declared moats | All features |
| Moat claims are testable | All claims |
| Export formats are stable contracts | All exports |

**Output:** `phase-3d-stickiness.md` (only if applicable)

**Pass condition for Phase 3:** All sub-gates pass individually. Any P0 in any gate = HALT.

---

## Phase 4: Synthesis Verification

**Who:** Claude Code (automated)
**Purpose:** Gate 6 (Artifact Readiness) — verify the product can produce its synthesis artifact truthfully.

### 4.1 Artifact Structure

| Check | What to Verify |
|-------|----------------|
| Artifact sections defined | All sections documented |
| Section requirements clear | Each section knows what info/decisions/states it needs |
| Section maturity tracked | Every section has state: Renderable/Partial/Placeholder/Blocked |

### 4.2 Feature-to-Artifact Traceability

| Check | What to Verify |
|-------|----------------|
| Every feature traces to an artifact section | No orphan features |
| Every artifact section has supporting features | No empty sections |
| Orphan features are documented and justified | If feature exists without artifact purpose, explain why |

### 4.3 Truthfulness

| Check | What to Verify |
|-------|----------------|
| Renderable sections can be produced now | Actually generate them, don't just claim |
| Undecided areas are explicitly marked | No hidden gaps |
| No placeholders presented as decisions | Honest about what's incomplete |
| Artifact shows actual state, not aspirational | What IS, not what WILL BE |

### 4.4 Delivery Readiness

| Check | What to Verify |
|-------|----------------|
| Artifact requires no verbal explanation | SA-006 |
| Artifact would not require apology | SA-004 |
| Agency Test passes | Premium agency would ship this |
| External confidence | Could share with client |

**Output:** `phase-4-synthesis.md`

**Pass condition:** All Truthfulness checks pass (these are P0). Delivery Readiness checks: P0 if "requires apology," P1 otherwise.

---

## Phase 5: Human Review

**Who:** Human (you)
**Purpose:** The tests that require human judgment and cannot be automated.

When Phases 1–4 pass, Claude Code presents a structured handoff:

```
═══════════════════════════════════════════════
  PHASES 1–4 PASSED

  Your review is needed for Phase 5.

  Estimated time: 15–30 minutes

  Audit folder: audit-output/{date}-release-review/

  Please review each item below and respond
  with PASS or FAIL + reason for each.
═══════════════════════════════════════════════
```

### 5.1 Professional Embarrassment Gate

Walk through every screen and answer honestly:

> Would you say "this part is still rough," "we'll improve this later," "ignore this for now," or "I know this looks off" about ANY part of ANY screen?

If yes for any screen → **FAIL** with specifics.

### 5.2 Demo Test

Imagine giving a live demo of this product to a demanding client:

> Is there any screen you would skip, any feature you would avoid clicking, any section you would explain away?

If yes → **FAIL** with specifics.

### 5.3 Screenshot Test

Take a screenshot of every primary screen:

> Would you include each screenshot in a pitch deck, portfolio, or case study without hesitation?

If hesitation on any → **FAIL** with specifics.

### 5.4 Peer Test

For each screen:

> Could this screen exist in Linear, Stripe, or Notion without looking out of place?

If any screen would look jarring next to these products → **FAIL** with specifics.

### 5.5 First Impression Test

Imagine a new user seeing the product for the first time:

> Within 10 seconds, would they understand what this product does, where to start, and what it's for?

If not → **FAIL** with specifics.

### 5.6 Artifact Walkthrough

Review the synthesis artifact generated in Phase 4:

> Would you send this artifact to a client or stakeholder right now, as-is, without any caveats?

If not → **FAIL** with specifics.

**Output:** Human provides PASS/FAIL for each item. Claude Code records in `phase-5-human-review.md`.

**Pass condition:** All items PASS. Any FAIL = fix and re-review from the earliest affected phase.

---

## Phase 6: Sign-Off

**Who:** Human (explicit)
**Purpose:** Formal acknowledgment that this version is ready to ship.

After Phase 5 passes, Claude Code presents:

```
═══════════════════════════════════════════════
  ALL PHASES PASSED

  Phase 1: Evidence Collection     ✓
  Phase 2: Cross-Surface Audit     ✓
  Phase 3: System-Level Gates      ✓
  Phase 4: Synthesis Verification  ✓
  Phase 5: Human Review            ✓

  Ready for sign-off.

  To ship, confirm: "Ship [version]"
  To hold, say what needs more work.
═══════════════════════════════════════════════
```

The human must explicitly say **"Ship [version]"** (e.g., "Ship v1.0").

Claude Code then:
1. Records the sign-off in `phase-6-signoff.md` with date and version
2. Logs a decision in `_decisions/REGISTRY.md`:
   ```yaml
   - id: DEC-{date}-RR
     decision: "Release Readiness Review passed for v{version}"
     date: {date}
     owner: "{human}"
     context: "Full release review completed"
     chosen: "Ship v{version}"
     rejected:
       - "Hold — all phases passed"
     stability: hard
     evidence: "audit-output/{date}-release-review/"
   ```
3. Updates Notion Implementation Log with release record

---

## Failure and Re-Review

When any phase fails:

### Failure in Phases 1–4 (Claude Code phases)

1. Claude Code reports the failures with specific issues
2. Issues are fixed normally (critique loops, patches)
3. The review **restarts from the earliest failed phase**, not from scratch
4. Previously-passed phases are not re-run unless fixes could have affected them

### Failure in Phase 5 (Human review)

1. Human provides specific failure reasons
2. Claude Code creates fix tasks from the failure report
3. After fixes, Phase 5 re-runs in full (human judgment is holistic)
4. Phases 1–4 re-run only if structural changes were made

### Re-Review Scope Rules

| What Changed | Re-Run From |
|--------------|-------------|
| Single screen fix (visual/copy) | Phase 2 (cross-surface could be affected) |
| New feature added | Phase 1 (evidence needed) |
| Navigation change | Phase 2 |
| Accessibility fix only | Phase 3 |
| Artifact content change only | Phase 4 |

---

## Output Structure

All review artifacts are saved to:

```
audit-output/
  {YYYY-MM-DD}-release-review/
    phase-1-evidence.md
    phase-2-cross-surface.md
    phase-3a-accessibility.md
    phase-3b-drift.md
    phase-3c-completeness.md
    phase-3d-stickiness.md          # if applicable
    phase-4-synthesis.md
    phase-5-human-review.md
    phase-6-signoff.md
    summary.md                       # overall pass/fail + key metrics
    screenshots/                     # visual evidence
```

### Summary File Format

```markdown
# Release Readiness Review — v{version}

**Date:** {date}
**Product:** {product name}
**Screens reviewed:** {count}
**Flows verified:** {count}

## Results

| Phase | Result | Issues Found | Issues Resolved |
|-------|--------|--------------|-----------------|
| 1. Evidence Collection | PASS | 0 | 0 |
| 2. Cross-Surface Audit | PASS | 2 P1 | 2 P1 |
| 3. System-Level Gates | PASS | 1 P1 | 1 P1 |
| 4. Synthesis Verification | PASS | 0 | 0 |
| 5. Human Review | PASS | 0 | 0 |
| 6. Sign-Off | SHIPPED | — | — |

## Key Metrics

- Total critique cycles across all screens: {N}
- Total P0 found and resolved: {N}
- Total P1 found and resolved: {N}
- Review iterations: {N} (1 = passed first time)
- Time from trigger to sign-off: {duration}

## Sign-Off

Shipped by: {human}
Date: {date}
Version: {version}
Decision: DEC-{date}-RR
```

---

## Relationship to Existing Gates

This review does **not** replace any existing gate. It orchestrates them.

| Gate | When It Normally Runs | Role in Release Review |
|------|----------------------|------------------------|
| Gate 0: Pre-Creation | Before building | Phase 1 verifies it happened |
| Gate 1: Self-Review | Before PR | Prerequisite (already done) |
| Gate 2: Critique Loop | Per screen | Prerequisite (trigger condition) |
| Gate 3: Accessibility | Before major release | Phase 3 runs it holistically |
| Gate 4: Drift Detection | Before merge | Phase 3 runs it holistically |
| Gate 5: Completeness | Before release | Phase 3 runs it holistically |
| Gate 6: Artifact Readiness | Before delivery | Phase 4 runs it |
| Gate 7: Stickiness | Before major release | Phase 3 runs it (if applicable) |

**What the Release Review adds that gates alone don't cover:**

- Phase 2 (Cross-Surface Audit) — consistency across screens
- Phase 5 (Human Review) — structured human judgment ceremony
- Phase 6 (Sign-Off) — explicit ship decision with audit trail
- Sequencing — enforced order ensures nothing is skipped
- Evidence — artifacts prove each gate ran, not just claimed

---

## Scope

### When to Run

| Event | Required? |
|-------|-----------|
| First version (v1.0) of any product | **Yes — mandatory** |
| Major version (v2.0, v3.0) | **Yes — mandatory** |
| Minor version with new screens | **Yes — mandatory** |
| Minor version with fixes only | No — critique loops sufficient |
| Patch/hotfix | No |

### What Counts as "All Screens"

The trigger condition "all screens passed critique loops" means:
- Every screen defined in the product spec has a passing scorecard
- Every screen that exists in the codebase has a passing scorecard
- These two sets are identical (no unspecified screens, no unbuilt specs)

If specs and implementation diverge, the review cannot trigger. Fix the divergence first.

---

## Anti-Gaming

The following behaviors are explicitly prohibited:

| Anti-Pattern | Why It's Wrong | What to Do Instead |
|--------------|----------------|-------------------|
| Inflating critique scores to trigger the review | Undermines the entire quality system | Scores must reflect actual state |
| Skipping Phase 2 because "each screen already passed" | Cross-surface issues are invisible per-screen | Phase 2 is mandatory |
| Self-certifying Phase 5 | Human judgment cannot be automated | Human must actually look |
| Signing off without reviewing audit folder | Sign-off implies review | Read the evidence |
| Declaring "fix later" for P1s found in Phase 2+ | P1s found in release review block ship | Fix, then re-review |
