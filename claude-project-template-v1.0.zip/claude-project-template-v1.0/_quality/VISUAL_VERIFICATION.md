# Visual Verification Protocol

> See what the user sees. Evaluate what actually renders, not what the code describes.

---

## The Law

> **Code review is not visual review.** Evaluating code quality, token compliance, and structural correctness are necessary but insufficient. Visual verification evaluates the rendered output — what users actually see and interact with.

Visual verification is required:
- After every build step that produces UI changes (Standard and Complex paths)
- As input to every critique cycle (not just the final one)
- When visual craft scores below 4 in any critique cycle
- When evaluating transitions between screens
- When assessing empty states, error states, or loading states

---

## Tools

### Recommended: Playwright

Playwright is the recommended tool for automated screenshot capture. It runs headless browsers, captures screenshots at specified viewports, and can simulate different states.

**Setup (in `config/tech-foundation.yaml` under `tooling.visual_verification`):**
```yaml
visual_verification:
  tool: playwright  # or: puppeteer, cypress, manual
  status: __SELECT__ [not_selected, active]
  config:
    browsers: [chromium]  # Add firefox, webkit for cross-browser
    default_viewport:
      width: 1440
      height: 900
    screenshot_format: png
    screenshot_quality: 90  # For jpeg only
```

### Alternative: Manual Browser

If Playwright is not configured, use manual browser rendering:
1. Start the dev server
2. Open in Chrome/Firefox
3. Use DevTools device toolbar for different viewports
4. Use browser screenshot (Ctrl+Shift+P → "Capture screenshot") for full-page captures

### What Claude Code Actually Does

Claude Code executes verification by:
1. Starting the development server (if not running)
2. Running a Playwright script (or equivalent) that navigates to the target surface
3. Capturing screenshots at specified breakpoints and states
4. Evaluating the screenshots against the verification checklist
5. Including findings in the critique scorecard

---

## Capture Protocol

### Breakpoints

Capture at these viewports (aligned with `_ui/RESPONSIVE.md` breakpoints):

| Name | Width | When Required |
|------|-------|---------------|
| Desktop (default) | 1440px | Always |
| Desktop (narrow) | 1024px | Always for Complex, if responsive for Standard |
| Tablet | 768px | If responsive design is in scope |
| Mobile | 375px | If responsive design is in scope |

**Note:** Only capture breakpoints that are in scope for the current build. If the product is desktop-only, capture Desktop (default) and Desktop (narrow) only.

### States

For each surface, capture these states (as applicable):

| State | Description | When Required |
|-------|-------------|---------------|
| Default/populated | Normal state with realistic data | Always |
| Empty | No data state | If the surface can be empty |
| Loading | Data is being fetched | If async data loading exists |
| Error | Something went wrong | If error states are designed |
| Hover (key elements) | Interactive element hover states | Standard + Complex |
| Focus | Keyboard focus visible | Complex (accessibility check) |
| Expanded/collapsed | If progressive disclosure exists | If applicable |
| Edge case: many items | Long lists, many tags, etc. | Complex |
| Edge case: long text | Overflowing titles, descriptions | Complex |
| Edge case: minimal data | Barely populated state | Complex |

### Realistic Data

**Critical:** Never use placeholder data for visual verification. Screenshots must use realistic data that resembles what actual users would see.

| Bad | Good |
|-----|------|
| "Lorem ipsum dolor sit amet" | "Q3 Revenue Report — North America Region" |
| "User 1", "User 2", "User 3" | "Sarah Chen", "Marcus Johnson", "Priya Patel" |
| 10 identical rows | Varied rows with different statuses, lengths, dates |
| Empty description fields | Some filled, some empty (realistic mix) |

---

## Screenshot Storage

```
audit-output/
  {date}-visual/
    {surface-name}/
      desktop-default.png
      desktop-narrow.png
      tablet.png          (if applicable)
      mobile.png          (if applicable)
      state-empty.png     (if applicable)
      state-loading.png   (if applicable)
      state-error.png     (if applicable)
      state-hover-{element}.png  (if applicable)
      edge-many-items.png (if applicable)
      edge-long-text.png  (if applicable)
```

**Naming convention:** `{breakpoint}-{state}.png`

**Retention:** Screenshots persist for the duration of the build. They are included in critique output and can be referenced in handoff files.

---

## Evaluation Protocol

After capturing screenshots, evaluate against these dimensions. This feeds directly into the critique loop's Visual Craft and related dimensions.

### Quick Evaluation (Standard tasks — 5-10 minutes)

For each screenshot, answer:
```yaml
quick_eval:
  first_impression:
    question: "What does this communicate in the first 2 seconds?"
    expected: "[Should match Screen Intent Declaration if it exists]"

  hierarchy:
    question: "Is the most important element also the most visually prominent?"
    check: "Apply Squint Test — blur the screenshot and confirm hierarchy"

  density:
    question: "Does the information density feel appropriate for the task?"
    check: "Compare to archetype density expectation"

  craft:
    question: "Would this pass the Peer Test? Screenshot Test?"
    check: "Could this exist in Linear/Notion/Stripe without apology?"

  issues:
    - "[Any visual issue spotted]"
```

### Full Evaluation (Complex tasks — 15-30 minutes)

Everything in Quick Evaluation, plus:
```yaml
full_eval:
  # Multi-persona walkthrough
  personas:
    anxious_first_timer:
      first_look: "[Where does attention land?]"
      hesitation: "[Where would they pause or worry?]"
      confidence: "[What builds or erodes trust?]"

    power_user_in_hurry:
      scan_path: "[Where do their eyes go for the key info?]"
      efficiency: "[Can they accomplish the task quickly?]"
      shortcuts: "[Are keyboard/power-user paths visible?]"

    skeptical_evaluator:
      credibility: "[What makes this feel professional or amateur?]"
      completeness: "[What's missing that they'd expect?]"
      edge_cases: "[What would they try to break?]"

  # Cross-state consistency
  state_consistency:
    question: "Do empty, loading, error, and populated states feel like the same product?"
    check: "Compare screenshots side by side"

  # Cross-surface consistency (if multi-surface)
  surface_consistency:
    question: "Does this surface feel like it belongs to the same product as siblings?"
    check: "Open sibling surface screenshots side by side"

  # Responsive consistency (if multiple breakpoints)
  responsive_consistency:
    question: "Does the responsive adaptation preserve hierarchy and intent?"
    check: "Compare desktop and narrow/tablet screenshots"

  # Alignment and spacing
  precision:
    question: "Are alignments precise? Any 'almost aligned' elements?"
    check: "Look specifically at left edges, baselines, and spacing rhythm"
```

### Visual Issue Severity

| Severity | Examples |
|----------|---------|
| P0 (Block Ship) | Broken layout, overlapping elements, invisible text, wrong colors |
| P1 (Block Done) | Missing hover states, inconsistent spacing, hierarchy unclear, alignment off |
| P2 (Backlog) | Minor polish (animation smoothness, micro-spacing tweaks, subtle optical adjustments) |

---

## Integration with Critique Loop

Visual verification output is a **required input** to the critique loop for Standard and Complex tasks.

### How It Connects

```
BUILD → VISUAL VERIFICATION → CRITIQUE → PATCH → VISUAL VERIFICATION → CRITIQUE → ...
```

Visual verification runs BEFORE each critique cycle, not after. The critique scores visual dimensions based on what verification found.

### Critique Dimensions Informed by Visual Verification

| Critique Dimension | Visual Verification Input |
|-------------------|-------------------------|
| Visual Craft | Quick/Full evaluation output |
| Information Architecture | Hierarchy assessment from screenshots |
| Interaction | Hover/focus state screenshots |
| Accessibility | Focus indicator visibility, contrast visual check |
| Completeness | State coverage (empty, loading, error all captured?) |
| Intent Alignment | First impression matches declared intent? |

### Score Capping Rule

**If visual verification was not performed, the following critique dimensions are capped at 3:**
- Visual Craft (cannot confirm what user actually sees)
- Interaction (cannot confirm hover/focus states render correctly)
- Completeness (cannot confirm all states are visually complete)

This cap is non-negotiable. "The code looks right" is not visual verification.

---

## Playwright Script Template

For projects using Playwright, here's a starter script that can be adapted:
```typescript
// scripts/visual-verify.ts
// Adapt this template to your project's needs

import { chromium, type Page } from 'playwright';
import path from 'path';
import fs from 'fs';

const BREAKPOINTS = {
  'desktop-default': { width: 1440, height: 900 },
  'desktop-narrow': { width: 1024, height: 768 },
  'tablet': { width: 768, height: 1024 },
  'mobile': { width: 375, height: 812 },
};

const OUTPUT_DIR = path.join(
  'audit-output',
  `${new Date().toISOString().split('T')[0]}-visual`
);

interface CaptureConfig {
  url: string;
  surfaceName: string;
  breakpoints: (keyof typeof BREAKPOINTS)[];
  states?: {
    name: string;
    setup: (page: Page) => Promise<void>;
  }[];
}

async function capture(config: CaptureConfig) {
  const browser = await chromium.launch();
  const surfaceDir = path.join(OUTPUT_DIR, config.surfaceName);
  fs.mkdirSync(surfaceDir, { recursive: true });

  for (const bp of config.breakpoints) {
    const context = await browser.newContext({
      viewport: BREAKPOINTS[bp],
    });
    const page = await context.newPage();
    await page.goto(config.url, { waitUntil: 'networkidle' });

    // Default state
    await page.screenshot({
      path: path.join(surfaceDir, `${bp}-default.png`),
      fullPage: true,
    });

    // Additional states
    if (config.states) {
      for (const state of config.states) {
        await state.setup(page);
        await page.screenshot({
          path: path.join(surfaceDir, `${bp}-${state.name}.png`),
          fullPage: true,
        });
      }
    }

    await context.close();
  }

  await browser.close();
  console.log(`Screenshots saved to ${surfaceDir}`);
}

// Usage example:
// capture({
//   url: 'http://localhost:3000/projects',
//   surfaceName: 'project-list',
//   breakpoints: ['desktop-default', 'desktop-narrow'],
//   states: [
//     { name: 'empty', setup: async (page) => { /* navigate to empty state */ } },
//     { name: 'loading', setup: async (page) => { /* throttle network */ } },
//   ],
// });
```

**This template is a starting point.** Adapt it to your project's tech stack, routing, and state management. The protocol is tool-agnostic — what matters is that screenshots are captured, stored, and evaluated.

---

## When Visual Verification Is Impractical

Sometimes visual verification cannot be fully automated (e.g., early prototyping, design exploration before code exists).

### Degraded Visual Verification

If full Playwright-based verification isn't possible:

| Method | Acceptable For | Score Cap |
|--------|---------------|-----------|
| Playwright/automated screenshots | All tasks | None (full scoring) |
| Manual browser screenshots | All tasks | None (full scoring) |
| Dev server + manual inspection (no screenshots saved) | Targeted tasks only | Visual Craft capped at 4 |
| Code review only (no rendering) | Micro tasks only | Visual Craft capped at 3 |

**Rule:** For Standard and Complex tasks, at minimum capture manual screenshots. "I looked at it in the browser" without saved screenshots is not verifiable and cannot support scoring above 4.

---

## Anti-Patterns

| Anti-Pattern | Why It Fails |
|--------------|-------------|
| "The code uses correct tokens, so it looks right" | Tokens can combine in unexpected ways |
| Screenshots with placeholder data | Doesn't reveal real-world visual issues |
| Only capturing default state | Empty/error/loading states often have visual problems |
| Only capturing desktop | Responsive issues are invisible at one breakpoint |
| Skipping visual verification to save time | Visual bugs caught in review cost more than prevention |
| Evaluating screenshots without criteria | "Looks good" is not evaluation |
