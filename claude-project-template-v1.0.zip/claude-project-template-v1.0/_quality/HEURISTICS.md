# Design Tradeoff Heuristics

> When design principles conflict, these heuristics guide resolution.

**Authority:** This file provides judgment guidance for design conflicts that the resolution order (`SYSTEM_CONTRACT.md`) does not address. The resolution order handles *structural* conflicts (which file wins). This file handles *design judgment* conflicts (which principle wins when both are valid).

**Scope:** These heuristics apply during building and critique. They do not override laws, invariants, or the resolution order. They guide the space *within* those constraints where designer judgment is required.

---

## Purpose

Rules tell you what must be true. Heuristics tell you what to prefer when multiple true things compete for the same space.

Every UI decision involves tradeoffs. Elite designers resolve these tradeoffs consistently because they've internalized priority systems. AI agents need those priorities made explicit.

---

## The Priority Ladder

When two valid design goals conflict, resolve using this priority order. Higher always wins.

### Tier 1: Non-Negotiable (Laws)

These are already encoded in `_rules/laws.yaml` and never lose a tradeoff.

| Priority | Principle | Reference |
|----------|-----------|-----------|
| 1 | **Data accuracy** — Displayed data matches system data | LAW-005 |
| 2 | **Accessibility** — Keyboard, contrast, screen reader | LAW-006 |
| 3 | **Affordance integrity** — Interactive things work | LAW-007 |
| 4 | **User confidence** — User knows where, what, why, escape | LAW-001 |

If any design choice compromises these, it loses. No tradeoff analysis needed.

### Tier 2: High Priority (Principles)

These win most tradeoffs but may yield to each other based on context.

| Priority | Principle | Loses To |
|----------|-----------|----------|
| 5 | **Clarity** — The user understands what's happening | Only Tier 1 |
| 6 | **Safety** — Destructive actions have guardrails | Only clarity + Tier 1 |
| 7 | **Predictability** — Same pattern works the same way everywhere | Only safety + above |
| 8 | **Completeness** — All necessary information is present | Only predictability + above |
### Tier 3: Important (Preferences)

These are valuable but yield to higher tiers.

| Priority | Principle | Loses To |
|----------|-----------|----------|
| 9 | **Efficiency** — Fewer steps/clicks to accomplish task | Tier 1 + Tier 2 |
| 10 | **Density** — More information per viewport | Tier 1 + Tier 2 |
| 11 | **Aesthetics** — Visual polish and craft | Tier 1 + Tier 2 |
| 12 | **Novelty** — Fresh or innovative approach | Everything above |

---

## Common Tradeoff Resolutions

### Clarity vs. Density

> "I can show more data, but it will be harder to scan."

**Default resolution:** Clarity wins. Dense data that can't be parsed is useless data.

**Exception:** When the audience is expert (manifest.yaml `audience.expertise: expert`) and the surface archetype is `workspace` or `data-dense`, density may win — but only if scanning is supported by clear hierarchy, grouping, and typography.

**Test:** Squint Test. If visual hierarchy disappears when the screen is blurred, density has won at clarity's expense.

### Speed vs. Safety

> "I can skip the confirmation, but the action is destructive."

**Default resolution:** Safety wins for destructive actions. Speed wins for non-destructive.

**Threshold:**

| Action Type | Default |
|------------|---------|
| Irreversible (delete, publish externally) | Confirmation required |
| High-impact reversible (archive, bulk change) | Confirmation required |
| Low-impact reversible (edit, move, reorder) | No confirmation — undo instead |
| Non-destructive (create, view, filter) | Never confirm |

**Reference:** BAN-I03 already bans confirmation for non-destructive actions.

### Consistency vs. Context

> "Every list uses click-to-select, but this list is different enough that another pattern would be better."

**Default resolution:** Consistency wins. Users build muscle memory; breaking it costs more than the contextual improvement gains.

**Exception:** When the structural difference is fundamental (not just aesthetic). If the list contains fundamentally different entities with different interaction needs, a different pattern may be justified — but must be documented in `_decisions/REGISTRY.md` with rationale.

**Test:** If you have to explain why this surface is different, consistency probably should have won.
### Completeness vs. Simplicity

> "I can show all the fields, but the form becomes overwhelming."

**Default resolution:** Simplicity wins for creation flows. Completeness wins for detail/edit views.

**Heuristic:** Progressive disclosure resolves this — show minimum viable fields upfront, additional fields on demand. See `_interaction/PROGRESSION.md` and `_extensions/disclosure/` if active.

**Rule of thumb:**

| Context | Prefer |
|---------|--------|
| **Create** | Minimum fields. Let user add detail after creation. |
| **Edit** | All fields visible. User chose to edit; show everything. |
| **View** | Key fields prominent. Secondary fields accessible but not competing. |
| **Search/Filter** | Simple by default. Advanced on demand. |

### Information vs. Noise

> "This notification/indicator/badge is technically informative, but it adds visual noise."

**Default resolution:** Suppress unless the user would actively miss it.

**Test:** The Absence Test from `_expectations/PRE-BUILD.md`. Would the user complain if this information were missing? If no, suppress it.

**Thresholds:**

| Signal | Show When |
|--------|-----------|
| Status badge | State is non-default AND user needs to act |
| Notification dot | Unread count > 0 AND notification is actionable |
| Warning icon | Risk exists AND user can mitigate |
| Info tooltip | Term is non-obvious AND user is likely to encounter it first time |

### Flexibility vs. Opinionation

> "I can make this configurable, or I can pick the right default and not offer a choice."

**Default resolution:** Opinionation wins. Every configuration option is a decision the user must make instead of the product making it for them.

**Exception:** When user needs genuinely differ AND the difference isn't predictable from context. If you can detect the right answer from context (audience type, usage pattern, content type), use a smart default instead.

**Reference:** LAW-009 (Replacement Before Addition) and LAW-010 (Negative Capability) support opinionation.

### Discoverability vs. Distraction

> "I want users to find this feature, but surfacing it disrupts their current task."

**Default resolution:** Current task wins. Discovery happens in dedicated moments (onboarding, empty states, feature announcements), not mid-task.

**Reference:** If disclosure extension is active, respect lifecycle stage rules. Features should be discoverable at the appropriate stage, not broadcast at all times.
---

## Applying Heuristics

### During Building

When you face a design conflict:

1. **Identify the competing principles** (name them explicitly)
2. **Check the Priority Ladder** — does one clearly outrank the other?
3. **Check Common Tradeoffs** — is this a known conflict with a default resolution?
4. **If still ambiguous**, apply the context-specific exception tests
5. **Document the resolution** — brief note in the surface spec or decision registry

### During Critique

When scoring reveals a tradeoff:

1. **Name the tradeoff** in the critique card (e.g., "Chose density over clarity")
2. **Evaluate whether the right principle won** using the Priority Ladder
3. **If wrong principle won**, flag as P1
4. **If right principle won but execution is weak**, flag as P2

### Tradeoff Documentation Template

For significant tradeoffs (not every micro-decision, but choices that shape the surface):
```yaml
tradeoff:
  surface: "SURF-__FILL__"
  competing_principles:
    - principle_a: "__FILL__"        # e.g., "density"
    - principle_b: "__FILL__"        # e.g., "clarity"
  resolution: "__FILL__"             # Which won and why
  priority_ladder_position:
    principle_a: __FILL__            # Number from ladder (5-12)
    principle_b: __FILL__
  exception_applied: __SELECT__      # yes | no
  if_exception: "__FILL__"           # Why the default resolution was overridden
```
---

## Tradeoff Anti-Patterns

| Anti-Pattern | Problem | Fix |
|-------------|---------|-----|
| **"We can have both"** | Refusing to acknowledge a tradeoff leads to mediocre compromise | Name the tradeoff, pick a winner |
| **Novelty over consistency** | Inventing new patterns when existing ones work | Consistency wins unless structural difference is fundamental |
| **Density by default** | Showing everything because "the user might need it" | Show what matters; provide access to the rest |
| **Safety theater** | Confirming non-destructive actions "just to be safe" | BAN-I03 exists for this reason |
| **Aesthetic override** | Making something prettier at the cost of clarity or accessibility | Aesthetics is Tier 3; it always yields to Tier 1 and 2 |
| **Feature parity as goal** | Adding features because competitors have them, not because users need them | LAW-010 (Negative Capability) |

---

## Extending Heuristics

Projects may add project-specific tradeoff resolutions in `_project.yaml` or via decision registry entries. These must not contradict the Priority Ladder — they can only add context-specific resolutions within the existing tier structure.
```yaml
# Example project-specific heuristic (in _project.yaml):
tradeoff_overrides:
  - conflict: "density_vs_clarity"
    project_resolution: "density wins on analytics surfaces"
    rationale: "Expert audience expects data-dense views"
    surfaces: ["SURF-__FILL__"]
```

---

## Related Files

| File | Relationship |
|------|-------------|
| `_rules/laws.yaml` | Tier 1 priorities (non-negotiable) |
| `SYSTEM_CONTRACT.md` | Resolution order for structural conflicts |
| `_expectations/PRE-BUILD.md` | Implicit Decision Surfacing (surfaces tradeoffs) |
| `_critique/LOOP.md` | Critique evaluates tradeoff resolution quality |
| `_quality/LEARNING.md` | Common tradeoff mistakes predict critique failures |
| `config/manifest.yaml` | Audience expertise and density posture inform context |
