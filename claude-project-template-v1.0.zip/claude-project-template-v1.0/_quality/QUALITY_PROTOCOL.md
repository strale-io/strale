# Quality Protocol

> Review gates, verification dimensions, and quality assurance.

---

## Quality Philosophy

> **Quality is correctness + coherence + craft.** All three required.

---

## Authority Levels

| Source | Authority | Meaning |
|--------|-----------|---------|
| **Protocol** | Must | Non-negotiable requirements |
| **Archetypes** | Target | Expected patterns and budgets |
| **Exemplars** | Inspiration | Reference examples (non-normative) |

When in conflict: Protocol > Archetypes > Exemplars.

---

## Review Gates

### Gate 0: Pre-Creation
Before any building. Check: spec interrogated, intent modeled, output type identified, success criteria defined, audience assumed, user expectations specified. If new capability, EIL completed.

**Non-Functional Requirements (Required):**
- [ ] Performance targets defined (see `_nfr/PERFORMANCE.yaml`)
- [ ] Reliability targets defined (see `_nfr/RELIABILITY.yaml`)
- [ ] Security requirements defined (see `_nfr/SECURITY.yaml`)
- [ ] Privacy requirements defined (see `_nfr/PRIVACY.yaml`)
- [ ] All NFR files have status "active" before building begins

**Pre-Creation Checklist (LAW-011 + LAW-012):**

**Spec Interrogation (Required):**
- [ ] Spec treated as hypothesis, not truth
- [ ] 3-5 assumptions extracted — each must be **falsifiable** (could be proven wrong)
- [ ] At least one assumption contradicts the obvious interpretation of the spec
- [ ] Assumptions reference specific product decisions, not generic truths ("users want to see data" is not falsifiable)
- [ ] Problem space expanded beyond spec wording
- [ ] Alternative interpretations considered
- [ ] Interrogation artifact exists before proceeding

**Enforcement:** Critique loop cannot begin without spec interrogation artifact. Missing artifact = Gate 0 failure.

**Intent Modeling:**
- [ ] Problem being solved is explicit
- [ ] Output type identified (Decision / Display / Export / Narrative)
- [ ] Scope boundaries set (what's in, what's out)
- [ ] Success criteria defined ("done" looks like...)
- [ ] Audience assumed (default: Client)

**Thesis Alignment (conditional — if `manifest.yaml` → `thesis.claim` is filled):**
- [ ] **Thesis alignment:** Feature serves product thesis (`manifest.yaml` → `thesis.claim`). If thesis not filled, note as gap.
- [ ] **Multiplication check:** Feature multiplies at least one existing feature, OR carries orphan justification.

**Job Traceability (conditional — if `_jobs/REGISTRY.yaml` is populated):**
- [ ] Surface traces to a JOB-NNN in `_jobs/REGISTRY.yaml`
- [ ] If no job mapping exists, justify why this surface is needed

**Expectation Invention Loop (if new capability):**
- [ ] EIL trigger evaluated (new data, state, or affordances?)
- [ ] If triggered: Immediate expectations documented
- [ ] If triggered: Secondary expectations documented (history, undo, explanation, comparison, consistency)
- [ ] If triggered: Trust expectations documented (status, provenance, constraints, errors, definitions)
- [ ] If triggered: Non-goals explicitly stated
- [ ] If triggered: Cascade decision made (Must Build / Must Defer / Must Prevent)
- [ ] If triggered: EIL artifact created in `_decisions/eil/`

**User Expectation Framework:**
- [ ] Peer context specified with at least one **pattern adopted** from peers and one **pattern deliberately avoided**, with reasoning for each (UE-001)
- [ ] Candidate features explored (what might users expect)
- [ ] Features classified (Expected/Helpful/Speculative/Dangerous/Prevented)
- [ ] Absence detection performed (Navigation/Creation/Management/Understanding/Continuity)
- [ ] Expected actions enumerated (Primary/Secondary with affordances)
- [ ] Surface role requirements identified (Index/Detail/Workspace/Dashboard/Settings/Onboarding)
- [ ] Inner Monologue Test answered (What is this? What can I do? What would I click? What confuses me? What builds trust?)

**Bounded Curiosity:**
- [ ] Restraint Gate applied to all features (no recommending without evidence, no collapsing deliberation, no hiding uncertainty, no premature commitment)

**Progressive Disclosure (conditional — if `disclosure` extension active AND this is a first-run surface):**
- [ ] First-Run Audit completed (`_extensions/disclosure/TEMPLATES.md`)

**Intelligence Restraint Gate (conditional — if `intelligence` extension active AND surface includes smart features):**
- [ ] Intelligence Restraint Gate passed (`_extensions/intelligence/GUARDRAILS.md`)
- [ ] Expected features: build or explicitly defer
- [ ] Speculative features: reject with documented reasoning
- [ ] Dangerous features: forbid
- [ ] Prevented assumptions: address in UI (copy, constraints, absence of affordance)

**Mental Model Audit (if multi-surface product):**
- [ ] Mental Model Audit completed (`_surfaces/EXPECTATIONS.md`)

**Adaptive Layout (if multi-form-factor):**
- [ ] Content priority declared for all target form factors
- [ ] Navigation transformation strategy chosen
- [ ] Touch adaptation plan documented (if supporting touch)
- [ ] Form factor declaration completed in surface spec

**Information Surfacing Audit:**
- [ ] Surfacing Audit performed (information inventory from truth model)
- [ ] Action-Change Test applied to each candidate item
- [ ] Tier distribution validated (Tier 1 ≤ 5, Tier 1+2 ≤ 15, Tier 4 = 0)
- [ ] Cross-surface consistency checked for shared information

**Tooling Verification:**
- [ ] Required tools are documented in tech-foundation.yaml tooling section
- [ ] Tool verdicts are current (no "trial" tools past their review date)

**Edge Case Enumeration:**
Before building any surface, enumerate the specific edge cases it must handle:

```yaml
edge_cases:
  - empty: "[No data exists yet]"
  - error: "[Fetch/action failed]"
  - loading: "[Data in flight]"
  - partial: "[Some data, not all]"
  - stale: "[Data might be outdated]"
  - denied: "[User lacks permission]"
```

- [ ] Edge cases enumerated for this surface
- [ ] Pattern choices accommodate all enumerated cases (not just happy path)
- [ ] Each case has a documented treatment

**Violation = P1.** Patterns chosen without edge case consideration produce retrofitting.

**Completeness Target (required):**
- [ ] Completeness target declared: Full / Scoped / Foundation
- [ ] If Scoped or Foundation: which Gate 5 checklist items are deferred, and why
- [ ] If Scoped or Foundation: what would trigger expansion to Full

| Target | Meaning | Gate 5 Expectation |
|--------|---------|-------------------|
| **Full** | All affordances functional, all flows complete | Full checklist applies |
| **Scoped** | Primary flows complete, secondary explicitly deferred | Deferred items documented, primary flows still pass |
| **Foundation** | Core entity + primary action only | Only primary flow checklist items apply; all others tracked as known debt |

**Rules:**
- Full is the default. Scoped and Foundation require justification.
- Deferred items must be listed explicitly — not "we'll add more later" but "search is deferred because list is <20 items."
- Completeness target is stated in the critique card header alongside Cycle and Date.
- A surface cannot ship at Foundation target in a production release (only development milestones).

**Violation = P1.** Building without intent modeling produces wrong outputs.
**Violation = P0.** Building without user expectation specification produces hollow surfaces.
**Violation = P0.** New capability shipped without EIL produces expectation debt.

### Gate 0: Degraded Mode (Retroactive Pre-Creation)

**Trigger:** Scope changes or new capabilities introduced after Gate 0 was already passed.

When requirements change post-build, full Gate 0 cannot be run retroactively. Instead:

**Retroactive Spec Interrogation (abbreviated):**
- [ ] 2 falsifiable assumptions documented for each new element
- [ ] Scope boundaries updated (what changed, what didn't)
- [ ] Success criteria revised

**EIL-Lite (replaces full EIL when time doesn't permit):**
```yaml
eil_lite:
  trigger: "New capability added after Gate 2"
  time_budget: "30 minutes max"
  required:
    immediate_expectations: "What users will expect to see/do (3 items)"
    obvious_non_goals: "What this capability explicitly does NOT do (2 items)"
    trust_minimum: "What signal tells user this capability is working"
  deferred:
    secondary_expectations: "Deferred to full EIL — tracked as debt"
    cascade_analysis: "Deferred to full EIL — tracked as debt"
  documentation:
    location: "_decisions/eil/"
    filename: "{entity}-LITE.yaml"
    marker: "status: lite"
  debt:
    type: "EIL_COMPLETION"
    severity: P1
    deadline: "Within 2 sprints of ship"
```

**Violation:** Shipping a new capability with neither full EIL nor EIL-Lite = P0.

### Gate 1: Self-Review
Before any PR. Check: truth model match, states handled, keyboard complete, preset followed.
- [ ] Content Quality Checklist passed (`_content/SYSTEM.md`)

### Gate 2: Critique Loop
For every screen. See `_critique/LOOP.md`. Stop conditions must pass.

**Coherence Sketch (Multi-Surface Builds):**
- [ ] Same terms used across surfaces
- [ ] Same visual hierarchy for same-level elements
- [ ] Navigation patterns consistent
- [ ] State representations consistent

### Gate 3: Accessibility Audit
Before major release. WCAG 2.1 AA compliance required.

### Gate 4: Drift Detection
Before merge. Run checklist below.

**Traceability Verification:**
- [ ] All requirements have traced surfaces (see `_quality/TRACE.yaml`)
- [ ] All surfaces have traced requirements (or orphan justification)
- [ ] All decisions have traced requirements (or orphan justification)
- [ ] No orphan tests (tests for deleted surfaces)

**Coherence Audit:**
- [ ] Full cross-surface audit per `_quality/COHERENCE.md`
- [ ] All coherence dimensions checked
- [ ] No new inconsistencies introduced since Gate 2

**Anchor Verification:**
- [ ] Interpretation anchors were written at Pre-Build
- [ ] Final decisions match anchors (or drift is documented)
- [ ] No silent interpretation changes occurred

### Gate 5: Completeness Audit
Before release. Check: all affordances functional, primary flows complete, navigation wired.

**Completeness Checklist:**
- [ ] Every button performs an action (or is disabled with explanation)
- [ ] Every link navigates somewhere
- [ ] Every chevron/arrow navigates
- [ ] Primary user flows work end-to-end
- [ ] Breadcrumbs are clickable and functional
- [ ] No "coming soon" on primary actions
- [ ] No dead ends in main navigation
- [ ] Progress indicators explain what they measure

**Non-Functional Requirements Verification:**
- [ ] Performance targets met (see `_nfr/PERFORMANCE.yaml`)
- [ ] Reliability targets met (see `_nfr/RELIABILITY.yaml`)
- [ ] Security requirements verified (see `_nfr/SECURITY.yaml`)
- [ ] Privacy requirements verified (see `_nfr/PRIVACY.yaml`)
- [ ] All NFR tests passing

**Job Completeness (conditional — if `_jobs/REGISTRY.yaml` is populated):**
- [ ] Orphaned surface check — any SURF-NNN with no JOB-NNN mapping requires justification
- [ ] All `served: partially` or `served: unserved` sub-jobs have `served_notes` explaining why

### Gate 6: Artifact Readiness
Before external delivery. Check: synthesis artifact can be produced truthfully, no verbal explanation required.

**Artifact Readiness Checklist (LAW-013):**

**Section Definition:**
- [ ] Artifact sections are defined for this product
- [ ] Each section has clear requirements (what info/decisions/states needed)
- [ ] Section maturity is tracked (Renderable/Partial/Placeholder/Blocked)

**Reverse Engineering:**
- [ ] Product features trace to artifact sections (SA-001)
- [ ] Features without artifact justification are documented
- [ ] Missing inputs for each section are identified

**Truthfulness:**
- [ ] Renderable sections can be produced truthfully (SA-002)
- [ ] Undecided areas are explicitly marked, not hidden (SA-003)
- [ ] No placeholders presented as decisions
- [ ] Artifact shows actual state, not aspirational state (SA-005)

**Delivery Readiness:**
- [ ] Artifact requires no verbal explanation (SA-006)
- [ ] Artifact would not require apology (SA-004)
- [ ] Artifact passes Agency Test: **name one peer product screen this could appear in without embarrassment** (e.g., "This could sit alongside a Notion database view" or "This matches Linear's project detail quality")
- [ ] Artifact could be shared externally with confidence

**Violation:** Artifact shipped with false placeholders = P0

**Coherence Regression:**
- [ ] Critique-driven changes didn't break cross-surface coherence
- [ ] If coherence was passing at Gate 4, still passing now
- [ ] Any coherence changes are intentional and documented

**Rationalization Log (if shipping with known issues):**

If shipping with any dimension scoring below 4, document explicitly:

```yaml
shipping_with_issues:
  - dimension: "[Which dimension]"
    score: "[Current score]"
    issue: "[What's wrong]"
    why_shipping_anyway: "[Explicit justification — must be articulated]"
    fix_planned: "[yes/no — if yes, when]"
```

- [ ] All scores below 4 have rationalization entries
- [ ] Each rationalization has explicit justification (not just "P1 not P0")
- [ ] If justification cannot be articulated clearly, do not ship

**Principle:** Making rationalization explicit makes it harder to do casually.

### Gate 7: Stickiness Audit (Optional)
Before major release. Check: features contribute to structural competitive advantage. **Only applies if `moat-conscious` preset is active.**

**Stickiness Checklist:**

**Moat Contribution:**
- [ ] At least one moat strengthened per major feature
- [ ] No moat undermined without explicit justification
- [ ] Moat-building claims are testable (not marketing)

**Special Know-how (if primary moat):**
- [ ] Expert judgment encoded in rules/defaults
- [ ] Decision rationale captured (institutional memory)
- [ ] Feedback loop from usage exists or planned

**System Rigidity (if primary moat):**
- [ ] Canonical artifact that downstream systems consume
- [ ] Export formats treated as contracts (no breaking changes)
- [ ] Versioning is immutable and auditable

**Scale (if primary moat):**
- [ ] Value compounds with deeper usage
- [ ] Outputs are deterministic and reproducible
- [ ] Quality gates and automated tests in place

**Moat Tests:**
- [ ] Compounding Test: Does value increase with usage?
- [ ] Replaceability Test: Hard to recreate elsewhere?
- [ ] Integration Test: Creates external dependencies?
- [ ] Memory Test: Accumulates context?

**Ethical Check:**
- [ ] Moats come from value creation, not value extraction
- [ ] No artificial friction to leave
- [ ] No data hostage patterns
- [ ] No manufactured dependency

See `_strategy/MOATS.md` for complete guidelines.

### Gate 8: Cross-Surface Coherence
Before release (multi-surface products). Check: surfaces do not contradict each other.

**Cross-Surface Coherence Checklist:**

**Terminology Consistency:**
- [ ] Same entity uses same name on every surface
- [ ] Same status uses same label on every surface
- [ ] Same action uses same verb on every surface
- [ ] No surface introduces a synonym for an established term

**Entity Representation:**
- [ ] Same entity shows same key properties wherever it appears
- [ ] Entity counts are consistent across surfaces (list count = dashboard metric)
- [ ] Entity status shown on one surface matches status shown on another

**Navigation Promises:**
- [ ] Every "click to see X" link leads to a surface that actually shows X
- [ ] Breadcrumb labels match the page titles they navigate to
- [ ] "Back" returns to the surface that promised forward navigation
- [ ] Metrics that imply drill-down actually drill down to matching data

**State Consistency:**
- [ ] An entity changed on Surface A reflects the change on Surface B (no stale siblings)
- [ ] Permission-hidden elements are hidden consistently (not visible on one surface, hidden on another)
- [ ] Empty states are consistent (same entity type, same empty message pattern)

**Cross-Surface Test:**

> Pick any entity. View it on every surface where it appears.
> Does it look like the same entity made by the same team?
> If anything feels contradictory, investigate.

**Violation:** Cross-surface contradiction = P1. Cross-surface terminology mismatch = P1. Broken navigation promise = P0.

**Automation Guidance:**

Gate 8 checks can be partially automated using the Surface Registry (`_surfaces/REGISTRY.yaml`):

1. **Terminology Consistency** — Iterate `shared_vocabulary` across linked surfaces; flag mismatches.
2. **Navigation Promises** — Verify `navigation_targets` have matching `navigation_sources` (bidirectional check).
3. **Entity Consistency** — Compare `entities` lists across surfaces showing same entity type.
4. **Count Reconciliation** — Cross-reference metrics on overview surfaces with counts on workspace surfaces.

Automation does NOT replace human judgment for:
- Semantic correctness (terms technically match but convey different meaning)
- Visual consistency (same data rendered differently)
- User expectation fulfillment (navigation works but destination disappoints)

See `_surfaces/REGISTRY.yaml` for the data structure that enables these checks.

### Gate 9: Release Readiness Review
Before any version ships. Mandatory for v1.0, major versions, and minor versions with new screens. See `_quality/RELEASE_REVIEW.md`.

**Trigger:** Claude Code initiates automatically when all screens pass Gate 2 (Critique Loop) with no unresolved P0/P1. Human can also trigger manually.

**Phases:**
1. Evidence Collection — verify all pre-build artifacts exist
2. Cross-Surface Audit — consistency across screens (navigation, visual, vocabulary, interaction, flow)
3. System-Level Gates — holistic run of Gates 3, 4, 5, and 7
4. Synthesis Verification — Gate 6 artifact readiness
5. Human Review — Professional Embarrassment, Demo, Screenshot, Peer, First Impression tests
6. Sign-Off — explicit human "Ship [version]" confirmation

**Pass condition:** All 6 phases pass. Human sign-off recorded.

**Evidence:** Full audit folder at `audit-output/{date}-release-review/`

**Violation = P0.** Version shipped without Release Readiness Review is invalid.

### Flow Gate (Conditional — fires only when `_flows/REGISTRY.yaml` is populated)

**Trigger:** When building a surface that participates in a registered flow (FLOW-NNN). Fires after Gate 2 (Critique Loop), before Gate 8 (Cross-Surface Coherence).

**Checklist:**
- [ ] Flow structure — all steps have entry/exit conditions
- [ ] Branching — decision points have defined criteria and all branches resolve
- [ ] Continuity — no dead ends, momentum maintained across surfaces
- [ ] Abandonment — every flow step has a graceful exit with work preserved
- [ ] Emotional coherence — surface tone matches position in flow's emotional arc
- [ ] Completeness — flow achieves its declared outcome

**Evidence:** Flow review output in `_artifacts/critique/` referencing FLOW-NNN.

**Pass condition:** All checklist items pass. See `_flows/QUALITY.md` for detailed scoring dimensions.

### Hard Stop Criteria

These conditions require immediate escalation regardless of mode (normal or degraded). Do not proceed under any circumstances:

| Condition | Action |
|-----------|--------|
| Supreme law cannot be satisfied AND no degraded path exists | STOP. Escalate to human with explicit tradeoff description. |
| More than 3 P0s identified in any mode | STOP. Do not ship. Requires fundamental rework. |
| Correctness < 5 with no path to fix | STOP. Wrong data is worse than no data. |
| External requirements contradict a supreme law | STOP. This is a scope negotiation, not a technical problem. |
| Truth model is incomplete AND implementation is complete | STOP. Cannot verify compliance against undefined standard. |

Hard stops override both normal and degraded modes. They exist to prevent the system from shipping harm under time pressure.

---

## Drift Detection Checklist

**Run before every merge / agent run / major change.**

### Component & Pattern Drift
- [ ] Did this introduce a **new component**? → If yes: STOP. Must use existing.
- [ ] Did this add a **new variant**? → If yes: Decision Registry entry required.
- [ ] Did this **bypass a primitive**? → If yes: Invalid. Use the primitive.
- [ ] Did this create a **layout not covered by an archetype**? → If yes: Invalid.
- [ ] Did this create a **parallel path** for an existing capability? → If yes: Invalid.
- [ ] Did this **loosen a constraint**? → If yes: Decision Registry entry required.

### Token Drift
- [ ] Did this add a **new token**? → If yes: Justify in Decision Registry.
- [ ] Did this use a **forbidden token pattern** (text-hover, icon-hover, ring-default)? → If yes: Invalid. Fix token.
- [ ] Did this use an **invalid token combination**? → Check constraints.capability_matrix.

### Architectural Drift
- [ ] Did this implement **persistence, auth, sync, or export**? → If yes: tech-foundation.yaml must have status "active".
- [ ] Did this **contradict tech-foundation decisions**? → If yes: Either fix implementation or amend tech-foundation (with decision entry).
- [ ] Did this implement a **non_goals_v1 item**? → If yes: Invalid. Remove or amend non_goals.

### Affordance Drift
- [ ] Did this add a **button that doesn't work**? → If yes: Invalid. Wire it or remove it.
- [ ] Did this add a **link that doesn't navigate**? → If yes: Invalid. Wire it or remove it.
- [ ] Did this add **chevrons on non-navigable rows**? → If yes: Invalid. Make navigable or remove chevrons.
- [ ] Did this create a **dead end screen**? → If yes: Invalid. Add escape path.
- [ ] Did this add **"coming soon" on a primary action**? → If yes: Invalid. Complete the flow or hide the action.

**If any checkbox triggers Invalid:** Do not proceed. Refactor to use existing system elements.

**If any checkbox requires Decision Registry:** Entry must exist before merge.

**Sanctioned Expansion Exception:**

When new elements are externally required (client, stakeholder, or product decision), drift detection converts from blocker to documentation requirement:

- [ ] New element documented in `_decisions/REGISTRY.md` with rationale
- [ ] Element classified: **required** (externally mandated) vs **proposed** (internally suggested)
- [ ] If required: proceed with Decision Registry entry. Drift check passes.
- [ ] If proposed: standard drift rules apply. Do not proceed without refactoring.

Sanctioned expansion requires a Decision Registry entry BEFORE proceeding. The entry replaces the block, not the accountability.

---

## Verification Dimensions

### Invariants

All invariants in `_invariants/REGISTRY.md` must be satisfied.

**Invariant violation = P0.** No exceptions.

### Data Integrity

| Check | Requirement |
|-------|-------------|
| Provenance | Every number traces to server, not client |
| Reconciliation | Aggregates equal sum of parts |
| Labels | From authoritative source, not derived |
| Timezone | Correct handling and display |

**Violation = P0.** Data correctness is non-negotiable.

### Behavioral Coherence

| Check | Requirement |
|-------|-------------|
| State Machine | UI states match `states.yaml` |
| Actions | All UI actions exist in `actions.yaml` |
| Permissions | Hidden or disabled per `permissions.yaml` |
| Navigation | Follows `grammar.yaml` patterns |

**Phantom actions (UI actions not in model) = P0.**

### UI Consistency

| Check | Requirement |
|-------|-------------|
| Tokens | All values from `tokens.yaml` (TK-001) |
| Token Constraints | Combinations valid per capability matrix (TK-002) |
| Forbidden Patterns | No text-hover, icon-hover, ring-default, focus/background (TK-003) |
| Components | All from `components.yaml` |
| Hierarchy | Clear visual priority |
| States | Hover, focus, active, disabled present |
| Contrast | AA compliance (4.5:1 text, 3:1 UI) |

**Hardcoded values = P1. Invalid token combination = P1. Contrast failure = P0.**

### Architectural Compliance

| Check | Requirement |
|-------|-------------|
| Tech Foundation | `config/tech-foundation.yaml` status is "active" before implementing persistence/auth/sync/export (TF-001) |
| Persistence | Implementation matches `data.persistence_mode` (TF-002) |
| Auth | Implementation matches `auth.mode` + `auth.tenancy` (TF-003) |
| Sync | Implementation matches `sync.mode` (TF-004) |
| Non-Goals | Features in `non_goals_v1` not implemented (TF-005) |
| Performance | Meets budgets in `performance.*` (TF-006) |

**Building without active tech-foundation = P0. Mode mismatch = P0.**

### Affordance Integrity

| Check | Requirement |
|-------|-------------|
| Buttons | Every button performs an action or is disabled with explanation (AF-001) |
| Links | Every link navigates to a real destination (AF-002) |
| Chevrons | Row chevrons indicate and perform navigation (AF-003) |
| Breadcrumbs | Every segment is clickable and navigates (AF-004) |
| Disabled | Disabled elements explain why (AF-005) |
| Progress | Progress indicators explain what they measure (AF-006) |
| Primary flows | Top user tasks work end-to-end (AF-007) |

**Dead affordance = P0. Primary flow incomplete = P0. Dead end = P0.**

### Intent Alignment

| Check | Requirement |
|-------|-------------|
| Intent Modeling | Problem, outcome, and scope were explicit before building (LAW-011) |
| Output Type | Screen type matches purpose (Decision / Display / Export / Narrative) |
| Audience | Built for assumed audience (default: Client) |
| Demonstration | Systems shown in context, not enumerated as lists |
| Success Criteria | "Done" was defined before building |

**Wrong output type = P1. System enumerated instead of demonstrated = P1. No intent modeling = P1.**

### Overview Page Quality

For pages that summarize status across multiple items (see `_model/patterns/overview.md`):

| Check | Requirement |
|-------|-------------|
| Three Questions | User can answer: State? Attention? Risk? |
| Signal Hierarchy | ONE primary signal per item, others secondary |
| Meaningful Ordering | Items ordered by significance (dependency, priority, status) |
| State Disambiguation | No ambiguous states ("pending", "incomplete") |
| Interpretation | Page interprets without recommending action |

**Competing signals = P1. Ambiguous states = P1. Arbitrary ordering = P1.**

### Narrative Output Quality

For screens that demonstrate a system (design preview, style guide, configuration summary):

| Guarantee | Requirement |
|-----------|-------------|
| Intent Is Explicit | States what system optimizes for, not aspirations |
| Structure Is Progressive | Reveals dependency/hierarchy, not flat categorization |
| State Is Interpretable | Contextual meaning without success/failure judgment |
| Omission Is Intentional | Absence reads as confidence, not gaps |

**Success Test:**
- Non-author can explain system accurately
- Reviewer senses intentional tradeoffs
- Nothing feels accidental or provisional
- Could appear in client presentation

**Flat structure = P1. Unexplained omissions = P1. Judgmental state language = P1.**

### User Expectation Verification

Every surface must satisfy all ten contracts. See `_ui/SYSTEM.md` for full framework.

**Orientation Contract:**

| Check | Requirement |
|-------|-------------|
| Location Clarity | User can answer "Where am I?" in 2 seconds |
| Orientation Signals | At least 2 signals present (breadcrumb, title, nav state, context) |
| Title Match | Page title matches navigation item (OR-001) |
| Breadcrumbs | Deep pages have functional breadcrumbs (OR-002) |
| Nav Indication | Current location visually indicated (OR-003) |

**Action Contract:**

| Check | Requirement |
|-------|-------------|
| Forward Motion | User can progress or explicitly understands why not (EX-003) |
| Metrics Navigate | Numbers link to details or filtered lists (EX-001) |
| Smart CTAs | Primary CTAs specify where/why, not just "Continue" (EX-002) |
| Surface Type Match | Actions match surface type (Display/Navigation/Manipulation/Configuration) |
| Dead Surface Test | User feels "empowered" not "blocked" when clicking |

**Information Contract:**

| Check | Requirement |
|-------|-------------|
| Arrival Questions | Questions user arrived with are answered |
| Raised Questions | Follow-up questions from displayed data are answered (IX-006) |
| Metric Context | Numbers show what they measure and if value is good/bad (IX-001) |
| Status Meaning | Status indicators explain what they mean (IX-002) |
| Empty State Context | Empty states explain why and what to do (IX-004) |

**Explanation Coverage:**

| Check | Requirement |
|-------|-------------|
| Mandatory Targets | State badges, progress, disabled, counts have explanation path |
| Appropriate Rung | Lowest sufficient rung on Explanation Ladder |
| Tooltip Contract | Meaning not instruction, ≤2 lines, accessible (XP-004) |
| Not Sole Source | Tooltips have backup explanation rung (XP-005) |
| Client Test | Every element explainable without designer speaking |

**Confidence Contract:**

| Check | Requirement |
|-------|-------------|
| No Color Judgment | Green/red doesn't imply good/bad without explanation (CF-001) |
| Rankings Explained | Any ranked list explains ranking criteria (CF-002) |
| Incompleteness Visible | Partial/filtered data is indicated (CF-003) |
| Defaults Marked | Pre-filled values distinguishable from user-entered (CF-004) |
| Uncertainty Explicit | Estimates/projections marked as such (CF-005) |

**Freshness Contract:**

| Check | Requirement |
|-------|-------------|
| Freshness Signals | Stale-able data shows when last updated (FR-001) |
| Sync Status | External data shows sync state and time (FR-002) |
| Currency Clear | User can answer "Is this current?" without asking |

**Feedback Contract:**

| Check | Requirement |
|-------|-------------|
| Action Response | Every action produces visible feedback (FB-001) |
| Error Recovery | Errors explain what went wrong and how to fix (FB-002) |
| Success Confirmed | Successful actions show explicit confirmation (FB-003) |
| Progress Shown | Async operations (>1s) show progress (FB-004) |

**Prediction Contract:**

| Check | Requirement |
|-------|-------------|
| Consequence Shown | Destructive actions state what will be affected (PR-001) |
| Count Shown | Bulk actions show affected count (PR-002) |
| Context in Confirm | Confirmation dialogs state what's being confirmed (PR-003) |
| Cascade Warning | Actions affecting related items warn about cascading (PR-004) |

**Reversibility:**

| Check | Requirement |
|-------|-------------|
| Irreversible Marked | Irreversible actions explicitly state this (RV-001) |
| Soft-Delete Preferred | Use trash/restore over hard delete where possible (RV-002) |
| Undo Available | Reversible actions offer undo (RV-003) |
| Window Shown | Time-limited undo shows remaining time (RV-004) |
| Regret Check | Would reasonable user regret if misunderstood? |

**Continuity Contract:**

| Check | Requirement |
|-------|-------------|
| Scroll Preserved | Returning to list restores scroll position (CN-001) |
| Unsaved Warning | Navigating from unsaved work prompts confirmation (CN-002) |
| Form Data Preserved | Back button doesn't lose form data (CN-003) |
| Filters Preservable | Filter/sort state preserved or easily restored (CN-004) |

**Completion Contract:**

| Check | Requirement |
|-------|-------------|
| Progress Visible | Multi-step flows show progress indication (CP-001) |
| Completion Signaled | When done, this is explicitly indicated (CP-002) |
| Next Step Clear | After completion, next action is obvious (CP-003) |

**Exit Awareness:**

| Check | Requirement |
|-------|-------------|
| Accomplishment Visible | User can see what they've done (EA-001) |
| Remaining Clear | User knows what's left if incomplete (EA-002) |
| Next Destination Obvious | User knows where to go (EA-003) |
| Save State Unambiguous | User knows if work is saved (EA-004) |
| Abandonment Test | User would feel confident, not anxious, if leaving |

---

### Surface Readiness Gate

**Final check before any surface ships.** All must pass.

| Contract | Test | Pass? |
|----------|------|-------|
| Orientation | "Where am I?" in 2 seconds | [ ] |
| Action | Dead Surface Test passes | [ ] |
| Information | Information Completeness Test passes | [ ] |
| Explanation | "Explain It to a Client" Test passes | [ ] |
| Confidence | No misleading certainty signals | [ ] |
| Freshness | "Is this current?" answerable | [ ] |
| Feedback | "Did that work?" answerable after any action | [ ] |
| Prediction | "What will happen?" answerable before significant action | [ ] |
| Reversibility | Irreversible actions marked, Regret Check passes | [ ] |
| Continuity | Leave and return without context loss | [ ] |
| Completion | "Am I done?" answerable | [ ] |
| Exit Awareness | "Would I feel confident leaving?" = Yes | [ ] |
| Visual Hierarchy | One focal point, Squint Test passes | [ ] |
| Visual Rhythm | Spacing from scale, consistent cadence | [ ] |
| Visual Density | Density matches task | [ ] |
| Visual Consistency | Same elements same treatment, no one-offs | [ ] |
| Visual Craft | Peer Test + Craft Test + Screenshot Test pass | [ ] |
| Vocabulary Legibility | All terms understandable or learnable | [ ] |
| Vocabulary Discoverability | Non-obvious terms have in-context explanation | [ ] |
| Vocabulary Consistency | Same term = same meaning everywhere | [ ] |
| Vocabulary Neutrality | Terms describe, don't judge | [ ] |
| Symbol Explanation | Bespoke symbols have tooltip or legend (VO-005) | [ ] |
| Symbol Accessibility | Symbols work in grayscale (VO-006) | [ ] |
| Ratio Clarity | Progress ratios labeled (VO-007) | [ ] |
| Symbol Family | Single primitive family used (SY-001) | [ ] |
| Symbol Weight | Consistent optical weight (SY-002) | [ ] |
| Symbol Axis | Single visual axis for progression (SY-003) | [ ] |
| Symbol Monotonicity | Visual order = semantic order (SY-004) | [ ] |
| Progress Hierarchy | Primary signal clear when multiple exist (PS-001) | [ ] |
| Progress Clarity | Sentence Test passes (PS-002) | [ ] |
| Status Neutrality | Labels descriptive, not evaluative (PS-003) | [ ] |
| Peer Context | Comparable products documented (UE-001) | [ ] |
| Absence Detection | Feature Category Checklist complete (UE-002) | [ ] |
| Expected Actions | Primary/secondary enumerated with affordances (UE-003) | [ ] |
| Surface Role | Surface type requirements satisfied (UE-004) | [ ] |
| Inner Monologue | All 5 questions answered confidently (UE-005) | [ ] |
| Visual Interactivity | Every interactive-looking element works (UE-006) | [ ] |
| Expectation Debt | Deferred features tracked (UE-007) | [ ] |
| Feature Exploration | Candidate features documented (UE-008) | [ ] |
| Feature Classification | All features classified (UE-009) | [ ] |
| Restraint Gate | All features passed restraint checks (UE-010) | [ ] |
| Rejection Documentation | Rejected features documented with reasoning (UE-011) | [ ] |

**If any contract fails → revise the surface before shipping.**

---

### Visual Quality Verification

Every surface must satisfy all five visual dimensions. See Visual Quality Contract in `_ui/SYSTEM.md`.

**Hierarchy:**

| Check | Requirement |
|-------|-------------|
| Focal Point | Exactly one primary focal point (VQ-005) |
| Priority | Focal point is the most important element |
| No Competition | No competing visual emphasis |
| Squint Test | Hierarchy visible when page is blurred |

**Rhythm:**

| Check | Requirement |
|-------|-------------|
| Scale Compliance | Spacing uses defined scale only (VQ-001) |
| Vertical Cadence | Consistent vertical rhythm throughout |
| Section Clarity | Sections clearly begin and end |
| Density Balance | No cramped or overly sparse areas |

**Density:**

| Check | Requirement |
|-------|-------------|
| Class Match | Density class appropriate for task (VQ-006) |
| Internal Consistency | Density consistent within surface |
| Peer Calibration | Density appropriate for peer products |

**Consistency:**

| Check | Requirement |
|-------|-------------|
| Element Treatment | Same elements have same treatment (VQ-007) |
| Icon Family | Icons from single family only (VQ-004) |
| Type Scale | Typography from defined scale only (VQ-003) |
| Color System | Colors from token system only (VQ-002) |
| No One-Offs | No one-off components |

**Craft:**

| Check | Requirement |
|-------|-------------|
| Peer Test | Could exist in Linear/Stripe/Notion without visual shock |
| Craft Test | Senior designer would not apologize |
| Screenshot Test | Would include in pitch deck |
| Zoom Test | At 200%, edges crisp and aligned |
| No Arbitrary | All values from defined scales (VQ-008) |

**Failing Peer Test, Craft Test, or Screenshot Test = P0.**

---

### Vocabulary Comprehension Verification

Every surface must satisfy all four vocabulary dimensions. See Vocabulary Comprehension in `_ui/SYSTEM.md`.

**Legibility:**

| Check | Requirement |
|-------|-------------|
| Comprehension Level | All terms self-evident, contextual, or learnable (no opaque) |
| Industry Match | Technical terms match common usage |
| Plain Language | Simplified where possible |
| Two Professionals Test | Same interpretation by domain experts |

**Discoverability:**

| Check | Requirement |
|-------|-------------|
| In-Context Explanation | Non-obvious terms have tooltip or inline explanation (VO-001) |
| Status Labels | All status/state labels have tooltips |
| Category Badges | All classification badges have tooltips |
| No Navigation | User learns without leaving surface (VO-003) |
| First Encounter Test | New user can understand or learn any term |

**Consistency:**

| Check | Requirement |
|-------|-------------|
| Term → Meaning | Same word means same thing throughout (VO-002) |
| Concept → Term | Same concept uses same term throughout |
| Label ↔ Logic | UI labels match system terminology |
| No Synonyms | No partial synonyms causing confusion |

**Neutrality:**

| Check | Requirement |
|-------|-------------|
| Descriptive | Terms describe state, don't evaluate it (VO-004) |
| No Criticism | No implied user failure |
| No Pressure | No manufactured urgency |
| Factual Status | Status is objective, not emotional |

**Failing First Encounter Test or having opaque terms = P1. Inconsistent term meanings = P1.**

---

### Symbol Grammar Verification

Every surface with status symbols must satisfy all symbol grammar rules. See Symbol Grammar System in `_ui/SYSTEM.md`.

**Primitive Family:**

| Check | Requirement |
|-------|-------------|
| Single Family | All symbols use same geometric basis (SY-001) |
| No Mixing | No area + line + count mixing in same set |
| Family Choice | Area-fill OR line-weight OR count OR opacity |

**Optical Weight:**

| Check | Requirement |
|-------|-------------|
| Consistent Mass | Same visual weight across all states (SY-002) |
| Bounding Box | Same optical size for all symbols |
| Stroke Weight | Identical stroke weight if using strokes |

**Semantic Axis:**

| Check | Requirement |
|-------|-------------|
| Single Variable | Only one variable changes (fill OR weight OR count) (SY-003) |
| No Multi-Axis | Fill doesn't change AND shape doesn't change |
| Clear Mapping | Variable change maps to semantic progression |

**Progression:**

| Check | Requirement |
|-------|-------------|
| Monotonic | Visual order = semantic order (SY-004) |
| Distinguishable | Each state visually distinct at small sizes |
| Equal Intervals | Roughly even visual progression |
| No Directionality | Directional symbols only for directional concepts |

**Symbol Validity Test:**

| Question | Requirement |
|----------|-------------|
| Matches family? | Same geometric basis as existing symbols |
| Single axis? | Only one variable changes |
| Legible at 12px? | Distinguishable when small |
| Neutral? | No emotional connotation |
| No unintended meaning? | No accidental directionality |

**Mixed primitive families or inconsistent optical weight = P1.**

---

### Progress & Status Verification

Every surface with progress indicators must satisfy progress semantics rules. See Progress & Status Semantics in `_ui/SYSTEM.md`.

**Signal Hierarchy:**

| Check | Requirement |
|-------|-------------|
| Primary Clear | When multiple signals exist, one is visually primary (PS-001) |
| Visual Prominence | Primary signal is largest, first, or most prominent |
| No Competition | No two signals competing for attention at same level |

**Sentence Test:**

| Check | Requirement |
|-------|-------------|
| Expressible | Can state as "[X] of [Y] are [state]" (PS-002) |
| Subject Clear | What is being measured is explicit |
| Count Clear | Numbers have clear meaning |
| State Clear | What the states mean is explicit |

**Ratio Clarity:**

| Check | Requirement |
|-------|-------------|
| Numerator Labeled | What the top number represents (VO-007) |
| Denominator Labeled | What the bottom number represents |
| Relationship Clear | "3/12 approved" not just "3/12" |

**Status Neutrality:**

| Check | Requirement |
|-------|-------------|
| Descriptive | Labels describe state factually (PS-003) |
| No Judgment | No "healthy", "unhealthy", "good", "bad" |
| No Comparison | No "behind", "ahead", "better", "worse" |
| No Encouragement | No "almost there!", "keep going!" |

**Competing progress signals or unlabeled ratios = P1. Evaluative status labels = P1.**

---

### Confidence Progression (Flow-Level)

For multi-step flows and onboarding sequences, verify confidence increases over time:

| Check | Requirement |
|-------|-------------|
| Later ≥ Earlier | Later steps never feel less certain than earlier steps |
| Explanations Clarify | Explanations get clearer as user progresses, not vaguer |
| Control Increases | User feels more in control as they progress |
| No Late Anxiety | Final steps don't introduce new uncertainty |

**Test:** Walk through the flow. Does confidence monotonically increase?

If confidence drops at any step → redesign that step.

---

### User Expectation Framework Verification

Every surface must satisfy all user expectation invariants. See User Expectation Framework in `_ui/SYSTEM.md`.

**Expectation Invention Loop (if new capability):**

| Check | Requirement |
|-------|-------------|
| EIL Trigger | Evaluated: does this introduce new data, state, or affordances? (EIL-001) |
| Immediate Expectations | What users now see/do/expect tracked documented (EIL-001) |
| Secondary Expectations | History, undo, explanation, comparison, consistency examined (EIL-003) |
| Trust Expectations | Status, provenance, constraints, errors, definitions examined (EIL-004) |
| Non-Goals | Prevented assumptions explicitly stated (EIL-002) |
| Cascade Decision | All expectations classified as Must Build / Must Defer / Must Prevent (EIL-001) |
| EIL Artifact | Created in `_decisions/eil/[capability-name].yaml` (EIL-001) |
| EIL → Pre-Build | EIL outputs feed into Pre-Build Flow (EIL-005) |

**Pre-Build Verification:**

| Check | Requirement |
|-------|-------------|
| Peer Context | Comparable products documented before building (UE-001) |
| Candidate Features | Features users might expect explicitly explored (UE-008) |
| Feature Classification | All candidates classified as Expected/Helpful/Speculative/Dangerous/Prevented (UE-009) |
| Absence Detection | Feature Category Checklist completed with P0/P1/P2 classification (UE-002) |

**Expectation Specification:**

| Check | Requirement |
|-------|-------------|
| Expected Actions | Primary and secondary actions enumerated with affordance mapping (UE-003) |
| Surface Role | Surface type identified with all must-have features present (UE-004) |
| Inner Monologue | All 5 questions answered confidently (UE-005) |
| Visual Interactivity | Every element that looks clickable is clickable (UE-006) |

**Bounded Curiosity:**

| Check | Requirement |
|-------|-------------|
| Restraint Gate | All features pass restraint checks before implementation (UE-010) |
| Expectation Debt | Deferred features tracked with reasoning and planned phase (UE-007) |
| Rejection Documentation | Speculative features logged with rejection reasoning (UE-011) |
| Prevention Documentation | Prevented assumptions addressed in UI (copy, constraints, absence) |

**Component Contracts:**

| Component | Requirement |
|-----------|-------------|
| Cards | Navigate on click (→ detail view) |
| Metrics | Drill down on click (→ detail or filtered list) |
| Status Badges | Explain on hover (tooltip with meaning) |
| Progress Indicators | Show composition (what's being measured) |
| Buttons | Perform action or explain why disabled |

**Surface Role Requirements:**

| Surface Type | Must Include |
|--------------|--------------|
| Index/Hub | Create, open, status summary, empty state, search (if >5) |
| Detail/Overview | Key info, primary action, back nav, edit affordance |
| Workspace/Editor | Save indication, undo, manipulation affordances, exit clarity |
| Dashboard/Report | Metrics with drill-down, time context, freshness signal |
| Settings/Config | Current values, save mechanism, reset option |
| Onboarding/Flow | Progress indication, current step, forward action |

**New capability without EIL = P0. Missing peer context or absence detection = P0. Missing feature classification = P1.**

---

### Synthesis Artifact Verification

Every product must satisfy artifact-first design principles. See `_artifacts/SYNTHESIS.md`.

**Artifact Definition:**

| Check | Requirement |
|-------|-------------|
| Sections Defined | Artifact sections are defined for this product (SA-001) |
| Section Requirements | Each section has clear requirements (what info/decisions/states needed) |
| Section Maturity | Each section has maturity state: Renderable/Partial/Placeholder/Blocked |
| Feature Mapping | Product features trace to artifact sections |
| Orphan Features | Features without artifact justification are documented |

**Reverse Engineering:**

| Check | Requirement |
|-------|-------------|
| Information Requirements | What information is required for each section? |
| Decision Requirements | What decisions must exist for each section? |
| State Requirements | What states must be tracked for each section? |
| Gap Analysis | What is currently missing from each section? |

**Artifact Truthfulness:**

| Check | Requirement |
|-------|-------------|
| Renderable Sections | Can be produced truthfully now (SA-002) |
| Undecided Marking | Undecided areas explicitly marked, not hidden (SA-003) |
| No False Placeholders | Placeholders never presented as decisions |
| Actual vs Aspirational | Artifact shows actual state, not hopes (SA-005) |

**Artifact Readiness:**

| Check | Requirement |
|-------|-------------|
| No Verbal Explanation | Artifact requires no verbal explanation (SA-006) |
| No Apology | External delivery would not require apology (SA-004) |
| Agency Test | Premium agency would ship this artifact |
| External Confidence | Artifact could be shared externally with confidence |

**Quality Tests:**

| Test | Question | Pass Criteria |
|------|----------|---------------|
| Agency Test | Would a premium agency ship this? | Yes, without revision |
| No Verbal Explanation Test | Can artifact stand alone? | No explanation needed |
| Honesty Test | Does artifact show actual state? | No aspirational content |
| Section Maturity Test | Is maturity tracked accurately? | All sections have state |
| Reverse Engineering Test | Do features trace to sections? | All features mapped |

**Feature without artifact justification = P1. Artifact section with false placeholder = P0. Artifact requiring apology = P0.**

---

### Professional Embarrassment Gate

**The final human-judgment gate.**

> The system must never ship a surface that a senior professional would feel the need to apologize for while presenting.

**The Test:**

If you would say any of the following while presenting this surface:
- "This part is still rough"
- "We'll improve this later"
- "Ignore this for now"
- "This is a placeholder"
- "I know this looks off"

→ **The surface fails. Do not ship.**

This gate cannot be bypassed. No exceptions.

---

### Design Reasoning Protocol

> For key decisions, produce brief design rationale. Not "I used the correct token" but "I chose X because Y."

For each surface, document reasoning for these decision types:

| Decision Type | Rationale Must Include |
|--------------|----------------------|
| **Layout choice** | Why this structure over alternatives |
| **Hierarchy decisions** | Why this element is primary/secondary |
| **Emphasis placement** | Why this element gets visual weight |
| **Density level** | Why this amount of information at this density |
| **Interaction pattern** | Why this interaction model for this context |

### Format

```
## Design Reasoning: [Screen Name]

### Layout
Chose [pattern] because [reason]. Considered [alternative] but rejected because [reason].

### Hierarchy
[Primary element] is dominant because [reason]. [Secondary element] is subordinate because [reason].

### Key Tradeoffs
- [Tradeoff 1]: Chose [A] over [B] because [reason]
```

**Rule:** Reasoning is not justification after the fact. It's thinking-out-loud during design. If you can't articulate why, you haven't decided — you've defaulted.

Store reasoning in critique scorecard output.

---

### Design Exploration Protocol

> For high-leverage surfaces, generate and compare multiple approaches before committing.

**Trigger:** Required for surfaces classified as high-leverage:
- Onboarding / first-run experience
- Primary workflow screens (most-used daily surfaces)
- First impression surfaces (landing, dashboard, home)

### Process

1. **Generate 2–3 distinct approaches** — not variations on a theme, but genuinely different structural approaches
2. **Evaluate each** against the Screen Intent Declaration (if exists) and User State Awareness
3. **Select with reasoning** — document why the chosen approach wins
4. **Preserve alternatives** — note rejected approaches and why, in case assumptions change

### Exploration Template

```
## Exploration: [Screen Name]

### Approach A: [Name]
Structure: [brief description]
Strengths: [what it does well]
Weaknesses: [what it sacrifices]

### Approach B: [Name]
Structure: [brief description]
Strengths: [what it does well]
Weaknesses: [what it sacrifices]

### Selected: [A/B/C]
Reason: [why this wins for this context]
```

**Rule:** If exploration produces only one viable approach, that's fine — but document why alternatives didn't work. "Couldn't think of alternatives" is not acceptable for high-leverage surfaces.

Store exploration artifacts alongside critique scorecards.

---

### Constraint-as-Design Protocol

> Flexibility is a cost, not a feature. Every point of user choice must justify its existence.

### The Question

For every user-configurable option, toggle, setting, or choice point:

> "Does this optionality serve the user, or does it just avoid a design decision?"

### Evaluation Framework

| Signal | Flexibility Is Justified | Flexibility Is Avoidance |
|--------|-------------------------|--------------------------|
| User need | Different users genuinely need different settings | All users would benefit from one good default |
| Frequency | User changes this setting regularly | User sets once and forgets (or never changes) |
| Expertise | Configuration requires domain knowledge user has | Configuration requires knowledge user shouldn't need |
| Consequence | Wrong choice is recoverable | Wrong choice causes silent problems |

### Decision

| Assessment | Action |
|-----------|--------|
| Justified | Keep the option, ensure good default |
| Avoidance | Remove the option, commit to the better choice |
| Uncertain | Default to removing; re-add only if users request it |

Unjustified flexibility in primary flows = P2. Flexibility that causes confusion or wrong defaults = P1.

---

## Archetype Compliance

Every screen must:
1. Have exactly one archetype
2. Stay within budget (decision points, components, actions)
3. Follow archetype layout patterns

Budgets defined in `_presets/_base.yaml`, overridable by preset.

---

## Quality Levels

| Level | P0 | P1 | Scores | Use |
|-------|----|----|--------|-----|
| Ship Gate | 0 | ≤2 | All ≥4, Correctness=5 | Can release |
| Production | 0 | 0 | All ≥4 | Fully complete |
| Reference | 0 | 0 | All =5 | Exemplar candidate |

---

## Exception Process

When a rule cannot be followed:

1. Document which rule (by ID)
2. Explain why
3. Propose alternative
4. Get human approval
5. Log in `_decisions/REGISTRY.md`

---

## Exemplar Rules

- Maximum 5 exemplars per category
- Good examples only (bad examples waste tokens)
- Anything not matching exemplars is implicitly incorrect
- Rotate stale examples quarterly
