# Directional Coherence

> Do features multiply each other, or merely coexist?

**Authority:** This protocol extends the quality framework in `QUALITY_PROTOCOL.md`. Surfaces may pass critique and visual coherence but still fail directional coherence — this catches products that are well-built collections of unrelated capabilities.

**Companion:** `COHERENCE.md` checks coherence of *form* (do screens look and feel unified). This file checks coherence of *direction* (do features reinforce each other toward the same thesis).

---

## Purpose

A product can pass every quality gate and still feel like a toolkit instead of a system. The difference: in a toolkit, each feature adds value independently. In a system, each feature makes other features more valuable.

**Core test:** Remove any single feature — does the remaining product become *disproportionately* less valuable? If removing a feature only subtracts its own value, it's an isolated utility. If removing it degrades other features too, it's load-bearing.

---

## The Product Thesis

Every product needs a falsifiable thesis — a single claim about why it wins.

**Source:** `config/manifest.yaml` → `thesis.claim`

The thesis is not a mission statement. It's a bet:

| Mission Statement | Product Thesis |
|---------------------|-------------------|
| "We empower teams to do their best work" | "Design decisions made in conversation are lost within 48 hours — we make them persist and compound" |
| "The easiest project management tool" | "Context switching between tools causes 30% of project delays — we eliminate the switch" |
| "Beautiful analytics for modern teams" | "Teams act on trends they can see in <5 seconds — we surface patterns, not dashboards" |

**Properties of a good thesis:**
- **Falsifiable** — you can describe what would prove it wrong
- **Specific** — names the problem, not just the aspiration
- **Testable per feature** — you can ask "does this feature serve this thesis?"

**Rule:** If the thesis isn't filled in `manifest.yaml`, directional coherence checks are skipped with a warning. The thesis is the gravity — without it, there's nothing to pull toward.

---

## Feature Multiplication Test

> Before building: does this feature make at least one existing feature more valuable?

### The Test

For every proposed feature, answer:
```yaml
multiplication_test:
  feature: "[Feature being proposed]"
  thesis_alignment: "[How does this serve the product thesis?]"

  multiplies:
    - feature: "[Existing feature this strengthens]"
      how: "[Specifically how it makes that feature more valuable]"

  multiplied_by:
    - feature: "[Existing feature that makes THIS feature more valuable]"
      how: "[Specifically how]"

  classification: "[load-bearing / amplifier / utility / orphan]"
```

### Feature Classifications

| Classification | Definition | Action |
|----------------|------------|--------|
| **Load-bearing** | Removing it degrades multiple other features | Protect — high priority, resist removal |
| **Amplifier** | Makes 2+ features more valuable, but could be removed without breaking them | Build — high thesis ROI |
| **Utility** | Adds value on its own, multiplies at least one other feature | Build — standard priority |
| **Orphan** | Adds value on its own, multiplies nothing | Justify or defer — explain why it belongs |

### Orphan Feature Protocol

Orphan features aren't automatically rejected. But they require explicit justification:
```yaml
orphan_justification:
  feature: "[The orphan feature]"
  standalone_value: "[What value it adds independently]"
  why_no_multiplication: "[Why it doesn't amplify other features]"
  justification:
    type: "[prerequisite / table-stakes / future-multiplier / user-expectation]"
    explanation: "[Why it belongs despite being an orphan]"
    review_by: "[Date to re-evaluate — can it become a multiplier?]"
```

| Justification Type | Meaning |
|--------------------|---------|
| **prerequisite** | Enables future multipliers (e.g., auth enables collaboration) |
| **table-stakes** | Users expect it; absence is disqualifying (e.g., search in a data app) |
| **future-multiplier** | Will multiply features not yet built (document which ones) |
| **user-expectation** | Peer products include it; absence would confuse users |

**Rule:** More than 30% orphan features = product direction warning. The product is accumulating utilities, not building a system.

---

## Multiplication Map

> Visualize which features strengthen which.

After multiple features are built, maintain a multiplication map:
```yaml
multiplication_map:
  thesis: "[Product thesis from manifest.yaml]"

  features:
    - name: "[Feature A]"
      classification: "[load-bearing / amplifier / utility / orphan]"
      multiplies: ["Feature B", "Feature C"]
      multiplied_by: ["Feature D"]

    - name: "[Feature B]"
      classification: "[amplifier]"
      multiplies: ["Feature A", "Feature E"]
      multiplied_by: ["Feature A"]

  # Features with no outgoing multiplication edges
  orphans: ["Feature F"]

  # Features with 3+ outgoing edges — the product's gravity centers
  gravity_centers: ["Feature A"]

  health:
    total_features: __FILL__
    orphan_count: __FILL__
    orphan_percentage: __FILL__    # Warning if >30%
    gravity_centers: __FILL__      # Should be 1-3
    avg_connections: __FILL__      # Higher = more cohesive
```

### Health Indicators

| Metric | Healthy | Warning | Alarm |
|--------|---------|---------|-------|
| Orphan percentage | <15% | 15-30% | >30% |
| Gravity centers | 1-3 | 0 or 4+ | 0 (no center) |
| Avg connections per feature | >1.5 | 1.0-1.5 | <1.0 |
| Thesis alignment gaps | 0 | 1-2 | 3+ |

---

## Directional Coherence Audit

> Product-level check. Run after 3+ features exist, and before any major release.

### Step 1: Thesis Verification
```yaml
thesis_check:
  thesis_filled: "[yes/no — from manifest.yaml]"
  thesis_still_accurate: "[yes/no — has the product evolved past the thesis?]"
  if_no: "[Update thesis in manifest.yaml, log as DEC entry]"
```

### Step 2: Feature-Thesis Mapping

For every feature in the product:
```yaml
feature_thesis_map:
  - feature: "[Feature name]"
    serves_thesis: "[yes / partially / no]"
    how: "[Specific connection to thesis claim]"
```

**Flag:** Any feature with `serves_thesis: no` must have an orphan justification on file.

### Step 3: Multiplication Density
```yaml
multiplication_density:
  total_multiplication_edges: "[Count of feature->feature connections]"
  total_possible_edges: "[n * (n-1) where n = feature count]"
  density: "[edges / possible — healthy range: 0.15-0.40]"
  assessment: "[cohesive / adequate / fragmented]"
```

| Density | Assessment | Meaning |
|---------|------------|---------|
| >0.40 | Over-coupled | Features may be too interdependent — fragile |
| 0.15-0.40 | Cohesive | Features reinforce each other appropriately |
| 0.05-0.15 | Adequate | Some multiplication, room to strengthen |
| <0.05 | Fragmented | Product is a feature collection, not a system |

### Step 4: Direction Vector

The final question: are features pulling in the *same* direction?
```yaml
direction_vector:
  primary_direction: "[What most features converge toward]"
  features_aligned: ["[List]"]
  features_divergent: ["[List]"]
  divergence_justified: "[yes/no — if yes, explain]"
  assessment: "[unified / mostly-aligned / divergent]"
```

**Unified:** All features serve the thesis and multiply each other.
**Mostly-aligned:** 1-2 features diverge but with justification.
**Divergent:** Multiple features pull in different directions — product identity at risk.

---

## When to Run

| Trigger | Required? |
|---------|-----------|
| Pre-Build: new feature proposed | Feature Multiplication Test only |
| 3+ features built | Full Directional Coherence Audit |
| Before major release | Full audit |
| After product pivot or thesis change | Full audit + re-map all features |
| Quarterly (if product is active) | Multiplication map health check |

---

## Integration Points

| System | How Directional Coherence Connects |
|--------|------------------------------------|
| `COHERENCE.md` | Form coherence (visual) + directional coherence (strategic) = full product coherence |
| `_strategy/MOATS.md` | Value loops and moats are *mechanisms*; thesis is *direction*. Features should serve thesis via moats/loops |
| `_jobs/VALUE_LOOPS.md` | Multiplication often works through value loops — Feature A feeds data that Feature B uses |
| `_expectations/PRE-BUILD.md` | Feature Multiplication Test runs during Pre-Build |
| `manifest.yaml` | Thesis declaration lives here — single source |

---

## Anti-Patterns

| Anti-Pattern | What It Looks Like | Fix |
|--------------|--------------------|-----|
| **Feature soup** | Many good features, no multiplication | Audit -> find connections or prune |
| **Thesis drift** | Thesis says X, features serve Y | Update thesis or realign features |
| **False multiplication** | "Feature A multiplies B" but the connection is vague | Require specific mechanism, not just assertion |
| **Orphan accumulation** | Orphans added as "table-stakes" without review dates | Enforce review_by dates; re-evaluate quarterly |
| **Single gravity center** | One feature does everything, others are decorative | Redistribute — if one feature IS the product, the others are noise |

---

## Related Invariants

> Proposed — add to `_invariants/REGISTRY.md` if adopted.

- **DC-001:** Every feature must declare thesis alignment before building.
- **DC-002:** Orphan features require explicit justification with review date.
- **DC-003:** Products with >30% orphan features must run a directional coherence audit before adding new features.
