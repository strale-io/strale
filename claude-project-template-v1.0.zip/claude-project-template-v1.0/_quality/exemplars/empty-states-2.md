# Filtered-Empty Key Results View

**Category:** empty-states
**Demonstrates:** Filtered empty state distinct from first-time empty, with visible cause and recovery
**References:** LAW-004 (Mandatory States), LAW-001 (User Confidence)

## Example

```yaml
surface: SURF-002 OKR Board (workspace archetype)
condition: Filters active but zero results match
type: filtered_empty           # NOT the same as first_time_empty

filter_bar:
  # Filter bar remains visible — user sees what caused the empty state
  search:
    component: input
    type: search
    value: ""
  filters:
    - component: select
      label: "Status"
      value: "At Risk"         # Active filter
    - component: select
      label: "Owner"
      value: "Sarah Chen"      # Active filter

active_filter_chips:
  # Chips remain visible — user sees the active cause
  chips:
    - component: badge
      variant: primary
      label: "Status: At Risk"
      dismiss:
        component: icon_button
        size: sm
        icon: x
        aria_label: "Remove status filter"

    - component: badge
      variant: primary
      label: "Owner: Sarah Chen"
      dismiss:
        component: icon_button
        size: sm
        icon: x
        aria_label: "Remove owner filter"

  clear_all:
    component: link
    variant: subtle
    label: "Clear all"

empty_state:
  component: empty_state
  position: centered_in_content_zone

  title:
    text: "No key results match your filters"
    typography: "typography.scale.2xl"
    color: "colors.text.primary"
    # Title says "match your filters" — not "No key results"

  description:
    text: "Try adjusting the status or owner filters to see more results."
    typography: "typography.scale.base"
    color: "colors.text.secondary"
    # Suggests specific recovery action

  action:
    component: button
    variant: secondary          # Secondary, not primary — recovery is optional
    label: "Clear Filters"
    action: clear_all_filters

  illustration: null

distinction_from_first_time:
  # First-time empty:
  #   title: "No objectives yet"
  #   action: "Create First Objective" (primary button)
  #   filter_bar: hidden
  #
  # Filtered empty:
  #   title: "No key results match your filters"
  #   action: "Clear Filters" (secondary button)
  #   filter_bar: visible with active chips
```

## Why It's Good
- Immediately distinguishable from first-time-empty through different title, action, and filter visibility
- Filter bar and chips stay visible — user sees both the cause and the remedy simultaneously
- CTA is "Clear Filters" (recovery action) not "Create" (wrong action for this state)
- Secondary button variant signals this is recovery, not a primary flow
- Description suggests what to adjust, not just that nothing matched

## Key Takeaway
Filtered-empty states must never look like first-time-empty states — the user must understand the difference immediately.
