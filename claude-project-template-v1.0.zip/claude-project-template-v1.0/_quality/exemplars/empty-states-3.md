# No Check-Ins for Current Cycle

**Category:** empty-states
**Demonstrates:** Time-scoped empty state with temporal context and deadline awareness
**References:** LAW-004 (Mandatory States), LAW-008 (Primary Flow Completion)

## Example

```yaml
surface: SURF-003 Objective Detail — Activity tab
condition: No check-ins submitted for current week
type: time_scoped_empty

empty_state:
  component: empty_state
  position: centered_in_tab_panel

  title:
    text: "No check-ins this week"
    typography: "typography.scale.2xl"
    color: "colors.text.primary"
    # Time scope explicit: "this week" not just "no check-ins"

  description:
    text: "Your team's weekly check-in for this objective hasn't been submitted yet. Check-ins help track progress and surface blockers early."
    typography: "typography.scale.base"
    color: "colors.text.secondary"

  temporal_context:
    component: badge
    variant: warning
    size: md
    label: "Due Friday"
    # Tells user WHEN the window closes

  action:
    component: button
    variant: primary
    label: "Start Check-In"
    action: open_check_in_modal  # Opens SURF-005 transient

  supplementary:
    text: "Last check-in: February 7, 2026"
    typography: "typography.scale.sm"
    color: "colors.text.secondary"
    # Shows WHEN last check-in happened — temporal orientation

tokens_used:
  - colors.text.primary
  - colors.text.secondary
  - colors.warning.light          # Badge background
  - colors.warning.dark           # Badge text
  - spacing.scale.4               # Between elements
  - spacing.scale.6               # Above/below empty state
```

## Why It's Good
- Time scope is explicit ("this week") — not a permanent absence, a temporal window
- Deadline badge ("Due Friday") creates urgency without aggressive language
- Last check-in date provides temporal orientation (how long since the last one?)
- CTA leads directly to the primary flow (check-in modal)
- Description explains the value of check-ins (valuable for new users)

## Key Takeaway
Time-scoped empty states should include the temporal context — when is the window? when does it close? — alongside the creation CTA.
