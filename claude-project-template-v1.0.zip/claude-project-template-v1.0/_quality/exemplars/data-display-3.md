# Filtered Objective List with Active Filter Tags

**Category:** data-display
**Demonstrates:** Omnibox filtering with visible active filters and clear-all affordance
**References:** LAW-001 (User Confidence)

## Example

```yaml
surface: SURF-002 OKR Board (workspace archetype)
entity: Objective (filtered view)

filter_bar:
  search:
    component: input
    type: search
    size: md
    placeholder: "Search objectives..."
    behavior:
      debounce: 150ms
      clear_button: true       # X button to clear search

  filter_controls:
    - component: select
      label: "Status"
      options: [All, Draft, Active, At Risk, Completed]
      default: "All"

    - component: select
      label: "Owner"
      options: [All, ...team_members]
      default: "All"

active_filters:
  visibility: "when_any_filter_active"
  layout: horizontal_wrap
  gap: "spacing.scale.2"      # 8px

  chips:
    - component: badge
      variant: primary         # colors.brand.primary_light bg
      size: md
      label: "Status: Active"
      dismiss:
        component: icon_button
        size: sm
        icon: x
        aria_label: "Remove status filter"
        action: clear_status_filter

    - component: badge
      variant: primary
      size: md
      label: "Owner: Sarah Chen"
      dismiss:
        component: icon_button
        size: sm
        icon: x
        aria_label: "Remove owner filter"
        action: clear_owner_filter

  clear_all:
    component: link
    variant: subtle            # colors.text.secondary, hover: colors.text.link
    label: "Clear all"
    action: clear_all_filters

count_indicator:
  text: "Showing 12 of 48 Objectives"
  typography: "typography.scale.sm"
  color: "colors.text.secondary"

results:
  component: table
  density: comfortable
  # ... table columns as defined in data-display-1.md

pagination:
  component: pagination
  variant: numbered
  items_per_page: 20
  current_page: 1
  total_pages: 3

filter_persistence:
  url_params: true             # Filters encoded in URL query string
  shareable: true              # Filtered URL can be shared
  bookmarkable: true           # Browser bookmark preserves filters
```

## Why It's Good
- Active filters are always visible — user knows exactly why they see what they see
- One-click removal per filter (dismiss icon on each badge chip)
- Clear All link provides batch reset when multiple filters active
- Count indicator ("12 of 48") gives orientation without scrolling
- Filter state persists in URL (shareable, bookmarkable)

## Key Takeaway
Every filtered view must explain its filter state — hidden filters produce "where did my data go?" confusion.
