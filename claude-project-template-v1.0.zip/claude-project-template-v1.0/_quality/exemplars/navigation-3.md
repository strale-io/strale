# Tab-Based Parallel Content on Objective Detail

**Category:** navigation
**Demonstrates:** Tabs for parallel content sections within a single entity view
**References:** LAW-002 (One Archetype), LAW-001 (User Confidence)

## Example

```yaml
surface: SURF-003 Objective Detail (detail archetype)
entity: Objective "Ship Q1 Features"

header:
  breadcrumb:
    component: breadcrumb
    items:
      - label: "Home"
        path: /
      - label: "Engineering"
        path: /teams/eng/objectives
      - label: "Ship Q1 Features"  # Current — not clickable
    max_items: 4

  title: "Ship Q1 Features"
    typography: heading-xl

  status:
    component: badge
    variant: success
    label: "On Track"

tabs:
  component: tabs
  max_tabs: 4            # Under the 7 maximum
  items:
    - label: "Overview"
      active: true
      panel_id: tab-overview
    - label: "Key Results"
      count: 4           # Badge showing count
      panel_id: tab-krs
    - label: "Initiatives"
      count: 7
      panel_id: tab-initiatives
    - label: "Activity"
      panel_id: tab-activity

  behavior:
    persist_selection: true       # Tab choice persists per user
    independent_scroll: true      # Each panel scrolls independently
    keyboard: true                # Arrow keys switch tabs
    aria_role: tablist

tab_panels:
  overview:
    content: "Objective metadata, health summary, owner, cycle info"
    components: [card, badge, avatar, progress]

  key_results:
    content: "Table of Key Results with inline progress editing"
    components: [table, badge, input, icon_button]
    states: [loading_skeleton, empty_first_time, error_with_retry]

  initiatives:
    content: "Linked initiatives with status"
    components: [table, badge, link]
    states: [loading_skeleton, empty_filtered, error_with_retry]

  activity:
    content: "Timeline of check-ins and comments"
    components: [avatar, badge, divider]
    states: [loading_skeleton, empty_no_activity]
```

## Why It's Good
- Tabs group content by concern (data type), not by action
- Archetype remains "detail" throughout — no archetype mixing across tabs
- Each tab panel declares its own states (loading, empty, error)
- Tab count (4) is well under the 7 maximum — room for growth
- Count badges on tabs surface information without requiring clicks

## Key Takeaway
Tabs group content types, not navigation hierarchies — if you need more than 7, restructure the surface.
