# Action-Triggered Loading on Save

**Category:** loading-states
**Demonstrates:** Loading state within an interactive component during async operation
**References:** LAW-007 (Affordance Integrity), LAW-004 (Mandatory States)

## Example

```yaml
surface: SURF-004 Team Settings (configuration archetype)
condition: User clicks "Save Changes" button, server processing
type: action_triggered_loading

button_states:
  default:
    component: button
    variant: primary
    label: "Save Changes"
    width: auto                 # Natural width based on label
    enabled: true

  loading:
    component: button
    variant: primary
    label: "Saving..."
    icon:
      component: spinner
      size: sm
      color: "colors.text.inverse"   # White spinner on primary bg
      position: before_text
    width: preserved            # Same width as default — no layout shift
    enabled: false              # Prevents re-click during save
    cursor: not_allowed

    # What DOES NOT happen:
    # - Button does not disappear
    # - Button does not shrink
    # - Button does not move
    # - Other buttons do not shift position

  success:
    # Button returns to default state immediately
    transition: instant
    feedback:
      component: toast
      variant: success
      message: "Settings saved"
      duration: 5000
      position: bottom_right

  error:
    # Button returns to default state (user can retry)
    transition: instant
    feedback:
      component: toast
      variant: error
      message: "Couldn't save settings. Try again."
      duration: 5000
      position: bottom_right

    # Form data is preserved — user does not lose their edits

adjacent_controls:
  # Other controls during save:
  cancel_button:
    component: button
    variant: secondary
    state: disabled             # Prevent cancel during save
  form_fields:
    state: disabled             # Prevent edits during save
    visual: slightly_dimmed     # Opacity reduction signals disabled

timing:
  # Loading state visible for at least 300ms even if server responds faster
  # Prevents flash of loading state that confuses users
  minimum_display: 300ms

  # Maximum time before showing error
  timeout: 10000ms             # 10 seconds
  timeout_message: "Save is taking longer than expected. Check your connection."

tokens_used:
  - colors.text.inverse          # Spinner color on primary button
  - colors.brand.primary         # Button background
  - colors.brand.primary_dark    # Button disabled state
```

## Why It's Good
- Button loading state prevents double-submit (disabled during save)
- Width is preserved — no layout shift when label changes from "Save Changes" to "Saving..."
- Spinner replaces text cleanly (not added alongside, which would widen the button)
- Both success and error have clear feedback paths (toast notifications)
- Adjacent controls disabled during save — prevents inconsistent state
- Minimum display time (300ms) prevents confusing flash for fast saves
- Form data preserved on error — user never loses their edits

## Key Takeaway
Loading states on action buttons must prevent re-triggering, preserve layout, and always resolve to either success or error feedback — never silent completion.
