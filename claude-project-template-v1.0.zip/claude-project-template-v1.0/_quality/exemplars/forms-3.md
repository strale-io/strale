# Inline Editing on Key Result Progress

**Category:** forms
**Demonstrates:** Inline editing with clear edit/view mode transitions and focus management
**References:** LAW-007 (Affordance Integrity), LAW-006 (Accessibility)

## Example

```yaml
surface: SURF-002 OKR Board — Key Result row in table
entity: KeyResult.current_value (type: number, unit: currency)

view_mode:
  layout: horizontal
  components:
    value:
      text: "$350,000"
      typography: "typography.scale.base"
      color: "colors.text.primary"

    target:
      text: "of $500,000"
      typography: "typography.scale.sm"
      color: "colors.text.secondary"

    edit_trigger:
      component: icon_button
      icon: pencil
      size: sm
      variant: ghost
      visibility: on_hover      # Appears on row hover
      aria_label: "Edit revenue target progress"
      tooltip:
        component: tooltip
        text: "Edit progress"
        delay: 300

edit_mode:
  trigger: click_edit_button OR double_click_value
  transition: view_mode components replaced in-place

  layout: horizontal
  components:
    input:
      component: input
      type: number
      size: sm
      # Editor contract: currency → number input with currency prefix
      prefix: "$"
      value: 350000
      auto_select: true         # All text selected on focus
      min: 0
      max: 500000               # Target value as upper bound

    confirm:
      component: icon_button
      icon: check
      size: sm
      variant: ghost
      color: "colors.success.default"
      aria_label: "Save progress"
      action: save_value

    cancel:
      component: icon_button
      icon: x
      size: sm
      variant: ghost
      color: "colors.text.secondary"
      aria_label: "Cancel editing"
      action: cancel_edit

  keyboard:
    enter: save_value
    escape: cancel_edit
    tab: save_and_move_to_next  # Save current, focus next editable cell

  focus_management:
    on_enter_edit: focus_input
    on_save: return_focus_to_edit_trigger
    on_cancel: return_focus_to_edit_trigger
    on_error: keep_focus_on_input

save_behavior:
  loading:
    input: disabled
    confirm: replaced_by spinner (sm)
    cancel: disabled
    duration: "until server responds"

  success:
    feedback:
      component: toast
      variant: success
      message: "Progress updated"
      duration: 3000
    transition: return_to_view_mode
    view_mode_value: updated_value

  error:
    feedback:
      component: toast
      variant: error
      message: "Couldn't update progress. Try again."
    transition: stay_in_edit_mode
    input: re-enabled with previous value

tokens_used:
  - colors.text.primary
  - colors.text.secondary
  - colors.success.default          # Confirm button
  - colors.error.default            # Error feedback
  - dimensions.input.height_sm
  - borders.radii.md
  - shadows.focus                   # Input focus ring
```

## Why It's Good
- Edit mode is unambiguous: pencil icon on hover implies editability, confirm/cancel icons make actions clear
- Keyboard shortcuts work: Enter saves, Escape cancels, Tab saves-and-moves
- Focus returns to the edit trigger button after save/cancel (never lost)
- Loading state disables all controls (no double-submit, no cancel during save)
- Both success and error paths have feedback (toast) and clear next states
- Editor contract respected: currency value uses number input with $ prefix, not text input

## Key Takeaway
Inline editing must make three things obvious: what is editable, how to confirm, and how to escape.
