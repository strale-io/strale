# Key Results Table with Status Badges and Sorting

**Category:** data-display
**Demonstrates:** Dense data table with semantic status, sorting, and selection
**References:** LAW-005 (Data Accuracy), LAW-006 (Accessibility)

## Example

```yaml
surface: SURF-003 Objective Detail — Key Results tab
entity: KeyResult (belongs_to Objective)

table:
  component: table
  density: comfortable
  row_height: "dimensions.table.row_height_comfortable"

  columns:
    - header: ""
      component: checkbox
      width: 40
      purpose: multi_select

    - header: "Key Result"
      component: text
      typography: "typography.scale.base"
      color: "colors.text.primary"
      sortable: true
      sort_direction_indicator: true  # ↑↓ arrow shown

    - header: "Status"
      component: badge
      size: sm
      variant_mapping:
        on_track: success       # colors.success.light bg, colors.success.dark text
        behind: warning         # colors.warning.light bg, colors.warning.dark text
        at_risk: error          # colors.error.light bg, colors.error.dark text
        not_started: default    # colors.background.muted bg, colors.text.secondary text
        completed: success

    - header: "Owner"
      components: [avatar, text]
      avatar_size: sm
      text_typography: "typography.scale.sm"
      text_color: "colors.text.secondary"

    - header: "Progress"
      component: progress
      variant: linear
      height: 4
      track: "colors.background.muted"
      fill: "colors.brand.primary"
      label: "{current} of {target} {unit}"  # "7 of 10 tasks completed"

    - header: "Updated"
      component: text
      typography: "typography.scale.sm"
      color: "colors.text.secondary"
      sortable: true

  selection:
    mode: multi                 # Checkbox + shift-click
    bulk_actions:
      component: button_group
      visibility: "when_selected"
      actions:
        - label: "Change Status"
          component: button
          variant: secondary
        - label: "Reassign"
          component: button
          variant: secondary
    count_indicator: "3 of 8 selected"

  sorting:
    default: "Key Result"
    direction: ascending
    single_column: true         # Only one sort active at a time
    keyboard: true              # Enter on header to toggle sort

  tokens_used:
    - colors.background.base            # Table background
    - colors.border.subtle              # Row borders
    - colors.interactive.hover          # Row hover
    - colors.interactive.selected       # Selected row
    - dimensions.table.row_height_comfortable
    - typography.scale.sm
    - typography.scale.base
```

## Why It's Good
- Status badges use semantic color only — no ambiguity between states
- Progress column shows descriptive fraction ("7 of 10 tasks") not bare percentage (LAW-005)
- Sort direction is always visible (user knows the current sort state)
- Selection shows count and context ("3 of 8 selected")
- All colors reference semantic tokens, not hardcoded values

## Key Takeaway
Data tables are projections of the truth model — every cell must trace to an entity attribute, and every status must use semantic tokens.
