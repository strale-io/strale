# Validation Errors on Objective Create Form

**Category:** error-states
**Demonstrates:** Inline form validation with specific error messages and multi-cue visual treatment
**References:** LAW-007 (Affordance Integrity), LAW-006 (Accessibility)

## Example

```yaml
surface: SURF-005 transient — Create Objective modal
condition: User clicks "Create Objective" with validation errors
type: form_validation_error

summary_alert:
  component: alert
  variant: error
  position: top_of_modal_body
  background: "colors.error.light"
  border: "colors.error.default"
  icon: error_icon
  message: "Fix 1 error before creating this objective"
  # Count is specific ("1 error") not vague ("errors found")
  # Anchored at top of form — visible without scrolling

field_errors:
  title_field:
    component: input
    type: text
    label: "Title"
    label_color: "colors.error.default"     # Label turns error color
    required: true
    state: error

    visual_cues:
      border: "colors.error.default"        # Red border
      # Multi-cue: border + icon + text (not color alone — LAW-006)

    error_message:
      text: "Objective title is required — enter a brief name like 'Increase Q1 revenue'"
      typography: "typography.scale.sm"
      color: "colors.error.default"
      icon: error_icon                      # Icon + color (not color alone)
      position: below_field
      aria_describedby: true                # Links error to field for screen readers

    accessibility:
      aria_invalid: true
      aria_describedby: "title-error"       # Points to error message element

  team_field:
    component: select
    label: "Team"
    state: default                          # Valid — no error styling
    # Only error fields get error treatment — valid fields stay neutral

  cycle_field:
    component: select
    label: "Cycle"
    state: default

focus_management:
  on_submit_with_errors:
    action: focus_first_error_field          # Title input receives focus
    scroll: scroll_to_first_error            # If form is scrollable

error_message_quality:
  # Bad: "Invalid"
  # Bad: "This field is required"
  # Good: "Objective title is required — enter a brief name like 'Increase Q1 revenue'"
  #
  # Pattern: [What's wrong] — [how to fix it]

tokens_used:
  - colors.error.default          # Border, label, error text, icon
  - colors.error.light            # Alert background
  - typography.scale.sm           # Error message text
  - borders.radii.md              # Input border radius unchanged
  - shadows.focus                  # Focus ring on error field
```

## Why It's Good
- Error messages explain HOW to fix ("enter a brief name like...") not just WHAT is wrong
- Multi-cue visual treatment: border color + icon + text color (not color alone — accessibility)
- Summary alert at top gives overview ("Fix 1 error") without requiring user to scan all fields
- Focus moves to first error field on submit — user doesn't have to find it
- Valid fields retain neutral styling — only errors are highlighted
- `aria-invalid` and `aria-describedby` link errors to fields for screen readers

## Key Takeaway
Validation errors must be specific, adjacent to the field, and suggest resolution — "Invalid" helps no one.
