# First-Time Empty OKR Board

**Category:** empty-states
**Demonstrates:** First-use empty state with contextual guidance and primary CTA
**References:** LAW-004 (Mandatory States), LAW-008 (Primary Flow Completion)

## Example

```yaml
surface: SURF-002 OKR Board (workspace archetype)
condition: Team has zero objectives in current cycle
type: first_time_empty         # Distinguished from filtered_empty

empty_state:
  component: empty_state
  position: centered_in_content_zone
  padding: "spacing.scale.8"   # 32px

  title:
    text: "No objectives yet"
    typography: "typography.scale.2xl"
    color: "colors.text.primary"
    # Must contain: empty_state.title (required per component spec)

  description:
    text: "Objectives help your team align on what matters most this quarter. Create your first objective to get started."
    typography: "typography.scale.base"
    color: "colors.text.secondary"
    max_width: 400             # Prevent long lines
    # Explains VALUE, not just absence

  action:
    component: button
    variant: primary
    label: "Create First Objective"
    action: open_create_objective_modal
    # Must contain: empty_state.action (required per component spec)
    # CTA is specific ("Create First Objective") not generic ("Get Started")

  illustration: null            # Optional per component spec — omitted here

context_preserved:
  # The rest of the surface remains functional:
  sidebar: visible              # Navigation still works
  header: visible               # Breadcrumb, team name still shown
  toolbar: hidden               # No filters needed when nothing exists
```

## Why It's Good
- Title names what belongs here ("objectives") — user learns the surface purpose
- Description explains the value proposition, not just the empty state
- CTA is specific ("Create First Objective") not generic ("Get Started" or "Add")
- Toolbar is hidden (no filters needed when collection is empty)
- Navigation remains functional — user is never stranded

## Key Takeaway
Empty states are onboarding moments — they teach what the surface is for, not just that it is empty.
