# Strategy Dashboard Metric Cards

**Category:** data-display
**Demonstrates:** Card-based metric display with drill-down affordance on an overview surface
**References:** LAW-003 (Hard Budgets), LAW-007 (Affordance Integrity)

## Example

```yaml
surface: SURF-001 Strategy Dashboard (overview archetype)
budget: max 12 components, 1 primary action, 8 decision points

card_grid:
  layout: 4 columns (desktop), 2 columns (tablet), 1 column (mobile)
  gap: "spacing.scale.4"       # 16px

  cards:
    - component: card
      variant: interactive     # Clickable — cursor: pointer, hover: shadows.sm
      action: navigate_to /teams/eng/objectives?status=at_risk

      content:
        label:
          text: "Engineering"
          typography: "typography.scale.sm"
          color: "colors.text.secondary"

        metric:
          text: "3 of 5"      # Descriptive fraction, not percentage
          typography: "typography.scale.2xl"  # Large, scannable
          color: "colors.text.primary"
          semantics: "objectives on track"

        trend:
          component: badge
          variant: warning     # colors.warning.light bg
          label: "1 at risk"
          size: sm

      tokens_used:
        - colors.background.base       # Card background
        - borders.radii.lg             # Rounded corners
        - colors.border.default        # Card border
        - shadows.sm                   # Hover shadow (interactive variant)
        - spacing.scale.4              # Internal padding

    - component: card
      variant: interactive
      action: navigate_to /teams/design/objectives

      content:
        label:
          text: "Design"
          typography: "typography.scale.sm"
          color: "colors.text.secondary"
        metric:
          text: "4 of 4"
          typography: "typography.scale.2xl"
          color: "colors.text.primary"
        trend:
          component: badge
          variant: success
          label: "All on track"

    # ... 2 more team cards (max 4 per overview budget)

budget_check:
  decision_points: 4           # One per card (within budget of 8)
  components: 4                # 4 cards (within budget of 12)
  primary_actions: 0           # Dashboard primary action is elsewhere
  status: within_budget
```

## Why It's Good
- Budget-compliant (4 cards = 4 decision points, well under the 8 maximum)
- Each card is a self-contained information unit with label, metric, and trend
- Interactive variant signals clickability through cursor and hover shadow (LAW-007)
- Trend badge interprets the metric ("1 at risk") instead of just showing a number
- Progress shown as descriptive fraction ("3 of 5 objectives on track"), not bare percentage

## Key Takeaway
Overview surfaces must interpret data, not just display it — a trend badge tells the user what changed, while a raw number makes them do the math.
