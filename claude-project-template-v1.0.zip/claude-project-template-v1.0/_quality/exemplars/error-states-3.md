# Full-Page Error with Recovery Options

**Category:** error-states
**Demonstrates:** Catastrophic error state with multiple recovery paths
**References:** LAW-004 (Mandatory States), LAW-001 (User Confidence)

## Example

```yaml
surface: SURF-003 Objective Detail
condition: Entire page fails to load (network error, 500, or 404)
type: full_page_error

layout:
  position: centered_in_viewport
  max_width: 400

  # Navigation remains visible:
  sidebar: visible              # User can navigate away
  header: visible               # Breadcrumb still shows context

  error_content:
    title:
      text: "Something went wrong"
      typography: "typography.scale.2xl"
      color: "colors.text.primary"
      # Honest but not alarming

    description:
      text: "We couldn't load this objective. This is usually temporary."
      typography: "typography.scale.base"
      color: "colors.text.secondary"
      # Reassuring: "usually temporary" sets expectation

    actions:
      spacing: "spacing.scale.3"   # 12px between buttons

      primary:
        component: button
        variant: primary
        label: "Try Again"
        action: reload_page
        # First recovery option: retry

      secondary:
        component: button
        variant: secondary
        label: "Go to Dashboard"
        action: navigate_to /
        # Second recovery option: navigate away

      tertiary:
        component: link
        variant: subtle
        label: "Contact Support"
        action: open_support
        # Third recovery option: get help
        # Using link (not button) for lowest-priority action

recovery_paths:
  # Minimum 2 paths required by LAW-001 (user knows how to escape):
  # 1. Retry (primary) — "maybe it works now"
  # 2. Navigate away (secondary) — "take me somewhere that works"
  # 3. Get help (tertiary) — "this keeps happening"
  #
  # Plus: sidebar navigation always works

accessibility:
  role: alert                   # Screen reader announces error
  focus_management:
    on_error: focus_title       # Focus moves to error title
    # User doesn't land on a blank page with no context

tokens_used:
  - colors.text.primary
  - colors.text.secondary
  - colors.text.link            # Support link
  - spacing.scale.3             # Between actions
  - spacing.scale.6             # Above/below error content
  - typography.scale.2xl        # Title
  - typography.scale.base       # Description
```

## Why It's Good
- Multiple escape routes: retry, navigate away, get help (user is never stranded)
- Language is honest without being alarming ("something went wrong" not "FATAL ERROR")
- "Usually temporary" sets expectations — user knows retrying might help
- Sidebar navigation remains functional — user can always leave
- Focus moves to error title on page load — screen reader users know immediately what happened
- Three action tiers: primary button (retry), secondary button (navigate), subtle link (support)

## Key Takeaway
Full-page errors must provide at least two escape routes — retrying and navigating elsewhere — because "try again" sometimes fails again.
