# Exemplars

> Reference examples that teach taste. Good only.

---

## Rules

1. **Maximum 5 per category** — more ≠ better calibration
2. **Good examples only** — bad examples waste tokens and risk overfitting
3. **Anything not matching exemplars is implicitly incorrect**
4. **Rotate quarterly** — keep examples fresh and relevant

---

## Format

```markdown
# [Title]

**Category:** [navigation | data-display | forms | empty-states | error-states | loading-states]
**Demonstrates:** [specific principle]
**References:** [LAW-XXX, RULE-XXX]

## Example
[Screenshot or code]

## Why It's Good
- Point 1
- Point 2

## Key Takeaway
[One sentence]
```

---

## Current Inventory

| Category | Count | Cap |
|----------|-------|-----|
| Navigation | 4 | 5 |
| Data display | 4 | 5 |
| Forms | 3 | 5 |
| Empty states | 3 | 5 |
| Error states | 3 | 5 |
| Loading states | 3 | 5 |

Add exemplars as files in this folder: `{category}-{number}.md`
