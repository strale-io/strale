# Team Settings Configuration Form

**Category:** forms
**Demonstrates:** Configuration archetype with grouped settings, mixed save behavior, and editor contracts
**References:** LAW-007 (Affordance Integrity), LAW-004 (Mandatory States)

## Example

```yaml
surface: SURF-004 Team Settings (configuration archetype)
budget: 4 decision points, 10 max components, 1 primary action

layout:
  structure: header → content (grouped sections with dividers)

sections:
  - label: "Team Information"
    description: "Basic team details visible to all members"
    save_behavior: explicit     # Requires "Save Changes" button

    fields:
      - component: input
        type: text
        size: md
        label: "Team Name"
        value: "Engineering"
        validation:
          trigger: on_blur
          rule: "required, max_length: 50"

      - component: textarea
        label: "Description"
        value: "Core product engineering team"
        min_height: 80
        resize: vertical

  - separator:
      component: divider
      variant: horizontal
      color: "colors.border.subtle"

  - label: "Notifications"
    description: "These settings take effect immediately"
    save_behavior: immediate    # Switch toggles save instantly

    fields:
      - component: switch
        size: md
        label: "Email check-in reminders"
        description: "Send weekly email when check-in is due"
        value: true
        on_change:
          action: save_immediately
          feedback:
            component: toast
            variant: success
            message: "Notification preference updated"
            duration: 3000

      - component: switch
        size: md
        label: "Slack notifications"
        description: "Post objective updates to team Slack channel"
        value: false
        on_change:
          action: save_immediately
          feedback:
            component: toast
            variant: success
            message: "Notification preference updated"

  - separator:
      component: divider
      variant: horizontal

  - label: "Cycle Settings"
    description: "Configure how your team runs planning cycles"
    save_behavior: explicit

    fields:
      - component: select
        label: "Default Scoring Method"
        options:
          - label: "Google-style (0.0–1.0)"
            value: google
          - label: "Percentage (0–100%)"
            value: percentage
          - label: "Traffic light (Red/Yellow/Green)"
            value: traffic_light
        default: google
        # Editor contract: enum → select (not text input)

      - component: select
        label: "Check-in Frequency"
        options: [Weekly, Biweekly, Monthly]
        default: "Weekly"
        # Editor contract: enum → select

footer:
  component: button
  variant: primary
  label: "Save Changes"
  disabled_condition: "no_changes_made"
  states:
    loading:
      text: "Saving..."
      icon: spinner
      disabled: true
    success:
      feedback:
        component: toast
        variant: success
        message: "Settings saved"
    error:
      feedback:
        component: toast
        variant: error
        message: "Couldn't save settings. Try again."

save_behavior_distinction:
  # Visual separation between immediate and explicit sections:
  # - Switch sections have description "take effect immediately"
  # - Form sections have "Save Changes" button at bottom
  # - Dividers separate the two behavior types
```

## Why It's Good
- Editor contracts respected: enums use `select` (not text input), booleans use `switch` for immediate effect
- Mixed save behavior is clearly distinguished: switches save immediately with toast confirmation, text fields require explicit "Save Changes" button
- Section descriptions explain the save behavior ("take effect immediately")
- Dividers separate logical groups and behavior types
- Save button is disabled when no changes exist — prevents empty saves

## Key Takeaway
Configuration surfaces must distinguish between immediate-effect settings (toggles) and explicit-save settings (forms) — mixing them without clarity causes "did that save?" anxiety.
