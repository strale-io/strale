# Failed Dashboard Data Section

**Category:** error-states
**Demonstrates:** Section-level error with graceful degradation and inline retry
**References:** LAW-004 (Mandatory States), LAW-007 (Affordance Integrity)

## Example

```yaml
surface: SURF-001 Strategy Dashboard (overview archetype)
condition: One section fails to load while others succeed
type: section_error            # Not full-page error

layout:
  working_sections:
    # These sections loaded successfully and remain fully interactive:
    - section: "Cycle Progress"
      component: card
      variant: default
      status: loaded

    - section: "Objective Summary"
      component: card
      variant: default
      status: loaded

  failed_section:
    section: "Team Performance"
    status: error

    error_display:
      component: alert
      variant: error
      # Styling:
      background: "colors.error.light"
      border: "colors.error.default"
      icon: error_icon

      message:
        text: "Couldn't load team performance data"
        typography: "typography.scale.base"
        color: "colors.text.primary"

      retry:
        component: button
        variant: ghost
        label: "Try Again"
        action: retry_section_load
        # Retry is inline — does not navigate away or refresh the whole page

    dimensions:
      # Alert occupies the same space the section would have occupied
      height: "match_expected_section_height"
      # Prevents layout shift when section eventually loads

  isolation:
    # Key principle: section failure does NOT affect other sections
    working_sections_interactive: true
    navigation_functional: true
    primary_action_available: true
    other_cards_clickable: true
```

## Why It's Good
- Partial failure handled gracefully — user still has access to 3 of 4 dashboard sections
- Error is contained to the failed section only (no page-level takeover)
- Retry is inline and specific to the failed section
- Alert occupies expected section dimensions — no layout shift
- Language is factual ("Couldn't load") not alarming ("Error!" or "Something broke!")

## Key Takeaway
Section errors should degrade gracefully — a failed chart should not collapse the entire dashboard.
