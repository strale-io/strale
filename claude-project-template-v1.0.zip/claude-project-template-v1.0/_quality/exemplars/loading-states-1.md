# Skeleton Loading for OKR Board Table

**Category:** loading-states
**Demonstrates:** Skeleton loading that matches the final layout structure exactly
**References:** LAW-004 (Mandatory States)

## Example

```yaml
surface: SURF-002 OKR Board (workspace archetype)
condition: Table data loading from server
type: skeleton_loading

skeleton_table:
  component: table
  density: comfortable
  row_count: 5                  # Show 5 skeleton rows (matches typical page size)

  header_row:
    # Real headers shown immediately — they are static content
    columns: ["", "Objective", "Status", "Owner", "Progress", "Updated"]
    visible: true

  skeleton_rows:
    delay: 100ms                # Show after 100ms — prevents flash for fast loads
    animation: subtle_pulse     # Matches skeleton component spec

    row_template:
      - column: checkbox
        component: skeleton
        variant: rect
        width: 20
        height: 20

      - column: objective_name
        component: skeleton
        variant: text
        width: "60%"            # Varies slightly per row for natural feel
        height: "typography.scale.base line_height"

      - column: status
        component: skeleton
        variant: rect
        width: 60
        height: 22              # Matches badge.sizes.md.height

      - column: owner
        components:
          - component: skeleton
            variant: circle
            size: 24             # Matches avatar.sizes.sm
          - component: skeleton
            variant: text
            width: 80

      - column: progress
        component: skeleton
        variant: rect
        width: 120
        height: 4               # Matches progress.variants.linear.height

      - column: updated
        component: skeleton
        variant: text
        width: 70

transition_to_content:
  animation: fade
  duration: 150ms              # Matches _ui/states.md transition spec
  easing: ease_out

motion_preference:
  prefers_reduced_motion:
    animation: none             # Disable pulse animation
    transition: instant         # No fade, immediate content swap

tokens_used:
  - colors.background.muted     # Skeleton fill color
  - dimensions.table.row_height_comfortable
  - typography.scale.base        # Text skeleton height reference
  - transitions.presets.hover    # Fade transition reference
```

## Why It's Good
- Skeleton matches the exact table structure users will see (column widths, row heights, component shapes)
- 100ms delay prevents skeleton flash for fast loads (sub-100ms responses skip skeleton entirely)
- Circle variant for avatars and rect variant for badges give structural preview — user knows what is loading
- Pulse animation respects `prefers-reduced-motion` preference
- Real table headers are shown immediately — static content doesn't need to load
- Content fades in at 150ms (matches states.md transition spec)

## Key Takeaway
Skeleton loaders are layout contracts — they must match the final structure exactly, or they create a false expectation of what is loading.
