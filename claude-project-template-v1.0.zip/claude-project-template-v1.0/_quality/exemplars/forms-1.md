# Create Objective Modal Form

**Category:** forms
**Demonstrates:** Transient archetype form with minimal fields, validation, and loading feedback
**References:** LAW-007 (Affordance Integrity), LAW-004 (Mandatory States)

## Example

```yaml
surface: SURF-005 transient (triggered from SURF-002 OKR Board)
archetype: transient (budget: 2 decision points, 6 max components, 1 primary action)

modal:
  component: modal
  size: md
  width: "dimensions.modal.width_md"

  header:
    title: "Create Objective"
    close_button:
      component: icon_button
      icon: x
      aria_label: "Close"
      action: close_modal

  body:
    form_fields:
      - component: input
        type: text
        label: "Title"
        required: true
        marker: "*"              # Asterisk for required
        placeholder: ""          # No placeholder-as-label
        validation:
          trigger: on_blur
          rule: "required"
          error_message: "Objective title is required — enter a brief name like 'Increase Q1 revenue'"

      - component: select
        label: "Team"
        required: true
        options: "[populated from truth model Teams]"
        default: "current_team"  # Pre-selected based on context
        validation:
          trigger: on_blur
          rule: "required"

      - component: select
        label: "Cycle"
        required: true
        options: "[populated from truth model Cycles]"
        default: "active_cycle"  # Defaults to current active cycle

      - component: textarea
        label: "Description"
        required: false          # Optional — progressive disclosure
        min_height: 80
        resize: vertical

    # Advanced fields NOT shown on create:
    # Owner, Due Date, Priority — available after creation
    # This is progressive disclosure: minimal fields for creation

  footer:
    component: button_group
    spacing: "spacing.scale.2"
    actions:
      - component: button
        variant: primary
        label: "Create Objective"
        states:
          default:
            text: "Create Objective"
          loading:
            text: "Creating..."
            icon: spinner
            icon_size: sm
            icon_color: "colors.text.inverse"
            disabled: true       # Prevents double-submit
            width: preserved     # No layout shift
          disabled:
            condition: "required fields invalid"

      - component: button
        variant: secondary
        label: "Cancel"
        action: close_modal

  error_state:
    component: alert
    variant: error
    position: top_of_body
    message: "Couldn't create objective. Check your connection and try again."
    dismissible: true

  behavior:
    focus_trap: true
    escape: close_modal
    scroll_lock: true
    unsaved_changes: false      # Create forms don't warn on close (no existing data to lose)
```

## Why It's Good
- Minimal fields on create (4 fields total: Title, Team, Cycle, Description) — progressive disclosure defers Owner, Due Date, Priority to after creation
- Validation is specific ("enter a brief name like...") not generic ("Error")
- Loading state replaces button text with spinner — prevents double-submit
- Button width preserved during loading — no layout shift
- Required fields marked with asterisk, not placeholder text
- Team and Cycle pre-selected from context — reduces friction

## Key Takeaway
Create forms should have the minimum viable fields — let users configure after creation, not before.
