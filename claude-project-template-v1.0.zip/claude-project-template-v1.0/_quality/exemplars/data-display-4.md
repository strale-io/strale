# Check-In History Timeline

**Category:** data-display
**Demonstrates:** Time-based data display with entity attribution and grouped entries
**References:** LAW-005 (Data Accuracy), LAW-004 (Mandatory States)

## Example

```yaml
surface: SURF-003 Objective Detail — Activity tab
entity: CheckIn (belongs_to Objective)

timeline:
  layout: vertical
  order: newest_first
  grouping: by_date

  date_group:
    label:
      text: "February 14, 2026"
      typography: "typography.scale.sm"
      color: "colors.text.secondary"
      weight: "typography.weights.semibold"
    separator:
      component: divider
      variant: horizontal

  entries:
    - type: check_in
      author:
        component: avatar
        size: sm
        fallback: initials       # "SC" for Sarah Chen
      timestamp:
        text: "2:30 PM"
        typography: "typography.scale.sm"
        color: "colors.text.secondary"
      status:
        component: badge
        variant: success
        label: "Submitted"
        size: sm
      summary:
        text: "Weekly check-in: 3 of 4 KRs on track. Revenue target progressing ahead of schedule."
        typography: "typography.scale.base"
        color: "colors.text.primary"

    - type: check_in
      author:
        component: avatar
        size: sm
      timestamp:
        text: "11:00 AM"
      status:
        component: badge
        variant: warning
        label: "Flagged blocker"
        size: sm
      summary:
        text: "API integration delayed — dependency on Platform team unresolved."

  multi_participant:
    component: avatar_group
    max_visible: 4
    overflow: "+N indicator"
    overlap: "25%"

  states:
    loading:
      component: skeleton
      variant: text
      rows: 4
      delay: 100ms
    empty:
      component: empty_state
      title: "No activity yet"
      description: "Check-ins and comments will appear here as your team updates progress."
    error:
      component: alert
      variant: error
      message: "Couldn't load activity"
      action:
        component: button
        variant: ghost
        label: "Try Again"

  tokens_used:
    - colors.text.primary
    - colors.text.secondary
    - colors.border.subtle          # Divider color
    - colors.background.base
    - spacing.scale.4               # Gap between entries
    - spacing.scale.6               # Gap between date groups
```

## Why It's Good
- Timeline naturally handles chronological data with newest-first ordering
- Date grouping provides temporal context without requiring each entry to repeat the full date
- Avatars provide quick attribution (who did this?)
- Status badges distinguish check-in types at a glance (submitted vs flagged)
- All three states (loading, empty, error) are defined with appropriate components

## Key Takeaway
Time-series data should be ordered by recency and grouped by meaningful intervals, not paginated arbitrarily.
