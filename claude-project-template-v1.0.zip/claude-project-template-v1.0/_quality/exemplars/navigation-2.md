# Command Palette as Navigation Complement

**Category:** navigation
**Demonstrates:** Global search as navigation shortcut, keyboard-first interaction
**References:** LAW-006 (Accessibility), LAW-001 (User Confidence)

## Example

```yaml
surface: Global (available on all surfaces)
trigger: Cmd+K (macOS) / Ctrl+K (Windows)

palette:
  component: modal
  size: md
  position: centered, 20% from top
  backdrop: semi_transparent

  search_input:
    component: input
    type: search
    placeholder: "Search commands and pages..."
    debounce: 150ms
    min_characters: 2

  default_state:  # No query entered
    sections:
      - label: "RECENT"
        items:
          - icon: objective
            title: "Ship Q1 Features"
            subtitle: "Objective — Engineering"
            action: navigate_to /objectives/obj-001
          - icon: settings
            title: "Team Settings"
            action: navigate_to /teams/eng/settings
        separator: divider

      - label: "ACTIONS"
        items:
          - icon: plus
            title: "Create Objective"
            shortcut: "Cmd+Shift+O"
            action: open_create_objective_modal
          - icon: checkin
            title: "Start Check-In"
            action: open_check_in_modal

      - label: "NAVIGATION"
        items:
          - icon: dashboard
            title: "Strategy Dashboard"
            action: navigate_to /
          - icon: team
            title: "Engineering"
            action: navigate_to /teams/eng

  result_types:
    navigation:
      format: "Go to {destination}"
      component: badge
      badge_variant: default
      badge_label: "Page"
    entity:
      format: "{entity}: {title}"
      component: badge
      badge_variant: primary
      badge_label: entity_type
    action:
      format: "{verb} {object}"
      component: badge
      badge_variant: default
      badge_label: "Action"

  keyboard:
    down_arrow: next_result
    up_arrow: prev_result
    enter: execute_selected
    escape: close_palette

  accessibility:
    role: combobox
    aria_expanded: true
    aria_haspopup: listbox
    focus_trap: true
    focus_return: trigger_element
    result_count_announced: true
```

## Why It's Good
- Reduces navigation hops — user goes directly to any entity or action
- Keyboard-first supports power users without excluding mouse users
- Escape always returns to previous context (LAW-001)
- Results grouped by type with badges for quick scanning
- Focus is trapped inside palette and returns to trigger on close

## Key Takeaway
The fastest navigation is the one that skips the hierarchy entirely.
