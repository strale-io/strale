# Master-Detail Pattern on OKR Board

**Category:** navigation
**Demonstrates:** List-to-detail navigation with persistent list context
**References:** LAW-007 (Affordance Integrity), LAW-001 (User Confidence)

## Example

```yaml
surface: SURF-002 OKR Board (workspace archetype)

layout:
  structure: content + sidebar
  content_width: "60%"
  sidebar_width: "40%"

master_list:
  zone: content
  component: table
  density: comfortable
  columns:
    - header: ""
      component: checkbox    # Selection column
    - header: "Objective"
      component: text
      sortable: true
    - header: "Status"
      component: badge
      variants:
        active: success
        at_risk: error
        draft: default
    - header: "Owner"
      component: avatar
      size: sm
    - header: "Progress"
      component: progress
      variant: linear

  selection:
    type: single_click      # Click row to select
    visual:
      selected_row:
        component: card
        variant: interactive
        border: "colors.brand.primary"
        background: "colors.interactive.selected"
    keyboard:
      arrow_down: next_row
      arrow_up: prev_row
      enter: open_detail

detail_panel:
  zone: sidebar
  component: drawer
  side: right
  size: md
  trigger: row_selection

  content:
    header:
      title: "{objective.title}"
      close_button:
        component: icon_button
        aria_label: "Close detail panel"
    body:
      sections:
        - label: "Key Results"
          component: table
          density: compact
        - label: "Recent Activity"
          components: [avatar, badge, divider]
    footer:
      component: button
      variant: secondary
      label: "Open Full Detail"
      action: navigate_to /objectives/{id}

  states:
    no_selection:
      message: "Select an objective to see details"
      component: empty_state
    loading:
      component: skeleton
      variant: text
      rows: 5
    error:
      component: alert
      variant: error
      action: "Try Again"

responsive:
  narrow:
    behavior: "Row click navigates to SURF-003 (full detail page)"
    sidebar: hidden
    breadcrumb_back: true
```

## Why It's Good
- Context is preserved — user never loses sight of the list while viewing detail
- Arrow keys navigate between rows naturally (keyboard-first)
- Selected row is visually distinct with brand border and selected background tokens
- Detail panel has its own state handling (empty, loading, error) independent of master
- Mobile falls back gracefully to page-level navigation with breadcrumb back

## Key Takeaway
Master-detail preserves context; page-level navigation destroys it — choose based on how often users switch between items.
