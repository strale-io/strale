# OKR Board Sidebar Navigation with Breadcrumbs

**Category:** navigation
**Demonstrates:** Primary sidebar paired with breadcrumb hierarchy for deep entity structures
**References:** LAW-001 (User Confidence), LAW-006 (Accessibility)

## Example

```yaml
surface: SURF-002 OKR Board (workspace archetype)
entity_depth: Organization → Team → Objective → Key Result

sidebar:
  # Composed from registered components: link items in a vertical list.
  # See _primitives/navigation-shell/SPEC.md for behavioral reference.
  structure: vertical_list
  items:
    - label: "Strategy Dashboard"
      icon: dashboard
      path: /
    - label: "Engineering"      # Current team
      icon: team
      path: /teams/eng
      active: true
      children:
        - label: "Objectives"
          path: /teams/eng/objectives
          active: true
        - label: "Settings"
          path: /teams/eng/settings
    - label: "Design"
      icon: team
      path: /teams/design
  behavior:
    collapsible: true           # Desktop: sidebar collapses to icons
    mobile: drawer              # Mobile: sidebar becomes drawer overlay
    keyboard: true              # Arrow keys navigate items

breadcrumb:
  component: breadcrumb
  items:
    - label: "Home"
      path: /
    - label: "Engineering"
      path: /teams/eng
    - label: "Q1 Objectives"   # Current page — not clickable
  max_items: 4                 # Truncate middle items to ellipsis if deeper
  current_page_clickable: false

primary_action:
  component: button
  variant: primary
  label: "Create Objective"
  position: header_right
```

## Why It's Good
- User always knows where they are (sidebar active state + breadcrumb trail)
- Breadcrumb reflects entity hierarchy (Organization → Team → Section), not URL structure
- Sidebar collapses cleanly on mobile without losing navigation access
- Single primary action in header (within workspace budget: max 2)

## Key Takeaway
Navigation must answer "where am I?" before it answers "where can I go?"
