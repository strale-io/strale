# Progressive Loading on Strategy Dashboard

**Category:** loading-states
**Demonstrates:** Independent section loading with structural frames visible immediately
**References:** LAW-004 (Mandatory States), LAW-001 (User Confidence)

## Example

```yaml
surface: SURF-001 Strategy Dashboard (overview archetype)
condition: Multiple data sources loading at different speeds
type: progressive_loading

layout:
  # Card frames render immediately — they are structural, not data-dependent
  card_grid:
    layout: 4 columns
    gap: "spacing.scale.4"

sections:
  - section: "Cycle Progress"
    load_priority: 1            # Fastest response expected
    card:
      component: card
      variant: default
      # Card frame visible immediately:
      background: "colors.background.base"
      border: "colors.border.default"
      radius: "borders.radii.lg"
      padding: "spacing.scale.4"

    states:
      loading:
        # Card frame visible, content is skeleton
        component: skeleton
        variant: text
        lines: 3
        delay: 100ms

      loaded:
        # Real content replaces skeleton
        transition:
          animation: fade
          duration: 150ms       # Fast/ease_out
        content: "[metric value + trend badge]"

  - section: "Objective Summary"
    load_priority: 2
    card:
      component: card
      variant: default

    states:
      loading:
        component: skeleton
        variant: text
        lines: 4
        delay: 100ms

      loaded:
        transition:
          animation: fade
          duration: 150ms

  - section: "Team Health"
    load_priority: 3            # Slower — requires aggregation
    card:
      component: card
      variant: default

    states:
      loading:
        component: skeleton
        variant: rect           # Chart-shaped skeleton
        width: "100%"
        height: 120
        delay: 100ms

      loaded:
        transition:
          animation: fade
          duration: 150ms

  - section: "Recent Activity"
    load_priority: 4            # Slowest — pagination query
    card:
      component: card
      variant: default

    states:
      loading:
        components:
          - component: skeleton
            variant: circle
            size: 24            # Avatar placeholder
            count: 3
          - component: skeleton
            variant: text
            lines: 3

      loaded:
        transition:
          animation: fade
          duration: 150ms

independence_rules:
  # Each section loads independently:
  - "Fast sections are NEVER delayed by slow sections"
  - "Each section transitions from skeleton to content individually"
  - "If a section fails, only that section shows error (see error-states-1.md)"
  - "User can interact with loaded sections while others still load"

tokens_used:
  - colors.background.base       # Card frame
  - colors.background.muted      # Skeleton fill
  - colors.border.default        # Card border
  - borders.radii.lg             # Card corners
  - spacing.scale.4              # Card padding and grid gap
```

## Why It's Good
- User sees progress immediately — card frames appear instantly, first data section loads within milliseconds
- Card frames establish layout before content arrives (no layout shift when content appears)
- Each section transitions from skeleton independently — fast sections never wait for slow siblings
- Skeleton shapes match the expected content type (text lines, chart rectangles, avatar circles)
- Loaded sections are interactive while other sections still load

## Key Takeaway
Progressive loading should prioritize the most useful section first and show structural frames immediately — users tolerate waiting better when they can see progress.
