# Build Intelligence

> Patterns that predict build quality before the critique loop runs.

**Authority:** Advisory. These are not rules — they are accumulated observations that help agents and builders make better decisions earlier. No invariant IDs. No P0/P1 classifications. Just signal.

**Updates:** This file grows over time as patterns emerge from critique results and post-mortems.

---

## What This File Is

The critique loop catches problems *after* building. This file captures patterns that predict problems *before* building — giving agents early warning signals and helping builders avoid known failure modes.

Think of it as: "If you see X before building, expect Y during critique."

---

## Early Warning Signals

These patterns, observed before or during the build phase, reliably predict critique failures.

### Intent & Planning Signals

| Signal | What It Predicts | Typical Critique Failure |
|--------|-----------------|--------------------------|
| No peer context specified | Surface will feel alien to target users | UE-001 fails, Peer Test fails |
| Output type not identified | Surface tries to do everything, does nothing well | Intent Alignment scores low, scope creep |
| "We'll figure out the details later" | Details become P0 issues during critique | Multiple P1s in first critique cycle |
| Success criteria are vague | No clear stop condition — critique loops exhausted | Escalation after 3 cycles |
| Skipped EIL on new capability | Secondary expectations missed entirely | Expectation debt discovered post-ship |

### Design Signals

| Signal | What It Predicts | Typical Critique Failure |
|--------|-----------------|--------------------------|
| Feature list but no absence detection | Missing expected features discovered late | UE-002 fails, hollow surface |
| No surface role identified | Must-have features for surface type are missing | UE-004 fails, Dead Surface Test fails |
| Building multiple surfaces simultaneously | Cross-surface coherence issues | Gate 8 failures, CS-001/CS-002 violations |
| "Just like [product] but different" | Neither matches peer expectations nor establishes own identity | Peer Test ambiguous, user disorientation |
| Primary flow not defined before secondary | Secondary surfaces built on assumptions about primary | AF-007 fails, flows don't connect |

### Implementation Signals

| Signal | What It Predicts | Typical Critique Failure |
|--------|-----------------|--------------------------|
| New component introduced ("we need a custom X") | Component drift, token violations | Drift Detection flags, VQ-007 fails |
| Tech foundation not active | Persistence/auth/sync decisions made ad-hoc | TF-001 P0, architectural rework |
| "Placeholder for now" on primary action | Completeness audit failure | AF-001 fails, LAW-007 violation |
| Building without truth model entries | Phantom actions, state mismatches | Behavioral Coherence P0 |
| Generic placeholder text left in build | "Lorem ipsum" or "Something went wrong" or "No results found" without specificity | Content Quality Score 2 |
| Unacknowledged design tradeoffs | Competing principles resolved silently without naming the conflict | Tradeoff Evaluation flags P1, critique reveals inconsistent pattern choices |

---

## Success Patterns

These patterns, observed before building, reliably predict high critique scores.

| Pattern | Why It Works |
|---------|-------------|
| Builder can state the output type in one sentence | Intent is clear → Intent Alignment scores high |
| Peer products identified with specific feature comparisons | Expectations are calibrated → UE-001/UE-004 pass |
| Feature classification completed with "Prevented" entries | Restraint was exercised → no scope creep, no bloat |
| Inner Monologue Test answered with confident responses | Surface is well-understood → first critique cycle often passes |
| Truth model entries created before UI work | No phantom actions → Behavioral Coherence passes clean |
| Surface role requirements listed as checklist before building | Must-haves are known → Completeness Audit passes |

---

## Common Traps

Recurring mistakes that experienced builders still fall into.

### The "One More Thing" Trap
> Adding a feature during build that wasn't in the pre-build classification.
**Why it fails:** Unclassified features bypass the Restraint Gate. They're usually Speculative, but feel Helpful in the moment. They often fail critique as incomplete (built quickly, not thoroughly).

### The "Obviously Fine" Trap
> Skipping pre-build for a surface that seems simple.
**Why it fails:** Simple surfaces (settings pages, empty states) have surface role requirements too. Skipping pre-build means missing must-haves that feel invisible until critique catches them.

### The "Matching the Mock" Trap
> Treating a design mockup as the specification.
**Why it fails:** Mockups show one state. Critique checks all states (loading, empty, error, disabled, hover, focus). Mocks also don't specify behavior, permissions, or keyboard interaction.

### The "Sibling Assumption" Trap
> Assuming a new surface will be consistent with existing ones without checking.
**Why it fails:** Each surface is built in its own critique context. Without explicit cross-surface verification (Gate 8), terminology drift and representation inconsistency accumulate silently.

---

## How to Use This File

**Before building:** Scan the Early Warning Signals table. If any match your current situation, address them before starting the build.

**During pre-build (Gate 0):** Use the Success Patterns as a quick checklist — if you can tick most of them, you're well-positioned.

**After a difficult critique:** Check the Common Traps. If one matches, note it here for future builders.

**Updating this file:** Add new patterns when they emerge from critique results. Keep entries observational, not prescriptive. This file teaches pattern recognition, not compliance.
