# Design Tooling Governance

> Framework for selecting, evaluating, and governing design and development tools.

**Scope:** Tools used to design, prototype, implement, and verify the product. Not the product's own tooling (that's tech-foundation.yaml).

---

## Core Principle

> Tool choices are architectural decisions. They constrain what's possible, affect collaboration, and create lock-in. Treat them with the same rigor as tech foundation choices.

---

## Universal Selection Criteria

Every tool selection must evaluate these criteria:

| Criterion | Question | Weight |
|-----------|----------|--------|
| **Output Portability** | Can outputs be used outside this tool? | Critical |
| **Collaboration Model** | How do multiple people work in it? | High |
| **System Compliance** | Can the tool enforce our tokens/components/patterns? | High |
| **AI Compatibility** | Can Claude Code read from / write to it? | High |
| **Learning Curve** | How long until productive? | Medium |
| **Cost Predictability** | Are costs known and bounded? | Medium |
| **Ecosystem Fit** | Does it integrate with our other tools? | Medium |
| **Vendor Risk** | What happens if the tool disappears? | Low (but non-zero) |

### Selection Template
```yaml
tool_evaluation:
  tool_name: "__FILL__"
  category: "__FILL__"  # See categories below
  evaluator: "__FILL__"
  date: "__FILL__"

  criteria:
    output_portability:
      score: __FILL__  # 1-5
      evidence: "__FILL__"
    collaboration_model:
      score: __FILL__
      evidence: "__FILL__"
    system_compliance:
      score: __FILL__
      evidence: "__FILL__"
    ai_compatibility:
      score: __FILL__
      evidence: "__FILL__"
    learning_curve:
      score: __FILL__
      evidence: "__FILL__"
    cost_predictability:
      score: __FILL__
      evidence: "__FILL__"
    ecosystem_fit:
      score: __FILL__
      evidence: "__FILL__"
    vendor_risk:
      score: __FILL__
      evidence: "__FILL__"

  verdict: "adopt | trial | hold | reject"
  rationale: "__FILL__"
  decision_ref: "DEC-__FILL__"  # Link to decision registry
```

---

## Tool Categories

### 1. Visual Design

**Purpose:** Creating visual designs, mockups, high-fidelity screens.
**Examples:** Figma, Sketch, Adobe XD, Penpot

**Category-specific criteria:**
- Can design tokens be enforced as a library?
- Can components be structured as a design system?
- Does it support developer handoff (inspect, export)?

---

### 2. Prototyping

**Purpose:** Interactive prototypes for testing flows and interactions.
**Examples:** Figma prototyping, Framer, ProtoPie, code prototypes

**Category-specific criteria:**
- Can it simulate real interaction patterns?
- Can it use real data?
- Is prototype fidelity sufficient for testing?

---

### 3. Design-to-Code

**Purpose:** Bridging design artifacts to implementation.
**Examples:** Figma Dev Mode, Storybook, Style Dictionary, design token export tools

**Category-specific criteria:**
- Does it preserve token semantics (not just values)?
- Can it generate framework-specific code?
- Does it maintain design-code parity?

---

### 4. Component Development

**Purpose:** Building and documenting UI components.
**Examples:** Storybook, Chromatic, Ladle, custom component playground

**Category-specific criteria:**
- Can components be viewed in isolation?
- Are all states demonstrable?
- Does it integrate with testing?

---

### 5. Visual Testing

**Purpose:** Detecting unintended visual changes.
**Examples:** Chromatic, Percy, Playwright visual comparison, manual screenshot review

**Category-specific criteria:**
- Can it detect sub-pixel changes?
- Does it handle responsive breakpoints?
- Can it compare against approved baselines?

---

### 6. Accessibility Testing

**Purpose:** Verifying accessibility compliance.
**Examples:** axe-core, Lighthouse, WAVE, manual screen reader testing

**Category-specific criteria:**
- Does it cover WCAG AA requirements?
- Can it run in CI/CD?
- Does it catch dynamic accessibility issues (not just static)?

---

### 7. Design Asset Management

**Purpose:** Managing icons, illustrations, images, and other assets.
**Examples:** Figma asset libraries, icon font tools, SVG sprite generators

**Category-specific criteria:**
- Are assets versioned?
- Can the system enforce consistent usage?
- Are assets optimized for web delivery?

---

### 8. Documentation

**Purpose:** Documenting design decisions, patterns, and guidelines.
**Examples:** Notion, Confluence, GitBook, in-repo markdown (this system)

**Category-specific criteria:**
- Is documentation co-located with what it describes?
- Can AI agents read and update it?
- Is versioning built in?

---

## Evaluation Workflow

### When to Evaluate

| Trigger | Action |
|---------|--------|
| New project bootstrapped | Evaluate categories 1–3 minimum |
| Existing tool failing criteria | Re-evaluate that category |
| New tool becomes available | Evaluate against current choice |
| Team size changes | Re-evaluate collaboration model |

### How to Evaluate

1. **Identify category** — Which of the 8 categories?
2. **List candidates** — Maximum 3 candidates per evaluation
3. **Apply universal criteria** — Score 1–5 on each
4. **Apply category criteria** — Additional scoring
5. **Document verdict** — adopt / trial / hold / reject
6. **Register decision** — DEC entry in `_decisions/REGISTRY.md`
7. **Record in tech-foundation** — Update tooling section

### Verdict Definitions

| Verdict | Meaning | Action |
|---------|---------|--------|
| **Adopt** | Use for all new work | Add to tech-foundation.yaml |
| **Trial** | Use for one project/feature to evaluate | Time-boxed, requires review |
| **Hold** | Don't adopt, but don't remove if already used | Document why |
| **Reject** | Do not use | Document why (prevents re-evaluation) |

---

## Tool Stack Documentation

Record active tool choices in `config/tech-foundation.yaml` under the tooling section.

---

## Governance Rules

| Rule | Requirement |
|------|-------------|
| **No silent adoption** | Every tool choice must be documented |
| **Output portability required** | No tool with score <3 on output portability |
| **AI compatibility preferred** | Tools that Claude Code can interact with are preferred |
| **One tool per category** | Avoid parallel tools in same category (single path to power) |
| **Evaluate before adopting** | No new tools without evaluation template |

---

## Anti-Patterns

| Anti-Pattern | Problem | Fix |
|--------------|---------|-----|
| Tool per person | Inconsistent outputs, no system compliance | One tool per category |
| Design tool as source of truth | Drift between design and code | Code is truth; design tools are proposals |
| No evaluation | Tools chosen by familiarity, not fitness | Run evaluation workflow |
| Tool hopping | Constant switching disrupts flow | Evaluate formally, commit deliberately |

---

## Related Files

- `config/tech-foundation.yaml` — Records active tool choices
- `.claude/RUNBOOK.md` — AI agent tool compatibility
- `_quality/QUALITY_PROTOCOL.md` — Tools for testing (categories 5-6)
