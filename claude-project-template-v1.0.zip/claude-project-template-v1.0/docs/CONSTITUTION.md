# Constitution

> Human-readable commentary on `_rules/laws.yaml`. Rule text lives exclusively in laws.yaml — this file provides context and rationale only.

**This file is informational.** The authoritative source is `_rules/laws.yaml`.

---

## Why Laws Exist

Laws prevent the chaos that emerges when AI agents optimize locally without system-wide constraints. They encode hard-won lessons about what makes products coherent.

---

## The Supreme Laws

### LAW-001: User Confidence
*(See `_rules/laws.yaml` for authoritative rule text.)*

Users should never feel lost. Every screen answers: Where am I? What can I do? Why is this happening? How do I leave?

### LAW-002: One Archetype
*(See `_rules/laws.yaml` for authoritative rule text.)*

A screen cannot be both a workspace and a settings page. Mixed purposes create confused interfaces. Pick one.

### LAW-003: Hard Budgets
*(See `_rules/laws.yaml` for authoritative rule text.)*

Complexity creeps. Budgets are the immune system. When you hit the limit, you simplify—you don't expand.

### LAW-004: Mandatory States
*(See `_rules/laws.yaml` for authoritative rule text.)*

The happy path is easy. Quality lives in the edge cases. If you can't show loading, empty, and error states, you're not done.

### LAW-005: Data Accuracy
*(See `_rules/laws.yaml` for authoritative rule text.)*

Numbers don't lie. Client-side calculations are forbidden. Every figure traces to an authoritative source.

### LAW-006: Accessibility
*(See `_rules/laws.yaml` for authoritative rule text.)*

Not optional. Not "nice to have." If someone can't use it with a keyboard, it's broken.

### LAW-007: Affordance Integrity
*(See `_rules/laws.yaml` for authoritative rule text.)*

No dead buttons. No fake links. No decorative chevrons. No hollow CTAs. If it looks clickable, it must work. If it's disabled, it must say why.

### LAW-008: Primary Flow Completion
*(See `_rules/laws.yaml` for authoritative rule text.)*

Happy path must work before edge cases. Core flows before nice-to-have screens. No "coming soon" on primary actions.

### LAW-011: Intent Before Execution
*(See `_rules/laws.yaml` for authoritative rule text.)*

What problem is being solved? What outcome would make this "worth it"? What does "done" look like? Answer before building.

### LAW-012: Bounded Curiosity
*(See `_rules/laws.yaml` for authoritative rule text.)*

**Core Principle:** Any new capability creates expectations; those expectations must be examined before the capability is finalized.

Actively discover what users might expect. Classify features as Expected/Helpful/Speculative/Dangerous/Prevented. Build Expected, consider Helpful, reject Speculative, forbid Dangerous, actively block Prevented. The goal is expectation-complete, not feature-heavy.

**Expectation Invention Loop (EIL):** When introducing new capabilities, run the cascade analysis:
1. Immediate Expectations — What does existence of this capability imply?
2. Secondary Expectations — What do users expect after using it twice? (history, undo, comparison, consistency)
3. Trust Expectations — What must exist so user does not lose confidence? (status, provenance, constraints, errors, definitions)
4. Non-Goals — What must user NOT assume? (explicitly prevented assumptions)
5. Cascade Decision — Classify as Must Build Now / Must Defer / Must Prevent

### LAW-013: Artifact-First Design
*(See `_rules/laws.yaml` for authoritative rule text.)*

**Core Principle:** Define the synthesis artifact (the deliverable) before building features. All product features must serve artifact sections.

**Synthesis Artifact:** A human-readable, professionally presentable representation of the system that accurately reflects decisions, intent, maturity, and constraints — suitable for external delivery without verbal explanation.

**Reverse Engineering Mandate:** For each artifact section, identify what information is required, what decisions must exist, what states must be tracked, and what is currently missing. Features exist to make artifact sections true.

**Quality Bar (The Agency Test):** Would a premium agency ship this artifact to a demanding client? If the artifact requires apology or verbal explanation, the system has failed.

**Artifact Honesty:** Artifacts must show what's decided (not what's hoped), show what's undecided (explicitly), and never present placeholders as decisions.

---

## The Locked Rules

### LAW-009: Replacement Before Addition
*(See `_rules/laws.yaml` for authoritative rule text.)*

Prefer collapse over accumulation. One way to do each thing.

### LAW-010: Negative Capability
*(See `_rules/laws.yaml` for authoritative rule text.)*

Prefer clarity with limits over flexibility with ambiguity. Do not add features solely to reduce theoretical friction.

---

## Why These Laws Are Non-Negotiable

These aren't preferences. They're the minimum bar for professional software:

- Confidence → Users trust the product
- Archetypes → Screens are coherent
- Budgets → Complexity stays controlled
- States → Edge cases work
- Accuracy → Data is reliable
- Accessibility → Everyone can use it
- Affordance Integrity → Everything works
- Primary Flow → Core tasks complete
- Intent → Purpose is clear
- Bounded Curiosity → Surfaces are expectation-complete
- Artifact-First → Outputs are agency-grade

Exceptions require human approval and logging in `_decisions/REGISTRY.md`.
