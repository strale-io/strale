# Data Flow Patterns

> Stack-agnostic shapes for how data moves through screens.

---

## Purpose

Describes the canonical data flow shapes that screens implement. These patterns are independent of technology — they describe **user-perceived** data movement, not implementation architecture.

The editorial guides describe what UI patterns look like. This file describes how data enters, transforms, and exits each screen from the user's perspective.

---

## Data Flow Shapes

### CRUD (Create-Read-Update-Delete)

The fundamental data lifecycle.

```
Trigger → Form → Validate → Persist → Confirm → Updated View
```

| Step | User Sees | Failure Mode |
|------|-----------|-------------|
| Trigger | Button, menu item, or link | Dead affordance (LAW-007) |
| Form | Input fields (see `forms.md`) | Missing required fields |
| Validate | Inline errors on blur/submit | Unclear error messages |
| Persist | Loading state on submit button | Network/server failure |
| Confirm | Toast (success) or alert (error) | No feedback |
| Updated View | Refreshed data reflecting change | Stale data (LAW-005) |

**Rules:**
- Read is the default state — other operations are transitions away from and back to Read
- Create uses minimal fields (progressive disclosure — configure after creation)
- Delete always requires confirmation (see `forms.md` confirmation rules)
- Update should preserve the user's scroll position and context

---

### Search → Filter → Display

Collection refinement from broad to specific.

```
Full Collection → User Query/Filters → Filtered Results → Display
```

| Step | User Sees | Failure Mode |
|------|-----------|-------------|
| Full Collection | All items (default view) | Data dump without structure |
| Query/Filters | Search input, filter controls | Hidden filter state |
| Filtered Results | Subset with count indicator | Ambiguous empty state |
| Display | Table, cards, or list | Wrong view type for data |

**Rules:**
- Filter state persists in URL (shareable, bookmarkable)
- Active filters are always visible as removable chips (see `data-display.md`)
- "Showing X of Y" count always present when filtered
- Filtered-empty is distinct from first-time-empty (different message, different CTA)
- Clear All affordance when any filters are active

---

### Master → Detail

Selection-driven context expansion.

```
Collection (Master) → Selection → Detail View → Back to Collection
```

| Variant | Detail Appears In | Context Preservation |
|---------|-------------------|---------------------|
| Side panel | Drawer or sidebar alongside master | Master remains visible |
| Inline expand | Expanded row within master list | Master rows above/below visible |
| Page navigation | Separate page | Master not visible (breadcrumb back) |

**Rules:**
- Selection state is visible in master (highlighted row, active card)
- Keyboard navigation works between master items (arrow keys)
- Detail can be closed/dismissed to return to master-only view
- Breadcrumb or back link when detail is a separate page

**Choose variant based on:**

| Factor | Side Panel | Inline Expand | Page Navigation |
|--------|-----------|---------------|-----------------|
| Detail complexity | Low-medium | Low | High |
| Switching frequency | High | Medium | Low |
| Mobile support | Collapses to page | Works on mobile | Native to mobile |
| Content width needed | Narrow detail | Full width | Full width |

---

### Wizard (Multi-Step)

Sequential data collection with validation gates.

```
Step 1 → Validate → Step 2 → ... → Summary → Confirm → Done
```

| Element | Required | Rule |
|---------|----------|------|
| Progress indicator | Yes | Show current step, total steps, completed steps |
| Back navigation | Yes | User can return to any completed step |
| Step validation | Yes | Validate before allowing next step |
| Summary step | Yes (if >2 steps) | Show all collected data before final submit |
| Cancel | Yes | With unsaved changes warning if data entered |

**Rules:**
- Each step collects one logical group of information
- Steps are independent where possible (order can vary)
- Validation errors prevent forward navigation but allow backward
- Summary shows all data in read-only format with edit links per section

---

### Real-Time Update

Server-pushed changes that modify the current view.

```
Server Event → Merge With Current State → Re-render Affected Area
```

**Rules:**
- Must not cause layout shift (content jumping)
- Must not interrupt active user input (form field in focus)
- Stale data indicator when connection is lost
- New items arrive at a predictable position (top or bottom, consistently)
- Changed items highlight briefly to draw attention without disrupting scan

---

## Data Flow × Archetype Matrix

| Flow Shape | Overview | Workspace | Detail | Configuration | Transient |
|------------|----------|-----------|--------|---------------|-----------|
| CRUD | Read-heavy | Full CRUD | Read + Update | Read + Update | Create, Delete confirm |
| Search/Filter | Primary | Supporting | Rare | Never | Never |
| Master-Detail | Primary | Primary | N/A | N/A | N/A |
| Wizard | Never | Rare | Rare | Sometimes | Sometimes |
| Real-Time | Sometimes | Often | Sometimes | Never | Never |

---

## Error Recovery by Flow Shape

| Flow | Failure Point | User Sees | Recovery |
|------|--------------|-----------|----------|
| CRUD | Create fails | Toast (error) + form preserved | Retry submit |
| CRUD | Update fails | Toast (error) + rollback change | Retry or discard |
| CRUD | Delete fails | Toast (error) + item remains | Retry delete |
| Search/Filter | Search fails | Alert in results area | Retry search |
| Search/Filter | Filter fails | Filters reset + error toast | Re-apply filters |
| Master-Detail | Detail load fails | Error state in detail panel | Retry or select different |
| Master-Detail | Master load fails | Full-page error | Retry page |
| Wizard | Step save fails | Error on current step | Retry current step |
| Wizard | Final submit fails | Error on summary + all data preserved | Retry submit |
| Real-Time | Connection lost | Stale indicator + last-known data | Auto-reconnect |

---

## Related Files

- `data-display.md` — How filtered/sorted data is displayed (view types, pagination)
- `forms.md` — How data is collected from users (validation, field patterns)
- `structure.md` — Where data flow UI elements sit on screen (zones)
- `composition.md` — How data flows compose with other patterns
- `_ui/states.md` — Loading, empty, error state specifications
- `_model/truth/entities.yaml` — Source data for all flows
- `_model/truth/actions.yaml` — Actions that trigger data flows
