# Navigation Patterns

> How users move through the product.

---

## Primary Navigation

### Sidebar Navigation
- For 5+ top-level sections
- Collapsible on desktop
- Drawer on mobile

### Top Navigation
- For ≤5 sections
- Maximum content width needed

---

## Secondary Navigation

### Tabs
- Parallel content (not sequential)
- Same parent entity
- ≤7 tabs

### Breadcrumbs
- Hierarchy depth ≥2
- Reflect true hierarchy (not URL)
- Current page not clickable

### Back Button
- Mobile interfaces
- Goes to logical parent (not browser history)

---

## Page-Level Patterns

### Master-Detail
- List + detail side by side
- Selecting item shows detail
- For frequent switching

### List → Detail
- Click navigates to detail page
- Back returns to list
- For mobile-first

---

## Navigation States

- Current location always indicated
- Disabled navigation shows tooltip
- Invalid URLs show helpful error

---

## Keyboard Navigation

| Shortcut | Action |
|----------|--------|
| Cmd+K | Command palette |
| Escape | Close/cancel |
| Tab | Focus navigation |
