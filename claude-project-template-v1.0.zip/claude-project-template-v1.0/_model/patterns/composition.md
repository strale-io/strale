# Pattern Composition

> How patterns combine to form complete screens.

---

## Purpose

The editorial guides define individual patterns. This file defines how patterns **compose** — which combinations are natural, which are problematic, and how to resolve tension when patterns compete for the same zone or budget.

---

## Natural Compositions

### Overview + Data Display

Overview archetype typically composes with data display patterns.

| Collection Size | Pattern | Components Used |
|-----------------|---------|-----------------|
| ≤20 items | Card grid | card (×N) + empty_state |
| 20+ items | Table | table + pagination + empty_state |
| Mixed metrics + items | Cards above table | card (×3-4) + table |

**Data flow:** Search → Filter → Display (see `data-flow.md`)

**Surfacing:** Run the Action-Change Test from `SURFACING.md` to decide what appears on each card or table row. Maximum 3-5 Tier 1 items.

---

### Detail + Forms

Detail archetype typically composes with form patterns for editing.

| Edit Scope | Pattern | Trigger |
|-----------|---------|---------|
| Single field | Inline editing | Click/pencil icon on value |
| Multiple fields | Modal form | Edit button in header |
| Full entity | Page-level form | Edit mode toggle |

**Data flow:** CRUD (Read default, Update on edit trigger)

**Tab structure** organizes different data groups within the detail view. Each tab maintains its own scroll position and loading state.

---

### Workspace + Navigation + Data Display

Workspace archetype is the most composition-heavy.

```
┌──────────────────────────────────────────┐
│  HEADER (breadcrumb + primary action)    │
├──────────────────────────────────────────┤
│  TOOLBAR (filters + view switch)         │
├───────────────────────┬──────────────────┤
│  CONTENT              │  SIDEBAR         │
│  (data-display:       │  (detail view    │
│   table or board)     │   or properties) │
└───────────────────────┴──────────────────┘
```

- Navigation patterns (sidebar, tabs, breadcrumbs) provide structure
- Data display patterns fill the Content zone
- Forms appear as transient overlays (modals) or inline editors
- Sidebar shows detail for selected item (master-detail flow)

---

### Configuration + Forms

Configuration archetype composes almost exclusively with form patterns.

```
HEADER
├── Section 1: [input fields]
├── DIVIDER
├── Section 2: [switch toggles — immediate effect]
├── DIVIDER
├── Section 3: [select dropdowns]
└── FOOTER: [Save Changes button — explicit save]
```

**Mixed save behavior:**
- `switch` components save immediately (with `toast` confirmation)
- Text inputs, selects save on explicit "Save Changes" button press
- These two behaviors must be visually and spatially separated

---

## Composition Rules

### Rule 1: One Primary Pattern Per Zone

Each layout zone (header, toolbar, content, sidebar) should implement **one** primary pattern. Stacking filter + form + navigation in a single zone creates cognitive overload.

| Zone | Primary Pattern | Secondary (if any) |
|------|----------------|-------------------|
| Header | Navigation (breadcrumb) | Primary action button |
| Toolbar | Filter/search | View switcher |
| Content | Data display OR form | Never both simultaneously |
| Sidebar | Detail view OR metadata | Never both simultaneously |

---

### Rule 2: Archetype Budgets Are Composition Limits

The archetype's `max_components` budget limits how many patterns can compose on a single screen.

**Example budget check (overview archetype, max 12 components):**

| Element | Components |
|---------|-----------|
| Filter bar | 3 (search input + 2 filter selects) |
| Card grid | 4 (4 metric cards) |
| Table | 1 (table component) |
| Pagination | 1 |
| Primary button | 1 |
| **Total** | **10** (within budget) |

If the total exceeds the budget, simplify. Common cuts:
1. Reduce cards from 4 to 3
2. Move secondary filters to a "More filters" popover (1 trigger instead of 3 filters)
3. Remove view switcher (pick one view)

---

### Rule 3: State Handling Compounds

Each composed pattern brings its own loading, empty, and error states (LAW-004). Composition multiplies the state space.

**Master-Detail state matrix:**

| Master State | Detail State | User Sees |
|-------------|-------------|-----------|
| Loading | — | Skeleton table, no detail panel |
| Loaded | No selection | Table populated, detail panel hidden or empty prompt |
| Loaded | Loading | Table populated, detail panel skeleton |
| Loaded | Loaded | Both populated |
| Loaded | Error | Table populated, detail panel error with retry |
| Error | — | Full content area error |
| Empty | — | Empty state (no items to select) |

**Rule:** Plan the full state matrix before building. Every cell must have a defined user experience.

---

### Rule 4: Navigation Depth Matches Archetype

| Archetype | Max Navigation Depth | Navigation Elements |
|-----------|---------------------|---------------------|
| Overview | 1 (entry point) | Breadcrumb (Home only), tabs for sub-sections |
| Workspace | 2 | Breadcrumb (Home > Section), tabs for views |
| Detail | 3 | Breadcrumb (Home > Section > Entity), tabs for data groups |
| Configuration | 2 | Breadcrumb (Home > Settings), sections via scroll |
| Transient | 0 | Back/close button only |

---

## Anti-Patterns

| Anti-Pattern | Problem | Fix |
|--------------|---------|-----|
| Dashboard-workspace hybrid | Competing archetypes — user doesn't know if they are scanning or working | Pick one archetype. If both needed, make them separate surfaces |
| Table inside table | Nested data display creates visual confusion and keyboard navigation conflict | Use expandable rows or master-detail instead |
| Form inside form | Nested submission creates "which save button?" confusion | Use a single form with sections, or modal for sub-entity creation |
| Navigation inside transient | Modal with sidebar nav is a page pretending to be a modal | If it needs navigation, it is a page, not a modal |
| Competing primary actions | Two primary buttons on screen (violates archetype budget) | One primary, additional as secondary or ghost variants |
| State explosion | Too many composed patterns creating an unmanageable state matrix | Reduce composition or load sections independently |

---

## Composition Decision Template

When designing a new surface, document its composition:

```yaml
composition:
  surface: "SURF-__FILL__"
  archetype: "__FILL__"
  budget_max_components: __FILL__

  zones:
    header:
      pattern: "__FILL__"  # e.g., "breadcrumb + primary action"
      components: __FILL__ # count
    toolbar:
      pattern: "__FILL__"  # e.g., "search + filter" or "none"
      components: __FILL__
    content:
      pattern: "__FILL__"  # e.g., "table with sorting"
      components: __FILL__
    sidebar:
      pattern: "__FILL__"  # e.g., "detail panel" or "none"
      components: __FILL__

  total_components: __FILL__
  within_budget: __FILL__  # true/false

  state_matrix:
    # List all state combinations that need design
    - "__FILL__"

  data_flows:
    # Which flows from data-flow.md apply
    - "__FILL__"
```

---

## Related Files

- `structure.md` — Screen anatomy templates (where zones sit)
- `data-flow.md` — Data flow shapes (how data moves through screens)
- `data-display.md` — Data display patterns (what goes in content zone)
- `forms.md` — Form patterns (what goes in form zones)
- `navigation.md` — Navigation patterns (what goes in header/sidebar)
- `overview.md` — Overview archetype contract (5 questions)
- `SURFACING.md` — Information importance tiers (what data to surface)
- `_quality/archetypes/*.yaml` — Budget constraints per archetype
