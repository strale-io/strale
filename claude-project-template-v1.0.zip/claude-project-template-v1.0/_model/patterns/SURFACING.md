# Information Surfacing Framework

> Deciding what information appears where, at what prominence, and why.

**Purpose:** Prevent two failure modes: (1) surfaces that show everything and help with nothing, and (2) surfaces that hide critical information behind navigation.

---

## Core Principle

> Information should appear where it changes decisions, not where it exists in the data model.

The truth model defines what data exists. This framework defines what data *matters* on each surface.

---

## The Action-Change Test

Before surfacing any piece of information on a screen, apply this test:

> **"If this information changed, would the user do something different on this surface?"**

| Answer | Action |
|--------|--------|
| **Yes, immediately** | Surface prominently (Tier 1) |
| **Yes, eventually** | Surface accessibly (Tier 2) |
| **Maybe, in some cases** | Surface on demand (Tier 3) |
| **No** | Don't surface here (Tier 4 — remove) |

### Action-Change Test Template
```yaml
action_change_test:
  surface: "SURF-__FILL__"
  information: "__FILL__"

  if_changed_would_user:
    do_something_different: "yes | no | sometimes"
    what_would_they_do: "__FILL__"
    how_urgently: "immediately | eventually | maybe"

  tier: __FILL__  # 1-4 based on answers
  surfacing: "__FILL__"  # prominent | accessible | on-demand | remove
```

---

## The 4-Tier Importance Model

### Tier 1: Prominent (Always Visible)

Information that drives immediate decisions on this surface.

| Characteristic | Example |
|----------------|---------|
| Changes user's next action | Error count on dashboard |
| Time-sensitive | Deadline approaching |
| Status-critical | Build failed |
| Primary metric | Revenue this month |

**Rule:** Maximum 3–5 Tier 1 items per surface. More dilutes all of them.

---

### Tier 2: Accessible (Visible Without Navigation)

Information that supports decisions but doesn't demand immediate attention.

| Characteristic | Example |
|----------------|---------|
| Context for Tier 1 items | Trend behind a metric |
| Secondary actions | Edit, share, export |
| Supplementary detail | Created date, owner |
| Comparative data | This week vs last week |

**Rule:** Tier 2 items should be scannable — visible but not competing with Tier 1.

---

### Tier 3: On Demand (Available Via Interaction)

Information that some users sometimes need.

| Characteristic | Example |
|----------------|---------|
| Deep detail | Full audit log |
| Historical | Past versions |
| Configurable | Advanced settings |
| Edge case | Error stack trace |

**Rule:** Tier 3 items behind a clear affordance. User must know they exist without seeing them.

---

### Tier 4: Remove (Not On This Surface)

Information that exists in the data model but doesn't belong here.

| Characteristic | Example |
|----------------|---------|
| No action connection | Internal ID on user-facing screen |
| Duplicate | Same metric shown on parent surface |
| Noise | Debug info in production |
| Wrong audience | Admin data on user screen |

**Rule:** Tier 4 is not "hide." It's "this information belongs on a different surface or nowhere."

---

## Surfacing Audit

Run during Pre-Build for every surface.

### Step 1: Inventory

List every piece of information that *could* appear on this surface (from the truth model):
```yaml
information_inventory:
  surface: "SURF-__FILL__"

  from_entities:
    - entity: "__FILL__"
      attributes:
        - name: "__FILL__"
          tier: __FILL__
          rationale: "__FILL__"

  from_computed:  # Derived values not in truth model
    - name: "__FILL__"
      computed_from: "__FILL__"
      tier: __FILL__
      rationale: "__FILL__"
```

### Step 2: Apply Action-Change Test

For each item, apply the test. Be honest — most information is Tier 3 or 4.

### Step 3: Validate Tier Distribution

| Check | Threshold |
|-------|-----------|
| Tier 1 items | ≤ 5 per surface |
| Tier 1 + Tier 2 | ≤ 15 per surface (above fold) |
| Tier 4 items removed | 100% — no Tier 4 items on surface |

### Step 4: Cross-Surface Consistency

Same information, same tier, same treatment across surfaces — unless the surface role justifies a change.
```yaml
cross_surface_check:
  information: "__FILL__"
  surface_a: "SURF-__FILL__"
  tier_on_a: __FILL__
  surface_b: "SURF-__FILL__"
  tier_on_b: __FILL__
  tier_difference_justified: "__FILL__"  # Why is the tier different?
```

---

## Surfacing Patterns

### Dashboard/Overview

| Tier | Treatment |
|------|-----------|
| 1 | Hero metrics, status indicators |
| 2 | Supporting charts, secondary metrics |
| 3 | Drill-down links, "show more" |
| 4 | Not shown |

### Detail/Record

| Tier | Treatment |
|------|-----------|
| 1 | Header fields, primary status |
| 2 | Tab content, section fields |
| 3 | Expandable sections, audit log |
| 4 | Not shown |

### List/Index

| Tier | Treatment |
|------|-----------|
| 1 | Column data, inline status |
| 2 | Additional columns (desktop), hover detail |
| 3 | Expand row, side panel |
| 4 | Not shown |

### Editor/Workspace

| Tier | Treatment |
|------|-----------|
| 1 | Active content, tool state |
| 2 | Properties panel, toolbar |
| 3 | Settings, advanced options |
| 4 | Not shown |

---

## Anti-Patterns

| Anti-Pattern | Problem | Fix |
|--------------|---------|-----|
| **Data dump** | Show everything, prioritize nothing | Run Action-Change Test, enforce tier limits |
| **Hidden gems** | Critical info buried in Tier 3 | Promote to Tier 1 or 2 |
| **Duplicate surfacing** | Same metric on parent and child surface | Pick one home, link from the other |
| **Stale information** | Surfacing data that rarely changes | Demote to Tier 3 or remove |
| **Information creep** | Surface gains items over time without audit | Re-run Surfacing Audit periodically |
| **Tier inflation** | Everything is "Tier 1" | Enforce maximum 3-5 Tier 1 items |

---

## Severity Levels

| Severity | Condition |
|----------|-----------|
| **P1** | Tier 1 item missing from surface (critical info not surfaced) |
| **P1** | More than 5 Tier 1 items on a surface (dilution) |
| **P2** | Tier 4 item present on surface (noise) |
| **P2** | No Surfacing Audit performed for surface |

---

## Related Files

- `_model/truth/entities.yaml` — Source data for surfacing inventory
- `_model/truth/actions.yaml` — Actions that drive tier decisions
- `_model/patterns/data-display.md` — How surfaced information is displayed
- `_expectations/PRE-BUILD.md` — Surfacing Audit runs during Pre-Build
- `_critique/PROMPT.md` — Information hierarchy scoring
- `_quality/QUALITY_PROTOCOL.md` — Gate 0 surfacing verification
