# Overview Page Pattern

> How to design pages that summarize status across multiple items.

---

## The Contract

Every overview page must help the user answer five questions:

| Question | What It Means |
|----------|---------------|
| **State** | What's the current situation? |
| **Action** | What can I do right now? |
| **Attention** | Where should focus go? |
| **Risk** | What's blocking, at risk, or needs action? |
| **Consequence** | What happens if I do nothing? |

If an overview only shows data without interpretation, it's incomplete.
If an overview shows state but no path forward, it's a dead surface.

---

## Interpretation vs Recommendation

Overview pages should **interpret** without **recommending**.

| Type | Example | Appropriate? |
|------|---------|--------------|
| Interpretation | "Colors is forming; Motion hasn't started" | ✅ Yes |
| Recommendation | "You should work on Colors next" | ❌ No |

World-class tools help users understand. They don't tell users what to do.

**Interpretation provides:**
- Relative progress across items
- Risk or attention signals
- Coherence indicators
- Paths forward (without prescribing which to take)

**Interpretation avoids:**
- Prescriptive next steps
- Urgency language ("fix now!")
- Gamification or nudging

---

## Overview Page Checklist

Before shipping an overview page:

**State & Interpretation:**
- [ ] User can understand current state at a glance
- [ ] Attention naturally flows to what matters
- [ ] Blocked/at-risk items are visually distinct
- [ ] Progress indicators use appropriate type (semantic vs numeric)
- [ ] Only ONE primary signal per item (Signal Hierarchy)
- [ ] Items ordered by significance, not arbitrarily
- [ ] States are disambiguated (not just "pending")

**Action & Forward Motion:**
- [ ] User can move forward from this page
- [ ] At least 2 meaningful actions available
- [ ] Metrics are clickable (drill down to details)
- [ ] Smart CTAs are contextual (not just "Continue")
- [ ] If action blocked, reason is explicit

**Explanation Coverage:**
- [ ] All status indicators have explanation path
- [ ] Progress bars explain what they measure
- [ ] Counts explain composition (X of Y what?)
- [ ] Passes "Explain It to a Client" test

---

## Common Overview Anti-Patterns

| Anti-Pattern | Problem | Fix |
|--------------|---------|-----|
| Data dump | Shows everything, interprets nothing | Add state/attention/risk signals |
| Competing signals | Multiple status indicators per item | Choose one primary signal |
| Flat list | All items equal weight | Order by dependency/priority |
| Ambiguous states | "7 pending" could mean anything | Disambiguate: not started / in progress / blocked |
| Recommendation creep | "You should do X" | Interpret state, don't prescribe action |

---

## Overview Types

| Type | Purpose | Key Trait |
|------|---------|-----------|
| Progress Overview | Track completion across items | Progress states, completion % |
| Status Overview | Understand current state | Semantic states, health indicators |
| Dashboard | Monitor metrics | Numbers, trends, thresholds |
| Index | Navigate to items | Minimal status, focus on access |

Choose the type based on what the user needs to accomplish.

---

## Related Concepts

- **Signal Hierarchy** (`_ui/SYSTEM.md`) — One primary signal per item
- **Semantic vs Progress States** (`_ui/SYSTEM.md`) — When to show meaning vs count
- **Meaningful Ordering** (`_ui/SYSTEM.md`) — Order by significance
- **State Disambiguation** (`_ui/states.md`) — Split ambiguous states
- **Information Surfacing** (`_model/patterns/SURFACING.md`) — What data appears where and at what prominence
