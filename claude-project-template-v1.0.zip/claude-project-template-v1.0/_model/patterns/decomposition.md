# Implementation Task Decomposition Patterns

> Stack-agnostic templates for breaking surface specs into implementation work units.

---

## Purpose

A complete surface spec tells you WHAT to build. This file tells you HOW to break that spec into ordered implementation tasks. Each archetype has a different decomposition because architectures, user intents, and complexity profiles differ.

**This is not a build sequence.** For build sequencing across tiers, see `.claude/BUILD.md`. For artifact mapping, see `_guides/IMPLEMENTATION_MAP.md`.

---

## Universal Decomposition Rules

These apply to all archetypes before the archetype-specific patterns.

### Rule 1: Foundation Before Features

```
1. Layout shell (structural zones, responsive breakpoints)
2. Data layer (types, fetching, state management)
3. Mandatory states (loading, empty, error)
4. Core components (primary content)
5. Interactions (actions, navigation, keyboard)
6. Polish (transitions, edge cases, accessibility audit)
```

### Rule 2: One Concern Per Task

Each task should address one implementation concern. "Build the header with navigation and search and primary action" is three tasks, not one.

### Rule 3: Verify After Each Task

Each task produces something testable. If you can't verify a task independently, it's either too small (merge with another) or too vague (decompose further).

### Rule 4: State First, Happy Path Second

Implement loading/empty/error states BEFORE the happy-path content. This prevents the common failure of building the success case and forgetting mandatory states.

---

## Archetype Decomposition Templates

### Overview Archetype

**Characteristics:** Dashboard-like, multiple data sections, read-heavy, low direct interaction.
**Budget:** __FILL__ decision points, __FILL__ max components (see `_quality/archetypes/overview.yaml`)

```yaml
decomposition:
  phase_1_structure:
    - task: "Layout shell — header, toolbar zone, content grid"
      verifies: "Empty page renders with correct zone structure"
      archetype_ref: "overview.yaml → layouts.recommended"

    - task: "Page title and primary action button in header"
      verifies: "Title visible, primary action positioned per archetype"
      archetype_ref: "overview.yaml → required.navigation"

  phase_2_data:
    - task: "Define data types for entities in scope"
      verifies: "Types match entity model properties"
      source: "_model/truth/entities.yaml"

    - task: "Data fetching layer — one query per independent section"
      verifies: "Each section fetches independently (progressive loading)"
      source: "_surfaces/REGISTRY.yaml → entity_scope.reads"

  phase_3_states:
    - task: "Loading states — skeleton per section matching final layout"
      verifies: "Skeletons render after 100ms delay, match content shapes"
      law: "LAW-004"

    - task: "Empty states — first-time empty with CTA per section"
      verifies: "First-time empty is distinct from no-data sections"
      law: "LAW-004"

    - task: "Error states — section-level error with retry, partial survival"
      verifies: "One section failing doesn't take down other sections"
      exemplar: "error-states-1.md"

  phase_4_content:
    - task: "Metric/summary cards — data display components"
      verifies: "Cards show correct data, use token values for styling"

    - task: "Data tables or lists — with sorting and selection if needed"
      verifies: "Table density matches archetype, columns match entity properties"

    - task: "Filter and search — toolbar controls for data refinement"
      verifies: "Filters produce correct results, active filters visible"

  phase_5_interaction:
    - task: "Navigation — links to detail/workspace surfaces from data items"
      verifies: "Clicking an item navigates to correct detail surface"
      source: "_surfaces/REGISTRY.yaml → exit_points"

    - task: "Primary action — create/add workflow"
      verifies: "Action triggers correct transient or navigates correctly"

    - task: "Keyboard navigation — tab order, focus management"
      verifies: "All interactive elements reachable via keyboard"
      law: "LAW-006"

  phase_6_polish:
    - task: "Transitions — fade-in for loaded content per PHYSICS.md"
      verifies: "Content transitions use correct duration and easing"
      source: "_interaction/PHYSICS.md"

    - task: "Responsive behavior — grid reflow at breakpoints"
      verifies: "Layout adapts at declared breakpoints"
      source: "_model/patterns/structure.md"

    - task: "Accessibility audit — contrast, ARIA, screen reader"
      verifies: "All ACC-* invariants pass"
      source: "_invariants/REGISTRY.md"
```

---

### Workspace Archetype

**Characteristics:** Primary work area, high engagement, extended sessions, keyboard-heavy.
**Budget:** __FILL__ decision points, __FILL__ max components (see `_quality/archetypes/workspace.yaml`)

```yaml
decomposition:
  phase_1_structure:
    - task: "Layout shell — header, optional sidebar, content area"
      verifies: "Sidebar collapses, content area fills remaining space"
      archetype_ref: "workspace.yaml → layouts.recommended"

    - task: "Navigation sidebar — items, active state, collapse behavior"
      verifies: "Active item highlighted, collapse preserves navigation access"
      exemplar: "navigation-1.md"

    - task: "Breadcrumb — entity hierarchy trail"
      verifies: "Breadcrumb reflects entity hierarchy, not URL"
      source: "_expectations/CONTRACTS.md → Orientation Contract"

  phase_2_data:
    - task: "Define data types for primary entity and children"
      verifies: "Types match entity model including state machines"
      source: "_model/truth/entities.yaml"

    - task: "Data fetching — primary list/table query with pagination"
      verifies: "Paginated fetch works, returns expected entity shape"

    - task: "Real-time or polling updates — if applicable"
      verifies: "Data refreshes without full page reload"
      source: "_model/patterns/data-flow.md → real_time_update"

  phase_3_states:
    - task: "Loading state — skeleton table/list matching final columns"
      verifies: "Skeleton has correct column count, row count, shapes"
      exemplar: "loading-states-1.md"

    - task: "Empty state — first-time with onboarding CTA"
      verifies: "First-time shows guidance, filtered-empty is distinct"
      exemplar: "empty-states-1.md"

    - task: "Error state — section error with retry"
      verifies: "Error shows recovery action, doesn't lose context"

  phase_4_content:
    - task: "Primary data display — table or board with entity rows"
      verifies: "Columns match entity properties, correct density"

    - task: "Status badges — entity state rendered as badge component"
      verifies: "Badge variants match declared entity states"

    - task: "Selection — checkbox or multi-select for batch operations"
      verifies: "Selection state persists across pagination"

    - task: "Sorting and filtering — column headers or filter bar"
      verifies: "Sort order persists, active filters visible as tags"
      exemplar: "data-display-3.md"

  phase_5_interaction:
    - task: "Primary action — create new entity (modal or navigation)"
      verifies: "Action opens correct transient/surface, entity created"

    - task: "Row actions — click to detail, context menu for secondary actions"
      verifies: "Row click navigates to detail surface correctly"
      source: "_surfaces/REGISTRY.yaml → exit_points"

    - task: "Inline editing — if applicable per archetype"
      verifies: "Edit mode activates correctly, save/cancel work"
      exemplar: "forms-3.md"

    - task: "Command palette — Cmd+K opens global search/action"
      verifies: "Palette opens, search works, results navigate correctly"
      source: "_primitives/command-palette/SPEC.md"

    - task: "Keyboard shortcuts — per archetype required shortcuts"
      verifies: "All required shortcuts fire correct actions"
      archetype_ref: "workspace.yaml → interactions.keyboard"

  phase_6_polish:
    - task: "Transitions — skeleton to content fade, row hover states"
      verifies: "Timing matches PHYSICS.md budgets"

    - task: "Responsive — sidebar drawer on mobile, content reflow"
      verifies: "Sidebar becomes drawer, table adapts or scrolls horizontally"

    - task: "Focus management — focus restoration after modals/actions"
      verifies: "Focus returns to trigger element after overlay close"
      source: "_interaction/FOCUS.md"

    - task: "Accessibility audit"
      verifies: "Tab order, ARIA roles, contrast, screen reader labels"
```

---

### Detail Archetype

**Characteristics:** Single entity focus, view and edit, medium engagement.
**Budget:** __FILL__ decision points, __FILL__ max components (see `_quality/archetypes/detail.yaml`)

```yaml
decomposition:
  phase_1_structure:
    - task: "Layout shell — header with entity identity, tabbed content area"
      verifies: "Entity name and status visible in header, tabs render"
      archetype_ref: "detail.yaml → layouts.recommended"

    - task: "Back navigation and breadcrumb to parent"
      verifies: "Back button returns to correct parent surface"
      archetype_ref: "detail.yaml → required.navigation"

  phase_2_data:
    - task: "Define types for primary entity with all properties"
      verifies: "Types match entity model including relationships"

    - task: "Single entity fetch — by ID from route parameter"
      verifies: "Entity loads correctly, 404 handles missing entity"

    - task: "Related entities fetch — children/associations"
      verifies: "Related data loads independently from primary entity"

  phase_3_states:
    - task: "Loading state — skeleton matching header + tab layout"
      verifies: "Header skeleton shows entity identity shape, tabs show skeleton"

    - task: "Not found state — 404 with navigation back"
      verifies: "Invalid ID shows not-found with recovery options"
      archetype_ref: "detail.yaml → required.states"

    - task: "Error state — with retry action"
      verifies: "Error preserves URL, retry refetches"

  phase_4_content:
    - task: "Entity header — name, type badge, status, key metadata"
      verifies: "All required identity fields visible"
      archetype_ref: "detail.yaml → required.content"

    - task: "Tab content — each tab as independent content section"
      verifies: "Tabs switch without refetching shared entity data"
      exemplar: "navigation-3.md"

    - task: "Related items display — child entities list or table"
      verifies: "Related items link to their own detail surfaces"

  phase_5_interaction:
    - task: "Edit mode — toggle between view and edit"
      verifies: "Edit activates correctly, cancel discards changes"

    - task: "Entity actions — primary action + secondary menu"
      verifies: "Actions execute correctly, destructive require confirmation"
      law: "LAW-011"

    - task: "Mutation feedback — toast/inline confirmation after save"
      verifies: "Every mutation produces visible feedback"
      law: "LAW-001"

  phase_6_polish:
    - task: "Transitions — tab switch animation, edit mode transition"
      verifies: "Timing per PHYSICS.md"

    - task: "Responsive — tabs adapt (scrollable or dropdown)"
      verifies: "All tabs accessible on narrow viewports"

    - task: "Accessibility audit"
      verifies: "ARIA tab roles, focus management on tab switch"
```

---

### Configuration Archetype

**Characteristics:** Settings and preferences, low frequency, focused intent.
**Budget:** __FILL__ decision points, __FILL__ max components (see `_quality/archetypes/configuration.yaml`)

```yaml
decomposition:
  phase_1_structure:
    - task: "Layout shell — section navigation (sidebar or tabs) + form area"
      verifies: "Sections render, current section indicated"
      archetype_ref: "configuration.yaml → layouts.recommended"

    - task: "Back/escape to main product navigation"
      verifies: "User can return to primary workspace"

  phase_2_data:
    - task: "Define types for all settings with current values"
      verifies: "Types match entity model, include validation rules"

    - task: "Settings fetch — load current values on mount"
      verifies: "All fields populated with current values on load"

  phase_3_states:
    - task: "Loading state — form skeleton matching section layout"
      verifies: "Skeleton shows field shapes, section grouping visible"

    - task: "Unsaved changes indicator — detect changes from initial values"
      verifies: "Indicator appears when any field differs from saved value"
      archetype_ref: "configuration.yaml → required.states"

    - task: "Save feedback — success toast and error handling"
      verifies: "Success shows toast, error preserves edits"
      exemplar: "loading-states-3.md"

  phase_4_content:
    - task: "Section grouping — related settings in labeled groups"
      verifies: "Groups have headers, settings are logically organized"
      exemplar: "forms-2.md"

    - task: "Form controls — correct input type per editor contract"
      verifies: "Boolean → switch, enum → select/radio, string → input"
      source: "_ui/components.yaml → editor_contracts"

    - task: "Help text — descriptions for non-obvious settings"
      verifies: "Descriptions explain consequences, not just labels"

  phase_5_interaction:
    - task: "Save mechanism — explicit button or auto-save with feedback"
      verifies: "Save persists changes, button shows loading state"

    - task: "Cancel/reset — discard changes, confirm if destructive"
      verifies: "Cancel restores saved values, warns if unsaved changes"

    - task: "Mixed save behavior — if applicable (immediate toggles + explicit forms)"
      verifies: "Immediate-save controls update instantly, form sections require explicit save"
      exemplar: "forms-2.md"

  phase_6_polish:
    - task: "Validation — field-level validation with specific messages"
      verifies: "Invalid fields show inline error, form prevents submit"
      exemplar: "error-states-2.md"

    - task: "Responsive — section nav adapts (tabs on mobile)"
      verifies: "All sections accessible on narrow viewports"

    - task: "Accessibility audit — form labels, error association, keyboard"
      verifies: "All form fields have associated labels, errors linked via aria-describedby"
```

---

### Transient Archetype

**Characteristics:** Short-lived overlays (modals, drawers, dialogs), focused single task.
**Budget:** __FILL__ decision points, __FILL__ max components (see `_quality/archetypes/transient.yaml`)

```yaml
decomposition:
  phase_1_structure:
    - task: "Overlay container — modal, drawer, or popover shell"
      verifies: "Overlay renders with backdrop, correct size, z-index"
      archetype_ref: "transient.yaml → layouts.recommended"

    - task: "Title and close button — descriptive title, X button, Escape key"
      verifies: "Title describes the task, close works via button and Escape"
      archetype_ref: "transient.yaml → required.navigation"

  phase_2_data:
    - task: "Define types for the transient's data (create form, confirmation payload)"
      verifies: "Types match entity model for the operation"

    - task: "Pre-fill or context data — if editing or confirming existing entity"
      verifies: "Form pre-populated with correct values, context displayed"

  phase_3_states:
    - task: "Loading state — if transient triggers async operation"
      verifies: "Submit button shows loading, prevents double-submit"
      exemplar: "loading-states-3.md"

    - task: "Error state — if action fails, show error within transient"
      verifies: "Error shows in transient, user can retry or cancel"

  phase_4_content:
    - task: "Form fields or confirmation content — per task purpose"
      verifies: "Fields match entity model, correct input types"
      exemplar: "forms-1.md"

    - task: "Progressive disclosure — if form has optional advanced fields"
      verifies: "Advanced fields hidden by default, expandable"
      source: "_interaction/PROGRESSION.md"

  phase_5_interaction:
    - task: "Primary action — submit, confirm, or create"
      verifies: "Action executes, transient closes, parent surface updates"

    - task: "Cancel — close without action, confirm if unsaved changes"
      verifies: "Cancel closes transient, focus returns to trigger"

    - task: "Focus management — trap focus in transient, restore on close"
      verifies: "Tab cycles within transient, Escape closes, focus returns"
      source: "_interaction/FOCUS.md"

  phase_6_polish:
    - task: "Entry/exit animation — per PHYSICS.md timing"
      verifies: "Open: ease-out 200-300ms, close: ease-in, faster than open"
      source: "_interaction/PHYSICS.md"

    - task: "Validation — inline field validation before submit"
      verifies: "Invalid fields prevent submit, show inline errors"

    - task: "Accessibility — ARIA dialog role, label, description"
      verifies: "role=dialog, aria-labelledby, aria-describedby, focus trapped"
```

---

## Task Sizing Guide

| Task Size | Indicator | Action |
|-----------|-----------|--------|
| Too small | "Add aria-label to save button" | Merge with parent task (accessibility audit) |
| Right size | "Loading states — skeleton per section matching final layout" | One concern, independently verifiable |
| Too large | "Build the entire data table with all features" | Decompose into: structure, columns, sorting, selection, pagination |

---

## Cross-Archetype Composition

When a surface combines archetypes (e.g., workspace with transient create modal), decompose each archetype independently, then add integration tasks:

```yaml
integration_tasks:
  - task: "Trigger connection — workspace action opens transient"
    verifies: "Button click opens modal with correct context"

  - task: "Data refresh — transient completion updates workspace data"
    verifies: "New entity appears in workspace list without full page reload"

  - task: "Focus restoration — closing transient returns focus to workspace trigger"
    verifies: "Focus on the button that opened the modal"
```

---

## Related Files

- `.claude/BUILD.md` — Build sequencing (which step comes when per tier)
- `_guides/IMPLEMENTATION_MAP.md` — Maps artifacts to implementation questions
- `_quality/VERIFICATION.md` — Post-implementation verification checklist
- `_quality/archetypes/*.yaml` — Archetype budgets and requirements
- `_model/patterns/structure.md` — Screen anatomy and zone rules
- `_model/patterns/composition.md` — How patterns compose across archetypes
