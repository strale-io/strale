# Data Display Patterns

> How to present collections and data.

---

## View Types

| View | When |
|------|------|
| List | Scanning, simple data, mobile |
| Table | Comparing, dense data, sorting |
| Board | Workflow stages, status-based |
| Grid | Visual content, browsing |
| Calendar | Date-based data |

---

## Common Patterns

### Filtering
- Show active filters clearly
- One-click removal per filter
- Clear all option
- Persist in URL

### Sorting
- Indicate current sort
- Show direction (↑↓)
- Single-column default

### Pagination
- Page numbers for known totals
- Load more for infinite content
- Show position and total

### Selection
- Single: click to select
- Multi: checkbox + shift-click
- Show count when selected

---

## Empty States

### No Data
- Explain what goes here
- CTA to create first item

### No Results
- Suggest adjusting filters
- Offer to clear filters

---

## Loading States

- Skeleton for known layout
- Spinner for unknown duration
- Keep content during refresh
