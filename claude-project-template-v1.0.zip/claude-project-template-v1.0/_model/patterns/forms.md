# Form Patterns

> How to collect user input.

---

## Form Types

| Type | Pattern |
|------|---------|
| Create | Minimal fields, progressive disclosure |
| Edit | Pre-filled, show what changed |
| Settings | Auto-save or explicit, grouped |
| Search | Apply immediately or with button |

---

## Field Patterns

### Labels
- Top-aligned (default)
- Required marked with asterisk
- Keep labels short

### Validation
- On blur (most fields)
- On change (formatting)
- On submit (cross-field)

### Errors
- Adjacent to field
- Color + icon (not color alone)
- Explain how to fix

---

## Multi-Step Forms

When to use:
- Many fields (>10)
- Logical groupings
- Conditional sections

Rules:
- Show progress
- Allow back navigation
- Validate before proceeding
- Summary before submit

---

## Inline Editing

```
View:  Project Name: Alpha  [✎]
Edit:  [Alpha______] [✓] [✕]
```

- Enter saves, Escape cancels
- Show saving state

---

## Confirmation

Only for:
- Destructive actions
- Irreversible actions
- Significant impact

Never for saves or creates.
