# Screen Structure Patterns

> Stack-agnostic templates for screen anatomy.

---

## Purpose

Defines the reusable zones and layout slots that screens are assembled from. The editorial guides (`navigation.md`, `data-display.md`, `forms.md`) describe **what** to put in each zone. This file describes **where** zones are and how they relate.

---

## Screen Anatomy

Every screen is composed of these zones:

```
┌─────────────────────────────────────────┐
│  HEADER                                 │
│  Title, breadcrumb, primary action      │
├─────────────────────────────────────────┤
│  TOOLBAR (optional)                     │
│  Filters, search, view switchers        │
├──────────────────────┬──────────────────┤
│                      │                  │
│  CONTENT             │  SIDEBAR         │
│  Primary area        │  (optional)      │
│                      │  Supplementary   │
│                      │                  │
├──────────────────────┴──────────────────┤
│  FOOTER (rare)                          │
│  Pagination, status bar                 │
└─────────────────────────────────────────┘
```

### Zone Rules

| Zone | Required | Contains | Constraint |
|------|----------|----------|------------|
| Header | Always (LAW-001) | Title, breadcrumb, primary action | One per screen |
| Toolbar | When content is filterable/sortable | Filters, search, view switches | Only with data display content |
| Content | Always | Primary working area | Exactly one per screen |
| Sidebar | Desktop only | Supplementary info, filters | Collapses to drawer on narrow viewports |
| Footer | Rare | Pagination, persistent status | Only when content is paginated |

---

## Layout Variants by Archetype

### Overview

```
HEADER → TOOLBAR → CONTENT
```

- No sidebar (filters live in toolbar)
- Content is card grid or table
- Footer only if paginated

**Typical content:** Card grid (≤20 items) or table (20+ items). See `data-display.md` for view type selection.

### Workspace

```
HEADER → TOOLBAR → CONTENT + SIDEBAR (optional)
```

- Sidebar collapses on narrow viewports
- Content dominates horizontal space (60-70%)
- Sidebar for properties panel, metadata, related items

**Typical content:** Primary work surface (board, editor, table with inline editing). See `data-display.md` and `forms.md`.

### Detail

```
HEADER → CONTENT (tabbed or scrollable sections)
```

- No toolbar (tabs replace toolbar role)
- Optional sidebar for metadata summary
- Content organized by tabs or scrollable sections

**Typical content:** Entity attributes, related lists, activity timeline. Tabs group by concern (e.g., Overview / Related / Activity).

### Configuration

```
HEADER → CONTENT (grouped sections with dividers)
```

- No toolbar, no sidebar
- Vertical scroll through grouped settings
- Dividers between logical groups

**Typical content:** Form groups separated by `divider`. See `forms.md` for settings patterns.

### Transient

```
TITLE BAR → BODY → FOOTER (actions)
```

- No toolbar, no sidebar
- Constrained height (modal/drawer)
- Footer contains action buttons (primary + cancel)
- Focus trapped within overlay

**Typical content:** Forms, confirmations, lightweight detail views. See `forms.md` for modal form patterns.

---

## Responsive Breakpoint Behaviors

> Navigation-specific responsive behavior (sidebar collapse, drawer behavior) is defined in `navigation.md`. This section covers structural zone behavior only.

### What Collapses

| Element | Wide (≥1024px) | Narrow (<768px) |
|---------|---------------|-----------------|
| Sidebar | Visible panel | Hidden (see `navigation.md` for drawer behavior) |
| Multi-column content | Side by side | Stacked vertically |
| Table columns | All visible | Priority columns only |
| Button groups | Inline | Stacked or overflow menu |

### What Stacks

- Horizontal card grids → vertical card list
- Side-by-side panels → tabbed or stacked sections
- Toolbar + content row → toolbar above content

### What Hides

- Secondary actions → overflow dropdown menu
- Supplementary metadata → collapsed section
- Decorative elements → hidden

### What Persists

- Navigation (sidebar or header nav — always accessible)
- Primary action (always visible)
- Status indicators (always visible)
- Breadcrumb (may truncate, never disappear)

---

## Zone Composition Rules

1. **Header is always present** — LAW-001 requires the user to know where they are and how to escape
2. **One Content Zone per screen** — Multiple content zones create competing focal points
3. **Sidebar and Content share horizontal space** — They never overlap or stack on desktop
4. **Toolbar only with filterable/sortable content** — A toolbar without filters is empty chrome
5. **Footer is pagination or nothing** — Do not use footer for secondary actions (those go in toolbar)
6. **Transient overlays are self-contained** — Modals/drawers have their own title-body-footer structure, independent of the underlying screen

---

## Related Files

- `navigation.md` — What navigation patterns exist (sidebar, tabs, breadcrumbs)
- `data-display.md` — What data display patterns exist (table, card, list)
- `forms.md` — What form patterns exist (create, edit, settings, inline)
- `overview.md` — Overview archetype contract (5 questions every overview answers)
- `SURFACING.md` — Which information appears where (4-tier importance model)
- `_ui/RESPONSIVE.md` — Responsive behavior specifications
- `_quality/archetypes/*.yaml` — Budget constraints per archetype
