# Implementation Translation Guide

> From governance artifacts to implementation decisions. A reference map, not a tutorial.

---

## Purpose

After completing the governance process, you have artifacts scattered across 15+ files. Each answers specific implementation questions. This guide maps **artifact → question answered** so you know where to look when building.

**This is not a build sequence.** For build sequencing, see `.claude/BUILD.md`. For session workflow, see `.claude/PROTOCOL.md`.

---

## The Map

### Your Surface Spec Tells You...

**Source:** `_surfaces/REGISTRY.yaml` (your project's instance) | **Template:** `_examples/REGISTRY.example.yaml`

| Artifact Field | Implementation Question |
|---------------|------------------------|
| `archetype` | What layout structure does this screen use? (See `_quality/archetypes/{archetype}.yaml`) |
| `entity_scope` | What data does this screen read and write? |
| `entry_points` | Where can users arrive from? What context do they carry? |
| `exit_points` | Where can users go next? What navigation must exist? |
| `primary_actions` | What is the single most prominent interactive element? |
| `secondary_actions` | What additional actions appear (within budget)? |
| `shared_vocabulary` | What labels/terms must be consistent across surfaces? |

**Implementation implication:** Your top-level component structure, data fetching boundaries, and route definitions derive from this file.

```yaml
# Example: reading a surface spec for implementation
surface: __FILL__                     # Your surface ID
archetype: __FILL__                   # Determines layout shell, budget limits
entity_scope:
  reads: [__FILL__]                   # Data fetching requirements
  writes: [__FILL__]                  # Mutation endpoints needed
entry_points:
  - from: __FILL__                    # Route guards, back-navigation targets
exit_points:
  - to: __FILL__                      # Link/navigation component targets
```

---

### Your Entity Model Tells You...

**Source:** `_model/truth/entities.yaml` (your project's instance) | **Template:** `_examples/README.md`

| Artifact Field | Implementation Question |
|---------------|------------------------|
| Entity properties | What fields exist on each data type? |
| Required vs optional | Which fields need validation rules? |
| Relationships (parent→child) | How are API endpoints and queries structured? |
| State machines | What status transitions are legal? What UI states must exist? |
| Cardinality | Is this 1:1, 1:many, many:many? How does the UI render multiplicity? |

**Implementation implication:** Your data models/types, API contracts, form field lists, validation logic, and state management shape derive from this file.

```yaml
# Example: translating entity model to implementation
entity: __FILL__
properties:
  - name: __FILL__
    type: __FILL__
    required: __FILL__                # → form validation rule
    # Implementation: field type determines input component (see editor contracts in components.yaml)
states:
  - __FILL__ → __FILL__              # → conditional rendering, button enable/disable logic
  # Implementation: state machine becomes status badge variants + action availability
```

---

### Your Token Mapping Tells You...

**Source:** `_ui/tokens.yaml` (your project's instance)

| Token Category | Implementation Question |
|---------------|------------------------|
| `color` | What are the exact color values for backgrounds, text, borders, states? |
| `typography` | What font sizes, weights, line heights apply at each level? |
| `spacing` | What are the padding/margin/gap values at each scale step? |
| `border` + `radius` | What border widths and corner radii apply to each component type? |
| `shadow` | What elevation levels exist? Which components use which? |
| `motion` | What transition durations and easings apply? (Cross-ref `_interaction/PHYSICS.md`) |
| `z_index` | What stacking order resolves overlapping elements? |

**Implementation implication:** Every hardcoded pixel value, color hex, or timing constant in your code should trace to a token. If it doesn't, it's either missing from the token file or violating the token system.

```yaml
# Example: token to CSS/style implementation
# Token path                          # Implementation
colors.background.base                # → body/page background
colors.text.default                   # → default text color
spacing.scale.4                       # → standard padding/gap value
borders.radii.lg                      # → card corner radius
transitions.presets.hover             # → hover state transition
```

---

### Your Interaction Laws Tell You...

**Source:** `_rules/laws.yaml`

| Law | Implementation Question |
|-----|------------------------|
| LAW-001 (User Confidence) | Does every state change have visible feedback? |
| LAW-002 (One Archetype) | Does this screen follow exactly one layout pattern? |
| LAW-003 (Hard Budgets) | Are decision points and component counts within archetype limits? |
| LAW-004 (Mandatory States) | Does every async operation handle loading, empty, and error? |
| LAW-005 (Data Accuracy) | Does displayed data match the source? No stale cache shown as current? |
| LAW-006 (Accessibility) | Does it meet WCAG 2.1 AA? Keyboard navigable? Screen reader compatible? |
| LAW-007 (Affordance Integrity) | Does everything that looks clickable work? Nothing interactive looks static? |
| LAW-008 (Primary Flow Completion) | Can the user complete the main task without dead ends? |
| LAW-011 (Intent Before Execution) | Do destructive actions require confirmation? |

**Implementation implication:** These are not aspirational — they are implementation requirements. Each law maps to specific code patterns:

- LAW-001 → Toast/alert after mutations, optimistic UI with rollback
- LAW-004 → Loading/empty/error components for every data-fetching boundary
- LAW-006 → ARIA attributes, focus management, keyboard handlers
- LAW-007 → Cursor styles, disabled states, interactive element semantics
- LAW-011 → Confirmation modals before delete/destructive operations

---

### Your Archetype Budget Tells You...

**Source:** `_quality/archetypes/{archetype}.yaml`

| Budget Field | Implementation Question |
|-------------|------------------------|
| `max_decision_points` | How many interactive choices can this screen present? |
| `max_components` | What is the component count ceiling? |
| `primary_actions` (count) | How many primary buttons/CTAs are allowed? |
| `secondary_actions` (count) | How many secondary actions can appear? |
| `required_patterns` | What patterns must be present regardless of features? |
| `forbidden_patterns` | What patterns must never appear on this archetype? |

**Implementation implication:** Budgets are ceilings, not targets. If your component tree exceeds the max, you must split the surface or remove components — not increase the budget.

```yaml
# Archetype budget → component tree audit
archetype: __FILL__
budget:
  max_decision_points: __FILL__       # Count: buttons + links + toggles + selects
  max_components: __FILL__            # Count: unique component instances
  primary_actions: __FILL__           # Count: primary-variant buttons (usually 1)
  secondary_actions: __FILL__         # Count: secondary-variant buttons
# If over budget → simplify, don't rationalize
```

---

### Your Invariants Tell You...

**Source:** `_invariants/REGISTRY.md`

| Invariant Category | Implementation Question |
|-------------------|------------------------|
| Identity (ID-001–005) | How are entity IDs generated, stored, and referenced? |
| Hierarchy (HIE-001–005) | How do parent-child relationships enforce structural rules? |
| State (ST-001–005) | How are entity state machines implemented? Can invalid transitions occur? |
| UI (UI-*) | What UI behaviors must never break? |
| Feedback (FB-*) | What feedback patterns must always fire? |
| Accessibility (A11Y-*) | What accessibility behaviors are non-negotiable? |

**Implementation implication:** Invariants are test cases. Every invariant in the registry should map to at least one automated test. If an invariant can't be tested, it can't be enforced.

```yaml
# Example: invariant to test mapping
invariant: ST-002                     # "Transitions are explicit"
test: __FILL__                        # → test that invalid state transitions throw errors
# Implementation: state machine library or reducer that rejects undeclared transitions
```

---

### Your User Contracts Tell You...

**Source:** `_expectations/CONTRACTS.md`

| Contract | Implementation Question |
|----------|------------------------|
| Orientation | Does the screen show location context (breadcrumbs, nav state, title)? |
| Action | Are available actions visible and discoverable? |
| Information | Is the displayed information complete for the user's task? |
| Feedback | Does every user action produce visible confirmation? |
| Prediction | Can users anticipate what will happen before they act? |
| Continuity | Does the screen remember user context (scroll position, selections, filters)? |
| Completion | Does the user know when their task is done? |

**Implementation implication:** Contracts are UX requirements that translate to specific component choices. Orientation → breadcrumb + nav highlight. Feedback → toast after mutations. Continuity → persist filter state to URL or local storage.

---

### Your Component Registry Tells You...

**Source:** `_ui/components.yaml`

| Registry Field | Implementation Question |
|---------------|------------------------|
| Component variants | Which visual variant does this use case need? |
| Sizes | What size is appropriate for the context? |
| Editor contracts | Which input component matches this data type? |
| DO NOT FORK list | Which components must use the registered implementation, never custom? |

**Implementation implication:** The component registry is the closed-world authority for UI elements. If a component isn't registered, it doesn't exist in your system. If you need something not in the registry, submit a governance proposal — don't improvise.

```yaml
# Example: editor contract → input component
value_type: __FILL__                  # From entity model
# Editor contract mapping (from components.yaml):
#   string        → input (variant: default)
#   long_text     → textarea
#   enum          → select | radio (≤4 options → radio, >4 → select)
#   boolean       → switch | checkbox
#   date          → input (variant: date)
#   number        → input (variant: number, with optional stepper)
```

---

### Your Interaction Specs Tell You...

**Source:** `_interaction/PHYSICS.md`, `_interaction/FOCUS.md`, `_interaction/CHOREOGRAPHY.md`, `_interaction/PROGRESSION.md`

| File | Implementation Question |
|------|------------------------|
| `PHYSICS.md` | What transition durations and easings apply to each animation category? |
| `FOCUS.md` | How does keyboard focus move? What is the focus order? Where does focus trap? |
| `CHOREOGRAPHY.md` | How do multiple elements animate together? What is the sequence? |
| `PROGRESSION.md` | How does progressive disclosure unfold? What reveals when? |

**Implementation implication:** Motion is functional, not decorative. Every animation needs a timing budget from PHYSICS.md and must respect `prefers-reduced-motion`. Focus management (FOCUS.md) is critical for modals, drawers, dropdowns, and command palettes.

---

### Your States Spec Tells You...

**Source:** `_ui/states.md`

| State | Implementation Question |
|-------|------------------------|
| Skeleton loading | What does the loading placeholder look like? (Must match final layout) |
| Spinner loading | When does a spinner appear instead of skeleton? (After 300ms) |
| First-time empty | What does the screen show when the user has no data yet? |
| Filtered empty | What does the screen show when filters produce zero results? |
| Inline error | How do field-level errors display? |
| Section error | How does a partial failure display while other sections succeed? |
| Full-page error | What recovery options exist? |

**Implementation implication:** Every data-fetching boundary needs three sibling components: loading, empty, and error. These are not optional. LAW-004 requires all three for every async operation.

---

### Your Tech Foundation Tells You...

**Source:** `config/tech-foundation.yaml`

| Foundation Field | Implementation Question |
|-----------------|------------------------|
| `stack.runtime` | What runtime and framework version? |
| `stack.ui_framework` | What component library/framework? |
| `stack.styling` | How are styles applied? (CSS modules, Tailwind, styled-components, etc.) |
| `stack.state_management` | What state library? How is state shaped? |
| `non_goals_v1` | What features are explicitly out of scope? |

**Implementation implication:** This file prevents accidental architecture. If it says `status: template`, no foundational implementation work should proceed. Fill it first.

---

## Cross-Reference Quick Lookup

When implementing a specific concern, check these files:

| Implementation Concern | Primary Source | Cross-Reference |
|----------------------|---------------|-----------------|
| **Layout structure** | `_quality/archetypes/*.yaml` | `_model/patterns/structure.md` |
| **Data fetching** | `_surfaces/REGISTRY.yaml` (entity_scope) | `_model/truth/entities.yaml` |
| **Form fields** | `_ui/components.yaml` (editor contracts) | `_model/truth/entities.yaml` (properties) |
| **Navigation** | `_surfaces/REGISTRY.yaml` (entry/exit points) | `_model/patterns/navigation.md` |
| **Loading/empty/error** | `_ui/states.md` | `_quality/exemplars/loading-states-*.md` |
| **Keyboard behavior** | `_interaction/FOCUS.md` | `_primitives/*/SPEC.md` |
| **Animation** | `_interaction/PHYSICS.md` | `_interaction/CHOREOGRAPHY.md` |
| **Color/spacing/type** | `_ui/tokens.yaml` | `_ui/components.yaml` (component tokens) |
| **State machines** | `_model/truth/entities.yaml` | `_invariants/REGISTRY.md` (ST-*) |
| **Accessibility** | `_invariants/REGISTRY.md` (A11Y-*) | `_rules/laws.yaml` (LAW-006) |
| **Validation** | `_model/truth/entities.yaml` (required) | `_expectations/CONTRACTS.md` |
| **Budget compliance** | `_quality/archetypes/*.yaml` | `_rules/laws.yaml` (LAW-003) |

---

## Reading Order for Implementation

If you're about to implement a surface, read these files in this order:

1. **`config/tech-foundation.yaml`** — Confirm status is `active` and stack is declared
2. **`_surfaces/REGISTRY.yaml`** — Find your surface, note archetype and entity scope
3. **`_quality/archetypes/{archetype}.yaml`** — Load budget constraints
4. **`_model/truth/entities.yaml`** — Understand data shape for entities in scope
5. **`_ui/components.yaml`** — Identify which components you'll compose
6. **`_ui/tokens.yaml`** — Load the values you'll use for styling
7. **`_ui/states.md`** — Understand mandatory loading/empty/error patterns
8. **`_rules/laws.yaml`** — Review laws relevant to your surface type
9. **`_invariants/REGISTRY.md`** — Note invariants that apply to your entities
10. **`_interaction/FOCUS.md`** — Plan keyboard behavior for interactive elements

**Not every implementation needs all 10.** A simple component change may only need items 5-6. A new surface needs all of them.

---

## Related Files

- `.claude/BUILD.md` — Build sequencing (what step comes when)
- `.claude/PROTOCOL.md` — Session management (how to log decisions)
- `_guides/ONBOARDING.md` — Setting up governance artifacts (precedes this guide)
- `_guides/LIGHTWEIGHT_PATH.md` — Fast path for small changes
- `_quality/VERIFICATION.md` — Post-implementation verification (complements this guide)
