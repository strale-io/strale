# Onboarding Walkthrough

> From "opened starter kit" to "complete surface specification" in 5 steps.

---

## Prerequisites

- Starter kit files are in your project repository
- You have read `SYSTEM_CONTRACT.md` (system rules) and `README.md` (directory map)
- `config/manifest.yaml` has your product name and class filled in

---

## The Path

| Step | What You Produce | File |
|------|-----------------|------|
| 1. Register Entities | Populated entity registry | `_model/truth/entities.yaml` |
| 2. Register Surfaces | Surface entries with archetypes | `_surfaces/REGISTRY.yaml` |
| 3. Load Archetype Constraints | Budget awareness per surface | `_quality/archetypes/*.yaml` |
| 4. Run Pre-Build | Intent model + outcome declaration | `_expectations/PRE-BUILD.md` |
| 5. Run Critique | Passing scorecard | `_critique/LOOP.md` |

---

## Step 1: Register Your Entities

**File to edit:** `_model/truth/entities.yaml`

### What This Is

The truth model is the canonical list of business objects in your product. Every entity that appears in your UI — every thing a user can create, view, edit, or delete — gets an entry here. The system uses this registry to validate that surfaces reference real entities, not invented ones.

### What to Do

1. Open `_model/truth/entities.yaml`
2. For each business object in your product, create an entry
3. Fill in: name, description, properties (with types), relationships to other entities

### Template

```yaml
__FILL_ENTITY_NAME__:
  description: "__FILL__"
  properties:
    - name: "__FILL__"
      type: "__FILL__"  # string | number | boolean | enum | date | reference
      required: true
  relationships:
    belongs_to: "__FILL__"  # Parent entity, if any
    has_many: []            # Child entities, if any
  states:
    - "__FILL__"            # e.g., draft → active → archived
```

### Example (Beacon — OKR Tool)

```yaml
Objective:
  description: "A team-level goal for a planning cycle"
  properties:
    - name: title
      type: string
      required: true
    - name: status
      type: enum
      values: [draft, active, at_risk, completed, archived]
    - name: health
      type: enum
      values: [on_track, behind, at_risk]
    - name: owner
      type: reference
      target: User
  relationships:
    belongs_to: Team
    has_many: [KeyResult, CheckIn, Comment]
  states:
    - draft → active → at_risk → completed → archived
```

### Checklist

- [ ] Every business object in your product has an entry
- [ ] Every property has a type declared
- [ ] Relationships between entities are bidirectional (if A belongs_to B, B has_many A)
- [ ] Entity names match what appears in your UI copy
- [ ] State machines are defined for entities that change status

### Common Mistakes

- **Modeling UI components as entities** — Entities are business objects (Project, Task, User), not UI (Sidebar, Modal, Card)
- **Forgetting relationship direction** — If Objective belongs_to Team, then Team has_many Objectives
- **Using internal names** — Entity names must match what users see. If users say "Goal" not "Objective," register it as "Goal"

---

## Step 2: Register Your Surfaces

**File to edit:** `_surfaces/REGISTRY.yaml`
**Reference example:** `_examples/REGISTRY.example.yaml`

### What This Is

The surface registry is the authoritative list of screens in your product. Every page, modal, and panel that a user can see gets an entry. This registry enforces navigation consistency, vocabulary alignment, and archetype compliance.

### What to Do

1. Open `_surfaces/REGISTRY.yaml`
2. For each screen/page/modal in your product, create an entry
3. Fill in: id, name, archetype, path, entities, actions, states
4. Map navigation relationships (sources → targets must be bidirectional)

### Archetype Quick Reference

| Archetype | Use For | Budget File |
|-----------|---------|-------------|
| overview | Dashboards, lists, summaries | `_quality/archetypes/overview.yaml` |
| workspace | Primary work areas, boards | `_quality/archetypes/workspace.yaml` |
| detail | Single-entity deep views | `_quality/archetypes/detail.yaml` |
| configuration | Settings pages | `_quality/archetypes/configuration.yaml` |
| transient | Modals, drawers, popovers | `_quality/archetypes/transient.yaml` |

**Rule (LAW-002):** Every screen has exactly one archetype.

### Template

```yaml
- id: SURF-__FILL__
  name: "__FILL__"
  archetype: __FILL__  # overview | workspace | detail | configuration | transient
  path: "__FILL__"     # URL path, or null for transient
  description: "__FILL__"

  entities:
    - __FILL__         # Must exist in entities.yaml

  actions:
    - __FILL__         # Must exist in actions.yaml

  states:
    - __FILL__         # entity.state format

  navigation_sources:
    - SURF-__FILL__    # Which surfaces link TO this one

  navigation_targets:
    - SURF-__FILL__    # Which surfaces this one links TO

  shared_vocabulary:
    - "__FILL__"       # Terms that must match across surfaces

  status: __FILL__     # planned | active | deprecated
```

### Example (Beacon)

```yaml
- id: SURF-001
  name: Strategy Dashboard
  archetype: overview
  path: /
  description: "Company-wide view of OKR health and team performance."
  entities: [Organization, Team, Objective, Cycle]
  actions: [filter_by_team, filter_by_cycle, navigate_to_objective]
  states: [objective.active, objective.at_risk, cycle.active]
  navigation_sources: [SURF-002, SURF-003, SURF-004]
  navigation_targets: [SURF-002, SURF-003, SURF-004]
  shared_vocabulary: ["on track", "at risk", "objective", "key result"]
  status: active
```

### Checklist

- [ ] Every screen has an archetype declared
- [ ] Navigation is bidirectional (if A links to B, B's sources include A)
- [ ] `shared_vocabulary` is populated for terms used across surfaces
- [ ] Every entity reference resolves to `_model/truth/entities.yaml`
- [ ] Transient surfaces have `path: null`

### Common Mistakes

- **Assigning two archetypes** — A settings page that also shows a dashboard is a design smell. Pick one
- **One-directional navigation** — If SURF-002 targets SURF-003, then SURF-003's sources must include SURF-002
- **Forgetting transient surfaces** — Modals and drawers are surfaces too. Register them

---

## Step 3: Load Archetype Constraints

**Files to read:** `_quality/archetypes/__FILL__.yaml` (one per archetype used in Step 2)

### What This Is

Archetypes define budgets and constraints for each screen type. Before building, you must know the limits. Exceeding an archetype budget requires a Decision entry in `_decisions/REGISTRY.md`.

### What to Do

1. For each surface in your registry, open its archetype file
2. Note the budgets (decision_points, max_components, max_primary_actions, max_secondary_actions)
3. Note required elements (navigation, states, data)
4. Compare your planned screen against these constraints **before building**

### Key Budgets

| Archetype | Decision Points | Max Components | Primary Actions | Secondary Actions |
|-----------|----------------|----------------|-----------------|-------------------|
| overview | 8 | 12 | 1 | 4 |
| workspace | 12 | 20 | 2 | 6 |
| detail | 6 | 15 | 1 | 4 |
| configuration | 4 | 10 | 1 | 2 |
| transient | 2 | 6 | 1 | 1 |

### Required States (All Archetypes)

Every surface must handle (LAW-004):
- **Loading** — Skeleton for known layout, spinner for unknown
- **Empty** — First-time vs filtered (different messages, different CTAs)
- **Error** — With retry affordance and escape route

### Checklist

- [ ] Each surface has been checked against its archetype budgets
- [ ] Required navigation elements are planned
- [ ] All three states (loading, empty, error) are planned per surface
- [ ] No surface exceeds its decision point budget

---

## Step 4: Run Pre-Build

**File to follow:** `_expectations/PRE-BUILD.md`
**Build tier reference:** `.claude/BUILD.md` Section 3

### What This Is

Pre-build is the quality gate before any building begins. It forces you to define what you are building, why, and how you will know it is done — before writing a single line.

### What to Do (Minimum Viable — Standard Builds)

Write this for your first surface:

```yaml
pre_build:
  intent:
    problem: "__FILL__"           # What problem are we solving?
    output_type: "__FILL__"       # Decision Surface | Data Display | Export | Narrative
    scope_in: "__FILL__"          # What is included
    scope_out: "__FILL__"         # What is explicitly excluded
    success: "__FILL__"           # Done looks like...
  completeness_target: "__FILL__" # Full | Scoped | Foundation
  outcome:
    before: "__FILL__"            # User state before this surface exists
    after: "__FILL__"             # User state after this surface exists
```

### What to Do (Full — Complex Builds)

For new screens or multi-surface features, follow the complete Pre-Build Exploration Flow in `_expectations/PRE-BUILD.md`. This includes:

- Spec interrogation with falsifiable assumptions
- Screen Intent Declaration (role, primary UI object, dominance)
- IA Position Declaration (parent, siblings, children, depth)
- Outcome Declaration with User State Model

### Example (Beacon — OKR Board)

```yaml
pre_build:
  intent:
    problem: "Team leads need a single view to manage objectives and track key results"
    output_type: "Decision Surface"
    scope_in: "Objective CRUD, KR progress tracking, cycle switching"
    scope_out: "Check-in flow (separate transient), team settings, analytics"
    success: "User can create objectives, add key results, update progress, and switch cycles"
  completeness_target: "Scoped"
  outcome:
    before: "Team lead has no centralized view of objectives; tracks in spreadsheets"
    after: "Team lead sees all objectives and KR progress in one workspace surface"
```

### Checklist

- [ ] Intent model completed (problem, output type, scope, success)
- [ ] Completeness target set
- [ ] Outcome declaration written (at minimum: before/after)
- [ ] If new capability: EIL triggered per `_expectations/PRE-BUILD.md`

---

## Step 5: Run Critique

**File to follow:** `_critique/LOOP.md`
**Prompt to use:** `_critique/PROMPT.md`
**Calibration:** `_critique/CALIBRATION.md`

### What This Is

The critique loop is the mandatory quality iteration protocol. It scores your build against 14 dimensions and requires fixes for critical issues before shipping.

### The Loop

```
BUILD → CRITIQUE → PATCH → VERIFY → (repeat max 3x) → SHIP or ESCALATE
```

### What to Do

1. Complete your build
2. Run critique using `_critique/PROMPT.md` as the scoring template
3. Score all dimensions using calibration from `_critique/CALIBRATION.md`
4. Fix P0 issues first, then up to 3 P1 issues per cycle
5. Verify fixes and check for side effects
6. Evaluate stop conditions: P0=0, P1≤2, all dimension scores ≥4
7. Ship when passing. Escalate after 3 failed cycles (RULE-031)

### Single-Cycle Mode (Quick Builds)

For Micro/Targeted tasks where only one critique cycle is available, use the reduced protocol in `_critique/LOOP.md` Single-Cycle Mode. This uses a must-pass floor (correctness=5, no dead affordances, token compliance, AA contrast) with degraded tracking for dimensions that normally require iteration.

### Stop Conditions

| Condition | Threshold |
|-----------|-----------|
| P0 issues | 0 |
| P1 issues | ≤ 2 |
| All dimension scores | ≥ 4 (correctness must be 5) |
| Max cycles | 3 (then escalate) |

### Checklist

- [ ] All dimensions scored using `_critique/PROMPT.md`
- [ ] P0 count is 0
- [ ] P1 count is ≤ 2
- [ ] Correctness score is 5
- [ ] Surprise test completed (per `_critique/LOOP.md`)

---

## What's Next

After completing your first surface through this walkthrough:

| Next Step | Where |
|-----------|-------|
| Build more surfaces | Repeat Steps 2-5 for each surface |
| Set up full workflow | `.claude/PROTOCOL.md` Bootstrap Mode |
| Explore design options | `_modes/explore.md` |
| Calibrate quality taste | `_quality/exemplars/` |
| Understand build tiers | `.claude/BUILD.md` Section 1-2 |
| Use the lightweight path | `_guides/LIGHTWEIGHT_PATH.md` |
