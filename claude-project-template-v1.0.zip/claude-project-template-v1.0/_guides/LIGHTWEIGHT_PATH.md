# Lightweight Build Path

> The fastest complete path through the system. Not a shortcut — a documented fast lane.

---

## When This Applies

Use this path when **all** of the following are true:

| Condition | Source |
|-----------|--------|
| Task classified as Micro or Targeted | `.claude/BUILD.md` Section 1 |
| Session mode is Quick | `.claude/PROTOCOL.md` Session Modes |
| No design decisions needed | Classification signal |
| 1-2 files touched | Classification signal |
| Under 2 hours estimated | Classification signal |

If **any** condition is false, use the Standard or Complex path in `.claude/BUILD.md`.

---

## The Path

```
Quick Session Start         .claude/PROTOCOL.md Quick Session Protocol
  │  Declare intent, connectivity check, read handoff
  ▼
Classify Task               .claude/BUILD.md Section 1
  │  Micro (0 decisions, 1-2 files) or Targeted (0-1 decisions, 2-5 files)
  ▼
Build Path                  .claude/BUILD.md Section 2
  │  Micro: LOAD → CHECK → BUILD → VERIFY → DONE
  │  Targeted: LOAD → LAWS → CONTEXT → BUILD → SPOT-CHECK → DONE
  ▼
Optional: Single-Cycle      _critique/LOOP.md Single-Cycle Mode
  │  Only when the change touches a visible screen
  ▼
Quick Session End           .claude/PROTOCOL.md Quick Session Protocol
     Handoff file, Linear update, Journal one-liner
```

---

## Step-by-Step

### 1. Quick Session Start

**Reference:** `.claude/PROTOCOL.md` Quick Session Protocol

1. Declare session intent: `Intent: [one sentence]`
2. Connectivity check: Git + handoff folder (Notion/Linear if needed)
3. Read `handoff/from-chat/` for pending items
4. Check relevant Linear issue

### 2. Classify the Task

**Reference:** `.claude/BUILD.md` Section 1

| Signal | Micro | Targeted |
|--------|-------|----------|
| Files touched | 1-2 | 2-5 |
| Design decisions | 0 | 0-1 |
| New UI surfaces | 0 | 0 |
| Estimated time | <30min | 30min-2hr |
| Example | Typo fix, config tweak | Bug fix, style adjustment |

### 3. Follow Build Path

**Reference:** `.claude/BUILD.md` Section 2

**Micro** (fastest possible):
1. **LOAD** — RUNBOOK.md context loading (quick fix row)
2. **CHECK** — Scan `_rules/laws.yaml` for relevant constraints
3. **BUILD** — Make the change
4. **VERIFY** — Does it work? Any regressions?
5. **DONE** — Commit, update Linear if applicable

No pre-build. No critique. No exploration.

**Targeted** (slightly more context):
1. **LOAD** — RUNBOOK.md context loading + check `handoff/from-chat/`
2. **LAWS** — Identify applicable constraints in `_rules/laws.yaml`
3. **CONTEXT** — If UI: load `_ui/tokens.yaml`, `_ui/states.md`, relevant component. If logic: load relevant truth model files
4. **BUILD** — Make the change
5. **SPOT-CHECK** — Does it respect loaded constraints? If visual: compare before/after. If behavioral: test the flow
6. **DONE** — Commit, update Linear

No formal pre-build. No full critique loop. Spot-check replaces critique.

### 4. Optional: Single-Cycle Critique

**Reference:** `_critique/LOOP.md` Single-Cycle Mode

**When:** The change touches a visible screen and you have time for one cycle.

Single-Cycle Mode is **not** skipping critique. It has strict requirements:

**Must-pass (non-negotiable):**

| Check | Requirement |
|-------|-------------|
| Correctness | Score = 5 |
| Affordance integrity | No dead affordances |
| Token compliance | No hardcoded values (RULE-002) |
| Contrast | WCAG AA (LAW-006) |
| Phantom actions | Zero |

**Degraded-but-tracked (accept lower bar, document as debt):**

| Dimension | Normal bar | Single-Cycle bar |
|-----------|-----------|-----------------|
| Model Coherence | 4 | 3 |
| User Expectations | 4 | 3 |
| Completeness | 4 | 3 |

**May-defer:** Performance, Moat Alignment, Visual Craft (polish beyond tokens)

All deferred items become P1s in the next build cycle.

### 5. Quick Session End

**Reference:** `.claude/PROTOCOL.md` Quick Session Protocol

1. Write handoff file (can be one-liner: `Intent: Fixed X. Linear: LIN-NNN → Done`)
2. Update Linear issue status + append Log row
3. Create Journal entry (one line minimum)

---

## Concrete Example: Fix Button Contrast

**Intent:** Fix contrast issue on Settings submit button (LIN-042)

**Classification:** Targeted (known cause, 1 file, no design decision)

```
1. START
   Intent: Fix contrast issue on Settings submit button (LIN-042)
   Git check: ✓  Handoff check: ✓  Linear: LIN-042 open

2. CLASSIFY
   Files: 1  Decisions: 0  New surfaces: 0  → Targeted

3. TARGETED PATH
   LOAD     Read handoff/from-chat/ — no pending items
   LAWS     LAW-006 (Accessibility) applies
   CONTEXT  Load _ui/tokens.yaml — valid color tokens
   BUILD    Change button bg from default/background-weak to brand/background
   SPOT     Contrast ratio: 7.2:1 (meets AA 4.5:1) ✓

4. SINGLE-CYCLE — not needed (no visible screen layout change)

5. END
   Commit: "fix: improve submit button contrast to meet AA (LIN-042)"
   Linear: LIN-042 → Done
   Handoff: one-liner
   Journal: one-liner
```

**Total time:** ~20 minutes including overhead.

---

## Escalation Signals

If any of these occur during a lightweight build, **stop and reclassify**:

| Signal | Required Action |
|--------|----------------|
| "Should I use approach A or B?" | Reclassify as Standard |
| "This affects another screen too" | Reclassify as Standard or Complex |
| "I need to add a new component" | Reclassify as Standard |
| Session past 90 minutes | Escalate to Full session mode |
| Touching the truth model | Reclassify as Standard minimum |

These are **not** optional. The lightweight path only works when the task genuinely fits.

---

## What This Path Does NOT Skip

Even on the lightest path, these always apply:

| Governance | Always |
|-----------|--------|
| `_rules/laws.yaml` | Checked |
| Handoff file | Written (even one line) |
| Linear update | If issue exists |
| Journal entry | Even one line |
| Closed World Assumption | Components.yaml only |
| Token-Only rule (RULE-002) | No hardcoded values |

The lightweight path reduces **which** steps run, not **whether** governance applies.

---

## Related Files

| File | What It Provides |
|------|------------------|
| `.claude/PROTOCOL.md` | Quick Session Protocol (steps 1, 5) |
| `.claude/BUILD.md` Section 1 | Task Classification Matrix (step 2) |
| `.claude/BUILD.md` Section 2 | Micro and Targeted build paths (step 3) |
| `_critique/LOOP.md` | Single-Cycle Mode definition (step 4) |
| `_rules/laws.yaml` | Constraints that always apply |
