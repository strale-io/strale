# Client Presentation Protocol

> Guidelines for preparing and delivering artifacts to external stakeholders.

---

## Purpose

This protocol ensures artifacts are presentation-ready before external delivery. It enforces LAW-013 (Reverse Engineering: Artifact First) by verifying artifacts meet quality standards before leaving the team.

---

## Pre-Delivery Checklist

### Content Readiness

- [ ] All sections are complete or explicitly marked as pending
- [ ] No internal jargon without explanation
- [ ] No "TBD", "TODO", or placeholder text visible
- [ ] All claims are supported by evidence
- [ ] Undecided areas explicitly marked as undecided

### Quality Verification

- [ ] Passes Professional Embarrassment Gate (QUALITY_PROTOCOL.md)
- [ ] Passes Agency Test: "Would a premium agency ship this?"
- [ ] No verbal explanation required (SA-006)
- [ ] Artifact shows actual state, not aspirational (SA-005)

### Visual Quality

- [ ] Consistent formatting throughout
- [ ] Tables properly aligned
- [ ] Code samples syntax-highlighted
- [ ] Images high-resolution and labeled
- [ ] Screenshot annotations clear and professional

### Traceability

- [ ] Version number included
- [ ] Date of preparation included
- [ ] Author/team attribution included
- [ ] References to source documents included

---

## Artifact Types and Expectations

### Design Deliverable

**Purpose:** Communicate design decisions and visual direction.

**Must include:**
- Design rationale (why, not just what)
- Visual specifications (not just mockups)
- Interaction descriptions
- Edge case handling

**Quality bar:** Client can implement without clarifying questions.

---

### Technical Specification

**Purpose:** Enable implementation by development team.

**Must include:**
- Requirements traceability
- API contracts (if applicable)
- Data models
- Error handling
- Security considerations

**Quality bar:** Developer can build without design consultation.

---

### Status Report / Progress Update

**Purpose:** Communicate project state to stakeholders.

**Must include:**
- What was accomplished
- What is in progress
- What is blocked (with mitigation)
- Next milestone and timeline

**Quality bar:** Executive can forward without editing.

---

### Research Findings

**Purpose:** Share insights from user research.

**Must include:**
- Methodology summary
- Key findings (prioritized)
- Supporting evidence (quotes, data)
- Recommendations

**Quality bar:** Product manager can make decisions from this document.

---

## Presentation Formats

### Document Delivery

| Format | When to Use | Preparation |
|--------|-------------|-------------|
| PDF | Final deliverables | Lock formatting, reduce file size |
| Markdown | Working documents | Ensure renders correctly |
| HTML | Interactive content | Test all links and interactions |

### Live Presentation

| Element | Requirement |
|---------|-------------|
| Narrative flow | Beginning → middle → end |
| Supporting materials | Pre-loaded, tested |
| Fallback | Offline copy available |
| Time buffer | 10% buffer for questions |

---

## Delivery Channels

### Async Delivery

- [ ] Document stored in agreed location
- [ ] Notification sent with context
- [ ] Response timeline set
- [ ] Follow-up scheduled if no response

### Sync Delivery (Presentation)

- [ ] Meeting scheduled with agenda
- [ ] Materials sent in advance (if appropriate)
- [ ] Recording consent obtained (if recording)
- [ ] Action items captured and distributed

---

## Post-Delivery

### Feedback Collection

- [ ] Structured feedback requested
- [ ] Clarifying questions answered
- [ ] Feedback logged for future reference

### Artifact Archival

- [ ] Final version stored in `_artifacts/synthesis/`
- [ ] Delivery date recorded
- [ ] Feedback summary attached
- [ ] Lessons learned captured

---

## Red Flags (Do Not Deliver)

Stop delivery if any of these are true:

| Red Flag | Action |
|----------|--------|
| Sections require verbal explanation | Rewrite section |
| Stakeholder would need to apologize when forwarding | Revise quality |
| Contains unresolved contradictions | Resolve before delivery |
| Key questions are unanswered | Answer or explicitly defer |
| Visual quality is inconsistent | Polish presentation |

---

## References

- `SYNTHESIS.md` — Synthesis artifact structure
- `_quality/QUALITY_PROTOCOL.md` — Gate 6: Artifact Readiness
- `_invariants/REGISTRY.md` — SA-001 through SA-006
- LAW-013 — Reverse Engineering: Artifact First
