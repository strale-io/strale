# Artifacts Directory

> Organized storage for build artifacts, deliverables, and process outputs.

---

## Purpose

This directory provides a structured home for artifacts produced during the build process. Artifacts are organized by type to enable:
- Easy location of related documents
- Clear separation of process outputs from source files
- Audit trail for quality assurance

---

## Directory Structure

```
_artifacts/
├── README.md           # This file
├── SYNTHESIS.md        # Synthesis artifact guidance (existing)
├── DELIVERY.md         # Client presentation protocol (new)
├── gates/              # Quality gate outputs
│   └── GATE_OUTPUT_TEMPLATE.yaml
├── critique/           # Critique scorecards and cycle outputs
├── synthesis/          # Final synthesis artifacts
└── specs/              # Surface and feature specifications
```

---

## Subdirectory Contents

### `/gates`

Quality gate result files.

**Naming:** `GATE-{N}_{surface-or-build-id}_{YYYY-MM-DD}.yaml`

**Example:** `GATE-5_SURF-001_2026-02-06.yaml`

See `GATE_OUTPUT_TEMPLATE.yaml` for format.

---

### `/critique`

Critique loop outputs including scorecards and cycle records.

**Naming:** `CRITIQUE_{surface-id}_{cycle}_{YYYY-MM-DD}.md`

**Example:** `CRITIQUE_SURF-001_C3_2026-02-06.md`

Contents:
- Critique scorecards
- Issue lists per cycle
- Resolution records
- Design reasoning documentation

---

### `/synthesis`

Final synthesis artifacts for external delivery.

**Naming:** `SYNTHESIS_{product-or-feature}_{version}.md`

**Example:** `SYNTHESIS_dashboard_v1.0.md`

See `SYNTHESIS.md` for artifact requirements and `DELIVERY.md` for presentation protocol.

---

### `/specs`

Detailed specifications beyond surface templates.

**Naming:** `SPEC_{topic}_{YYYY-MM-DD}.md`

**Example:** `SPEC_search-algorithm_2026-02-06.md`

Contents:
- Detailed feature specifications
- Algorithm documentation
- API contracts
- Integration specifications

---

## Artifact Lifecycle

| Stage | Location | Status |
|-------|----------|--------|
| In progress | Working directory | Draft |
| Gate passed | `/gates` | Archived |
| Critique complete | `/critique` | Archived |
| Ready for delivery | `/synthesis` | Active |
| Delivered | `/synthesis` | Delivered |

---

## Retention Policy

| Artifact Type | Retention |
|---------------|-----------|
| Gate outputs | Permanent (audit trail) |
| Critique records | Permanent (learning source) |
| Synthesis artifacts | Permanent (delivery record) |
| Spec drafts | Until superseded |

---

## Related Files

- `SYNTHESIS.md` — Synthesis artifact format and requirements
- `DELIVERY.md` — Client presentation protocol
- `_runs/` — Build run logs (separate from artifacts)
- `_quality/QUALITY_PROTOCOL.md` — Gate definitions

---

## Usage Notes

1. **Never modify archived artifacts** — Create new versions instead
2. **Include metadata** — Date, author, version in every artifact
3. **Link traceability** — Reference SURF-NNN, DEC-NNN, RUN-NNN IDs
4. **Follow templates** — Use provided templates for consistency
