# Synthesis Artifact

> The system is designed backward from the artifacts it must produce, not forward from features.

---

## Purpose

A **Synthesis Artifact** is a human-readable, professionally presentable representation of the system that accurately reflects decisions, intent, maturity, and constraints — suitable for external delivery without verbal explanation.

This is the thing the product exists to create.

All product capabilities must ultimately support the creation of synthesis artifacts. Features that cannot be traced to artifact sections require explicit justification.

---

## The Core Principle

> Design backward from output, not forward from features.

Instead of asking:
- "What feature should I build?"

Ask:
- "What must exist for the artifact to be true?"

This is how elite agencies work. They start with the deliverable, then reverse-engineer everything required to make that deliverable inevitable.

---

## Target Audience

Synthesis artifacts must be suitable for:
- Executives (no jargon, clear intent)
- External partners (no internal context required)
- Practitioners (actionable, not just philosophical)
- Future team members (complete context, no archaeology)

**The No Verbal Explanation Test:**

> If any artifact section would require verbal explanation when shared externally, the section fails.

---

## Quality Bar

The artifact must feel:
- **Intentional** — every element is there for a reason
- **Calm** — no anxiety, no uncertainty theater
- **Defensible** — decisions can be justified
- **Opinionated** — clear stance without being prescriptive
- **Premium** — comparable to deliverables from world-class agencies

**The Agency Test:**

> Would a premium agency ship this to a demanding client?

If the artifact feels generic, templated, or incomplete, the system has failed.

---

## Artifact Honesty Principle

Synthesis artifacts must:
- Show what's decided (not what's hoped)
- Show what's undecided (explicitly)
- Never present placeholders as decisions
- Never extrapolate beyond captured intent
- Never require disclaimers or apologies

This prevents "agency theater" — artifacts that look polished but represent nothing.

---

## Artifact Section Model

Every synthesis artifact is composed of **sections**. The specific sections depend on the product, but the model is universal.

### Section Types

| Type | Purpose | Examples |
|------|---------|----------|
| **Intent** | Why the system exists | Vision, philosophy, principles |
| **Foundation** | Core building blocks | Primitives, tokens, base decisions |
| **Composition** | How foundations combine | Patterns, components, layouts |
| **Decision State** | What's locked vs. open | Maturity summary, change log |
| **Governance** | How to change safely | Rules, processes, ownership |

### Section Maturity

Each section has a maturity state:

| State | Meaning | Artifact Behavior |
|-------|---------|-------------------|
| **Renderable** | Can be produced truthfully now | Include fully |
| **Partial** | Some content exists, gaps identified | Include with explicit gaps |
| **Placeholder** | Section exists but content is aspirational | Mark as "In Progress" |
| **Blocked** | Cannot render due to missing decisions | Show what's blocking |

**Critical:** Placeholder sections must never be presented as complete. The artifact must be honest about its own maturity.

---

## Reverse Engineering Mandate

For each artifact section, the system must identify:

| Question | Purpose |
|----------|---------|
| What information is required? | Defines data dependencies |
| What decisions must exist? | Defines decision dependencies |
| What states must be tracked? | Defines system requirements |
| What explanations must be available? | Defines content requirements |
| What is currently missing? | Defines gaps to close |

**Feature Justification:**

Features may only be introduced if they clearly support one or more artifact sections. If a feature doesn't serve a section, it requires explicit justification.

| Feature Type | Relationship to Artifact |
|--------------|-------------------------|
| Product features | Must serve artifact sections |
| Infrastructure features | Serve product features (indirect) |
| Operational features | May not map to artifact (acceptable) |

---

## Artifact Types

Systems may produce multiple artifact types:

| Type | Audience | Depth |
|------|----------|-------|
| **Executive Summary** | Leadership | High-level intent, key decisions |
| **Full System Documentation** | Practitioners | Complete detail |
| **Handoff Artifact** | Implementation teams | Actionable specifications |
| **Reference Export** | Machines | Tokens, configs, structured data |

All types must be consistent. No contradictions between artifacts.

---

## Artifact Readiness Gate

An artifact is not ready for delivery unless:

- [ ] Each section can be rendered truthfully
- [ ] No section requires placeholder language presented as final
- [ ] Undecided areas are explicitly marked
- [ ] The artifact could be shared externally without apology
- [ ] The artifact requires no verbal explanation
- [ ] The artifact passes the Agency Test

**If any section would feel embarrassing or incomplete, the artifact is not ready.**

---

## The "Worth It" Moment

The synthesis artifact is where the system proves its value.

The moment the user realizes:

> "I didn't write this. I didn't design this. But it is accurate, tasteful, and defensible."

That's not automation. That's leverage.

---

## Integration with Other Systems

| System | Relationship |
|--------|--------------|
| **EIL** | Artifact sections may create new expectations (run EIL) |
| **Pre-Build** | Features serve artifact sections (reverse engineering) |
| **Feature Classification** | "Does this serve an artifact section?" |
| **Quality Gates** | Artifact Readiness is Gate 6 |
| **Expectation Debt** | Unrenderable sections create artifact debt |

---

## Artifact Section Checklist

Before declaring any artifact section complete:

- [ ] Content reflects actual decisions, not aspirations
- [ ] Uncertainty is marked, not hidden
- [ ] No verbal explanation would be required
- [ ] Section could be extracted and shared independently
- [ ] Premium agency would not revise substantially
- [ ] Future reader could understand without archaeology

---

## What Synthesis Artifacts Are NOT

Synthesis artifacts are not:
- **Data dumps** — they are curated, narrated
- **Feature lists** — they explain intent, not inventory
- **Marketing materials** — they are honest, not promotional
- **Living documents** — they are snapshots of truth at a point in time
- **Exhaustive references** — they are authoritative summaries

---

## Summary

> The system exists to produce synthesis artifacts.
> Features exist to make artifact sections true.
> Artifact quality is the ultimate measure of system quality.

If the artifact is impressive, the system worked.
If the artifact requires apology, the system failed.
