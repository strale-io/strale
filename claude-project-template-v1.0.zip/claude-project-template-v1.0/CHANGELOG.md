# Changelog

All notable changes to the Starter Kit.

---

## v12.16.0

### Implementation Bridge Documents

**3 new files closing the spec-to-implementation gap.**

**Core Insight:** The system produces excellent governance artifacts but doesn't help translate them into implementation work. A developer completing governance has artifacts scattered across 15+ files with no map connecting them to implementation questions, no post-implementation verification, and no task decomposition templates.

| Change | File(s) | Purpose |
|--------|---------|---------|
| **Implementation Translation Guide** | `_guides/IMPLEMENTATION_MAP.md` | Reference map: "Your surface spec tells you...", "Your entity model tells you...", etc. Cross-reference lookup table and recommended reading order. |
| **Code Verification Protocol** | `_quality/VERIFICATION.md` | Post-implementation checklist: token traceability, mandatory states, budget compliance, interaction laws, entity integrity, accessibility, affordance integrity, tech foundation. Scoped by build tier. |
| **Task Decomposition Patterns** | `_model/patterns/decomposition.md` | Stack-agnostic templates for breaking specs into ordered tasks per archetype (overview, workspace, detail, configuration, transient). 6 phases: structure → data → states → content → interaction → polish. |
| **README update** | `README.md` | Added IMPLEMENTATION_MAP.md to _guides/ directory tree |

DEC-038 (draft — pending approval)

---

## v12.15.0

### Task-Aware Dispatch

**1 new file, 4 surgical edits consolidating context loading guidance.**

**Core Insight:** The system had 40+ feature files but no mechanism to tell AI agents which ones to read for a given task. Vague loading tables ("UI work → + _ui/*") left agents guessing, causing v2.0 features to sit dormant. DISPATCH.yaml provides task-type-specific reading lists with exact file paths, reasons, triggers, and gates.

| Change | File(s) | Purpose |
|--------|---------|---------|
| **DISPATCH.yaml** | `.claude/DISPATCH.yaml` | Task-aware routing: 13 task types with must_read lists, before/after triggers, and quality gate mappings |
| **RUNBOOK loading consolidation** | `.claude/RUNBOOK.md` | Replaced vague starter kit loading table with DISPATCH reference |
| **govern.md loading consolidation** | `_modes/govern.md` | Replaced YAML load sets with DISPATCH reference |
| **SYSTEM_CONTRACT loading consolidation** | `SYSTEM_CONTRACT.md` | Replaced starter kit loading table with DISPATCH reference; updated folder description |

DEC-030 — follows CONSTRAINTS_INDEX.yaml pattern (DEC-003) as reference-only routing index.

### DISPATCH Enhancements (9 rounds)

**Round 1 — Attention-Directing Metadata:**
- Added `key_signals` to all 13 task types — critical rules extracted from files, readable without opening them
- Added `depth` tiers (full/scan/verify) with `look_for` hints to every must_read entry
- Added `context_budget` and `priority_if_constrained` per task type
- Added `file_digests` section — minimum viable knowledge for 8 common files
- Added Loading Protocol to RUNBOOK.md

**Round 2 — Session Workflow Bridge:**
- Added `session_workflow` to all 13 task types (session_mode, notion_read, notion_write, linear_actions, handoff_weight)
- Expanded cross-cutting triggers: replaced 1 vague trigger with 4 specific blocking triggers + 1 periodic
- Added PROTOCOL.md and NOTION.md file digests
- Added Session Workflow Essentials to RUNBOOK.md

**Round 3 — Infrastructure + BUILD Bridge:**
- Added `build_classification` to all 13 task types (typical tier, range, pre_build)
- Added BUILD.md file digest
- Created `handoff/` directory structure (README, _general/from-chat/, _general/from-code/, _archive/)
- Created `tasks/todo.md` and `tasks/lessons.md`
- Created stub `CLAUDE.md` from PROTOCOL.md template
- Rewrote RUNBOOK.md Task Flow with DISPATCH→BUILD→PROTOCOL→WORKFLOW interconnection diagram
- Added Template State note to RUNBOOK.md Context Loading
- Updated README.md directory tree

**Round 4 — Cross-Reference Integrity:**
- Updated DISPATCH.yaml HOW TO USE with build_classification and session_workflow steps
- Updated DISPATCH.yaml RELATIONSHIP section to include BUILD.md
- Added DISPATCH.yaml to BUILD.md Related table
- Added cross-cutting triggers note to BUILD.md Section 2
- Added upstream context references to WORKFLOW.md
- DEC-031

**Round 5 — Quality Loop Routing + Archetype Completion:**
- Added `should_read` entries to 5 task types (new_screen, full_feature, review_audit, data_display, modify_screen) routing critique inputs and pre-build dependencies
- Bridged DESIGN_ROUTER.yaml from DISPATCH.yaml — single should_read entry per UI task type
- Fixed broken BUILD.md reference (`_quality/RUBRIC.md` → `_critique/RUBRIC.md`)
- Created `_quality/archetypes/configuration.yaml` and `transient.yaml` provisional stubs (completing all 5 claimed archetypes)
- Updated archetype file digest (3 → 5 archetypes)
- Added EVOLUTION.md file digest
- Fixed README.md Bootstrap Order (added DISPATCH.yaml and BUILD.md at positions 5-6)
- Added DESIGN_ROUTER.yaml to RUNBOOK.md Related table
- DEC-033

**Round 6 — Flow/Job Routing + Component Fix + Navigation Cleanup:**
- Routed `_flows/REGISTRY.yaml` to 4 more task types (new_screen, modify_screen, review_audit, exploration) — was only in full_feature
- Routed `_jobs/REGISTRY.yaml` to 3 more task types (new_screen, review_audit, exploration)
- Added `_jobs/VALUE_LOOPS.md` to full_feature should_read
- Added `_jobs/TEMPLATES.md` and `_flows/TEMPLATES.md` to exploration should_read
- Fixed `new_component` design system reference (components.yaml vs components.md note)
- Added `should_read` section to `new_component` (was the only UI task type without one)
- Added `_examples/` file digest
- Reworded RUNBOOK.md Template State warning for clarity
- Added EVOLUTION.md to RUNBOOK.md Related table
- Fixed README.md `_model/patterns/` description (added overview)
- DEC-034

**Round 7 — Routing Gap Closure:**
- Added `_quality/VISUAL_VERIFICATION.md` and `_critique/CALIBRATION.md` to `token_work` should_read; added critique loop after-trigger
- Added `_flows/REGISTRY.yaml` and `_jobs/REGISTRY.yaml` to `model_change` should_read (missed in Round 6)
- Added `CONSTRAINTS_INDEX.yaml` to `new_screen`, `full_feature`, and `new_component` should_read (was only in token_work)
- Added `should_read` section to `config_change` (conditional _flows/, _jobs/, _content/SYSTEM.md)
- Added `should_read` section to `refactor` (_quality/TRACE.yaml — conditional)
- Added `_critique/CALIBRATION.md` to `review_audit` should_read (RUBRIC.md scoring companion)
- Added `_decisions/REGISTRY.md` to `modify_screen` should_read (fixes before-trigger referencing unloaded file)
- Added `_quality/REFERENCE_ANALYSIS.md` to `exploration` should_read (explore.md Step 0)
- Updated `context_budget` for all 10 affected task types
- Expanded QUICKREF.md invariant prefix table (9 → 27 categories), added Entry Points rows, Modes and Routing sections
- DEC-035

**Round 8 — Trigger-Load Mismatches + Thin Task Types + File Digests:**
- Fixed systemic trigger-load mismatch: `_critique/LOOP.md` referenced in 6 task type after-triggers but never loaded — added to should_read for `new_screen`, `modify_screen`, `token_work`, `new_component`, `full_feature`, `data_display`
- Fixed `_decisions/REGISTRY.md` trigger-load mismatch for 3 more task types (`new_component`, `full_feature`, `config_change`) — before-triggers reference it but file wasn't loaded
- Fixed 3 one-off trigger-load mismatches: `_ui/states.md` for `data_display`, `_quality/QUALITY_PROTOCOL.md` for `accessibility`, `_quality/COHERENCE.md` for `full_feature`
- Filled thin `should_read` sections: `bug_fix` (+`_ui/states.md`, +`_content/PATTERNS.md`), `data_display` (+`_model/truth/actions.yaml`, +`_contract.yaml`, +`_ui/tokens.yaml`), `accessibility` (+`_content/SYSTEM.md`)
- Added `_rules/laws.yaml` to `token_work` must_read and `config_change` should_read
- Added 4 file digests: `CONSTRAINTS_INDEX.yaml`, `_content/SYSTEM.md`, `_ui/states.md`, `_quality/QUALITY_PROTOCOL.md` (17 total)
- Updated `context_budget` for all 10 affected task types
- Fixed `govern.md` "Open Questions database" → "Deferred database" (canonical name per NOTION.md)
- Added 4 rows to QUICKREF.md Quality & Critique table (CALIBRATION.md, VISUAL_VERIFICATION.md, REFERENCE_ANALYSIS.md, RELEASE_REVIEW.md)
- DEC-036

**Round 9 — Structural Documentation + Remaining Digests + State Routing:**
- Added `_design-systems/` directory tree to README.md (professional/ and publishing/ with all 6 files each)
- Added `GOVERNANCE.md`, `EVOLUTION.md`, `CONSTRAINTS_INDEX.yaml` to README.md root listing
- Added 11 missing directories to SYSTEM_CONTRACT.md Folder Responsibilities table (`_surfaces/`, `_nfr/`, `_design-systems/`, `_expectations/`, `_artifacts/`, `_runs/`, `_resilience/`, `_research/`, `_strategy/`, `_examples/`)
- Added `_ui/states.md` to `modify_screen` and `new_component` should_read (last two UI task types missing it)
- Added 5 file digests: `_critique/LOOP.md`, `_quality/VISUAL_VERIFICATION.md`, `_flows/REGISTRY.yaml`, `_jobs/REGISTRY.yaml`, `_ui/tokens.yaml` (22 total)
- Improved `data_display` key_signal: added SURFACING.md cross-reference
- Corrected `new_screen` should_read_tokens budget (~2300 → ~3200) to reflect 17-entry section
- Added `EVOLUTION.md` and `_quality/exemplars/` rows to QUICKREF.md
- Updated `context_budget` for `modify_screen`, `new_component`, `new_screen`
- DEC-037

### Design Activation Package

- Updated `.claude/PROTOCOL.md` — added conditional design checkpoint (step 5/9) to Quick and Full session checklists and narrative protocols: "If session touches UI: Read `DESIGN_ROUTER.yaml`"
- Updated `.claude/PROTOCOL.md` — added Design Brief template to handoff system with structured format for visual identity, surface types, and peer benchmarks
- Updated `.claude/PROTOCOL.md` — added "Design Brief" to `from-chat/` contents list
- Added `DESIGN_ROUTER.yaml` — surface-type routing file mapping 8 surface types (table, detail, form, dashboard, settings, wizard, empty_state, modal) to design files, plus always-load and cross-cutting sections

### Product Thesis & Feature Multiplication

- Added `thesis` section to `config/manifest.yaml` — falsifiable claim every feature is tested against, with assumptions and falsification criteria
- Added `_quality/DIRECTIONAL_COHERENCE.md` — feature multiplication test, orphan detection, multiplication map, directional audit protocol
- Updated `_quality/COHERENCE.md` — added companion cross-reference to directional coherence
- Updated `_expectations/PRE-BUILD.md` — added Thesis Alignment Check (step 3) and Feature Multiplication Check (step 4); existing steps renumbered
- Updated `_critique/PROMPT.md` — added "Directional Coherence" critique dimension (conditional)
- Updated `_critique/LOOP.md` — added Product Thesis to spec-declaration mapping table
- Updated `_quality/QUALITY_PROTOCOL.md` — added thesis alignment and multiplication checks to Gate 0
- Updated `README.md` — added DIRECTIONAL_COHERENCE.md to directory structure
- Updated `QUICKREF.md` — split coherence into visual/directional entries; added Feature Multiplication principle
- Updated `.claude/RUNBOOK.md` — noted thesis in quick-fix context loading

### Information Surfacing Framework

- Added `_model/patterns/SURFACING.md` — Action-Change Test, 4-tier importance model (Prominent/Accessible/On Demand/Remove), Surfacing Audit protocol, surface-type patterns
- Updated `_model/patterns/overview.md` — added Information Surfacing to Related Concepts
- Updated `_expectations/PRE-BUILD.md` — added Surfacing Audit step (step 10) to Pre-Build flow
- Updated `_critique/PROMPT.md` — added "Information Surfacing" critique dimension (High, min 4)
- Updated `_critique/LOOP.md` — added SURFACING.md to critique inputs and Information Surfacing to scoring table
- Updated `_critique/RUBRIC.md` — added scoring criteria for Information Surfacing dimension
- Updated `_critique/CALIBRATION.md` — added calibration for Information Surfacing
- Updated `_quality/QUALITY_PROTOCOL.md` — added Surfacing Audit checklist to Gate 0
- Updated `README.md` — added surfacing to patterns directory description
- Updated `QUICKREF.md` — added information surfacing entry

### Design Tooling Governance

- Added `config/TOOLING.md` — universal selection criteria (8 dimensions), 8 tool categories, evaluation workflow, verdict system (adopt/trial/hold/reject)
- Updated `config/tech-foundation.yaml` — added tooling section for recording active tool choices
- Updated `README.md` — added TOOLING.md to directory structure
- Updated `QUICKREF.md` — added design tooling entry
- Updated `.claude/RUNBOOK.md` — tool adoption added to "Requires Proposal" list
- Updated `_quality/QUALITY_PROTOCOL.md` — tooling verification added to Gate 0
- Updated `_critique/PROMPT.md` — tooling compliance added to Architectural Compliance checks

### Adaptive Layout Governance

- Added `_ui/ADAPTIVE.md` — content priority framework, navigation transformation, touch adaptation, form factor declaration
- Updated `_ui/RESPONSIVE.md` — added companion reference
- Updated `_surfaces/SPEC_TEMPLATE.md` — added form factor declaration and content priority templates
- Updated `_expectations/PRE-BUILD.md` — added adaptive declaration step (step 9) to Pre-Build flow
- Updated `_critique/PROMPT.md` — added "Adaptive Layout" critique dimension (conditional)
- Updated `_critique/LOOP.md` — added dimension to scoring table
- Updated `_quality/QUALITY_PROTOCOL.md` — added adaptive checks to Gate 0
- Updated `README.md` — added ADAPTIVE.md to directory structure
- Updated `QUICKREF.md` — added adaptive layout entry

### Value Loop Mapping

- Added `_jobs/VALUE_LOOPS.md` — 4 loop types (Data, Learning, Integration, Network), loop-to-job mapping, visibility guidelines, value loop audit
- Updated `_strategy/MOATS.md` — added "Connection to Value Loops" section mapping loop types to moat types
- Updated `README.md` — added VALUE_LOOPS.md to directory structure and Key Concepts
- Updated `QUICKREF.md` — added value loops entry to Jobs & Flows section

### Visual Verification Protocol

- Added `_quality/VISUAL_VERIFICATION.md` — complete protocol for visual verification
- Capture protocol: breakpoints (1440px, 1024px, 768px, 375px), states (default, empty, loading, error, hover, focus, edge cases)
- Quick Evaluation (5-10 min for Standard) and Full Evaluation (15-30 min for Complex with multi-persona walkthrough)
- Screenshot storage convention: `audit-output/{date}-visual/{surface-name}/`
- Score capping rule: without visual verification, Visual Craft/Interaction/Completeness capped at 3
- Playwright script template for automation
- Degraded mode table for when automation isn't available
- Updated `.claude/WORKFLOW.md` — replaced aspirational visual verification with protocol reference
- Updated `_critique/LOOP.md` — visual verification as required critique input and cycle step
- Updated `config/tech-foundation.yaml` — visual verification tool configuration section

### Exploration Phase with Reference Analysis

- Rewrote `_modes/explore.md` — structured exploration with reference analysis, approach generation, and constraint-based evaluation
- Added `_quality/REFERENCE_ANALYSIS.md` — protocol for analyzing reference products and extracting transferable principles
- Step 0 (Reference Analysis): identify pattern type, select 2-3 reference products, analyze, extract transferable principles
- Step 3 (Generate Approaches): requires genuinely different structural approaches, not cosmetic variations
- Step 4 (Evaluate): criteria tied to system constraints (laws, archetypes, tokens, truth model)
- Exploration artifacts with clear storage locations (inline for Standard, dedicated folder for Complex)
- Exit criteria distinguish Standard (proceed) from Complex (human approval required)
- Updated `_critique/PROMPT.md` — reference-informed Visual Craft scoring (Complex tasks without reference analysis cap at 3)
- Time budgets: 15-30 min for Standard, 30-60 min for Complex

### Build Conductor

- Added `.claude/BUILD.md` — central orchestration for all build tasks
- Task classification: Micro / Targeted / Standard / Complex with clear signals
- Four build paths with numbered steps referencing specific files
- Pre-build requirements matrix right-sized to task complexity
- File reference map covering all system files organized by need
- Common build scenarios with classification guidance
- Reclassification protocol for upgrading/downgrading mid-task
- Anti-patterns catalog for common process failures
- Updated `.claude/RUNBOOK.md` — references BUILD.md for task flow sequencing
- Updated `.claude/WORKFLOW.md` — cross-reference to BUILD.md for sequencing

### Cross-Surface Expectation Framework

- New `_surfaces/EXPECTATIONS.md` — proactive mental model consistency
- Five propagation rules: entity identity, interaction patterns, hierarchy, vocabulary, capability scope
- Mental Model Audit template for pre-build (multi-surface builds)
- Conflict detection with severity-based resolution (breaking / confusing / minor)
- Cross-surface expectation debt tracking
- Integration: feeds Gate 0, extends COHERENCE.md, extends PRE-BUILD.md

### Design Tradeoff Heuristics

- New `_quality/HEURISTICS.md` — design judgment guidance for competing principles
- Priority Ladder: 4 tiers (non-negotiable, high priority, important, preferences) with 12 ranked priorities
- 7 common tradeoff resolutions: clarity/density, speed/safety, consistency/context, completeness/simplicity, information/noise, flexibility/opinionation, discoverability/distraction
- Tradeoff documentation template for significant design decisions
- Tradeoff anti-patterns catalog
- Integration: Tradeoff Evaluation in critique, Tradeoff Anticipation in pre-build, warning signal in build intelligence

### Content Design System

- New `_content/SYSTEM.md` — product writing rules and voice execution
- New `_content/PATTERNS.md` — reusable writing patterns for errors, empty states, confirmations, success, loading, onboarding
- Five content principles: clarity over cleverness, specific over generic, action-oriented, honest, consistent
- Voice execution mapping: manifest.yaml voice → writing rules
- Content types: labels, buttons, errors, empty states, confirmations, tooltips, notifications, loading text
- Content Quality Checklist for pre-critique verification
- New critique dimension: Content Quality (High, min 4)
- Integration: extends vocabulary governance, Copy-First Gate, and voice configuration

---

## v12.14.0 — Jobs Architecture + Flow Design

**Why this product exists — expressed as the progress users are trying to make.**

### New Directory: `_jobs/`

| File | Purpose |
|------|---------|
| `FRAMEWORK.md` | Job hierarchy, statement format, competing jobs, completeness tests, traceability rules |
| `REGISTRY.yaml` | JOB-NNN entries with core/sub hierarchy, served status, flow mappings |
| `TEMPLATES.md` | Discovery tools: Core Job Discovery, Sub-Job Decomposition, Feature-to-Job Validation, Interview Question Bank, Completeness Audit |

### New Example

| File | Purpose |
|------|---------|
| `_examples/JOBS.example.yaml` | Beacon OKR product with 1 core job + 5 sub-jobs demonstrating full hierarchy |

### Integration Edits

- `README.md` — `_jobs/` added to directory tree + `JOBS.example.yaml` to `_examples/`
- `QUICKREF.md` — Jobs & Flows section added to File Lookup + `JOB-` added to ID Schemes
- `SYSTEM_CONTRACT.md` — `_jobs/` registered in Folder Responsibilities (authority: High)
- `QUALITY_PROTOCOL.md` — Conditional job traceability check in Gate 0 + job completeness check in Gate 5
- `_critique/PROMPT.md` — Job alignment question added to Output Type Alignment dimension
- `_surfaces/REGISTRY.yaml` — Optional `jobs:` field added to schema

### Design Principles

- **Soft enforcement:** Job traceability is conditional on `_jobs/REGISTRY.yaml` being populated. Teams adopt jobs gradually.
- **One core job per product:** A product that tries to serve multiple core jobs serves none well.
- **Depth limit: 2 levels:** Core → Sub only. No sub-sub-jobs.
- **Solution-independent:** Jobs exist whether or not the product exists.

### Decision Registry
- DEC-011: Added Jobs Architecture module

### Upgrade Advisory (Jobs)

**For existing projects:**
- No action needed — all changes are additive and conditional
- Gate 0/Gate 5 job checks only fire when `_jobs/REGISTRY.yaml` has entries
- Start by drafting a core job statement using `_jobs/TEMPLATES.md`

### New Directory: `_flows/`

| File | Purpose |
|------|---------|
| `FRAMEWORK.md` | Flow anatomy, types (linear/branching/cyclical/exploratory/recovery), emotional arcs, handoff design, abandonment strategies |
| `REGISTRY.yaml` | FLOW-NNN entries linking jobs to surface sequences |
| `QUALITY.md` | Flow Gate checklist and 5 critique dimensions (Continuity, Momentum, Recovery, Completeness, Emotional Coherence) |
| `TEMPLATES.md` | Flow Mapping, Flow Review Checklist, Abandonment Analysis, Flow Comparison |

### New Example

| File | Purpose |
|------|---------|
| `_examples/FLOWS.example.yaml` | Beacon with 4 flows: OKR Creation (linear), Progress Review (exploratory), Weekly Check-In (cyclical), Risk Investigation (branching) |

### Integration Edits (Flows)

- `README.md` — `_flows/` added to directory tree + `FLOWS.example.yaml` to `_examples/`
- `QUICKREF.md` — Flow entries added to Jobs & Flows section + `FLOW-` added to ID Schemes
- `SYSTEM_CONTRACT.md` — `_flows/` registered in Folder Responsibilities (authority: High)
- `QUALITY_PROTOCOL.md` — Conditional Flow Gate added (fires after Gate 2, before Gate 8)
- `_surfaces/REGISTRY.yaml` — Optional `flows:` field added to schema
- `_expectations/PRE-BUILD.md` — Flow integration note added to Journey Context
- `_expectations/CONTRACTS.md` — Flow-Level Completion section added to Completion Contract
- `_critique/PROMPT.md` — Flow Continuity added as conditional critique dimension

### Design Principles (Flows)

- **Soft enforcement:** Flow checks only fire when `_flows/REGISTRY.yaml` is populated. Teams adopt flows gradually.
- **Five flow types:** Linear, branching, cyclical, exploratory, recovery — each with distinct design implications.
- **Emotional arc required:** Every flow declares how user confidence/engagement evolves across steps.
- **Abandonment is designed:** Every flow step has a graceful exit with work preserved.

### Decision Registry
- DEC-012: Added Flow Design module

### Upgrade Advisory (Flows)

**For existing projects:**
- No action needed — all changes are additive and conditional
- Flow Gate and Flow Continuity dimension only fire when `_flows/REGISTRY.yaml` has entries
- Start by mapping your primary flow using `_flows/TEMPLATES.md`

### Capability Extensions (New Mechanism)

**New extension type: cross-cutting capabilities that work with any product class.**

Unlike product class extensions (mutually exclusive, loaded by `product_class`), capability extensions are activated independently via `capability_extensions` in `config/manifest.yaml`. Multiple can be active simultaneously. Loading order: Core → Product Class → Capability Extensions → Project Overrides.

### Progressive Disclosure Protocol (Capability Extension)

**First capability extension: strategic lifecycle-level disclosure.**

| File | Purpose |
|------|---------|
| `_extensions/disclosure/CONTRACT.md` | Scope, rules, activation |
| `_extensions/disclosure/PROTOCOL.md` | Lifecycle stages, aha moments, complexity budget, starter content, feature discovery |
| `_extensions/disclosure/TEMPLATES.md` | First-run audit, complexity staging worksheet, aha moment design, feature discovery plan |

Complements `_interaction/PROGRESSION.md` (within-surface disclosure) with strategic guidance for what to show across the user's entire lifecycle — from first contact to mastery.

### Integration Edits (Disclosure)

- `config/manifest.yaml` — `capability_extensions: []` field added (schema change)
- `README.md` — `_extensions/disclosure/` added to directory tree
- `QUICKREF.md` — Disclosure extension entries added
- `SYSTEM_CONTRACT.md` — Capability extensions mechanism documented
- `_extensions/README.md` — Capability extensions section added
- `_interaction/PROGRESSION.md` — Cross-reference to disclosure extension added
- `_ui/SYSTEM.md` — Disclosure alignment note added to Progressive Trust Architecture
- `QUALITY_PROTOCOL.md` — Conditional first-run audit item added to Gate 0
- `_expectations/PRE-BUILD.md` — Complexity budget check added to Feature Classification

### Design Principles (Disclosure)

- **Additive only:** Extension adds guidance; does not override core or product class rules
- **Conditional enforcement:** All disclosure checks only fire when `disclosure` is in `capability_extensions`
- **Two levels of disclosure:** Within-surface (PROGRESSION.md) + across-lifecycle (this extension)
- **Five lifecycle stages:** First Contact → First Value → Adoption → Proficiency → Mastery

### Decision Registry
- DEC-013: Added Progressive Disclosure Protocol + capability extensions mechanism

### Upgrade Advisory (Disclosure)

**For existing projects:**
- No action needed — capability extensions field defaults to empty `[]`
- All disclosure guidance is conditional on activation
- To activate: add `disclosure` to `capability_extensions` in `config/manifest.yaml`

### Collaboration Patterns (Capability Extension)

**Second capability extension: multi-user experience design.**

| File | Purpose |
|------|---------|
| `_extensions/collaboration/CONTRACT.md` | Scope, rules, activation, collaboration layers |
| `_extensions/collaboration/PATTERNS.md` | Presence, communication, coordination, co-creation patterns |
| `_extensions/collaboration/NOTIFICATIONS.md` | Notification architecture: urgency, channels, content, aggregation, control |
| `_extensions/collaboration/INVARIANTS.md` | 19 collaboration invariants (CO-001 through CO-019) |

**Collaboration layers:** Awareness → Communication → Coordination → Co-creation (hierarchical — higher layers include lower).

**Collaboration Contract:** Added as conditional contract #11. Fires only when extension active.

**Notification architecture:** Urgency framework (immediate / soon / eventual / digest), channel design (in-app, email, push), aggregation rules, user control model.

### Integration Edits (Collaboration)

- `README.md` — `_extensions/collaboration/` added to directory tree
- `QUICKREF.md` — Collaboration entries added + `CO-` added to ID Schemes
- `_extensions/README.md` — Collaboration status updated to Active
- `_expectations/CONTRACTS.md` — Collaboration Contract added as conditional #11
- `_critique/PROMPT.md` — Collaboration Quality added as conditional critique dimension
- `_surfaces/REGISTRY.yaml` — Optional `collaboration_layer` field added to schema

### Design Principles (Collaboration)

- **Four layers:** Awareness → Communication → Coordination → Co-creation (hierarchical)
- **Layer per surface:** Each surface declares its collaboration layer
- **Experience over access:** This extension designs how collaboration feels; permissions.yaml controls who can do what
- **Notification architecture:** Dedicated file because notification design is the #1 collaboration UX failure point

### Decision Registry
- DEC-014: Added Collaboration Patterns extension

### Upgrade Advisory (Collaboration)

**For existing projects:**
- No action needed — all changes are conditional on activation
- To activate: add `collaboration` to `capability_extensions` in `config/manifest.yaml`

### Intelligence Design Framework (Capability Extension)

**Third capability extension: responsible smart feature design.**

| File | Purpose |
|------|---------|
| `_extensions/intelligence/CONTRACT.md` | Scope, rules, activation, intelligence spectrum, exception to Dangerous classification |
| `_extensions/intelligence/FRAMEWORK.md` | Confidence display, suggestion design, smart defaults, automation design, autonomy rules |
| `_extensions/intelligence/GUARDRAILS.md` | Intelligence Restraint Gate (10-item checklist), failure mode catalog, degradation rules |
| `_extensions/intelligence/INVARIANTS.md` | 13 intelligence invariants (IN-001 through IN-013) |

**Intelligence spectrum:** Insight → Suggestion → Smart Default → Automation → Autonomy (increasing trust required, increasing failure impact).

**The Agency Test:** "Does this feature make the user more capable, or more dependent?" — applied to every smart feature.

**Intelligence Restraint Gate:** 10-item checklist every smart feature must pass before shipping. Failure = classified as Dangerous. Extends (not replaces) the standard Restraint Gate.

### Decision Registry
- DEC-015: Added Intelligence Design Framework extension

### Upgrade Advisory (Intelligence)

**For existing projects:**
- No action needed — all changes are conditional on activation
- To activate: add `intelligence` to `capability_extensions` in `config/manifest.yaml`

---

### v12.14.0 Summary — Five-Module System Expansion

This version adds 5 modules (18 new files) spanning jobs architecture, flow design, and three capability extensions:

| Module | Location | Files | Type |
|--------|----------|-------|------|
| Jobs Architecture | `_jobs/` | 3 | Core directory |
| Flow Design | `_flows/` | 4 | Core directory |
| Progressive Disclosure Protocol | `_extensions/disclosure/` | 3 | Capability extension |
| Collaboration Patterns | `_extensions/collaboration/` | 4 | Capability extension |
| Intelligence Design Framework | `_extensions/intelligence/` | 4 | Capability extension |

**New mechanism:** Capability extensions — cross-cutting modules activated via `capability_extensions` in manifest.yaml. Compatible with all product classes. Multiple can be active simultaneously.

**New ID schemes:** JOB-NNN, FLOW-NNN, CO-NNN, IN-NNN.

**Beacon worked examples:** `_examples/JOBS.example.yaml`, `_examples/FLOWS.example.yaml`.

---

## v2.3.0 — Worked Examples

**5-file example set using a fictional B2B SaaS product (Beacon) to demonstrate starter kit formats in practice.**

### Changes
- Added `_examples/` directory with 5 Beacon-based worked examples
- `README.md` — Overview explaining Beacon and how examples connect
- `REGISTRY.example.yaml` — Surface Registry with 5 surfaces (all archetypes)
- `DECISIONS.example.md` — Decision Registry with 5 product-level decisions
- `GATE-0.example.md` — Completed Gate 0 for the OKR Board surface
- `CRITIQUE.example.md` — Failing Cycle 1 critique scorecard with patch plan

### Coverage
- Exercises all screen archetypes (Index, Detail, Workspace, Dashboard, Settings)
- Deep entity hierarchies and state machines
- Cross-surface coherence patterns
- Files cross-reference each other to show system integration

### Decision Registry
- DEC-010: Added worked examples using fictional product Beacon

### Upgrade Advisory

**For existing projects:**
- No action needed — examples are purely additive
- Files are reference-only and deletable once understood

---

## v2.2.0 — Release Readiness Review

**6-phase ceremony ensuring product readiness before shipping.**

### Changes
- Added `_quality/RELEASE_REVIEW.md` — full release review protocol
- Added Gate 9: Release Readiness Review to `_quality/QUALITY_PROTOCOL.md`
- Added Release Review Trigger to `.claude/RUNBOOK.md`
- Added Release Protocol section to `.claude/WORKFLOW.md`

### Phases
1. **Evidence Collection** — verify all pre-build artifacts exist
2. **Cross-Surface Audit** — consistency across screens
3. **System-Level Gates** — holistic run of Gates 3, 4, 5, and 7
4. **Synthesis Verification** — Gate 6 artifact readiness
5. **Human Review** — Professional Embarrassment, Demo, Screenshot, Peer, First Impression tests
6. **Sign-Off** — explicit human "Ship [version]" confirmation

### Trigger Conditions
- Mandatory: v1.0 releases, major version bumps, minor versions with new screens
- Automatic: Claude Code initiates when all screens pass Gate 2 with no unresolved P0/P1
- Manual: Human can trigger at any time

### Upgrade Advisory

**For existing projects:**
- Gate 9 is additive — no changes to existing gates
- Review triggers automatically when critique loops complete
- No database changes required

---

## v2.1.0 — Evolution Protocol

**Upstream learning propagation — how the starter kit learns from the projects it creates.**

### Changes
- Added `EVOLUTION.md` — upstream learning propagation protocol
- Added `_decisions/DIVERGENCE.md` — per-project divergence tracking template
- Added Learning Queue as 9th Notion database
- Added `promote` field to Decision Registry entry format
- Added Learning Signals to critique scorecard output
- Added Session Exit Learning Check to govern.md Transition phase
- Added learning capture step to RUNBOOK.md Task Flow
- Updated NOTION.md with Learning Queue documentation

### Upgrade Advisory

**For existing projects (Blueprint, etc.):**
- [ ] Add `promote` field to your `_decisions/REGISTRY.md` entry format
- [ ] Create `_decisions/DIVERGENCE.md` from template and fill version info
- [ ] Update `.claude/NOTION.md` to include Learning Queue database (ID: a469f116334f49389d28b0004b60366b)
- [ ] Update `.claude/RUNBOOK.md` task flow to include learning check step

**No action needed:**
- Learning Queue Notion database is workspace-level (shared across all projects)
- Critique and session exit hooks only need to exist in the template; Claude reads them from project knowledge

---

## v2.0.0 — Structural Expansion

**16 amendments adding new directories and capabilities for enterprise-grade documentation systems.**

### AMD-001: Surface Registry
- New `_surfaces/` directory
- `REGISTRY.yaml` for SURF-NNN tracking
- `SPEC_TEMPLATE.md` for surface specifications
- Links surfaces to entities, actions, states, tests

### AMD-002: Traceability Graph
- New `_quality/TRACE.yaml`
- Maps REQ → DEC → SURF → TEST → INV
- Traceability checks added to Gate 4

### AMD-003: Non-Functional Requirements
- New `_nfr/` directory with 4 YAML files
- `PERFORMANCE.yaml` — response time, throughput, resource budgets
- `RELIABILITY.yaml` — availability, recovery, fault tolerance
- `SECURITY.yaml` — auth, data protection, audit logging
- `PRIVACY.yaml` — regulatory compliance, data subject rights
- NFR checks added to Gate 0 and Gate 5

### AMD-004: Gate Structured Output
- New `_artifacts/gates/` directory
- `GATE_OUTPUT_TEMPLATE.yaml` for standardized gate results
- Enables automation and audit trail

### AMD-005: Immutable Build Logs
- New `_runs/` directory
- `README.md` with retention policy
- `RUN_TEMPLATE.yaml` for build run logging
- Append-only for audit integrity

### AMD-006: Cross-Surface Coherence Automation
- Automation guidance added to Gate 8
- References Surface Registry for automated checks
- Clarifies what automation can/cannot verify

### AMD-007: Failure-Mode Catalog
- New `_resilience/` directory
- `FAILURE_MODES.md` for cross-cutting failure scenarios
- Graceful degradation patterns
- Error communication guidelines

### AMD-008: User Research Integration
- New `_research/` directory
- `INTERVIEW_TEMPLATE.md` for user interviews
- `USABILITY_TEST_TEMPLATE.md` for usability testing
- `COMPETITIVE_ANALYSIS_TEMPLATE.md` for competitor analysis
- `PERSONA_TEMPLATE.md` for user personas

### AMD-009: Responsive Behavior Specification
- New `_ui/RESPONSIVE.md`
- Breakpoint system, adaptation strategies
- Component adaptation rules, touch targets
- References archetypes without redefining them

### AMD-010: Internationalization Guidance
- New `_ui/I18N.md`
- Text externalization, expansion planning
- Date/time/number formatting, pluralization
- References `_ui/layouts/RTL.md` for RTL specifics

### AMD-011: Artifact Namespace Organization
- New subdirectories: `_artifacts/gates/`, `critique/`, `synthesis/`, `specs/`
- New `_artifacts/README.md` with organization guide
- Clear separation of artifact types

### AMD-012: Client Presentation Protocol
- New `_artifacts/DELIVERY.md`
- Pre-delivery checklist
- Artifact type expectations
- References SYNTHESIS.md and LAW-013

### AMD-013: Quick-Reference Navigation Card
- New `QUICKREF.md` at root
- Fast lookup for common tasks
- Navigation aid (references only, no definitions)
- ID schemes, common commands, key principles

### AMD-014: Version Migration Guide Template
- New `MIGRATION_TEMPLATE.md` at root
- Step-by-step migration structure
- Pre/post checklists, rollback procedure

### AMD-015: Authority Boundary Clarification
- Authority Boundary section added to `.claude/RUNBOOK.md`
- Clarifies what starter kit owns vs product owns
- Boundary rules for conflict resolution

### AMD-016: Lesson Promotion Protocol
- Lesson Promotion Protocol added to `.claude/WORKFLOW.md`
- Criteria for promoting learnings from runs to LEARNING.md
- Promotion process and template
- Links `_runs/` to `_quality/LEARNING.md`

### Decision Registry
- DEC-009: v2.0.0 Structural Expansion (this release)

### Migration
No breaking changes. All new directories and files are additive.

---

## v12.13.0 — Cross-Surface Coherence + Build Intelligence

**Closing the remaining gaps from the 11-question stress test.**

### Cross-Surface Coherence (#6)

Surfaces can now individually pass critique but still fail as a system. Gate 8 catches contradictions between sibling surfaces.

**New Gate:**
- Gate 8: Cross-Surface Coherence Audit (before release, multi-surface products)

**New Invariants:**
- CS-001 to CS-005 (Cross-Surface Coherence)

**Critique Awareness:**
- P1 flags added for terminology/status/navigation mismatches to surface early for Gate 8

**Cross-Surface Test:**
> Pick any entity. View it on every surface where it appears.
> Does it look like the same entity made by the same team?

### Build Intelligence (#7/#8)

New file `_quality/LEARNING.md` captures predictive patterns — what signals predict build success or failure before the critique loop runs.

**Contains:**
- Early Warning Signals (11 patterns that predict critique failures)
- Success Patterns (6 patterns that predict high scores)
- Common Traps (4 recurring mistakes)

**Key insight:** This file teaches evaluation thinking, not compliance. It grows over time as patterns emerge.

### Completeness Target Declaration (#3)

Surfaces now declare their completeness target at Gate 0: Full, Scoped, or Foundation.

**Changes:**
- Gate 0 Pre-Creation checklist: completeness target required
- Critique card header: completeness target displayed
- Gate 5 measures against declared target, not implicit 100%
- Foundation target cannot ship in production releases

### Migration

No breaking changes. All existing surfaces are implicitly at Full completeness target.

### Updated Counts

- Gates: 9 (was 8) — +Gate 8: Cross-Surface Coherence
- Invariants: +CS-001 to CS-005
- Files: +`_quality/LEARNING.md` (replaces Post-Build Learning Protocol)

---

## v12.12.0 — Stability Declaration

**Foundational structures frozen. Intelligence layer remains open.**

### Core Insight

Compounding systems need fixed points. If foundational structures change every release, references break silently, agents cannot build reliable mental models, and quality improvements never settle into muscle memory. The system has reached structural maturity — time to freeze the foundations and evolve only within them.

### Frozen Structures

| Structure | Why frozen |
|-----------|------------|
| **Laws (LAW-001 to LAW-013)** | 13 laws are sufficient. Refinement yes, restructuring no. |
| **Gate sequence (Gate 0–7)** | 8 gates cover the build lifecycle. Degraded modes can be added within. |
| **Critique loop (BUILD → CRITIQUE → PATCH → VERIFY → SHIP)** | 5 phases are complete. Modes can be added within. |
| **Three Absolutes** | Definitional. Not subject to governance. |
| **Meta-rules** | 5 meta-rules are sufficient. Clarification yes, addition no. |

### What Remains Open

- Invariant categories and IDs
- Scoring dimensions
- Expectation framework contracts and tests
- Extension system and product classes
- Presets, primitives, layouts, patterns
- Degraded modes and relief valves

### Amendment Process

Unfreezing requires: written argument that current structure **cannot accommodate** the need, impact analysis, and explicit approval in Decision Registry with stability: `amendment`. The bar is deliberately high.

### Migration

No breaking changes. This change restricts future structural evolution, not current functionality.

---

## v12.11.0 — Graceful Degradation

**4 additions creating honest paths for when full compliance isn't possible within constraints.**

### Core Insight

Stress test revealed the system deadlocks under simultaneous time pressure, late requirements, and incomplete specs — because every gate is binary (pass/fail) with no acknowledged middle state. **Tracked debt is better than hidden shortcuts.**

### Changes

| Change | File(s) | Purpose |
|--------|---------|---------|
| **Gate 0 Degraded Mode** | `QUALITY_PROTOCOL.md` | EIL-Lite protocol for late-arriving capabilities when full EIL isn't possible |
| **Sanctioned Expansion** | `QUALITY_PROTOCOL.md` | Converts drift detection from blocker to documentation requirement for externally-required elements |
| **Single-Cycle Mode** | `LOOP.md` | Reduced critique protocol with must-pass/degraded-but-tracked/may-defer tiers |
| **Hard Stop Criteria** | `QUALITY_PROTOCOL.md` | Explicit conditions that override all modes and require immediate escalation |

### Design Principle

**The system doesn't weaken rules under stress — it creates honest, tracked paths for partial compliance.** EIL-Lite produces debt, not exemption. Single-Cycle Mode produces accountability through documentation, not shortcuts. Hard Stops prevent shipping harm regardless of time pressure.

### New Concepts

| Concept | Definition |
|---------|------------|
| **EIL-Lite** | 30-minute abbreviated EIL with deferred cascade analysis, creates P1 debt |
| **Sanctioned Expansion** | Client-required elements bypass drift block via Decision Registry, not via exemption |
| **Single-Cycle Mode** | Must-Pass + Degraded-but-Tracked + May-Defer tiers with explicit debt capture |
| **Hard Stop** | Conditions that override all modes and require human escalation |

### Migration

No breaking changes. All additions provide new paths — they don't modify existing flows. Teams not under stress conditions can ignore these mechanisms entirely.

---

## v12.10.0 — Anti-Gaming Tightenings

**6 targeted edits converting self-assessed checks into evidence-based accountability.**

### Core Insight

Red team simulation revealed that a lazy agent could pass all quality gates through template compliance — writing hollow artifacts that technically exist without meaningful content. The fix: transform yes/no self-assessment into fill-in-the-blank requirements that force specificity.

### Changes

| Change | File(s) | Purpose |
|--------|---------|---------|
| **Falsifiable assumptions** | `QUALITY_PROTOCOL.md` | Gate 0 assumptions must be falsifiable, not generic truths |
| **Named focal point** | `RUBRIC.md` | Visual Craft Score 4 requires naming and justifying the primary focal point |
| **Action field in Surprise Test** | `LOOP.md` | Surprises must produce action or justify why no action needed |
| **Named comparator in Agency Test** | `QUALITY_PROTOCOL.md` | "Would agency ship?" becomes "name a peer product screen this matches" |
| **Copy/avoid extraction** | `QUALITY_PROTOCOL.md` | Peer context requires naming patterns adopted AND deliberately avoided |
| **Generic CTA = P1** | `PROMPT.md` | "View All", "Learn More", "Get Started" without context classified as P1 |

### Design Principle

**Specificity is harder to fake than affirmation.** The pattern across all six changes: replace "is X good?" with "show me evidence of X."

### Migration

No breaking changes. All changes tighten existing mechanisms per LAW-009 (Replacement Before Addition).

---

## v12.9.0 — System Integrity

**7 changes improving system coherence and reducing duplication.**

### Core Insight

System integrity means: one source of truth, governed expansion mechanisms, and explicit processes for change.

### Changes

| Change | File(s) | Purpose |
|--------|---------|---------|
| **CONSTRAINTS_INDEX.yaml** | `CONSTRAINTS_INDEX.yaml` | Reference-only constraint locator for AI agents — points to sources, never restates rules |
| **Constitution deduplication** | `docs/CONSTITUTION.md` | Removed verbatim law text; now references `_rules/laws.yaml` only |
| **Deprecation Protocol** | `GOVERNANCE.md` | Lifecycle for retiring system elements (Active → Deprecated → Removed) |
| **Law numbering note** | `_rules/laws.yaml` | Explains why LAW-009/010 are in locked tier (historical reclassification) |
| **Extension status fields** | `_extensions/*/CONTRACT.md` | All 5 extensions now declare `status: active` |
| **Surprise Test** | `_critique/LOOP.md` | Required pre-check before evaluating stop conditions — disrupts autopilot scoring |
| **Extension Exceptions mechanism** | `SYSTEM_CONTRACT.md` | Replaced hardcoded creative-tool exception with governed extension exception system |

### New Files

| File | Purpose |
|------|---------|
| `CONSTRAINTS_INDEX.yaml` | Lightweight index of all hard constraints by category |

### Glossary Additions

| Term | Definition |
|------|------------|
| **Deprecation** | Lifecycle state where an element is discouraged for new work |

### Migration

No breaking changes. All changes tighten constraints or reduce duplication.

---

## v12.8.0 — System Intelligence Release

**38 additions that teach the system to think about design, not just check rules.**

### Core Insight

v12.7.0 asks "Is this well-built?" — v12.8.0 adds "Does this match what it was supposed to be?" and "Does it work for real humans in real situations?"

### Expectations Framework (`_expectations/FRAMEWORK.md`)

- **Spec Interrogation Protocol** — Mandatory Step 0: treat spec as hypothesis, extract assumptions, expand problem space
- **Screen Intent Declaration** — Declare each screen's role, primary UI object, dominance requirement, vocabulary gate
- **Emotional Intent Declaration** — Declare intended tone per screen with calibration test
- **Outcome Declaration** — Every screen declares its intended user state change
- **Failure Scenario Modeling** — Model 3–5 user-perspective failure scenarios before building
- **User Intelligence Graph** — Five-layer framework (functional, cognitive, emotional, aesthetic, behavioral) for understanding users
- **Continuation Surface & User Momentum** — Surface type classification, momentum killers, momentum test

### Tests (`_expectations/TESTS.md`)

- **Inner Monologue Test enrichments** — Alignment checks + multi-persona simulation
- **Weight-Importance Alignment Test** — Visual weight vs. information importance
- **Purposeful Space Test** — Every element of whitespace serves a function
- **User State Awareness Test** — Six universal user states with simulation passes
- **Diminishing Novelty Test** — Maturity curve evaluation
- **Delight Delta Test** — Strategic, not decorative, delight moments
- **Real-Data Stress Test** — Seven stress conditions with realistic data
- **Attention & Cognitive Cost Test** — Cognitive energy budget evaluation
- **Concept Budget Test** — Concept inventory with collapse technique
- **Second-Order Consequences Test** — What happens when the design succeeds?

### Critique (`_critique/PROMPT.md`, `_critique/LOOP.md`)

- **Flow Architecture Compliance** — Conditional dimension checking screen intent alignment
- **Shortcut Detection** — Catches unjustified familiar-pattern reuse
- **Copy as Design Material** — Evaluates microcopy as design decisions
- **Attention Cost dimension** — Evaluates whether each surface justifies its mental energy demand
- **Confidence Flagging** — Agent marks 2–3 lowest-confidence decisions per surface
- **Product Spec as Critique Input** — Formal input to critique loop

### Quality (`_quality/QUALITY_PROTOCOL.md`)

- **Design Reasoning Protocol** — Brief rationale for key decisions
- **Design Exploration Protocol** — 2–3 approaches for high-leverage surfaces
- **Constraint-as-Design** — Evaluate flexibility as a cost

### UI & Interaction (`_ui/SYSTEM.md`, `_interaction/CHOREOGRAPHY.md`)

- **Information Grouping** — Unit reading principle with grouping rules
- **Progressive Trust Architecture** — Trust accumulation order and budget by journey stage
- **Transition Design** — Four dimensions of intentional transition design

### Invariants (`_invariants/REGISTRY.md`)

- **FA-001 to FA-004** — Flow Architecture invariants (conditional)
- **AS-001 to AS-003** — Affordance State invariants (toggle/switch consistency)

### New Files

| File | Purpose |
|------|---------|
| `_quality/COHERENCE.md` | Cross-surface coherence audit |
| `_quality/LEARNING.md` | Post-build learning protocol |

### Workflow (`.claude/WORKFLOW.md`, `.claude/NOTION.md`)

- **Reference Precision** — Cite specific sections, not whole files
- **Intent Drift Detection** — Re-validate understanding during long builds
- **Gap Recognition** — Document unsolvable problems as governance proposals
- **Visual Verification** — Evaluate rendered output, not code
- **Flow Architecture in Notion** — How to declare screen intent in Notion specs

---

## v12.7.0 — Moats Framework

**Strategic layer for building structurally defensible products.**

### Core Insight

> Moats should come from value creation, not value extraction.

Products with structural competitive advantages (moats) are harder to replace. This release adds optional guidance for building moat-conscious products without adding complexity for simpler projects.

### Moat Types

| Type | Definition | Product Lever |
|------|------------|---------------|
| **Special Know-how** | Encoded judgment competitors can't copy | Opinionated defaults, decision memory, feedback loops |
| **System Rigidity** | Product becomes structurally central | Canonical artifacts, stable exports, workflow integration |
| **Scale** | Value compounds or costs decrease | Compounding features, variance reduction, quality gates |
| **State Granted** | Regulatory barriers (usually N/A) | Compliance outputs |

### New Files

| File | Purpose |
|------|---------|
| `_strategy/MOATS.md` | Moat guidelines and tests |
| `_strategy/priorities.yaml` | Project-specific moat priorities (template) |
| `_presets/moat-conscious.yaml` | Opt-in moat awareness preset |

### New Dimension

**Dimension 15: Moat Alignment (Optional)**

- Only active when `moat-conscious` preset enabled
- Minimum score: 3
- Tests: Compounding, Replaceability, Integration, Memory

### New Gate

**Gate 7: Stickiness Audit (Optional)**

- Only applies when `moat-conscious` preset enabled
- Checks moat contribution, ethical framing, export stability

### New Invariants

| ID | Invariant |
|----|-----------|
| MT-001 | Features undermining moats require justification |
| MT-002 | Moat claims are testable, not marketing |
| MT-003 | Export formats are contracts |
| MT-004 | Decision rationale is captured |

### Integration Points

- **Pre-Build Flow:** Stickiness Assessment (4 questions) added to `_expectations/FRAMEWORK.md`
- **Critique Loop:** Dimension 15 added to `_critique/PROMPT.md` and `RUBRIC.md`
- **Quality Protocol:** Gate 7 added to `_quality/QUALITY_PROTOCOL.md`
- **Invariants:** MT-001 to MT-004 added to `_invariants/REGISTRY.md`

### Migration

No breaking changes. Moat features are entirely opt-in via `moat-conscious` preset.

To enable:
1. Add `moat-conscious` to preset chain in `config/manifest.yaml`
2. Fill `_strategy/priorities.yaml` with your moat priorities
3. Set `priorities.yaml` status to `active`

---

## v12.6.0 — Efficiency Release

**Major restructure for reduced redundancy and improved discoverability.**

### Changes

- **CHANGELOG.md** — Version history extracted from README (~800 lines saved)
- **_expectations/** — User expectation framework extracted from SYSTEM.md (~600 lines)
- **.claude/WORKFLOW.md** — Claude Code workflow orchestration guidance added
- **Leaner README** — Setup-focused, ~180 lines (was 1,020)
- **Leaner SYSTEM.md** — UI-focused, ~1,500 lines (was 2,581)

### New Files

| File | Purpose |
|------|---------|
| `CHANGELOG.md` | Version history (you are here) |
| `.claude/WORKFLOW.md` | Execution guidance for Claude Code |
| `_expectations/FRAMEWORK.md` | Core expectation framework |
| `_expectations/CONTRACTS.md` | All 10 user contracts |
| `_expectations/TESTS.md` | Inner Monologue, Peer, Agency tests |

### Migration

No breaking changes. All principles preserved, just reorganized.

---

## v12.5.13 — Synthesis Artifact

**Artifact-First Design (LAW-013):**

The system is now designed backward from the artifacts it must produce, not forward from features.

### Core Insight

> Define the synthesis artifact (the deliverable) before building features. Features exist to make artifact sections true.

A **Synthesis Artifact** is a human-readable, professionally presentable representation of the system that accurately reflects decisions, intent, maturity, and constraints — suitable for external delivery without verbal explanation.

### Reverse Engineering Mandate

Instead of asking "What feature should I build?", ask "What must exist for the artifact to be true?"

For each artifact section, identify:
- What information is required?
- What decisions must exist?
- What states must be tracked?
- What is currently missing?

### Section Maturity Model

| State | Meaning | Artifact Behavior |
|-------|---------|-------------------|
| **Renderable** | Can be produced truthfully now | Include fully |
| **Partial** | Some content exists, gaps identified | Include with explicit gaps |
| **Placeholder** | Section exists but content is aspirational | Mark as "In Progress" |
| **Blocked** | Cannot render due to missing decisions | Show what's blocking |

### Key Tests

- **Agency Test:** Would a premium agency ship this artifact to a demanding client?
- **No Verbal Explanation Test:** If any artifact section would require verbal explanation when shared externally, the section fails.
- **Honesty Principle:** Show what's decided (not hoped), show what's undecided (explicitly), never present placeholders as decisions.

### Gate 6: Artifact Readiness

Before external delivery:
- Artifact sections defined with requirements
- Product features trace to artifact sections
- Renderable sections can be produced truthfully
- Undecided areas explicitly marked
- Artifact passes Agency Test

**Violation:** Artifact shipped with false placeholders = P0

### New Invariants

| ID | Invariant |
|----|-----------|
| SA-001 | Product features must serve artifact sections |
| SA-002 | Artifact sections must be renderable without false placeholders |
| SA-003 | Undecided areas are explicitly marked |
| SA-004 | External delivery requires no apology |
| SA-005 | Artifact reflects actual state, not aspirational state |
| SA-006 | Artifact requires no verbal explanation |

### New Files

| File | Purpose |
|------|---------|
| `_artifacts/SYNTHESIS.md` | Synthesis Artifact definition and principles |

### Dimension 14: Synthesis Artifact

The critique loop now has 14 dimensions. Minimum score to ship: **4**

---

## v12.5.12 — Expectation Invention Loop

**Cascade Thinking for New Capabilities:**

When introducing new capabilities, ask: "What expectations does this capability create?" before "Does this surface meet expectations?"

### Core Insight

> Any new capability creates expectations; those expectations must be examined before the capability is finalized.

Every shipped feature creates secondary expectations, then tertiary expectations, then norms. EIL ensures we think through the cascade before shipping.

### The 5 Steps

```
1. IMMEDIATE EXPECTATIONS → What does existence of this capability imply?
2. SECONDARY EXPECTATIONS → What do users expect after using it twice?
3. TRUST EXPECTATIONS → What must exist so user does not lose confidence?
4. NON-GOALS → What must user NOT assume?
5. CASCADE DECISION → Classify: Must Build Now / Must Defer / Must Prevent
```

### New Feature Classification: Prevented

| Classification | Definition | Action |
|----------------|------------|--------|
| **Expected** | User would assume this exists | Must build or explicitly defer |
| **Helpful** | Improves experience but not assumed | May defer with explanation |
| **Speculative** | Nice idea, no user expectation | Reject with documented reasoning |
| **Dangerous** | Adds bias, pressure, or false confidence | Forbidden |
| **Prevented** | Assumption that must NOT be true | Actively block in UI |

### New Invariants

| ID | Invariant |
|----|-----------|
| EIL-001 | New capabilities run Expectation Invention Loop |
| EIL-002 | Prevented assumptions are documented |
| EIL-003 | Secondary expectations are examined |
| EIL-004 | Trust expectations are examined |
| EIL-005 | EIL outputs feed Pre-Build |

### Artifact Location

EIL artifacts stored in `_decisions/eil/[capability-name].yaml`

---

## v12.5.11 — User Expectation Framework

**Bounded Curiosity — Explore Before Building:**

Surfaces that pass all invariants can still feel hollow. This version transforms the system from reactive (critique after building) to generative (explore before building).

### LAW-012: Bounded Curiosity

> The system must explore more than it builds, and explain what it chooses not to build.

### Quality Bar

> The goal is to match user expectations. A surface is expectation-complete when every Expected feature exists or is explicitly deferred, and no Speculative or Dangerous features were added.

### Pre-Build Exploration Flow

```
0. EXPECTATION INVENTION LOOP → If new capability, run EIL first
1. PEER CONTEXT → What do comparable products do?
2. CANDIDATE FEATURES → What might users expect?
3. FEATURE CLASSIFICATION → Expected / Helpful / Speculative / Dangerous / Prevented
4. ABSENCE DETECTION → What's missing by category?
5. EXPECTED ACTIONS → What would user want to do?
6. SURFACE ROLE REQUIREMENTS → What must this surface type include?
7. INNER MONOLOGUE TEST → Simulate user thinking
8. RESTRAINT GATE → Filter through restraint principles
9. BUILD / DEFER / REJECT / PREVENT LISTS → Document decisions
```

### Feature Classification System

| Classification | Test |
|----------------|------|
| **Expected** | Would user complain if missing? |
| **Helpful** | Would user be delighted if present? |
| **Speculative** | Would user ever ask for this? |
| **Dangerous** | Does this violate restraint principles? |
| **Prevented** | Would user wrongly assume this exists? |

### Surface Role Requirements

| Surface Type | Must Include |
|--------------|--------------|
| **Index/Hub** | Create, open, status summary, empty state, search (if >5) |
| **Detail/Overview** | Key info, primary action, back nav, edit affordance |
| **Workspace/Editor** | Save indication, undo, manipulation affordances, exit clarity |
| **Dashboard/Report** | Metrics with drill-down, time context, freshness signal |
| **Settings/Config** | Current values, save mechanism, reset option |
| **Onboarding/Flow** | Progress indication, current step, forward action |

### Inner Monologue Test

| Question | Must Have Confident Answer |
|----------|---------------------------|
| "What is this page?" | Yes — or orientation fails |
| "What can I do?" | Yes — or purpose unclear |
| "What would I click first?" | Yes — or affordances unclear |
| "What would confuse me?" | Nothing — or fix those things |
| "What would build trust?" | Nothing major missing |

### New Invariants

UE-001 to UE-011 (User Expectations)

### Updated Audit System

- 13 scoring dimensions (was 12): +User Expectations
- Surface Readiness Gate: 42 checks (was 31)

---

## v12.5.10 — Symbol Grammar

**Visual Language Systems:**

Status symbols and progress indicators are visual languages requiring grammatical consistency.

### Symbol Grammar Rules

| Rule | Requirement |
|------|-------------|
| **Single Primitive Family** | All symbols use same geometric basis |
| **Consistent Optical Weight** | Same bounding box and visual mass |
| **Single Semantic Axis** | One variable changes (fill, weight, or count) |
| **Monotonic Progression** | Visual order = semantic order |
| **No Unintended Directionality** | Directional symbols only for directional concepts |

### Progress Semantics

> When multiple progress indicators appear on a surface, one must be declared primary.

**The Progress Sentence Test:**
> Any progress representation must be expressible as: "Of [total], [X] are [state A], [Y] are [state B], and [Z] are [state C]."

### New Invariants

- VO-005 to VO-007 (Symbol Vocabulary)
- SY-001 to SY-004 (Symbol Grammar)
- PS-001 to PS-003 (Progress & Status)

### Updated Audit System

- 12 scoring dimensions (was 10): +Symbol Grammar, +Progress & Status
- Surface Readiness Gate: 31 checks (was 21)

---

## v12.5.9 — Vocabulary Comprehension

**The Language Contract:**

Users must understand the language the product speaks.

### Core Principle

> A world-class product is not one where users eventually learn the language — it's one where the language teaches itself.

### The First Encounter Test

> If an intelligent, motivated new user sees this term, can they either:
> 1. Understand it immediately, or
> 2. Find explanation without leaving the surface?
> If neither → fail.

### Four Vocabulary Dimensions

| Dimension | Question |
|-----------|----------|
| **Legibility** | Is the term understandable? |
| **Discoverability** | Can explanation be found in-context? |
| **Consistency** | Does the term mean the same thing everywhere? |
| **Neutrality** | Is the term descriptive, not judgmental? |

### New Invariants

VO-001 to VO-004

### Updated Audit System

- 10 scoring dimensions (was 9): +Vocabulary Comprehension
- Surface Readiness Gate: 21 checks (was 17)

---

## v12.5.8 — Visual Quality Contract

**The Perception Layer:**

Users judge visual quality in ~500ms — before they read a single word.

### Core Principle

> Visual quality is judged by coherence, restraint, and inevitability — not novelty or decoration.

### Five Visual Dimensions

| Dimension | User's Question |
|-----------|-----------------|
| **Hierarchy** | Do I know where to look? |
| **Rhythm** | Does this feel measured? |
| **Density** | Does this fit the task? |
| **Consistency** | Does this belong together? |
| **Craft** | Was this designed deliberately? |

### Visual Quality Tests

| Test | Question |
|------|----------|
| Squint Test | Is hierarchy visible when page is blurred? |
| Peer Test | Could this exist in Linear/Stripe/Notion without visual shock? |
| Craft Test | Would a senior designer apologize for anything? |
| Screenshot Test | Would you include this in a pitch deck? |

### New Invariants

VQ-001 to VQ-008

### Updated Audit

Surface Readiness Gate: 17 checks (+5 Visual Quality)

---

## v12.5.7 — Meta-Systems

**User Psychology Over Time:**

### Exit Awareness Check

> "If the user leaves now, will they feel oriented or abandoned?"

### Reversibility Principle

| Action Type | Expectation |
|-------------|-------------|
| Reversible | Default — no special marking |
| Soft-reversible | Show undo window |
| Hard-reversible | Warn before action |
| Irreversible | Require explicit confirmation |

### Professional Embarrassment Gate

> The system must never ship a surface that a senior professional would feel the need to apologize for.

### New Invariants

- EA-001 to EA-004 (Exit Awareness)
- RV-001 to RV-004 (Reversibility)

### Updated Audit

Surface Readiness Gate: 12 checks (+Exit Awareness, +Reversibility)

---

## v12.5.6 — Complete Expectation Framework

**10 User Contracts:**

| Contract | Question |
|----------|----------|
| **Orientation** | Where am I? |
| **Action** | What can I do? |
| **Information** | What will I learn? |
| **Explanation** | How do I understand? |
| **Confidence** | Can I trust this? |
| **Freshness** | Is this current? |
| **Feedback** | Did that work? |
| **Prediction** | What will happen? |
| **Continuity** | Does it remember me? |
| **Completion** | When is this done? |

### New Invariants

- OR-001 to OR-005 (Orientation)
- CF-001 to CF-005 (Confidence)
- FR-001 to FR-003 (Freshness)
- FB-001 to FB-004 (Feedback)
- PR-001 to PR-004 (Prediction)
- CN-001 to CN-004 (Continuity)
- CP-001 to CP-003 (Completion)

---

## v12.5.5 — User Expectation Framework

- Action Contract + Information Contract
- Dead Surface Test
- Information Completeness Test
- Explanation System with Explanation Ladder
- New invariants: EX-001 to EX-005, IX-001 to IX-006, XP-001 to XP-006

---

## v12.5.4 — Narrative Output

- Four guarantees: Intent Explicit, Structure Progressive, State Interpretable, Omission Intentional
- Audit output conventions with dated folders
- Narrative Output Success Test

---

## v12.5.3 — Intent Modeling

- LAW-011: Pre-Creation Protocol
- Gate 0: Pre-Creation verification
- Intent Alignment dimension (9 dimensions)
- Output Intent Framework (Decision / Display / Export / Narrative)
- Overview Page Contract pattern

---

## v12.5.2 — Completeness & Restraint

**Completeness Laws:**
- LAW-007: Affordance Integrity — no dead buttons, links, or chevrons
- LAW-008: Primary Flow Completion — flows work before surfaces ship

**Restraint Laws:**
- LAW-009: Replacement Before Addition — justify why existing can't be modified
- LAW-010: Negative Capability — OK to not support a use case

**Audit Framework:**
- Affordance Invariants (AF-001 to AF-007)
- Gate 5: Completeness Audit
- Completeness dimension in critique

**Taste Encoding:**
- Silent Success feedback philosophy
- Feature Gravity principle
- Time-to-First-Value guidance
