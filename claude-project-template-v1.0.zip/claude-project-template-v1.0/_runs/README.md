# Build Runs

> Immutable log of build executions for audit and learning.

---

## Purpose

This directory stores immutable records of build runs. Each run captures:
- What was built
- What gates were passed
- What issues were found and resolved
- What decisions were made

## Immutability Rule

**Build logs are append-only.** Once a run file is created:
- Do NOT modify existing entries
- Do NOT delete run files
- Amendments are added as new entries, not edits

This preserves the audit trail and enables post-mortem analysis.

## File Naming

```
RUN-{YYYYMMDD}-{sequence}.yaml
```

Examples:
- `RUN-20260206-001.yaml` — First run on Feb 6, 2026
- `RUN-20260206-002.yaml` — Second run on Feb 6, 2026

## When to Create a Run Log

Create a run log when:
1. A surface passes Gate 5 (Completeness Audit)
2. A build passes Gate 6 (Artifact Readiness)
3. A release passes Gate 8 (Cross-Surface Coherence)
4. Any significant build milestone is reached

## Template

See `RUN_TEMPLATE.yaml` for the standard format.

## Usage for Learning

Run logs feed into `_quality/LEARNING.md`:
- Patterns that worked are extracted
- Common traps are identified
- Early warning signals are refined

See AMD-016 Lesson Promotion Protocol in `.claude/WORKFLOW.md`.
