<!-- TEMPLATE STATE: This file contains placeholders. Run Bootstrap (see .claude/PROTOCOL.md) to fill them for your project. -->

## Workflow Protocol

### Session Start
1. Declare session intent (one sentence: what is this session for?)
2. Determine mode:
   - **Quick:** Bug fix, config change, single small component (<2 hours, no design decisions)
   - **Full:** New feature, design exploration, multi-component work, anything requiring decisions
3. Escalation triggers: second feature touched, design decision emerges, >2hr estimate, contradiction detected.
See .claude/PROTOCOL.md for full criteria and protocol definitions.

### Notion Access (REQUIRED)
- Project Home: [URL]
- Product Strategy — Current State Summary: [URL]
- Product Strategy — Full History: [URL]
- Feature Registry: [DB URL]
- Journal DB: [DB ID]
- Decisions DB: [DB ID]
- Deferred DB: [DB ID]
- Glossary: [URL]

### Linear Access (REQUIRED)
- Team: [name]

### GitHub Access (REQUIRED)
- Repo: [org/repo-name]
- Main branch: main
- Feature branch pattern: type/kebab-description

### Active Decisions (top 10–20)
[Maintain a short list of the most important active decisions here.]

**Refresh triggers:**
- At session end if decisions were created
- Immediately when Contradiction Protocol supersedes a listed decision
- During periodic integrity checks (catch-up only)

**How to refresh:** Query the Decisions database for `Status: active`, sorted by date descending. Replace this list with the top 10-20 most relevant (global decisions always, plus feature-relevant). If in degraded mode, append decisions from this session's handoff file with `[PENDING SYNC]` marker until backfill completes.

**For new projects:** If no decisions exist yet, leave this section as "[No decisions yet]".

- DEC-YYYYMMDD-A-XXXX: [one-line summary]
- DEC-YYYYMMDD-A-XXXX: [one-line summary]
- ...

### Standing Delegations (if any)
[List active standing delegations. Remove when expired/revoked.]

- [delegation description] — expires [date] — DEC-YYYYMMDD-A-XXXX
- ...

### Quick Session Checklist
1. Declare session intent
2. Connectivity check (Git + handoff; Notion/Linear if needed). Log failures.
3. Read handoff/from-chat/ for pending items (if empty, proceed)
4. Check relevant Linear issue(s) (if none exist, proceed)
5. If session touches UI: Read `DESIGN_ROUTER.yaml` → load referenced design files for affected surface types
6. Do the work
7. Write handoff file to `handoff/<feature>/from-code/` (create folder if new feature) or `handoff/_general/from-code/` for cross-cutting work. Even one-liner, starts with Intent:
8. Update Linear issue if one exists, or create issue if task needs tracking. Create Journal entry (even one line)

### Full Session Checklist
1. Declare session intent
2. Run full Pre-Build Connectivity Checklist. Log failures.
3. Read Project Home → current focus (if empty, note "focus not yet defined")
4. Read Product Strategy — Current State Summary (if empty/not created, note "strategy pending"; if stale, regenerate first)
5. Read last 5 relevant Journal entries filtered by feature, Action Required, type (if none exist, skip — expected for new projects)
6. Read active Decisions — global always, feature-scope when relevant (if none exist, note "first session — no prior decisions")
7. Read handoff/from-chat/ for pending specs or feedback (if empty, proceed)
8. Check Linear priorities (if no issues exist, proceed)
9. If session touches UI: Read `DESIGN_ROUTER.yaml` → load referenced design files for affected surface types
10. Do the work
11. Create Journal entry (full format)
12. Update Linear statuses + append Log rows (if issues exist); create issue if task needs tracking
13. Create Linear issues for follow-up items
14. Log decisions made (respect authority thresholds; include authority note + detection signal)
15. Save session summary to `handoff/<feature>/from-code/` (create folder if new feature) or `handoff/_general/from-code/`
16. Update Feature Registry if changed; create entry if building a new feature
17. Contradiction check if decisions were made (including CLAUDE.md update)
18. Post-Session Self-Audit (decisions + signals, authority actions, contradictions, CLAUDE.md, glossary terms)

### Workflow Invariants (Non-Negotiable)
- NEVER edit Journal entries, Decision content, or Deferred content
- NEVER delete anything in Notion or Linear
- Corrections → new Journal entry, type = course-correction
- Strategy updates → append new section + add changelog row + Journal link
- Global decisions → ALWAYS get confirmation
- Supersessions → ALWAYS use Contradiction Protocol (including CLAUDE.md update)
- Use Naming Convention for all new entries (see Glossary)
- Auto-created Decisions → ALWAYS include authority note + detection signal in Rationale
- Glossary material changes → ALWAYS create Journal entry BEFORE editing the definition
- Standing delegations → CANNOT override global-scope, supersession, or strategy gates
- Standing delegation references → ALWAYS include delegation Decision ID in authority note
- Uncertain decision detection → Journal entry (decision-context), NEVER auto-create Decision

**Conflict duty:** If the human's request would contradict an active Decision, violate a law in laws.yaml, or skip a Mandatory tier requirement, state the conflict before proceeding. Do not silently comply. Quote the specific Decision, law, or requirement being violated and ask the human to confirm, supersede, or revise.

**Quality gate duty:** Before building or modifying any UI component, read `_rules/laws.yaml` and apply the critique loop defined in `.claude/WORKFLOW.md`. No component is considered complete without scoring ≥ 3 on all five visual quality dimensions (Hierarchy, Rhythm, Density, Consistency, Craft). If a score falls below 3, redesign before proceeding. Read `config/manifest.yaml` for the product's voice and personality — the UI must reflect it.

### Linear Format
- Title: [TYPE] Description
- Description: Split format — editable Summary on top, append-only Log below the separator
- Every status change: append Log row

### Degraded Mode
If Notion/Linear unavailable: work continues, log to handoff files with [BACKFILL] prefix.
Log which tools failed and why in the handoff file.
If Git unavailable: STOP. Fix before proceeding.
Backfill: check for duplicates AND contradictions with entries created during degraded period before syncing.

### Post-Session Self-Audit (Full sessions only)
Before writing handoff file, answer:
1. Decisions created this session — list IDs + detection signals
2. Authority threshold actions — were confirmations obtained?
3. Contradictions — detected? Protocol followed?
4. CLAUDE.md — updated if needed?
5. Glossary terms — any new terms introduced? Registered?
