# Critique Calibration

> What each score level looks like. Use this to calibrate scoring.

---

## How to Use This File

RUBRIC.md defines **what** to check. This file defines **what good looks like** at each level.

For each dimension, this file provides:
- Score boundary definitions (what separates 3 from 4, 4 from 5)
- Generic anti-patterns per score level
- Calibration prompts

---

## Calibration Prompts (Generic)

| Score | Calibration Question |
|-------|---------------------|
| 5 | Would a senior designer at a respected product company use this as an exemplar? |
| 4 | Would they ship this with confidence? |
| 3 | Would they ship this with caveats? |
| 2 | Would they request revisions before shipping? |
| 1 | Would they request a redesign? |

---

## 1. Model Coherence

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Perfect match vs "correct but minor label inconsistencies" |
| 4 vs 3 | All entities/actions/states correct vs "core correct, edges fuzzy" |
| 3 vs 2 | Mostly correct vs "inconsistencies affect user understanding" |
| 2 vs 1 | Fixable gaps vs "fundamental model violations" |

**Anti-patterns by score:**
- Score 2: Phantom actions (UI suggests actions not in model)
- Score 2: State machine gaps (missing transitions user might try)
- Score 1: Wrong entities (displaying data from wrong model)
- Score 1: Permissions ignored (user sees actions they can't perform)

**Calibration check:** "Could I regenerate the truth model from this UI alone?"

---

## 2. Information Architecture

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Exemplary wayfinding vs "clear but minor polish possible" |
| 4 vs 3 | All navigation correct vs "works but some unexpected behaviors" |
| 3 vs 2 | Functional navigation vs "confusing in secondary flows" |
| 2 vs 1 | Usable but frustrating vs "users get lost" |

**Anti-patterns by score:**
- Score 3: Back behavior occasionally unexpected
- Score 2: Breadcrumbs inaccurate or missing deep links
- Score 2: Dead ends in secondary flows
- Score 1: Users cannot reliably return to where they started

**Calibration check:** "Can a new user navigate to any screen and back without confusion?"

---

## 3. Visual Craft

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Exemplar quality (portfolio-worthy) vs "professional, minor polish possible" |
| 4 vs 3 | Consistent and intentional vs "mostly consistent, some spacing drift" |
| 3 vs 2 | Acceptable vs "hardcoded values or invalid tokens present" |
| 2 vs 1 | Inconsistent but fixable vs "chaotic, no clear system" |

**Anti-patterns by score:**
- Score 3: Inconsistent spacing in secondary areas
- Score 2: Hardcoded colors or sizes (not from tokens)
- Score 2: Invalid token combinations (e.g., text-hover)
- Score 1: No clear focal point, competing visual elements

**Calibration check:** "Would this screenshot fit in a pitch deck for a Series A startup?"

---

## 4. Interaction

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Motion enhances understanding vs "correct but unremarkable" |
| 4 vs 3 | All states and motion correct vs "mostly correct, minor gaps" |
| 3 vs 2 | Functional vs "missing states or jarring motion" |
| 2 vs 1 | Gaps noticeable vs "motion broken or focus lost" |

**Anti-patterns by score:**
- Score 3: Missing disabled state explanation
- Score 2: Focus management issues (focus lost after modal close)
- Score 2: Motion feels wrong (too slow, too bouncy)
- Score 1: Keyboard navigation broken

**Calibration check:** "Can a keyboard-only user complete the primary flow without getting stuck?"

---

## 5. Correctness

| Score | Boundary Definition |
|-------|---------------------|
| 5 | Required to ship — no bugs, all data correct |
| 4 | Minor display issues — blocks ship |
| 3-1 | Bugs present — blocks ship |

**Anti-patterns (any = blocks ship):**
- Data calculated client-side that should come from server
- Aggregates don't equal sum of parts
- Labels derived rather than from authoritative source
- Error states silently swallowed

**Calibration check:** "Would an auditor find any data inconsistency?"

**Note:** This dimension has no gradient — it's 5 or it blocks ship.

---

## 6. Accessibility

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | WCAG AA+ with excellent screen reader experience vs "AA compliant" |
| 4 vs 3 | Full compliance vs "main flows accessible, gaps in secondary" |
| 3 vs 2 | Core accessible vs "contrast failures or keyboard gaps" |
| 2 vs 1 | Partially accessible vs "major accessibility failures" |

**Anti-patterns by score:**
- Score 3: Color as sole indicator in some contexts
- Score 2: Contrast failures on secondary elements
- Score 2: Keyboard traps in modals
- Score 1: Screen reader cannot navigate primary flow

**Calibration check:** "Can a screen reader user understand and complete the primary task?"

---

## 7. Performance

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Exceeds budgets, could be benchmark vs "meets all budgets" |
| 4 vs 3 | All budgets met vs "minor budget misses" |
| 3 vs 2 | Acceptable vs "noticeable delays" |
| 2 vs 1 | Slow but usable vs "performance blocks usage" |

**Anti-patterns by score:**
- Score 3: Slight layout shift on load
- Score 2: User notices wait times on common actions
- Score 2: Jank during scroll or animation
- Score 1: Page feels unresponsive

**Calibration check:** "Would a user on 3G mobile give up before completing the task?"

---

## 8. Completeness

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | All affordances work, could demo immediately vs "core complete, minor gaps" |
| 4 vs 3 | Primary flows work end-to-end vs "main path works, secondary gaps" |
| 3 vs 2 | Happy path complete vs "primary affordances have gaps" |
| 2 vs 1 | Partial vs "hollow — too many dead affordances" |

**Anti-patterns by score:**
- Score 3: Secondary navigation elements don't work
- Score 2: "Coming soon" on features user would expect
- Score 2: Buttons that don't do anything
- Score 1: Primary CTA doesn't complete action

**Calibration check:** "Can I demo this to a customer without apologizing?"

---

## 9. Intent Alignment

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Output type perfectly matches purpose, impressive vs "correct, minor alignment issues" |
| 4 vs 3 | Intent clear and served vs "intent recoverable but structure could be better" |
| 3 vs 2 | Adequate vs "intent unclear, speculative building visible" |
| 2 vs 1 | Mismatched vs "wrong output type entirely" |

**Anti-patterns by score:**
- Score 3: Systems enumerated rather than demonstrated
- Score 2: Structure doesn't serve the stated purpose
- Score 2: Built for wrong audience
- Score 1: No evidence of intent modeling before building

**Calibration check:** "Would someone unfamiliar with the brief understand what this is for?"

---

## 10. Vocabulary Comprehension

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Self-teaching, no tooltips needed vs "clear with tooltips for non-obvious terms" |
| 4 vs 3 | Terms consistent and explained vs "core clear, some jargon unexplained" |
| 3 vs 2 | Mostly understandable vs "several opaque terms" |
| 2 vs 1 | Requires domain expertise vs "users cannot understand without external help" |

**Anti-patterns by score:**
- Score 3: Occasional jargon without tooltip
- Score 2: Same word means different things in different places
- Score 2: Status labels with no explanation
- Score 1: Language implies user failure

**Calibration check:** "Would a new hire understand every term on their first day?"

---

## 11. Content Quality

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Every text element is exemplary vs "professional with minor inconsistencies" |
| 4 vs 3 | Clear, specific, voice-consistent vs "functional but some generic patterns" |
| 3 vs 2 | Mostly clear vs "generic text in important places" |
| 2 vs 1 | Generic but present vs "missing or misleading text" |

**Anti-patterns by score:**
- Score 3: "Are you sure?" without naming consequence
- Score 2: "Something went wrong" without next step
- Score 2: "OK / Cancel" on destructive confirmations
- Score 1: No empty state text at all

**Calibration check:** "Would a content designer at a top product company sign off on every piece of text?"

---

## 12. Symbol Grammar

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Systematic, could be exemplar vs "consistent with minor refinements possible" |
| 4 vs 3 | Single family, clear progression vs "mostly consistent, some weight issues" |
| 3 vs 2 | Understandable vs "mixed primitive families" |
| 2 vs 1 | Inconsistent vs "ad-hoc symbol selection" |

**Anti-patterns by score:**
- Score 3: Optical weight slightly inconsistent at small sizes
- Score 2: Area-fill and line-stroke symbols mixed
- Score 2: Non-monotonic progression
- Score 1: Symbols visually unrelated, no grammar

**Calibration check:** "If I added a new status, would I know exactly what symbol to use?"

---

## 12. Progress & Status Semantics

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Exemplary clarity, single primary signal vs "clear, minor hierarchy issues" |
| 4 vs 3 | Primary signal clear, all pass Sentence Test vs "identifiable, some unlabeled ratios" |
| 3 vs 2 | Understandable vs "competing signals, no clear primary" |
| 2 vs 1 | Ambiguous vs "user cannot understand progress" |

**Anti-patterns by score:**
- Score 3: Ratio shown without context ("3/12" not "3/12 approved")
- Score 2: Two progress indicators at same prominence
- Score 2: Evaluative labels ("behind", "unhealthy")
- Score 1: Multiple competing signals, none primary

**Calibration check:** "Can I express every progress indicator as '[X] of [Y] are [state]'?"

---

## 13. User Expectations

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Expectation-perfect, EIL complete if applicable vs "complete with minor gaps in rejection docs" |
| 4 vs 3 | Pre-build followed, features classified vs "some gaps in absence detection" |
| 3 vs 2 | Some pre-build evident vs "expected features missing" |
| 2 vs 1 | Little pre-build evidence vs "hollow or over-featured" |

**Anti-patterns by score:**
- Score 3: Absence detection incomplete for some categories
- Score 2: Expected features missing without explanation
- Score 2: Speculative features added without classification
- Score 1: No evidence of peer context or feature exploration

**Calibration check:** "Can I explain why every feature exists and why absent features are absent?"

---

## 14. Synthesis Artifact

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Agency-grade, no explanation needed vs "ready with minor section gaps" |
| 4 vs 3 | Sections defined, features traceable vs "some features without artifact justification" |
| 3 vs 2 | Partial definition vs "feature-section mapping unclear" |
| 2 vs 1 | Few sections defined vs "no artifact thinking" |

**Anti-patterns by score:**
- Score 3: Some sections not yet renderable
- Score 2: Undecided areas hidden rather than marked
- Score 2: Placeholders presented as decisions
- Score 1: Artifact would cause embarrassment if shared

**Calibration check:** "Would a premium agency ship this artifact without revision?"

---

## 15. Moat Alignment (Optional)

**Applies when:** `moat-conscious` preset is active.

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Multi-moat strengthening vs "one moat strengthened clearly" |
| 4 vs 3 | Clear moat contribution vs "moat-neutral" |
| 3 vs 2 | Neutral vs "missed clear opportunity" |
| 2 vs 1 | Missed opportunity vs "actively undermining moats" |

**Anti-patterns by score:**
- Score 3: Feature doesn't strengthen any moat but doesn't undermine
- Score 2: Export format changes without migration path
- Score 2: Decision rationale not captured
- Score 1: Feature makes product easier to leave

**Calibration check:** "Would switching to a competitor mean losing accumulated value?"

---

## 15. Information Surfacing

| Score | Boundary Definition |
|-------|---------------------|
| 5 vs 4 | Exemplar surfacing, audit complete vs "correct tiers with minor prominence issues" |
| 4 vs 3 | Formal audit, tiers within thresholds vs "some tier thinking but informal" |
| 3 vs 2 | Identifiable tiers vs "tier inflation or noise present" |
| 2 vs 1 | Some prioritization vs "data dump, no tier thinking" |

**Anti-patterns by score:**
- Score 3: More than 5 items competing for top-tier prominence
- Score 2: Tier 4 information visible on surface (noise)
- Score 2: Same information surfaced at different tiers across surfaces without justification
- Score 1: All information shown at equal prominence (data dump)

**Calibration check:** "Can the user identify the 3 most important pieces of information in 5 seconds?"

---

## Using This File

1. **Before scoring:** Read the relevant dimension's calibration
2. **When uncertain:** Use boundary definitions to place the score
3. **Check anti-patterns:** Presence of anti-pattern caps the score
4. **Apply calibration check:** The question should have a confident "yes" for score 4+
5. **After scoring:** If score < 4, identify which boundary wasn't crossed
