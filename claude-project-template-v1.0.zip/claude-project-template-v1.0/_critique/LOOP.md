# Critique Loop

> The mandatory iteration protocol for quality emergence.

---

## The Law

> **RULE-030:** Every screen runs through the critique loop before shipping.

No exceptions. "Looks good to me" is not a stop condition.

---

## The Loop

```
BUILD → CRITIQUE → PATCH → VERIFY → (repeat max 3x) → SHIP or ESCALATE
```

| Phase | Input | Output |
|-------|-------|--------|
| BUILD | Requirements, patterns | Implementation |
| CRITIQUE | Implementation | Scorecard with issues |
| PATCH | Issues | Fixes |
| VERIFY | Fixes | Updated scores |
| SHIP | Passing scores | Done |
| ESCALATE | 3 failed cycles | Escalation report |

---

## Loop Inputs

Critique reads ONLY from these sources:

```yaml
inputs:
  # Project-specific (from Notion)
  notion:
    - Constitution database (project laws)
    - Product Specs (what to build)
    - Decisions database (past decisions)
    
  # System-wide (from starter kit)
  config:
    - config/manifest.yaml
    - config/tech-foundation.yaml
    
  truth:
    - _model/truth/entities.yaml
    - _model/truth/actions.yaml
    - _model/truth/states.yaml
    - _model/truth/permissions.yaml
    
  invariants:
    - _invariants/REGISTRY.md
    
  artifacts:
    - _artifacts/SYNTHESIS.md
    
  patterns:
    - _model/patterns/navigation.md
    - _model/patterns/data-display.md
    - _model/patterns/forms.md
    - _model/patterns/SURFACING.md
    
  ui:
    - _ui/SYSTEM.md
    - _ui/components.yaml
    - _ui/tokens.yaml
    - _ui/states.md
    
  interaction:
    - _interaction/PHYSICS.md
    - _interaction/FOCUS.md
    - _interaction/PROGRESSION.md
    - _interaction/CHOREOGRAPHY.md

  content:
    - _content/SYSTEM.md
    - _content/PATTERNS.md

  heuristics:
    - _quality/HEURISTICS.md

  visual_verification:
    - audit-output/{date}-visual/{surface-name}/*.png
    - _quality/VISUAL_VERIFICATION.md (evaluation protocol)

  strategy:  # Optional: if moat-conscious preset active
    - _strategy/MOATS.md
    - _strategy/priorities.yaml
    
  context:
    - _presets/{active}.yaml
    - _quality/archetypes/{relevant}.yaml
```

### Product Spec as Evaluation Baseline

When a Product Spec exists in Notion and declares Screen Intent Declarations, Outcome Declarations, or Emotional Intent Declarations (see `_expectations/PRE-BUILD.md`), these declarations become formal critique inputs. The critique loop checks built screens against declared intent, not just against general quality.

| Spec Declaration | Critique Checks Against |
|-----------------|------------------------|
| Product Thesis (manifest.yaml) | Directional Coherence dimension |
| Screen Intent Declaration | Flow Architecture Compliance dimension |
| Outcome Declaration | Intent Alignment dimension |
| Emotional Intent | Emotional calibration in Visual Craft |
| Failure Scenarios | Recovery paths in Completeness |

**If the spec has declarations, critique must reference them. If not, these conditional checks don't fire.**

**Hard rule:** If it's not in inputs, it's not a requirement.

**Priority:** Notion Constitution laws override starter kit defaults.

---

## Critique Output

### Critique Card (max 30 lines)

```markdown
# Critique: [Screen Name]
**Cycle:** 1 of 3
**Date:** [date]
**Completeness Target:** Full | Scoped | Foundation

## Scores

| Dimension | Score | Notes |
|-----------|-------|-------|
| Model Coherence | 4/5 | Actions match truth model |
| Information Architecture | 4/5 | Navigation follows grammar |
| Visual Craft | 3/5 | Missing hover states |
| Interaction | 4/5 | Focus management correct |
| Correctness | 5/5 | Data verified |
| Accessibility | 4/5 | Keyboard complete |
| Performance | 4/5 | Under budget |
| Completeness | 4/5 | All affordances work |
| Intent Alignment | 4/5 | Output type matches purpose |
| Vocabulary | 4/5 | Terms clear, tooltips present |
| Symbol Grammar | 4/5 | Single family, consistent weight |
| Progress & Status | 4/5 | Primary signal clear |
| User Expectations | 4/5 | Pre-build complete, surface expectation-complete |

## Issues

### P0 (Block Ship)
- None

### P1 (Block Done)
1. [VISUAL] Missing hover state on row actions
2. [VISUAL] Button spacing inconsistent

### P2 (Backlog)
1. [POLISH] Animation could be smoother

## Patch Plan

1. Add hover states to row actions → fixes P1-1
2. Apply spacing tokens to buttons → fixes P1-2

## Stop Condition

**FAIL** — 2 P1 issues remain

---
```

### Patch Summary (max 15 lines)

```markdown
# Patch Summary: [Screen Name]
**Cycle:** 1 → 2

## Changes Made
- Added hover states to `.row-action` elements
- Applied `space-2` token to button group

## Not Changed
- Animation timing (P2, not blocking)

## New Risks
- None identified

## Verification
- Hover states confirmed on all 4 row actions
- Button spacing matches other screens
```

---

## Scoring

### The 14 Core Dimensions (+1 Optional)

| Dimension | Weight | Minimum | What It Measures |
|-----------|--------|---------|------------------|
| Model Coherence | Critical | 4 | Does UI match truth model? |
| Information Architecture | Critical | 4 | Does navigation follow grammar? No dead ends? |
| Visual Craft | High | 4 | Are components, tokens, hierarchy correct? |
| Interaction | High | 4 | Are motion, focus, states correct? |
| Correctness | Critical | 5 | Is data accurate? No bugs? |
| Accessibility | Critical | 4 | Keyboard, contrast, screen reader? |
| Performance | Medium | 3 | Within render/load budgets? |
| Completeness | Critical | 4 | Do affordances work? Primary flows complete? |
| Intent Alignment | Critical | 4 | Was intent modeled? Does structure match purpose? |
| Vocabulary Comprehension | Critical | 4 | Can users understand the language? Terms clear? |
| Content Quality | High | 4 | Is writing clear, specific, honest, consistent? |
| Symbol Grammar | Critical | 4 | Are status symbols grammatically consistent? |
| Progress & Status | Critical | 4 | Are progress signals clear and hierarchical? |
| User Expectations | Critical | 4 | EIL performed (if new capability)? Pre-build done? Surface expectation-complete? |
| Synthesis Artifact | Critical | 4 | Do features serve artifact sections? Artifact ready for external delivery? |
| Adaptive Layout | Conditional | 4 | Content priority preserved? Touch adapted? Nav transforms? (if multi-form-factor) |
| Information Surfacing | High | 4 | Are information tiers correct? Tier limits respected? Surfacing Audit performed? |
| Moat Alignment | Optional | 3 | Does surface strengthen declared moats? (if `moat-conscious` preset active) |

### Score Definitions

| Score | Meaning |
|-------|---------|
| 5 | Excellent — Could be an exemplar |
| 4 | Good — Senior engineer quality |
| 3 | Acceptable — Meets minimum bar |
| 2 | Below bar — Significant issues |
| 1 | Poor — Major problems |

### Comparative Scoring Anchor

Before scoring any dimension, establish comparison point:

```yaml
comparison_anchor:
  comparing_to: "[previous iteration / exemplar / peer product / ideal]"
  if_previous_iteration: "⚠️ WARNING: 'Better than before' ≠ 'Good'"
  external_reference: "[What external reference would score 5 on this dimension?]"
```

**Rule:** If `comparing_to: previous iteration`, force an external comparison before scoring.

**Question:** "How would this score if I were seeing it for the first time, compared to the best work in this category?"

**Integration:** Use `_critique/CALIBRATION.md` for boundary definitions when establishing external reference.

### Dimension Confidence Declaration

For each dimension, declare scoring confidence:

| Dimension | Score | Confidence | If Low, Why |
|-----------|-------|------------|-------------|
| Visual Craft | 4 | Low | "Can't evaluate optical alignment" |
| Symbol Grammar | 4 | Medium | "Rules followed, unsure about feel" |

**Confidence levels:**

| Level | Definition | Action |
|-------|------------|--------|
| **High** | Would defend this score to a senior practitioner | Score stands |
| **Medium** | Believe it's correct, could be wrong | Note uncertainty |
| **Low** | Scoring based on rules, not genuine evaluation | Flag for external review |

**Rule:** Low-confidence scores on critical dimensions should trigger:
1. Extra scrutiny (re-evaluate more carefully), OR
2. Explicit flag for external review

**Purpose:** Uncertain 4s are dangerous — they hide blind spots. Making uncertainty visible enables better decisions.

**Note:** This complements (not duplicates) the Confidence Flagging meta-dimension in `_critique/PROMPT.md`. That flags low-confidence decisions during building; this flags low-confidence scores during critique. Different moments, same transparency goal.

---

## Learning Signals (appended to every final scorecard)

After the stop condition, Claude appends:

```markdown
## Learning Signals

### Template Gap Detected?
- [ ] Yes — describe below
- [x] No

### If Yes:
- **Gap:** [What the template should have covered but didn't]
- **Evidence:** [What happened because of the gap]
- **Generic?** [Would this affect any product, not just this one?]
- **Proposed fix:** [New invariant / law / pattern / dimension]
```

**When a gap IS detected:** Claude also:
1. Adds `promote: candidate` to the relevant Decision Registry entry (or creates one)
2. Creates a Notion Learning Queue entry with status `captured`

This is mandatory on every SHIP and ESCALATE. If no gap, just check "No."

---

## Severity Definitions

### P0 — Must Fix Before Ship

These block release:
- Breaks truth model or permissions
- Violates any invariant (_invariants/REGISTRY.md)
- Violates Notion Constitution law
- Incorrect or misleading data
- Keyboard navigation broken / focus trap
- Navigation loses user context
- WCAG AA failure
- Crash or critical error
- **Dead affordance** — button/link/chevron that does nothing (LAW-007)
- **Primary flow incomplete** — core task not executable end-to-end (LAW-008)
- **Navigation dead end** — screen with no escape path

### P1 — Must Fix Before "Done"

These block completion:
- Inconsistent interaction states
- Visual layering issues
- Missing states (loading/empty/error)
- Unclear copy in primary flows
- Minor accessibility gaps
- Secondary affordance issues (e.g., disabled without explanation)
- Progress indicator without clear semantics

### P2 — Backlog

These never block:
- Micro-spacing refinements
- Animation polish
- Nice-to-have improvements
- Edge case handling

---

## Pre-Critique Calibration

> Before scoring, acknowledge your current state honestly.

**Required:** Before starting any critique cycle, answer:

```yaml
pre_critique_check:
  investment_level: "[How many iterations have I put into this?]"
  wanting_to_pass: "[Am I looking for reasons to pass or reasons to fail?]"
  fatigue_level: "[Cycle 1/2/3+? Is my rigor matching cycle 1?]"
  comparison_anchor: "[Am I comparing to previous iteration or to excellence?]"
```

### If Bias Detected

If `wanting_to_pass: yes` — this is a warning, not a disqualification. Compensate:

1. Score the hardest dimension first
2. Identify at least one problem before looking for passes
3. Compare explicitly to external reference, not previous iteration

### Purpose

Making bias visible makes it harder to act on unconsciously. The check doesn't eliminate bias; it creates friction against it.

---

## Stop Conditions

### Surprise Test (Required)

Before evaluating stop conditions, the reviewer must identify:
```yaml
surprise_test:
  observation: "[One specific thing about this implementation that was unexpected — either better or worse than anticipated]"
  implication: "[What this means for the current critique cycle]"
  action: "[REQUIRED: What changed as a result. If 'none', justify why the surprise requires no response]"
```

**Rules:**
- If the reviewer cannot name a genuine surprise, the critique was performed mechanically — re-run with fresh attention. A surprise with no action and no justification for inaction is a failed surprise test.
- Generic statements like "everything looks good" or "quality is as expected" fail this test
- The surprise can be positive (something clever) or negative (something missed)
- The surprise must be specific to THIS implementation, not a general observation

**Purpose:** This disrupts autopilot scoring. If nothing surprises you, you weren't really looking.

### PASS (Ship Ready)

```yaml
pass_conditions:
  P0_count: 0
  P1_count: <= 2
  scores:
    model: >= 4
    ia: >= 4
    visual: >= 4
    interaction: >= 4
    correctness: == 5  # Must be perfect
    accessibility: >= 4
    performance: >= 3
    completeness: >= 4  # No hollow products
    intent: >= 4  # Must build the right thing
    vocabulary: >= 4  # Users must understand the language
    symbol_grammar: >= 4  # Status symbols must be consistent
    progress_status: >= 4  # Progress signals must be clear
    user_expectations: >= 4  # Must be expectation-complete
    moat_alignment: >= 3  # Only if moat-conscious preset active
```

### FAIL (Continue Loop)

If any condition not met, continue to next cycle.

### ESCALATE (Stuck)

After 3 cycles without passing:

```yaml
escalation:
  output:
    why_stuck: "Max 5 bullets"
    what_input_missing: "Which file needs what"
    recommendation: "Suggested path forward"

  action: Human decision required
```

### DIMINISHING RETURNS (Stop Signal)

> Know when revisions are helping vs. hurting.

After each revision cycle, assess:

```yaml
revision_trajectory:
  cycle: "[Which revision cycle]"

  improvement_assessment:
    what_improved: "[Specific improvements this cycle]"
    what_degraded: "[What got worse or more fragmented]"
    net_direction: "[better/same/worse]"

  diminishing_returns_check:
    improvement_magnitude: "[large/moderate/small/negligible]"
    effort_required: "[high/moderate/low]"
    ratio: "[Was the improvement worth the effort?]"
```

### Stop Condition Additions

| Condition | Action |
|-----------|--------|
| 2 consecutive cycles with `net_direction: worse` | **Stop.** Revisions are eroding, not improving. |
| 3 consecutive cycles with `improvement_magnitude: negligible` | **Stop.** Diminishing returns — approach limit reached. |
| Any cycle where `what_degraded` exceeds `what_improved` | **Pause.** Evaluate whether to continue. |
| `effort_required: high` with `improvement_magnitude: small` | **Reassess.** Efficiency problem. |

### When Approach Limit Is Reached

If stop condition triggers, you have three options:

1. **Ship as-is** — Accept current state, document limitations
2. **Consolidation pass** — Unify patches without adding features
3. **Restart with learnings** — Apply what you learned to fresh approach

**Rule:** More iteration is not always the answer. Sometimes the approach has a ceiling.

### Single-Cycle Mode

**Trigger:** Only one critique cycle is available due to time constraints.

When the standard max-3-cycle loop cannot run, use this reduced protocol:

**Must-Pass (non-negotiable even in single cycle):**

| Check | Requirement |
|-------|-------------|
| Correctness | Score = 5 |
| Affordance integrity (AF-001 to AF-004) | No dead affordances |
| Token compliance (TK-001 to TK-003) | No violations |
| Contrast (AA) | No failures |
| Phantom actions | Zero |

**Degraded-but-Tracked (accept lower bar with documented debt):**

| Dimension | Normal min | Single-cycle min | Debt tracking |
|-----------|-----------|-----------------|---------------|
| Model Coherence | 4 | 3 | Document incomplete model elements |
| User Expectations | 4 | 3 | Document missing EIL as P1 debt |
| Synthesis Artifact | 4 | 3 | Document incomplete sections |
| Completeness | 4 | 3 | Document unwired affordances |

**May-Defer (accept later polish):**

| Dimension | Reason deferrable |
|-----------|--------------------|
| Performance | Slow but working beats not shipping |
| Moat Alignment | Strategic, not correctness |
| Visual Craft (beyond tokens) | Polish, not function |

**Single-Cycle Output:**
```yaml
single_cycle_critique:
  date: __FILL__
  reason: "[Why only 1 cycle available]"
  must_pass:
    correctness: __FILL__  # Must be 5
    dead_affordances: __FILL__  # Must be 0
    token_violations: __FILL__  # Must be 0
    contrast_failures: __FILL__  # Must be 0
    phantom_actions: __FILL__  # Must be 0
  degraded_scores:
    model_coherence: __FILL__  # Min 3, document gaps
    user_expectations: __FILL__  # Min 3, document gaps
    completeness: __FILL__  # Min 3, document gaps
  explicit_debt:
    - type: __FILL__
      detail: __FILL__
      severity: __FILL__  # P1 or P2
      planned_resolution: __FILL__
  ship_decision: __SELECT__ [SHIP_WITH_DEBT, DO_NOT_SHIP, ESCALATE]
  decision_owner: __FILL__  # Human who approved
```

**Single-Cycle Mode is not a shortcut.** It produces the same accountability through debt tracking instead of iteration. All debt items become P1s in the next cycle.

---

## Cycle Rules

### Within Each Cycle

1. If new capability → verify Expectation Invention Loop (EIL-001 to EIL-005)
2. Verify pre-build User Expectation Framework (UE-001 to UE-011)
3. Verify pre-build intent modeling (LAW-011)
4. Verify artifact-first design (SA-001 to SA-006)
5. **Experiential evaluation** — Actually use the surface before scoring:

```yaml
experiential_check:
  task_attempted: "[What goal did I approach with?]"
  hesitation_points: "[Where did I pause, even briefly?]"
  confusion_points: "[Where was I unsure what to do?]"
  friction_points: "[Where did something feel slow or awkward?]"
  satisfaction: "[Did completing the task feel good?]"
```

**Method:**
- Clear mental context (stop thinking about implementation)
- Approach as a user with a goal
- Note every hesitation, confusion, or friction — even small ones
- Small hesitations compound into "this feels clunky"

**Rule:** "Mechanism exists" ≠ "mechanism works well." This evaluates experience, not presence.

6. **Visual verification** — Before scoring, run visual verification per `_quality/VISUAL_VERIFICATION.md`:
   - Capture screenshots at required breakpoints
   - Capture all applicable states
   - Run Quick Evaluation (Standard) or Full Evaluation (Complex)
   - Visual findings feed directly into dimension scoring
   - If visual verification not performed: Visual Craft, Interaction, and Completeness are capped at 3
7. Score all 14 dimensions
8. Identify all issues
9. Rank issues by severity
10. Create patch plan (max 5 items)
11. Evaluate stop condition

### Between Cycles

1. Execute patch plan
2. Document what changed
3. Note what didn't change (and why)
4. Identify new risks
5. Verify fixes
6. Check fix side effects:

```yaml
fix_side_effects:
  - fix: "[What was changed]"
    potentially_affected:
      - "[What else uses this component/pattern/token]"
      - "[What adjacent elements might be impacted]"
    checked: "[yes/no]"
    new_issues: "[List any, or 'none']"
```

**Rule:** A fix that creates a new P1 is not a fix. It's a trade.

For each fix applied:
- List what else could be affected
- Verify those areas
- Document any new issues created

### Holistic Re-evaluation

After all fixes in a cycle are applied, before proceeding:

> Step back. Evaluate the whole, not the parts.

```yaml
holistic_check:
  first_impression: "[What does this feel like now, as a whole?]"
  cumulative_effect: "[Did individual fixes improve the whole, or fragment it?]"
  coherence_preserved: "[Does this still feel like one thing, or a collection of patches?]"
  fresh_eyes_assessment: "[If seeing this for the first time, what would I think?]"
```

**If `first_impression` is negative** — The fixes addressed symptoms but not the underlying issue. Consider whether the approach needs rethinking, not just more fixing.

**Rule:** Verifying individual fixes ≠ evaluating the whole. Both are required.

**Test:** Describe your first impression in 5 words. If those words aren't positive, the fixes haven't succeeded.

### Revision Arc Tracking

> Track cumulative direction, not just this cycle.

After holistic check, assess the revision arc:

```yaml
revision_arc_check:
  revision_count: "[How many revision cycles so far?]"

  cumulative_assessment:
    original_vision_preserved: "[Is the original intent still visible, or obscured by patches?]"
    revision_direction: "[improving/drifting/fragmenting]"
    patchwork_risk: "[Are changes cohering or accumulating as layers?]"

  if_fragmenting:
    root_cause: "[What's causing the fragmentation?]"
    options:
      - "Continue patching (accept fragmentation)"
      - "Consolidation pass (unify the patches)"
      - "Restart from clearer foundation"
    chosen_option: "[Which, and why]"
```

### Revision Direction Definitions

| Direction | Definition | Action |
|-----------|------------|--------|
| **Improving** | Each revision makes the whole better | Continue |
| **Drifting** | Changes are lateral, not improvements | Pause and reassess |
| **Fragmenting** | Changes are creating incoherence | Stop and decide |

### Consolidation Pass

A **consolidation pass** is a revision cycle focused on unifying accumulated patches rather than adding new changes. Use when:
- Multiple revisions have addressed different issues without considering the whole
- The product works but feels like a patchwork
- Original vision is obscured by accumulated changes

### Revision Arc Rules

1. **Track revision arc.** Don't just evaluate this cycle; evaluate cumulative direction.
2. **`fragmenting` triggers decision.** If revisions are fragmenting, explicit choice required.
3. **More than 3 revision cycles = warning.** If you're past 3 cycles without passing, the approach may be wrong.

### Across Cycles

- Max 3 cycles total
- Fix all P0 issues first
- Fix max 3 P1 issues per cycle
- P2 issues never block
- If stuck, escalate with specifics

---

## Excellence Gap Question

> After every critique cycle, identify the gap to excellence — even if shipping is justified.

**Required:** Before exiting a critique cycle (pass or fail), answer:

> "What single change would elevate this from current score to 5?"

### Documentation

```yaml
excellence_gap:
  dimension: "[Which dimension has most room to grow]"
  current_score: "[Score]"
  what_would_make_it_5: "[Single change]"
  implementing: "[yes/no — if no, why not]"
```

### Purpose

This is different from fixing P1s. It's asking:
- What's the gap to excellence, not just the gap to shipping?
- Over time, these accumulate into patterns of "what excellence looks like"

### Rules

- Answer must be specific, not "make it better"
- Document even if not implementing (the gap is still valuable to capture)
- One dimension per cycle (the one with most room to grow)

---

## Shared Components

When critiquing a shared component:

```yaml
shared_component:
  scope: Component in isolation
  
  additional_check:
    - List all screens using this component
    - Run 1 critique cycle on each
    - Flag regressions
    
  blocking:
    - New P0 in any consuming screen
```

---

## Scorecard Storage

```yaml
scorecards:
  location: _critique/scorecards/
  naming: "{YYYY-MM-DD}-{screen-name}.md"
  retention: Keep all (for learning)
```
