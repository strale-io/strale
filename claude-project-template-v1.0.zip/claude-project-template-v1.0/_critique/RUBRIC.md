# Critique Rubric

> Detailed scoring criteria for each dimension.

---

## 1. Model Coherence

> Does the UI correctly reflect the truth model?

### Score 5 — Exemplary
- All entities match `entities.yaml` exactly
- All actions match `actions.yaml` exactly
- State machine flows correctly per `states.yaml`
- Permissions enforced per `permissions.yaml`
- No phantom actions (UI actions not in model)
- No phantom states (UI states not in model)

### Score 4 — Good
- Entities and actions match model
- State machine correct
- Permissions enforced
- Minor labeling inconsistencies (fixable)

### Score 3 — Acceptable
- Core entities correct
- Most actions match
- State machine mostly correct
- Some permission edge cases unclear

### Score 2 — Below Bar
- Entity definitions inconsistent with model
- Actions missing or extra
- State machine has gaps
- Permissions not fully enforced

### Score 1 — Poor
- Major disconnect from truth model
- Phantom actions throughout
- State machine broken
- Permissions ignored

---

## 2. Information Architecture

> Does navigation follow the grammar? Are there dead ends?

### Score 5 — Exemplary
- URL patterns match `grammar.yaml`
- Breadcrumbs reflect true hierarchy and are clickable
- Back behavior is logical and predictable
- Deep linking works perfectly
- User always knows where they are
- No dead ends — every screen has escape path and next step
- All navigation affordances (chevrons, arrows) navigate

### Score 4 — Good
- URLs follow patterns
- Breadcrumbs correct and functional
- Back behavior works
- Deep linking functional
- Minor navigation polish needed
- No dead ends

### Score 3 — Acceptable
- URLs mostly correct
- Breadcrumbs present and clickable
- Back works (occasionally unexpected)
- Deep linking works for main flows
- Rare dead ends in edge cases

### Score 2 — Below Bar
- URL patterns inconsistent
- Breadcrumbs inaccurate or non-functional
- Back behavior confusing
- Some states not linkable
- Dead ends in secondary flows

### Score 1 — Poor
- URLs don't follow patterns
- No breadcrumbs or wrong
- Back dumps user at root
- Deep linking broken
- Multiple dead ends

---

## 3. Visual Craft

> Are components, tokens, and hierarchy correct?

### Score 5 — Exemplary
- All values from tokens (TK-001)
- All token combinations valid per capability matrix (TK-002)
- No forbidden token patterns (TK-003)
- Components from registry only
- Clear visual hierarchy
- Consistent spacing throughout
- Intentional use of whitespace
- Could be used as exemplar

### Score 4 — Good
- Tokens used correctly
- Token combinations valid
- Components applied properly
- Primary focal point **named and justified** (what it is and why it's primary)
- Visual hierarchy **matches importance order** (most important element is most visually prominent)
- Spacing consistent
- Minor refinements possible

### Score 3 — Acceptable
- Mostly using tokens
- No invalid token combinations
- Components mostly correct
- Hierarchy understandable
- Some spacing inconsistencies

### Score 2 — Below Bar
- Hardcoded values present
- Invalid token combinations (e.g., text-hover)
- Non-standard components
- Hierarchy unclear
- Spacing inconsistent

### Score 1 — Poor
- Many hardcoded values
- Forbidden token patterns used
- Custom components without approval
- No clear hierarchy
- Spacing chaotic

---

## 4. Interaction

> Are motion, focus, and states handled correctly?

### Score 5 — Exemplary
- Motion follows PHYSICS.md
- Focus management per FOCUS.md
- Progressive disclosure per PROGRESSION.md
- All interactive states present (hover, focus, active, disabled)
- Reduced motion respected

### Score 4 — Good
- Motion appropriate
- Focus management correct
- Disclosure logical
- States present
- Minor polish possible

### Score 3 — Acceptable
- Motion mostly correct
- Focus works
- Disclosure present
- Most states present

### Score 2 — Below Bar
- Motion feels off
- Focus issues
- Disclosure inconsistent
- Missing states

### Score 1 — Poor
- Motion violates principles
- Focus broken
- No progressive disclosure
- Many states missing

---

## 5. Correctness

> Is the data accurate? Are there bugs?

### Score 5 — REQUIRED
- All data from server (no client calculations)
- Numbers reconcile correctly
- Labels from authoritative sources
- No bugs in implemented functionality
- Error handling complete

### Score 4 — Not acceptable for ship
- Minor data display issues
- Edge case bugs
- Error handling gaps

### Score 3-1 — Blocks ship
- Data issues present
- Bugs in main flows
- Error states missing

**Note:** Correctness must be 5 to ship. This is non-negotiable.

---

## 6. Accessibility

> Can all users use this?

### Score 5 — Exemplary
- WCAG 2.1 AA compliant
- Full keyboard navigation
- Screen reader tested
- Focus indicators visible
- Color not sole indicator
- Reduced motion supported

### Score 4 — Good
- AA compliant
- Keyboard works
- Screen reader compatible
- Focus visible
- Minor gaps in advanced features

### Score 3 — Acceptable
- Main flows accessible
- Keyboard mostly works
- Basic screen reader support
- Focus mostly visible

### Score 2 — Below Bar
- Contrast failures
- Keyboard gaps
- Screen reader issues
- Focus problems

### Score 1 — Poor
- Major accessibility failures
- Keyboard broken
- Screen reader unusable
- No focus indicators

---

## 7. Performance

> Is it fast enough? Budgets defined in `config/tech-foundation.yaml`.

### Score 5 — Exemplary
- Exceeds all tech-foundation budgets
- No layout shift
- Virtualization where needed
- Optimistic UI applied
- Could be benchmark

### Score 4 — Good
- Meets all tech-foundation budgets
- Minimal layout shift
- Performance acceptable
- No user-perceptible delays

### Score 3 — Acceptable
- Meets most budgets (minor misses)
- Some layout shift
- Usable but not snappy

### Score 2 — Below Bar
- Misses multiple budgets
- Noticeable jank
- Performance issues
- User notices delays

### Score 1 — Poor
- Significantly exceeds budgets
- Unusable on slow connections
- Major jank
- Performance blocking usage

---

## 8. Completeness

> Do affordances work? Are primary flows complete?

### Score 5 — Exemplary
- All affordances functional (buttons, links, chevrons)
- Primary flows work end-to-end
- No dead ends anywhere
- Disabled states explained
- Progress indicators clear
- Could use immediately after build

### Score 4 — Good
- All primary affordances work
- Core flows complete
- No dead ends in main paths
- Minor secondary affordance gaps

### Score 3 — Acceptable
- Primary CTAs work
- Main happy path complete
- Some secondary affordances incomplete
- Dead ends in edge cases only

### Score 2 — Below Bar
- Primary affordances broken
- Core flow has gaps
- Dead ends in secondary flows
- "Coming soon" on important features

### Score 1 — Poor
- Multiple dead affordances
- Primary flow incomplete
- Navigation has dead ends
- Product is hollow

---

## 9. Intent Alignment

> Was the right thing built? Does structure match purpose?

### Score 5 — Exemplary
- Intent was explicitly modeled before building
- Output type perfectly matches purpose
- Structure serves the audience assumption
- Systems are demonstrated in context, not enumerated
- Nothing extraneous, nothing missing
- A discerning client would be impressed

### Score 4 — Good
- Intent was clear before building
- Output type is correct
- Structure is appropriate
- Systems shown in use where relevant
- Minor alignment issues

### Score 3 — Acceptable
- Intent was implicit but recoverable
- Output type mostly correct
- Structure adequate
- Some enumeration where demonstration would be better

### Score 2 — Below Bar
- Intent unclear, built speculatively
- Output type mismatched
- Structure doesn't serve purpose
- Systems listed rather than shown
- Audience assumption wrong

### Score 1 — Poor
- No evidence of intent modeling
- Wrong output type entirely
- Structure arbitrary
- Flat enumeration throughout
- Built without understanding why

### Additional checks for system/configuration screens:
- Is the system demonstrated in use, or merely listed?
- Does the output build confidence in coherence?
- Are decisions shown in context, not isolation?
- Would a client understand without explanation?

---

## 10. Vocabulary Comprehension

> Can users understand the language the product speaks?

### Score 5 — Exemplary
- All terms self-evident or contextual
- Technical terms match industry usage exactly
- No tooltips needed (language is that clear)
- Same term means same thing everywhere
- Language is purely descriptive, never judgmental
- A new user would understand immediately
- Could be used as vocabulary exemplar

### Score 4 — Good
- Most terms self-evident or contextual
- Non-obvious terms have in-context explanation (tooltips)
- Technical terms match industry usage
- Terms used consistently throughout
- Language is descriptive
- Minor vocabulary gaps (easily fixed)

### Score 3 — Acceptable
- Core terms understandable
- Important status labels have tooltips
- Most terms used consistently
- Some jargon without explanation
- Occasional judgmental language

### Score 2 — Below Bar
- Several opaque terms without explanation
- Inconsistent terminology (same word, different meanings)
- Technical terms don't match industry usage
- Status labels without tooltips
- Judgmental language present

### Score 1 — Poor
- Many opaque terms
- User cannot understand without external help
- Terms used inconsistently throughout
- No explanations available
- Language implies user failure

### Key tests:
- First Encounter Test: Can new user understand or learn each term?
- Two Professionals Test: Would experts interpret the same way?
- Consistency Test: Same term = same meaning everywhere?
- Neutrality Test: Does language describe or judge?

---

## 11. Content Quality

> Is product writing clear, specific, honest, and consistent?

### Score 5 — Exemplary
- All error messages follow what/why/what-next structure
- All empty states name the missing entity and provide creation CTA
- All buttons use specific verb + object pattern
- All confirmations name specific consequences with quantified impact
- Writing voice matches manifest.yaml perfectly
- Zero generic text anywhere

### Score 4 — Good
- Error messages are clear and helpful
- Empty states are well-written with CTAs
- Most buttons are specific
- Confirmations are clear
- Minor voice inconsistencies

### Score 3 — Acceptable
- Errors have some structure but inconsistent
- Empty states exist but some are generic
- Buttons work but some use "OK" or "Submit"
- Confirmations exist but some say "Are you sure?"

### Score 2 — Below Bar
- Generic errors ("Something went wrong")
- Missing or unhelpful empty states
- Buttons use "OK/Cancel" patterns
- Missing confirmation for destructive actions

### Score 1 — Poor
- No error handling text
- No empty states
- Buttons are unlabeled or misleading
- No confirmation dialogs

---

## 12. Symbol Grammar

> Do status symbols form a coherent, consistent visual language?

### Score 5 — Exemplary
- Single primitive family throughout (all area-based, all line-based, etc.)
- Consistent optical weight across all symbols
- Single semantic axis (fill OR weight OR count)
- Perfectly monotonic progression
- All symbols legible at 12px
- Could be used as symbol system exemplar

### Score 4 — Good
- Single primitive family
- Consistent optical weight
- Clear semantic axis
- Monotonic progression
- Symbols work at small sizes
- Minor refinements possible

### Score 3 — Acceptable
- Mostly single primitive family
- Optical weight mostly consistent
- Semantic axis understandable
- Progression generally monotonic
- Some legibility issues at small sizes

### Score 2 — Below Bar
- Mixed primitive families (area + line)
- Inconsistent optical weight
- Multiple axes changing simultaneously
- Non-monotonic in places
- Poor small-size legibility

### Score 1 — Poor
- Ad-hoc symbol selection
- No consistent grammar
- Symbols visually unrelated
- Progression unclear or random
- Symbols indistinguishable

### Key tests:
- Single Family Test: All symbols share geometric basis?
- Weight Test: Same visual mass across states?
- Axis Test: Only one variable changes?
- Monotonic Test: Visual order = semantic order?
- Validity Test: Would new symbol pass all criteria?

---

## 12. Progress & Status Semantics

> Are progress indicators and status labels clear, hierarchical, and neutral?

### Score 5 — Exemplary
- Clear primary progress signal when multiple exist
- All representations pass Sentence Test
- All labels purely descriptive
- All ratios labeled with context
- No competing signals
- Could be used as progress UI exemplar

### Score 4 — Good
- Primary signal is clear
- Most representations pass Sentence Test
- Labels are descriptive
- Ratios labeled
- Minor hierarchy issues

### Score 3 — Acceptable
- Primary signal identifiable
- Core representations clear
- Most labels descriptive
- Some ratios unlabeled
- Occasional competing signals

### Score 2 — Below Bar
- No clear primary signal
- Multiple ambiguous representations
- Some evaluative labels
- Ratios unlabeled
- Competing progress signals

### Score 1 — Poor
- Multiple competing signals, none primary
- Representations fail Sentence Test
- Judgmental labels ("behind", "healthy")
- No context for any metrics
- User cannot understand progress

### Key tests:
- Hierarchy Test: Primary signal identifiable in 2 seconds?
- Sentence Test: Can express as "[X] of [Y] are [state]"?
- Neutrality Test: Labels describe, not evaluate?
- Ratio Test: Numerator and denominator clear?

---

## 13. User Expectations

> Was the surface built with user expectations in mind? Is it expectation-complete? If new capability, was EIL performed?

### Score 5 — Exemplary
- If new capability: EIL performed completely (all 5 steps, artifact created)
- Peer context fully specified before building
- Candidate features explored thoroughly
- All features classified (Expected/Helpful/Speculative/Dangerous/Prevented)
- Prevented assumptions addressed in UI
- Absence detection complete across all categories
- All surface role requirements satisfied
- Inner Monologue Test passes perfectly
- Restraint Gate applied to all features
- All deferred features tracked
- All rejected features documented with reasoning
- EIL outputs properly feed Pre-Build (if applicable)
- Surface feels exactly right — nothing missing, nothing extra
- Could be used as pre-build process exemplar

### Score 4 — Good
- If new capability: EIL performed (cascade decision made, non-goals stated)
- Peer context specified
- Features classified and filtered (including Prevented where relevant)
- Absence detection performed
- Surface role requirements met
- Inner Monologue Test passes
- Visual-implies-interactive holds
- Expectation debt tracked
- Minor gaps in rejected feature documentation
- Surface feels expectation-complete

### Score 3 — Acceptable
- Some pre-build thinking evident
- EIL partially performed if new capability
- Core expected features present
- Most surface role requirements met
- Inner Monologue answers mostly confident
- Some absence detection gaps
- Restraint Gate partially applied
- Surface has minor expectation gaps

### Score 2 — Below Bar
- Little evidence of pre-build exploration
- EIL skipped for new capability
- Expected features missing
- Surface role requirements partially met
- Inner Monologue answers uncertain
- Absence detection incomplete
- No feature classification
- Surface feels hollow or bloated

### Score 1 — Poor
- No pre-build process followed
- New capability shipped without EIL (if applicable)
- Major expected features missing
- Surface role requirements not met
- Inner Monologue Test fails
- No absence detection
- No feature classification
- No Restraint Gate
- No non-goals documented
- Surface is incomplete or over-featured
- Cannot explain what was/wasn't built

### Key tests:
- EIL Trigger Test: Does this introduce new data, state, or affordances?
- EIL Cascade Test: Were 5 steps completed (if triggered)?
- Non-Goals Test: Are prevented assumptions documented?
- Peer Context Test: Were comparable products documented?
- Classification Test: Is every feature classified (including Prevented)?
- Absence Test: Were all categories checked?
- Role Test: Does surface meet type requirements?
- Monologue Test: Do all 5 questions have confident answers?
- Interactivity Test: Does every clickable-looking element work?
- Bounded Curiosity Test: Can you explain rejections?

---

## 14. Synthesis Artifact

> Are artifact sections defined? Do features serve sections? Is artifact ready for external delivery?

### Score 5 — Exemplary
- All artifact sections defined with clear requirements
- Every product feature traceable to artifact section
- Section maturity tracked and accurate (Renderable/Partial/Placeholder/Blocked)
- All renderable sections can be produced truthfully
- Undecided areas explicitly marked
- Artifact requires no verbal explanation
- Artifact passes Agency Test (premium agency would ship)
- No placeholders presented as decisions
- Artifact shows actual state, not aspirational
- Could be shared externally with pride

### Score 4 — Good
- Artifact sections defined
- Most features traceable to sections
- Section maturity tracked
- Renderable sections are truthful
- Undecided areas marked
- Artifact would not require apology
- Agency Test mostly passes
- Minor gaps in section documentation

### Score 3 — Acceptable
- Some artifact sections defined
- Feature-to-section mapping incomplete
- Section maturity partially tracked
- Some sections not yet renderable
- Some undecided areas not marked
- Artifact would need some explanation
- Agency Test has concerns

### Score 2 — Below Bar
- Few artifact sections defined
- Feature-to-section mapping unclear
- Section maturity not tracked
- Many sections not renderable
- Undecided areas hidden
- Artifact would require significant explanation
- Agency Test fails

### Score 1 — Poor
- No artifact sections defined
- No feature-to-section mapping
- No section maturity tracking
- Artifact cannot be rendered truthfully
- Placeholders presented as decisions
- Artifact would cause embarrassment
- No reverse engineering performed
- Features built without artifact justification

### Key tests:
- Reverse Engineering Test: Do features trace to artifact sections?
- Section Maturity Test: Is maturity tracked accurately?
- Truthfulness Test: Does artifact show actual state?
- No Verbal Explanation Test: Can artifact stand alone?
- Agency Test: Would premium agency ship this?
- Honesty Test: Are placeholders clearly marked?

---

## 15. Information Surfacing

> Is the right information shown at the right prominence on this surface?

### Score 5 — Exemplary
- Surfacing Audit performed completely (inventory, action-change test, tier validation, cross-surface check)
- Tier 1 items ≤ 5, each passes Action-Change Test ("if changed, user acts differently")
- Tier 2 items scannable but not competing with Tier 1
- Tier 3 items behind clear affordances (user knows they exist)
- Zero Tier 4 items on surface
- Surfacing pattern matches surface type perfectly
- Cross-surface consistency maintained
- Could be used as surfacing exemplar

### Score 4 — Good
- Surfacing Audit performed
- Tier distribution within thresholds (Tier 1 ≤ 5, Tier 1+2 ≤ 15)
- No Tier 4 items present
- Surface type pattern followed
- Cross-surface consistency checked
- Minor prominence issues

### Score 3 — Acceptable
- Some tier thinking evident
- Tier 1 items identifiable but may exceed 5
- Most Tier 4 items removed
- Surface type pattern mostly followed
- Cross-surface consistency not formally checked

### Score 2 — Below Bar
- No formal Surfacing Audit
- Tier 1 inflation (>5 prominent items competing)
- Tier 4 items present (noise)
- Information hierarchy unclear
- Data dump tendencies

### Score 1 — Poor
- No information prioritization
- Everything shown at same prominence
- Surface is a data dump
- No tier thinking whatsoever
- User cannot identify what matters

### Key tests:
- Action-Change Test: For each Tier 1 item, "If this changed, would the user act differently here?"
- Tier Count Test: ≤ 5 Tier 1 items, ≤ 15 above fold
- Noise Test: Zero Tier 4 items visible
- Pattern Match Test: Surfacing matches surface type (Dashboard/Detail/List/Editor)

---

## 16. Moat Alignment (Optional)

> Does the surface contribute to structural competitive advantage?

**Applies when:** `moat-conscious` preset is active.

### Score 5 — Exemplary
- Surface actively strengthens multiple declared moats
- Clear contribution to institutional memory (decisions captured with rationale)
- Export formats are stable and treated as contracts
- Feature passes all four moat tests (Compounding, Replaceability, Integration, Memory)
- No moat-undermining without explicit justification

### Score 4 — Good
- Surface strengthens at least one declared moat
- Decision rationale captured
- Export formats stable
- Feature passes 3+ moat tests
- No unjustified moat undermining

### Score 3 — Acceptable
- Surface is moat-neutral (doesn't strengthen but doesn't undermine)
- Some decision rationale captured
- Export formats reasonably stable
- Feature passes 2+ moat tests

### Score 2 — Below Bar
- Surface misses clear opportunity to strengthen moat
- Decision rationale inconsistently captured
- Export formats unstable
- Feature passes <2 moat tests

### Score 1 — Poor
- Surface actively undermines existing moats without justification
- No decision rationale captured
- Breaking changes to export formats
- Feature makes product easier to replace

### Moat Tests

| Test | Question | Pass Criteria |
|------|----------|---------------|
| **Compounding** | Does value increase with usage? | More valuable over time |
| **Replaceability** | How hard to recreate elsewhere? | Significant effort required |
| **Integration** | Creates external dependencies? | Other systems consume outputs |
| **Memory** | Accumulates context? | History/decisions would be lost |

### Key Questions

- Which declared moat does this strengthen? (Know-how / Rigidity / Scale)
- What would be lost if user switched to competitor?
- Is this feature building genuine value or artificial friction?
- Are moat claims testable (not just marketing language)?

---

## Quick Reference Table

| Dimension | 5 | 4 | 3 | 2 | 1 |
|-----------|---|---|---|---|---|
| Model | Perfect match | Minor labels | Mostly correct | Inconsistent | Broken |
| IA | Perfect nav, no dead ends | Minor polish | Works | Confusing | Lost |
| Visual | Exemplar | Professional | Acceptable | Inconsistent | Chaotic |
| Interaction | Exemplar | Polished | Works | Gaps | Broken |
| Correctness | Perfect | — | — | — | Bugs |
| Accessibility | AA+ | AA | Main flows | Gaps | Broken |
| Performance | Snappy | Good | Acceptable | Slow | Unusable |
| Completeness | All works | Core works | Main path | Gaps | Hollow |
| Intent | Impressive | Aligned | Adequate | Mismatched | Wrong |
| Vocabulary | Self-teaching | Clear + tooltips | Core clear | Opaque terms | Incomprehensible |
| Symbol Grammar | Systematic | Consistent | Mostly consistent | Mixed grammars | Ad-hoc |
| Progress/Status | Clear hierarchy | Primary clear | Identifiable | Competing | Chaotic |
| User Expectations | Expectation-perfect | Complete | Minor gaps | Hollow/bloated | Not considered |
| Synthesis Artifact | Agency-grade | Ready | Partial | Gaps | Not defined |
| Info Surfacing | Exemplar tiers | Audit done | Some thinking | Inflation/noise | Data dump |
| Moat Alignment | Multi-moat | One moat | Neutral | Missed opportunity | Undermining |

---

## Minimum Scores to Ship

| Dimension | Minimum |
|-----------|---------|
| Model Coherence | 4 |
| Information Architecture | 4 |
| Visual Craft | 4 |
| Interaction | 4 |
| Correctness | **5** (required) |
| Accessibility | 4 |
| Performance | 3 |
| Completeness | **4** (required) |
| Intent Alignment | **4** (required) |
| Vocabulary Comprehension | **4** (required) |
| Symbol Grammar | **4** (required) |
| Progress & Status | **4** (required) |
| User Expectations | **4** (required) |
| Synthesis Artifact | **4** (required) |
| Information Surfacing | **4** (required) |
| Moat Alignment | **3** (if preset active) |
