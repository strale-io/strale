# Critique Prompt

> The stable prompt for self-critique. Run this after every build.

---

## Usage

After completing a screen or flow, run this prompt to generate a critique card.

---

## The Prompt

```markdown
You are critiquing a UI implementation against the documentation system.

## Context

Screen/Flow: [NAME]
Archetype: [ARCHETYPE]
Cycle: [N] of 3

## Pre-Build Verification (LAW-011)

Before scoring, confirm these were established:

- [ ] **Intent stated** — Problem being solved is explicit
- [ ] **Output type identified** — Decision Surface / Data Display / Export / Narrative
- [ ] **Scope boundaries set** — What's in, what's out
- [ ] **Success defined** — "Done" criteria articulated
- [ ] **Audience assumed** — Explorer / Practitioner / Decision-maker / Client

If any are missing, flag as **P1: "Built without intent modeling"** and note which step was skipped.

## Your Task

1. **Score** each dimension (1-5) based on RUBRIC.md criteria
2. **Identify** all issues, ranked by severity (P0/P1/P2)
3. **Create** a patch plan (max 5 items)
4. **Evaluate** the stop condition
5. **Output** a critique card

## Scoring Process

For each dimension, check against the loaded inputs:

### Model Coherence (Critical, min 4)
- Compare to _model/truth/entities.yaml
- Compare to _model/truth/actions.yaml
- Compare to _model/truth/states.yaml
- Compare to _model/truth/permissions.yaml
- Flag any phantom actions or states

### Information Architecture (Critical, min 4)
- Compare to _ia/grammar.yaml
- Check URL patterns
- Check breadcrumb accuracy
- Check back behavior

### Visual Craft (High, min 4)
- All values from _ui/tokens.yaml?
- Token combinations valid per constraints.capability_matrix?
- No forbidden patterns (text-hover, icon-hover, ring-default, focus/background)?
- Components from _ui/components.yaml?
- Within archetype budget?
- Hierarchy clear?

### Interaction (High, min 4)
- Motion per _interaction/PHYSICS.md?
- Focus per _interaction/FOCUS.md?
- Disclosure per _interaction/PROGRESSION.md?
- Choreography per _interaction/CHOREOGRAPHY.md?
- All states present?

### Correctness (Critical, min 5)
- Data from server, not client?
- Numbers reconcile?
- No invariant violations (_invariants/REGISTRY.md)?
- No bugs?
- Error handling complete?

### Accessibility (Critical, min 4)
- Keyboard navigation complete?
- Contrast meets AA?
- Focus indicators visible?
- Screen reader compatible?

### Performance (Medium, min 3)
- Meets budgets in config/tech-foundation.yaml?
- Renders within navigation_ms budget?
- No layout shift?
- Virtualization if needed?

### Architectural Compliance (Critical, min 4)
- Is config/tech-foundation.yaml status "active"?
- Persistence implementation matches data.persistence_mode?
- Auth implementation matches auth.mode + auth.tenancy?
- Sync implementation matches sync.mode?
- Non-goals in non_goals_v1 respected (not built)?
- Design tooling matches declared choices in tech-foundation.yaml tooling section?

### Affordance Integrity (Critical, min 4)
Check AF-001 through AF-007 per `_invariants/REGISTRY.md`:
- AF-001 (buttons)
- AF-002 (links)
- AF-003 (chevrons)
- AF-004 (breadcrumbs)
- AF-005 (disabled states)
- AF-006 (progress indicators)
- AF-007 (primary flows)

### Cognitive Load (High, min 3)
- What is the primary mental model of this screen? (state it)
- How many new concepts does this screen introduce? (target: 1, max: 2)
- Are secondary concepts deferred or behind progressive disclosure?

### Sharpness Test (High, min 3)
- Does this feature make the product feel more focused?
- Could a first-time user ignore this and still succeed?
- If removed, would the product become clearer?

### Output Type Alignment (High, min 3)
- Is the output type correct for the intent? (Decision / Display / Export / Narrative)
- If showing a system: Is it demonstrated in use, or merely enumerated?
- If narrative output: Is it read-only, curated, and contextual?
- Does the structure match the output type's key traits?
- Does this surface advance a documented job? (If `_jobs/REGISTRY.yaml` is populated, check JOB-NNN mapping)

### Overview Page Quality (High, min 3) — if applicable
- Can user answer: What's the state? Where should attention go? What's at risk?
- Is there ONE primary signal per item? (Signal Hierarchy)
- Are items ordered by significance, not arbitrarily? (Meaningful Ordering)
- Are states disambiguated? (not just "pending" or "incomplete")
- Does page interpret without recommending?

### Narrative Output Standards (High, min 4) — if applicable
- Is intent explicit? (what system optimizes for, not aspirations)
- Is structure progressive? (reveals dependency/hierarchy, not flat list)
- Is state interpretable? (contextual meaning, no success/failure judgment)
- Is omission intentional? (absence reads as confidence, not gaps)
- Would a non-author understand this correctly?
- Could this appear in a client presentation?

### User Expectation: Action Contract (Critical, min 4)
- Can user move forward from this surface? (or understands why not)
- Are expected actions available? (based on surface type)
- Are metrics clickable? (drill down to details) (EX-001)
- Are CTAs contextual? (not just "Continue") (EX-002)
- "If I clicked everything clickable, would I feel blocked or empowered?"
- If "blocked" more than twice → surface fails

### User Expectation: Information Contract (Critical, min 4)
- What questions did user arrive with? Are they answered?
- What questions does displayed content raise? Are they answered?
- Can user understand without external knowledge?
- Are metrics contextualized? (what it measures, good/bad) (IX-001)
- Are status indicators explained? (IX-002)
- Are empty states explained? (IX-004)

### User Expectation: Explanation Coverage (High, min 4)
- Do all mandatory targets have explanation path? (state badges, progress, disabled, counts)
- Is explanation rung appropriate? (lowest sufficient)
- Do tooltips follow contract? (meaning not instruction, ≤2 lines, accessible)
- Is no tooltip the sole explanation source? (XP-005)
- "Explain It to a Client" test: Can every element be explained without designer speaking?

### User Expectation: Orientation Contract (Critical, min 4)
- Can user answer "Where am I?" within 2 seconds?
- Are at least 2 orientation signals present? (breadcrumb, title, nav state, context)
- Does page title match navigation item? (OR-001)
- Do deep pages have breadcrumbs? (OR-002)
- Is current nav location visually indicated? (OR-003)
- If deep-linkable, is page self-sufficient? (OR-004)

### User Expectation: Confidence Contract (High, min 4)
- Does color imply quality judgment? (CF-001 — should not)
- Are rankings/sorts explained? (CF-002)
- Is incompleteness visible? (CF-003)
- Are defaults/suggestions marked? (CF-004)
- Is uncertainty explicit? (CF-005)
- Could any element mislead about certainty?

### User Expectation: Freshness Contract (Medium, min 3)
- Does stale-able data show freshness? (FR-001)
- Does synced data show sync status? (FR-002)
- Can user answer "Is this current?" without asking?

### User Expectation: Feedback Contract (Critical, min 4)
- Do all actions produce visible feedback? (FB-001)
- Do errors explain recovery? (FB-002)
- Is success explicitly confirmed? (FB-003)
- Do async operations show progress? (FB-004)
- After any action, can user answer "Did that work?"

### User Expectation: Prediction Contract (High, min 4)
- Do destructive actions show consequences? (PR-001)
- Do bulk actions show affected count? (PR-002)
- Do confirmations include context? (PR-003)
- Are cascading effects warned? (PR-004)
- Before significant action, can user answer "What will happen?"

### User Expectation: Reversibility (High, min 3)
- Are irreversible actions explicitly marked? (RV-001)
- Is soft-delete preferred over hard-delete? (RV-002)
- Is undo available for reversible actions? (RV-003)
- Is time-limited reversibility shown? (RV-004)
- Does Regret Minimization Check pass?

### User Expectation: Continuity Contract (Medium, min 3)
- Is scroll position preserved? (CN-001)
- Are unsaved changes warned? (CN-002)
- Does back button preserve form data? (CN-003)
- Are filters preservable? (CN-004)

### User Expectation: Completion Contract (High, min 4)
- Is progress visible for multi-step flows? (CP-001)
- Is completion signaled? (CP-002)
- Is next step clear after completion? (CP-003)
- Can user answer "Am I done here?"

### User Expectation: Exit Awareness (High, min 4)
- Does user know what they've accomplished? (EA-001)
- Does user know what remains? (EA-002)
- Is next destination obvious? (EA-003)
- Is save state unambiguous? (EA-004)
- Would user feel confident (not anxious) if leaving now?

### Explanation Restraint (Medium, min 3)
- Does surface pass Demo Test? (Would you hide anything for a demo?)
- Does surface pass Scan Test? (Understandable without reading all explanations?)
- Does surface pass Density Test? (No more than 3 tooltips visible at once?)
- Is anything over-explained?

### Visual Quality: Hierarchy (High, min 4)
- Is there one primary focal point? (VQ-005)
- Is the focal point the most important element?
- Are there competing visual emphases?
- Does the surface pass the Squint Test? (hierarchy visible when blurred)

### Visual Quality: Rhythm (High, min 4)
- Does spacing use defined scale only? (VQ-001)
- Is there consistent vertical cadence?
- Do sections clearly begin and end?
- Are there cramped or overly sparse areas?

### Visual Quality: Density (High, min 3)
- Is density class appropriate for task? (VQ-006)
- Is density consistent within surface?
- Does density match peer product expectations?

### Visual Quality: Consistency (Critical, min 5)
- Do same elements have same treatment? (VQ-007)
- Are icons from single family? (VQ-004)
- Is typography from defined scale? (VQ-003)
- Are colors from token system? (VQ-002)
- Are there any one-off components?

### Visual Quality: Craft (High, min 4)
- Does surface pass Peer Test? (Could exist in Linear/Stripe/Notion)
- Does surface pass Craft Test? (No apologies needed)
- Does surface pass Screenshot Test? (Pitch deck worthy)
- Is alignment precise? (No "almost" alignment)
- Are there arbitrary values? (VQ-008)

### Reference-Informed Evaluation
- Were reference products analyzed before building? (explore.md Step 0)
- Do the transferable principles appear in the implementation?
- Are user conventions from reference products respected?
- If reference analysis was skipped, is there justification?

**Scoring impact:** Missing reference analysis for Complex tasks = maximum Visual Craft score of 3 (cannot score 4+ without calibration against external references).

### Vocabulary: Legibility (High, min 4)
- Are all terms self-evident, contextual, or learnable? (no opaque jargon)
- Do technical terms match industry usage?
- Does plain language test pass? (simplified where possible)
- Would two professionals interpret each term the same way?

### Vocabulary: Discoverability (Critical, min 4)
- Do non-obvious terms have in-context explanation? (VO-001)
- Do status/state labels have tooltips?
- Do category badges have tooltips?
- Can user learn any term without navigation? (VO-003)
- Does First Encounter Test pass for all terms?

### Vocabulary: Consistency (Critical, min 4)
- Does same term mean same thing everywhere? (VO-002)
- Does same concept use same term everywhere?
- Do UI labels match system terminology?
- Are there any partial synonyms causing confusion?

### Content Quality (High, min 4)
- Do error messages follow what/why/what-next structure? (`_content/SYSTEM.md`)
- Do empty states name what's missing and provide CTA? (`_content/PATTERNS.md`)
- Do buttons start with verbs and name the action specifically?
- Do confirmation dialogs name specific consequences?
- Is there any generic text ("Something went wrong", "No results")?
- Does writing match manifest.yaml voice settings?
- Is sentence case used consistently (not Title Case)?

### Vocabulary: Neutrality (High, min 3)
- Do terms describe rather than judge? (VO-004)
- Is there any implied criticism of user?
- Is there any manufactured urgency?
- Is status factual, not emotional?

### Symbol Vocabulary (Critical, min 4)
- Do bespoke symbols have in-context explanation? (VO-005)
- Are symbols distinguishable without color? (VO-006)
- Do symbols encode state, not emotion?
- Do symbols have textual equivalents?
- Is legend visible at point of use? (sticky or per-symbol tooltips)
- Are progress ratios labeled? (VO-007)
- Does Ratio Test pass? ("X of Y are Z" expressible)

### Symbol Grammar (High, min 4)
- Do all status symbols use single primitive family? (SY-001)
- Do symbols have consistent optical weight? (SY-002)
- Does progression map to single visual axis? (SY-003)
- Is progression monotonic? (SY-004)
- Does Symbol Validity Test pass for all symbols?
- Are there any mixed-grammar anti-patterns?
- Are symbols legible at small sizes (12px)?

### Progress & Status Semantics (High, min 4)
- Is there a clear primary progress signal? (PS-001)
- Does Progress Sentence Test pass? (PS-002)
- Are status labels descriptive, not evaluative? (PS-003)
- Are fractions/ratios labeled with context?
- Are there competing progress signals at same visual level?
- Do status labels avoid judgment words? ("healthy", "behind", "good")

### User Expectations: Pre-Build Verification (Critical, min 4)
- Was peer context specified before building? (UE-001)
- Was absence detection performed? (UE-002)
- Were expected actions enumerated? (UE-003)
- Are surface role requirements satisfied? (UE-004)
- Does Inner Monologue Test pass? (UE-005)
- Does Visual-implies-interactive law hold? (UE-006)
- Is expectation debt tracked? (UE-007)

### User Expectations: Bounded Curiosity (Critical, min 4)
- Were candidate features explored before building? (UE-008)
- Were features classified (Expected/Helpful/Speculative/Dangerous/Prevented)? (UE-009)
- Was Restraint Gate applied to all features? (UE-010)
- Are rejected features documented with reasoning? (UE-011)
- Does the surface feel expectation-complete (not sparse, not bloated)?
- Can you explain why features NOT built were rejected?

### User Expectations: Expectation Invention Loop (Critical if new capability)
- Was EIL trigger evaluated? (Is this new data, state, or affordances?)
- If triggered, was EIL performed? (EIL-001)
- Were immediate expectations documented? (what users now see/do/expect tracked)
- Were secondary expectations documented? (history, undo, explanation, comparison, consistency) (EIL-003)
- Were trust expectations documented? (status, provenance, constraints, errors, definitions) (EIL-004)
- Are non-goals explicitly stated? (EIL-002)
- Was cascade decision made? (Must Build / Must Defer / Must Prevent)
- Do EIL outputs feed Pre-Build? (EIL-005)
- Is EIL artifact created in `_decisions/eil/`?

### User Expectations: Component Contracts (High, min 4)
- Do cards navigate on click? (Component Contract: Card)
- Do metrics have drill-down? (Component Contract: Metric)
- Do status badges have explanation on hover? (Component Contract: Badge)
- Do progress indicators show composition? (Component Contract: Progress)
- Do buttons perform actions or explain why disabled? (Component Contract: Button)

### User Expectations: Absence Detection (High, min 4)
- Were Navigation features checked? (entry, back, hierarchy)
- Were Creation features checked? (new, duplicate, template)
- Were Management features checked? (rename, delete, status change)
- Were Understanding features checked? (explanation, progress, learn more)
- Were Continuity features checked? (resume, what changed, incomplete)
- Are all P0 absences addressed?

### User Expectations: Surface Role (Critical, min 4)
- Is surface type correctly identified? (Index/Detail/Workspace/Dashboard/Settings/Onboarding)
- Does surface include ALL must-have features for its type?
- For Index: Create, open, status summary, empty state, search (if >5)?
- For Detail: Key info, primary action, back nav, edit affordance?
- For Workspace: Save indication, undo, manipulation affordances, exit clarity?
- For Dashboard: Metrics with drill-down, time context, freshness signal?

### Synthesis Artifact: Reverse Engineering (Critical, min 4)
- Are artifact sections defined for this product? (SA-001)
- Does each product feature trace to an artifact section?
- Are section requirements documented (what info/decisions/states needed)?
- Is section maturity tracked (Renderable/Partial/Placeholder/Blocked)?
- Are features without artifact justification explicitly documented?

### Synthesis Artifact: Readiness (Critical, min 4)
- Can each artifact section be rendered truthfully? (SA-002)
- Are undecided areas explicitly marked, not hidden? (SA-003)
- Would external delivery require apology? (should be no) (SA-004)
- Does artifact require verbal explanation? (should be no) (SA-006)
- Does artifact pass the Agency Test? (would premium agency ship this?)

### Synthesis Artifact: Honesty (Critical, min 4)
- Does artifact show actual state, not aspirational? (SA-005)
- Are placeholders clearly marked as placeholders? (SA-002)
- Is uncertainty never presented as decision? (SA-003)
- Could artifact be shared externally without disclaimers?
- Does artifact avoid "agency theater" (polished but represents nothing)?

### Moat Alignment (Optional, min 3) — if moat-conscious preset active
- Does this surface strengthen at least one declared moat? (MT-001)
- Does this surface undermine any existing moat? (If yes, is it justified?)
- Are moat-building claims testable, not marketing? (MT-002)
- Are export formats treated as contracts? (MT-003)
- Is decision rationale captured for institutional memory? (MT-004)
- Does feature pass Compounding Test? (more valuable with usage)
- Does feature pass Replaceability Test? (hard to recreate elsewhere)
- Does feature pass Integration Test? (creates dependencies)
- Does feature pass Memory Test? (accumulates context)

### Directional Coherence (Conditional, min 3)
**Fires only when `config/manifest.yaml` → `thesis.claim` is filled.**
- Does this surface serve a feature that aligns with the product thesis?
- Does the feature this surface belongs to multiply at least one other feature?
- If this surface were removed, would other features lose value? (multiplication test)
- Are orphan features on this surface explicitly justified?

### Flow Architecture Compliance (Conditional, min 4)
**Fires only when a Product Spec declares Screen Intent Declarations.**
- Does the Primary UI Object match what was declared?
- Is the Role Intent (Orientation/Action/Information/Review) served by the screen structure?
- Is the declared Dominance Requirement met visually?
- Is vocabulary compliant with gating declaration?
- Does the Outcome Declaration match the actual user state change?
- Does the Emotional Intent match the perceived tone?
- Flag mismatches between declaration and implementation

### Flow Continuity (Conditional — if `_flows/REGISTRY.yaml` is populated, min 4)
**Fires only when the surface participates in a registered flow (FLOW-NNN).**
- Does the surface maintain momentum within the flow? (No dead ends, no unexplained waits)
- Is the handoff from the previous surface smooth? (Context preserved, no re-orientation)
- Is the handoff to the next surface prepared? (Clear next step, data carries forward)
- Does the surface's emotional tone match its position in the flow's emotional arc?
- Can the user abandon the flow gracefully? (Work preserved, clear exit)
- Can the user re-enter the flow without starting over?
- Flag any flow step where the user must context-switch to a different flow

### Collaboration Quality (Conditional — if `collaboration` extension active, min 4)
**Fires only when `collaboration` capability extension is active AND the surface has a collaboration layer above "none."**
- **Awareness Clarity:** Is it obvious who else is present and what they're doing?
- **Communication Context:** Do conversations happen where the work is? Are @mentions and comments contextual?
- **Notification Quality:** Are notifications timely, relevant, and actionable? No notification fatigue? No silent important events?
- **Conflict Handling:** If multiple users can edit, is the conflict resolution strategy clear and functional?
- **State Ownership:** Is it clear which state is shared vs. personal? No accidental changes to others' views?

### Intelligence Quality (Conditional, min 4)
**Fires only when `intelligence` capability extension is active AND the surface has smart features.**
- **Confidence Calibration:** Does confidence display match actual confidence? No overstating? Unknown = silent?
- **Suggestion Quality:** Are suggestions dismissible, reasoned, contextual, non-accumulating, expertise-respecting?
- **Agency Preservation:** Does the feature make the user more capable or more dependent? Manual path equally accessible?
- **Failure Gracefully:** When intelligence is wrong or unavailable, does the product still work? No error clutter?
- **Transparency:** Can the user understand what data feeds the intelligence and why it suggests what it suggests?

### Copy as Design Material (High, min 4)
- Are labels specific and descriptive, not generic? ("manage," "optimize," "streamline" = placeholder language)
- Are primary CTAs specific to their action? (e.g., "View 47 Tasks" not "View All"; "Create Project" not "Get Started")
- Do labels tell user what happens next, not just that something happens?
- Do empty states guide the user, not just announce emptiness?
- Do error messages explain what went wrong AND how to fix it?
- Would microcopy make sense to someone who has never seen the product?
- Is onboarding text teaching, not just labeling?
- Flag any copy that requires domain knowledge the spec doesn't assume
- **Generic CTA copy in primary flows = P1** ("View All", "Learn More", "Get Started", "Continue" without destination context)

### Attention & Cognitive Cost (High, min 3)
- How many distinct elements compete for attention on this surface?
- Does the information hierarchy match the importance hierarchy?
- Do interruptions (modals, toasts, alerts) justify their attention cost?
- Is the product competing with itself for the user's attention?
- Are there moments that restore cognitive energy (confirmations, progress, delight)?
- Flag surfaces where attention demand exceeds ≈7 distinct elements without progressive disclosure

### Adaptive Layout (Conditional, min 4)
**Fires only when surface supports multiple form factors.**
- Is content priority declared and preserved at each form factor?
- Is the primary content/action above the fold on the smallest supported form factor?
- Does navigation transform appropriately (not just collapse)?
- Are all hover-dependent elements accessible via touch?
- Do all interactive elements meet touch target minimums (≥44px)?
- Are drag-and-drop and keyboard shortcut alternatives provided?
- Does the form factor declaration exist in the surface spec?
- Flag any hover-only information as P1

### Information Surfacing (High, min 4)
- Was a Surfacing Audit performed? (inventory → action-change test → tier validation → cross-surface consistency)
- Are Tier 1 items ≤ 5 per surface? (more dilutes all of them)
- Are Tier 1 + Tier 2 items ≤ 15 per surface above the fold?
- Are all Tier 4 items removed from the surface? (100% — no Tier 4 present)
- Does surfacing pattern match surface type? (Dashboard/Detail/List/Editor per `_model/patterns/SURFACING.md`)
- Is cross-surface consistency maintained? (same information, same tier, same treatment — unless role justifies change)
- Does each Tier 1 item pass the Action-Change Test? ("If this changed, would the user do something different here?")
- Flag any surface with >5 Tier 1 items as P1 (tier inflation)
- Flag any Tier 4 information present on surface as P2 (noise)

### Shortcut Detection (Medium, min 3)
- For each major design pattern used, can the agent articulate WHY this pattern was chosen for this specific context?
- Is there evidence the pattern was evaluated against alternatives, or was it the first/familiar choice?
- For high-leverage surfaces (onboarding, primary workflows), were multiple approaches considered?
- Flag any pattern where the justification is "it's standard" or "it's what we usually do" without contextual reasoning

### Confidence Flagging (Meta-Dimension)

After completing all dimension scores, the agent must identify:

- **2–3 lowest-confidence design decisions** for this surface
- For each, state: what the decision was, why confidence is low, and what would increase confidence

Format:

```
## Low-Confidence Decisions

1. [Decision]: [What was decided]
   Confidence: [Low/Medium]
   Reason: [Why uncertain]
   Would help: [What input/validation would resolve this]

2. ...
```

This is not scored. It is a lightweight escalation path for human review of uncertain decisions. If the agent has zero low-confidence decisions, this itself is a flag — re-examine.

## Tradeoff Evaluation

After scoring, review the surface for design tradeoffs. Reference `_quality/HEURISTICS.md`.

- Were competing design principles identified explicitly?
- Did the Priority Ladder resolve ambiguous conflicts? (Tier 1 > Tier 2 > Tier 3)
- Were tradeoff resolutions documented for significant decisions?
- Did any Tier 3 principle (efficiency, density, aesthetics, novelty) override a Tier 2 principle (clarity, safety, predictability, completeness)? If so, flag as P1.
- Were Common Tradeoff Resolutions consulted for known conflicts?

**If tradeoffs were resolved without acknowledgment**, flag as P1: "Unacknowledged tradeoff — [principle A] vs [principle B]."

---

## Issue Severity

P0 (Must fix before ship):
- Breaks truth model/permissions
- Violates invariant (_invariants/REGISTRY.md)
- Violates Notion Constitution law
- Invalid token combination (TK-002, TK-003)
- Building without active tech-foundation (TF-001)
- Architectural mismatch (TF-002, TF-003, TF-004)
- Dead affordance (AF-001, AF-002, AF-003, AF-004)
- Primary flow incomplete (AF-007)
- Navigation dead end
- Incorrect data
- Keyboard broken
- Navigation loses user
- User blocked with no explanation (EX-003 violation)
- Metric displayed with no drill-down AND no context (EX-001 + IX-001)
- User cannot determine location (OR-001, OR-003 violation)
- Action produces no visible feedback (FB-001)
- Unsaved work lost without warning (CN-002)
- Destructive action with no consequence warning (PR-001)
- Irreversible action not marked as irreversible (RV-001)
- User would feel anxious if leaving (EA-004 + Abandonment Test)
- No primary focal point (VQ-005 violation)
- Colors outside token system (VQ-002 violation)
- Fails Peer Test (would cause visual shock in Linear/Stripe/Notion)
- Primary expected action has no affordance (UE-003)
- Surface role requirement missing (UE-004 — e.g., Index with no Create)
- P0 absence detected and unaddressed (UE-002)
- Inner Monologue Test fails on "What is this page?" (UE-005)
- Element looks interactive but isn't (UE-006)
- Card doesn't navigate on click (Component Contract violation)
- No peer context specified before building (UE-001)
- Expected feature classified and neither built nor deferred (UE-009)
- New capability shipped without EIL (EIL-001)
- New capability has no documented non-goals (EIL-002)
- Prevented assumption not addressed in UI (users will falsely assume capability exists)
- Product feature not traceable to artifact section (SA-001)
- Artifact section presents placeholder as decision (SA-002, SA-003)
- Artifact would require apology if shared externally (SA-004)
- Artifact shows aspirational state as actual state (SA-005)

P1 (Must fix before "done"):
- Inconsistent states
- Visual issues
- Missing states
- Unclear copy
- Disabled without explanation (AF-005)
- Progress indicator unclear (AF-006)
- Built without intent modeling (LAW-011)
- Wrong output type for intent
- System enumerated instead of demonstrated
- Overview has competing signals (Signal Hierarchy violation)
- Overview uses ambiguous states (State Disambiguation)
- Overview ordered arbitrarily (Meaningful Ordering)
- Narrative output with flat structure (no progression)
- Narrative output with unexplained omissions (inconsistent depth)
- Narrative output with judgmental state language ("failed", "behind", "overdue")
- Narrative output with aspirational intent (what it hopes to be, not what it is)
- Metric not clickable (EX-001)
- Generic CTA without context (EX-002)
- Status indicator without meaning explanation (IX-002)
- Progress without composition clarity (IX-003)
- Empty state without guidance (IX-004)
- Error without resolution path (IX-005)
- State indicator without explanation path (XP-001)
- Tooltip is sole explanation source (XP-005)
- Tooltip not keyboard accessible (XP-004)
- Client would need designer to explain element
- Deep page without breadcrumbs (OR-002)
- Page title doesn't match nav item (OR-001)
- Color implies quality without explanation (CF-001)
- Ranking without criteria explanation (CF-002)
- Incompleteness hidden (CF-003)
- Defaults not marked as defaults (CF-004)
- Stale data without freshness signal (FR-001)
- Synced data without sync status (FR-002)
- Error without recovery guidance (FB-002)
- Success not explicitly confirmed (FB-003)
- Bulk action without affected count (PR-002)
- "Are you sure?" without context (PR-003)
- Scroll position lost on return (CN-001)
- Multi-step flow without progress indicator (CP-001)
- Completion not signaled (CP-002)
- Next step unclear after completion (CP-003)
- Soft-delete not used where possible (RV-002)
- Undo not available for reversible action (RV-003)
- Time-limited reversibility not shown (RV-004)
- User cannot see accomplishment (EA-001)
- User cannot see what remains (EA-002)
- Next destination unclear (EA-003)
- Over-explanation (fails Density Test)
- Surface fails Demo Test
- Spacing not from defined scale (VQ-001)
- Typography not from defined scale (VQ-003)
- Mixed icon families (VQ-004)
- Density mismatch for task (VQ-006)
- Same elements have different treatment (VQ-007)
- Arbitrary visual values (VQ-008)
- Competing visual emphasis
- Inconsistent vertical rhythm
- "Almost" alignment (close but not on grid)
- One-off component (pattern used exactly once)
- Fails Screenshot Test
- Fails Craft Test (designer would apologize)
- Domain term with no explanation path (VO-001)
- Same term used with different meanings (VO-002)
- Explanation requires navigation away (VO-003)
- Judgmental vocabulary/status language (VO-004)
- Opaque term (fails First Encounter Test)
- Fails Two Professionals Test (ambiguous interpretation)
- Acronym without expansion on first use
- Status/state label without tooltip
- Bespoke symbol with no tooltip or legend (VO-005)
- Symbols rely on color alone for differentiation (VO-006)
- Progress ratio unlabeled (VO-007)
- Status symbols mix primitive families (SY-001)
- Symbols have inconsistent optical weight (SY-002)
- Progression uses multiple visual axes (SY-003)
- Non-monotonic symbol progression (SY-004)
- Directional symbol for non-directional state
- Symbol not legible at small sizes
- Fails Symbol Validity Test
- Multiple progress signals with no clear primary (PS-001)
- Progress representation fails Sentence Test (PS-002)
- Evaluative status labels ("healthy", "behind") (PS-003)
- Celebratory/emotional icons in status indicators
- Legend not visible at point of use (scroll orphans symbols)
- Competing progress signals at same visual level
- Secondary expected action has no affordance (UE-003)
- P1 absence detected and unaddressed (UE-002)
- Inner Monologue Test has weak answers (UE-005)
- Expectation debt not tracked (UE-007)
- Candidate features not explored before building (UE-008)
- Features not classified before implementation (UE-009)
- Restraint Gate not applied (UE-010)
- Rejected features not documented (UE-011)
- Metric doesn't drill down (Component Contract: Metric)
- Status badge has no explanation (Component Contract: Badge)
- Progress indicator has no composition view (Component Contract: Progress)
- Feature Category Checklist incomplete (Absence Detection)
- Surface feels hollow (expectation-incomplete)
- Surface feels bloated (features beyond expectations)
- Cannot explain why rejected features were not built
- Secondary expectations not examined (EIL-003 — history, undo, comparison, consistency)
- Trust expectations not examined (EIL-004 — status, provenance, constraints, errors, definitions)
- EIL outputs not feeding Pre-Build (EIL-005)
- EIL artifact missing from `_decisions/eil/`
- "Prevented" classification not used where false assumptions are possible
- Artifact section maturity not tracked (SA-002)
- Missing "what's required" documentation for artifact section (SA-001)
- Artifact requires verbal explanation (SA-006)
- Artifact section not traceable to product features
- No Verbal Explanation test not performed
- Agency Test not performed
- Artifact sections not defined for product
- Generic placeholder copy used in primary flows ("Manage your X", "Optimize your Y")
- Pattern reuse without contextual justification on high-leverage surface
- Screen Intent Declaration mismatch (when declarations exist)
- Attention demand > 7 elements without progressive disclosure
- Term used differently than on sibling surface (CS-001, verify at Gate 8)
- Status label doesn't match sibling surface (CS-002, verify at Gate 8)
- Link/metric promises content that destination may not show (CS-003, verify at Gate 8)
- Count may not reconcile with sibling surface (CS-004, verify at Gate 8)

P2 (Backlog):
- Polish items
- Nice-to-haves

## Stop Condition

PASS if:
- P0 count = 0
- P1 count ≤ 2
- All scores meet minimums (Correctness must be 5)

FAIL if any condition not met.

ESCALATE if cycle 3 and still failing.

## Output Format

[See LOOP.md for critique card format]
```

---

## Example Output

```markdown
# Critique: Project List

**Cycle:** 1 of 3
**Date:** 2026-01-31

## Scores

| Dimension | Score | Notes |
|-----------|-------|-------|
| Model Coherence | 4/5 | All actions match, minor label inconsistency |
| Information Architecture | 5/5 | URLs correct, breadcrumbs accurate |
| Visual Craft | 3/5 | Missing hover states on rows |
| Interaction | 4/5 | Focus management correct |
| Correctness | 5/5 | Data verified against API |
| Accessibility | 4/5 | Keyboard complete, contrast passes |
| Performance | 4/5 | Renders in 150ms |

## Issues

### P0 (Block Ship)
None

### P1 (Block Done)
1. [VISUAL] No hover state on table rows — violates states.md requirement
2. [VISUAL] Action buttons use 14px spacing, should be 16px per tokens

### P2 (Backlog)
1. [POLISH] Loading skeleton could match final layout more closely

## Patch Plan

1. Add `hover:bg-gray-50` to table rows → P1-1
2. Change button spacing from `space-3.5` to `space-4` → P1-2

## Stop Condition

**FAIL** — 2 P1 issues remain, Visual Craft at 3 (needs 4)

---
```

---

## Rules

1. **Be specific** — Cite which file/rule is violated
2. **Be actionable** — Each issue has a clear fix
3. **Be honest** — Don't inflate scores to pass
4. **Be efficient** — Max 5 patches per cycle
5. **Be decisive** — PASS/FAIL/ESCALATE, no "maybe"

---

## After Critique

If **PASS**: Document scorecard, ship the work.

If **FAIL**: Execute patch plan, run critique again (cycle N+1).

If **ESCALATE** (cycle 3 failed):
```markdown
## Escalation Report

### Why Stuck
- [Issue 1]
- [Issue 2]
- [Issue 3 max 5]

### What Input Is Missing
- [File] needs [information]

### Recommendation
- [Suggested path forward]

**Requires human decision to proceed.**
```
