# Focus Management

> How attention is directed and controlled.

**Gravity:** Intent & Constraints
**Scope:**
  - RESPONSIBLE FOR: Focus behavior, keyboard navigation, attention rules
  - MUST NOT CONTAIN: Component specs, visual styling
  - DECISIONS ALLOWED: Focus order within patterns
  - DECISIONS DEFERRED: Component implementation

---

## Core Principle

> **Focus is the user's cursor. Never steal it.**

Moving focus without user action is disorienting. Let users control their attention.

---

## Focus Invariants

| ID | Rule | Description |
|----|------|-------------|
| FOCUS-001 | Never steal focus | Focus moves only on user action |
| FOCUS-002 | Always visible | Focus indicator always visible on focused element |
| FOCUS-003 | Escape always works | Escape closes any transient UI and returns focus |
| FOCUS-004 | Logical order | Tab order matches visual/reading order |
| FOCUS-005 | Return focus | Closing overlay returns focus to trigger |

---

## What Can Move Focus

### Permitted (User-Initiated)

| Action | Focus Moves To |
|--------|----------------|
| Click element | That element |
| Tab/Shift+Tab | Next/previous focusable |
| Open modal/drawer | First focusable in overlay |
| Close modal/drawer | Trigger element |
| Submit form | Success message or next logical element |
| Error on submit | First error field |

### Prohibited (System-Initiated)

| Action | Why Prohibited |
|--------|----------------|
| Data loads | User may be reading elsewhere |
| Notification arrives | Interrupts user's task |
| Timer expires | Unexpected context switch |
| Background process completes | User moved on |

**Exception:** Critical alerts (session expiry, data loss risk) may request attention but should NOT move focus.

---

## Focus Trapping

### When to Trap

- Modal dialogs (required)
- Drawers in blocking mode (required)
- Command palette (required)

### When NOT to Trap

- Non-blocking drawers
- Popovers
- Dropdowns
- Tooltips

### Trap Implementation

```yaml
focus_trap:
  entry:
    - Store previous activeElement
    - Move focus to first focusable in trap
    
  during:
    - Tab cycles within trap
    - Shift+Tab reverse cycles
    - Focus cannot leave trap
    
  exit:
    - Restore focus to stored element
    - If element gone, focus body
    
  escape:
    - Always exits trap
    - Triggers same as clicking outside (if permitted)
```

---

## Focus Order Patterns

### Page Layout

```
[Skip Link] → [Header Nav] → [Sidebar Nav] → [Main Content] → [Footer]
```

### Form

```
[Label/Input 1] → [Label/Input 2] → ... → [Cancel] → [Submit]
```

### Modal

```
[Close Button] → [Content Fields] → [Secondary Action] → [Primary Action]
```

### Table

```
[Column Headers (sortable)] → [Row 1 actions] → [Row 2 actions] → ...
```

---

## Focus Restoration

### After Modal Close

```yaml
modal_close:
  focus_to: trigger_element
  fallback: main_content_start
```

### After Drawer Close

```yaml
drawer_close:
  focus_to: trigger_element
  fallback: main_content_start
```

### After Inline Edit Cancel

```yaml
inline_edit_cancel:
  focus_to: the_edited_element
```

### After Delete Action

```yaml
delete_action:
  focus_to: next_item_in_list
  fallback: previous_item
  final_fallback: list_container
```

---

## Keyboard Navigation

### Global Shortcuts

| Shortcut | Action | Scope |
|----------|--------|-------|
| `Tab` | Next focusable | Always |
| `Shift+Tab` | Previous focusable | Always |
| `Escape` | Close/cancel | Overlays, edit modes |
| `Enter` | Activate/submit | Buttons, links, forms |
| `Space` | Activate | Buttons, checkboxes |

### Component-Specific

| Component | Keys | Behavior |
|-----------|------|----------|
| Dropdown | `↑↓` | Navigate options |
| Dropdown | `Enter` | Select option |
| Tabs | `←→` | Switch tabs |
| Table | `↑↓` | Navigate rows |
| Menu | `↑↓` | Navigate items |
| Menu | `→` | Open submenu |
| Menu | `←` | Close submenu |

---

## Skip Links

Required for accessibility:

```html
<a href="#main-content" class="skip-link">
  Skip to main content
</a>
```

**Rules:**
- Visible on focus (hidden otherwise)
- First focusable element on page
- Links to main content area
- Additional skip links for repeated blocks (sidebar, etc.)

---

## Focus Indicators

### Visual Requirements

```yaml
focus_indicator:
  style: outline_or_ring
  color: primary_or_high_contrast
  width: 2px minimum
  offset: 2px from element (don't overlap)
  
  never:
    - Remove outline without replacement
    - Use color alone (must have shape change)
```

### By Component Type

| Component | Focus Style |
|-----------|-------------|
| Buttons | Ring around button |
| Inputs | Border highlight |
| Links | Underline + outline |
| Cards | Ring around card |
| List items | Background + ring |

---

## Complex Component Focus

### Combobox/Autocomplete

```yaml
combobox:
  input:
    - Always focusable
    - Arrow keys move in list
    
  list:
    - Not focusable (aria-activedescendant)
    - Visual highlight follows arrow keys
    
  selection:
    - Enter selects highlighted
    - Focus stays in input
```

### Data Table

```yaml
data_table:
  navigation:
    - Tab to table
    - Arrow keys navigate cells
    - Tab moves to next focusable after table
    
  selection:
    - Space toggles row selection
    - Shift+Arrow selects range
```

### Tabs

```yaml
tabs:
  navigation:
    - Tab to tab list
    - Arrow keys switch tabs
    - Tab moves to tab content
    
  activation:
    - Automatic (arrow switches tab)
    - OR Manual (arrow moves, Enter activates)
```

---

## Accessibility Notes

### ARIA for Focus

```yaml
aria:
  - aria-activedescendant: For composite widgets
  - aria-hidden: Remove from focus order
  - tabindex="-1": Programmatically focusable only
  - tabindex="0": In natural tab order
  - Never tabindex > 0: Breaks natural order
```

### Screen Reader Announcements

Focus changes should announce:
- Element role
- Element name
- Element state (if relevant)
- Context (if changed significantly)
