# Interaction Choreography

> Motion explains causality. Focus follows attention. Nothing else moves.

**Authority:** This file binds all primitives and layouts. No exceptions.

---

## Core Principle

Animation is not decoration — it's explanation. Every motion must answer:
- What changed?
- Why did it change?
- Where should I look now?

If motion doesn't clarify, remove it.

---

## Focus Transfer Rules

Focus must always move predictably. Users should never wonder "where did my cursor go?"

### Transfer Chain

```
Page → List → Detail Drawer → Modal → Popover → Tooltip
  ↑                                                  │
  └──────────────────────────────────────────────────┘
                    (on dismiss)
```

### Rules

| Trigger | Focus Moves To |
|---------|----------------|
| Open drawer | First focusable in drawer |
| Open modal | First focusable in modal (or primary action for confirmations) |
| Open popover | First focusable in popover |
| Close overlay | Element that triggered it |
| Trigger gone | Nearest logical ancestor |
| Delete item | Next item in list (or previous if last) |
| Create item | The new item |
| Save form | First error field (if error) or trigger element |
| Bulk action | Selection count indicator |

### Focus Trapping

| Surface | Trapped? |
|---------|----------|
| Modal | Yes — Tab cycles within |
| Drawer | Yes — Tab cycles within |
| Popover | Yes — Tab cycles within |
| Dropdown | Yes — Arrow keys cycle, Tab exits |
| Tooltip | No — not focusable |
| Toast | No — but has focus target if action present |

### Focus Visibility

- Focus ring **always visible** on keyboard navigation
- Focus ring **hidden** on mouse click (`:focus-visible`)
- Focus ring style: `shadows.focus` token only

---

## Allowed Transitions

Only these transition types are permitted:

| Type | Use For | Duration | Easing |
|------|---------|----------|--------|
| **Fade** | Overlays, tooltips, toasts | 150–200ms | ease-out |
| **Slide** | Drawers, panels, mobile nav | 200–250ms | ease-out |
| **Scale** | Modals, popovers (subtle: 0.95→1) | 200–300ms | ease-out |
| **Collapse** | Accordions, expandable sections | 200ms | ease-out |
| **None** | State changes, selections, hovers | 0ms or ≤100ms | — |

### Duration Limits

| Context | Maximum Duration |
|---------|------------------|
| Micro-interaction (hover, toggle) | 100ms |
| Standard transition | 200ms |
| Large surface (modal, drawer) | 300ms |
| Complex choreography | 400ms absolute max |

**Rule:** If you think you need >400ms, you don't. Simplify.

### Easing

| Motion Type | Easing | Use |
|-------------|--------|-----|
| Enter (appear) | ease-out | Elements coming into view |
| Exit (disappear) | ease-in | Elements leaving view |
| Move (reposition) | ease-in-out | Elements changing position |
| Spring | cubic-bezier(0.34, 1.56, 0.64, 1) | Celebrations only |

**Forbidden easing:**
- Linear (feels mechanical)
- Bounce (feels unserious)
- Elastic (feels toy-like)

---

## State Transitions

### Hover/Active/Focus

| State | Transition | Duration |
|-------|------------|----------|
| Hover enter | Instant or fade | ≤100ms |
| Hover exit | Fade | 150ms |
| Active (press) | Instant | 0ms |
| Focus | Instant | 0ms |

**Rule:** Hover should feel instant. Exit can be slightly softer.

### Selection

| Action | Visual Response | Timing |
|--------|-----------------|--------|
| Select item | Background change | Instant (<16ms) |
| Deselect item | Background change | Instant |
| Range select | All items update | Instant |
| Select all | All items update | Instant |

**Rule:** Selection is never animated. It's state, not motion.

### Loading

| Context | Behavior |
|---------|----------|
| Initial load | Show skeleton after 100ms delay |
| Refresh | Keep content visible, subtle indicator |
| Action pending | Button shows spinner, disable interaction |
| Long operation | Progress indicator after 1s |

**Rule:** Never show loading for <100ms. It creates flicker.

---

## Forbidden Animations

These patterns are **never allowed**:

| Pattern | Why Forbidden |
|---------|---------------|
| Layout shift on hover | Causes missed clicks |
| Bounce/elastic easing | Feels unserious |
| Parallax scrolling | Causes motion sickness |
| Auto-playing carousels | Hijacks attention |
| Zoom on image hover | Unexpected, jarring |
| Color cycling/pulsing | Distracting, accessibility issue |
| Infinite spinners >5s | Must show progress or error |
| Entry animations on scroll | Performance + distraction |
| Staggered list animations | Slow, wastes time |
| Modal shake on invalid | Aggressive, condescending |

---

## Coordinated Motion

When multiple elements move together, they must be choreographed.

### Drawer + List

```
1. User clicks list item (0ms)
2. List item shows selected state (instant)
3. Drawer slides in (250ms ease-out)
4. Focus moves to drawer (after slide complete)
```

### Modal + Backdrop

```
1. Trigger clicked (0ms)
2. Backdrop fades in (200ms)
3. Modal scales + fades in (250ms, starts at 50ms)
4. Focus moves to modal (after animation)
```

### Toast Appearance

```
1. Action completes (0ms)
2. Toast slides up + fades in (200ms)
3. Toast auto-dismisses (5000ms)
4. Toast slides down + fades out (150ms)
```

### Collapse/Expand

```
1. Toggle clicked (0ms)
2. Content height animates (200ms ease-out)
3. Focus stays on toggle
```

---

## Reduced Motion

When `prefers-reduced-motion: reduce` is set:

| Normal Behavior | Reduced Motion |
|-----------------|----------------|
| Slide transitions | Instant or fade only |
| Scale transitions | Fade only |
| All durations | ≤100ms max |
| Loading spinners | Static or very slow |
| Progress bars | Static fill, no animation |

**Implementation:**
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

## Performance Constraints

| Metric | Target |
|--------|--------|
| Animation frame rate | 60fps minimum |
| JS during animation | None (CSS only) |
| Layout during animation | None (transform/opacity only) |
| Paint during animation | Minimal |

**Allowed animation properties:**
- `transform` (translate, scale, rotate)
- `opacity`

**Forbidden animation properties:**
- `width`, `height` (use `transform: scale`)
- `top`, `left`, `right`, `bottom` (use `transform: translate`)
- `margin`, `padding` (causes layout)
- `color`, `background-color` (can cause paint, use opacity)

---

## Primitive Bindings

Each primitive must declare its choreography:

| Primitive | Enter | Exit | Internal |
|-----------|-------|------|----------|
| Modal | Scale + fade (250ms) | Scale + fade (200ms) | None |
| Drawer | Slide (250ms) | Slide (150ms) | None |
| Popover | Fade (150ms) | Fade (100ms) | None |
| Dropdown | Fade (100ms) | Fade (100ms) | None |
| Tooltip | Fade (150ms, 300ms delay) | Fade (0ms) | None |
| Toast | Slide + fade (200ms) | Slide + fade (150ms) | None |
| Command Palette | Scale + fade (200ms) | Fade (150ms) | None |
| Table | None | None | Instant selection |
| Navigation | None (or collapse 200ms) | None | Instant highlight |

---

## Audit Checklist

For any animation in the product:

- [ ] Does it explain a state change?
- [ ] Is duration ≤300ms (≤400ms for complex)?
- [ ] Does it use only transform/opacity?
- [ ] Does it respect reduced motion?
- [ ] Does focus move correctly after?
- [ ] Is it in the allowed transitions list?
- [ ] Does it run at 60fps?

If any answer is "no," remove or fix the animation.

---

## Transition Design

> The moments between screens are design decisions, not implementation details.

### Four Dimensions of Transitions

Every transition between surfaces should be evaluated across:

| Dimension | Question | Purpose |
|-----------|----------|---------|
| **Relationship Communication** | Does the transition show how the source and destination relate? | Spatial orientation |
| **Context Preservation** | Does the user retain their mental context across the transition? | Don't lose the user's place |
| **Attention Management** | Does the transition direct attention to the right place on arrival? | Speed and focus |
| **Completion Signaling** | Does the user know when the transition is done and they can act? | Clarity of arrival |

### Evaluation Per Transition

For each navigation event in a primary flow:

| Check | Pass | Fail |
|-------|------|------|
| Relationship | User understands spatial relationship (drilling in, going back, switching peer) | User is disoriented about where they are in the hierarchy |
| Context | Key information from previous screen is accessible or remembered | User must re-find information they just had |
| Attention | User's eye is drawn to the most important element on arrival | User scans randomly to find where to look |
| Completion | Arrival is clear and immediate | User is unsure whether the page is still loading or ready |

### Transition Types

| Navigation Type | Expected Relationship Signal |
|----------------|------------------------------|
| Drill down (list → detail) | Slide or expand from source element |
| Go back (detail → list) | Reverse of entry, return to scroll position |
| Peer switch (tab A → tab B) | Horizontal movement or instant swap |
| Modal overlay | Dim background, animate from center or trigger |
| New context | Full page transition, clear visual reset |

Disorienting transition in primary flow = P1. Transition that loses scroll position or form state = P1 (see also Continuity Contract in `_expectations/CONTRACTS.md`).
