# Progressive Disclosure

> Revealing complexity when needed, not before.

**Gravity:** Intent
**Scope:**
  - RESPONSIBLE FOR: Information layering, reveal patterns
  - MUST NOT CONTAIN: Component specs, visual styling
  - DECISIONS ALLOWED: When to hide/reveal
  - DECISIONS DEFERRED: How to animate (PHYSICS.md)

> **Lifecycle-level disclosure:** For strategic across-lifecycle disclosure (what features are visible at first use vs. after 20 uses), see `_extensions/disclosure/PROTOCOL.md` when the `disclosure` capability extension is active. This file governs within-surface disclosure mechanics.

---

## Core Principle

> **Show only what's needed for the current task.**

Complexity should be available, not visible. The happy path should be obvious.

---

## Disclosure Levels

| Level | Contains | Visibility |
|-------|----------|------------|
| 1 - Primary | Essential actions, key info | Always visible |
| 2 - Secondary | Common options, supporting info | One click/hover away |
| 3 - Tertiary | Advanced options, edge cases | Behind "More" or settings |
| 4 - Expert | Power features, rarely used | Deep in settings or command palette |

**Rule:** 80% of users should never need Level 3 or 4.

---

## Disclosure Patterns

### Expand/Collapse

```
▸ Advanced Options
  └─ [Hidden content]

▾ Advanced Options
  ├─ Option A
  ├─ Option B
  └─ Option C
```

**When to use:**
- Optional content within a form
- Additional details on an entity
- FAQ/help content

**Rules:**
- Clear affordance (chevron, "Show more")
- Preserve state during session
- Don't hide required fields

### Hover Reveal

```
[Card Content          ]     →     [Card Content    [Actions]]
```

**When to use:**
- Row/card actions in lists
- Toolbar items
- Supporting information

**Rules:**
- Touch devices need alternative (long-press or visible)
- Don't hide essential actions
- Reveal should be fast (<100ms)

### Click to Edit

```
View:  Project Name: Alpha        [✎]
Edit:  [Alpha____________] [✓] [✕]
```

**When to use:**
- Inline editing
- Settings that rarely change
- Reducing form fatigue

**Rules:**
- Clear edit affordance
- Escape to cancel
- Save on blur or explicit action

### Tabs/Segmented Control

```
[Overview] [Details] [Settings]
```

**When to use:**
- Parallel content categories
- Same entity, different aspects
- Reducing page length

**Rules:**
- Content is independent (switching doesn't lose state)
- Max 7 tabs
- Tabs for categories, not steps

### Modal/Drawer

```
[Trigger] → Opens overlay with full content
```

**When to use:**
- Focused task requiring attention
- Content that doesn't fit inline
- Actions needing confirmation

**Rules:**
- Clear trigger
- Easy dismissal
- Don't nest (one level max)

---

## What to Disclose When

### Show Immediately (Level 1)

- Primary action for the screen
- Entity name and status
- Critical errors/warnings
- Navigation location

### Show on Demand (Level 2)

- Secondary actions (edit, delete)
- Detailed metadata
- Filters and sorting
- Help text

### Hide Behind "More" (Level 3)

- Bulk actions
- Export/import
- Advanced filters
- Rarely used settings

### Hide in Settings/Palette (Level 4)

- Keyboard shortcuts customization
- Display density preferences
- Integration settings
- Power user features

---

## Anti-Patterns

### Hiding Critical Information

❌ Error messages behind "Details"
❌ Required fields in collapsed sections
❌ Primary action in overflow menu

### Premature Disclosure

❌ All options visible on simple forms
❌ Advanced settings on first screen
❌ Every possible action always shown

### Inconsistent Disclosure

❌ Same information hidden some places, shown others
❌ Different reveal mechanisms for similar content
❌ Disclosure level varying by user role without indication

---

## Form Disclosure

### Simple Form

```
┌─────────────────────────────────────┐
│ Name *                              │
│ [________________________]          │
│                                     │
│ Email *                             │
│ [________________________]          │
│                                     │
│         [Cancel] [Create]           │
└─────────────────────────────────────┘
```

Show only required fields. "Add more details" for optional.

### Complex Form with Disclosure

```
┌─────────────────────────────────────┐
│ Name *                              │
│ [________________________]          │
│                                     │
│ Email *                             │
│ [________________________]          │
│                                     │
│ ▸ Additional Details                │
│                                     │
│         [Cancel] [Create]           │
└─────────────────────────────────────┘
```

---

## Settings Disclosure

### Grouped with Defaults

```
┌─────────────────────────────────────┐
│ Notifications                       │
│ ├─ Email notifications    [ON]      │
│ └─ ▸ Email preferences              │
│                                     │
│ Privacy                             │
│ ├─ Profile visibility    [Team]    │
│ └─ ▸ Advanced privacy               │
└─────────────────────────────────────┘
```

Most users see toggles. Power users expand for details.

---

## Disclosure and Accessibility

### ARIA Patterns

```yaml
expand_collapse:
  trigger:
    aria-expanded: "true" | "false"
    aria-controls: "content-id"
  content:
    id: "content-id"
    hidden: when collapsed

tabs:
  tablist:
    role: "tablist"
  tab:
    role: "tab"
    aria-selected: "true" | "false"
    aria-controls: "panel-id"
  panel:
    role: "tabpanel"
    aria-labelledby: "tab-id"
```

### Screen Reader Announcements

- Announce expanded/collapsed state
- Announce when content is revealed
- Don't hide content from screen readers unless truly supplementary

---

## Performance Considerations

### Lazy Loading

- Content behind disclosure can be lazy loaded
- Show skeleton while loading
- Don't block interaction

### Animation

- Use PHYSICS.md timing for reveals
- Collapse faster than expand
- Respect reduced motion preference
