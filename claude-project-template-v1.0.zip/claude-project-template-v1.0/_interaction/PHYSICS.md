# Interaction Physics

> How motion communicates meaning.

---

## Core Principle

> **Motion is information, not decoration.**

Every transition answers: "What just happened?" If it doesn't communicate, it shouldn't exist.

---

## Timing Budgets

| Category | Duration | Easing | When |
|----------|----------|--------|------|
| Micro | 100-150ms | ease-out | Hover, toggle, focus |
| Small | 150-200ms | ease-out | Dropdown, tooltip, reveal |
| Medium | 200-300ms | ease-in-out | Modal, drawer, panel |
| Large | 300-400ms | ease-in-out | Page transition, view change |

**Rule:** Exit faster than enter.

---

## Motion Invariants

| ID | Rule |
|----|------|
| MOTION-001 | User-initiated only |
| MOTION-002 | Reduced motion respected |
| MOTION-003 | No content shift during load |
| MOTION-004 | Exit faster than enter |
| MOTION-005 | Motion has purpose |

---

## Easing Intent

| Easing | Communicates | Use For |
|--------|--------------|---------|
| ease-out | "Here it is" | Entrances |
| ease-in | "Going away" | Exits |
| ease-in-out | "Moving" | Position changes |
| linear | "Progress" | Loading bars |

Never use bounce or elastic easing.

---

## Prohibited Motion

- Auto-play animation
- Parallax scrolling
- Bouncy/elastic easing
- Motion on data update
- Looping decoration

---

## Performance

| Constraint | Limit |
|------------|-------|
| Simultaneous animations | Max 3 |
| Frame rate | 60fps minimum |
| CPU during animation | <30% |

Animate only `transform` and `opacity` (GPU-accelerated).

---

## Reduced Motion

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

Always respect this preference.

---

## Touch & Gesture Interactions

These guidelines apply to touch-enabled devices.

### Touch Target Sizes

| Element Type | Minimum Size | Recommended |
|--------------|--------------|-------------|
| Primary action | 44×44px | 48×48px |
| Secondary action | 44×44px | 44×44px |
| Dense list item | 44px height | 48px height |
| Icon button | 44×44px | 48×48px |

**Rule:** Touch targets may be visually smaller if the tappable area meets minimums.

### Gesture Vocabulary

| Gesture | Use For | Never For |
|---------|---------|-----------|
| Tap | Primary activation | — |
| Long press | Context menu, selection mode | Primary actions |
| Swipe horizontal | Reveal actions, dismiss, navigate | Primary content interaction |
| Swipe vertical | Scroll, pull-to-refresh | Page navigation |
| Pinch | Zoom | Navigation |
| Double tap | Zoom to fit, like/favorite | Primary actions |

### Touch Feedback

| Feedback Type | When | Duration |
|---------------|------|----------|
| Highlight/ripple | On touch start | 100-150ms |
| State change | On touch end | Immediate |
| Haptic (if available) | Destructive actions, mode changes | Single pulse |

### Touch Invariants

| Rule | Rationale |
|------|-----------|
| Touch targets don't overlap | Prevents mis-taps |
| Swipe actions have visual hint | Discoverability |
| Long press has alternative | Accessibility |
| No hover-dependent UI | Touch has no hover state |
| Edge gestures are reserved | System navigation |

### Preventing Accidental Input

| Pattern | Implementation |
|---------|----------------|
| Destructive swipe | Require >50% swipe OR tap to confirm |
| Accidental tap | Require touch-up within target |
| Palm rejection | Ignore touches > certain size |
| Scroll vs. tap | Distinguish based on movement threshold |

---

## Related Invariants

- A11Y-002: Touch targets ≥44px on touch devices
- A11Y-003: Motion respects prefers-reduced-motion
