# Evolution Protocol

> How the starter kit learns from the projects it creates.

---

## The Problem

Every new project starts by copying the starter kit into a fresh Git repository. From that moment, the copy is independent. Learnings discovered inside a project — new laws, better patterns, refined critique dimensions — have no automatic path back to the canonical template.

Without a formal protocol, knowledge stays trapped in individual projects, and the template stops evolving.

**The human will forget to propagate learnings.** This protocol is designed so that Claude captures them automatically during existing mandatory activities, and prompts the human only when decisions are needed.

---

## The Lifecycle

```
Template (canonical)
    │
    ├──► Copy → Project A (Blueprint)
    │         Claude auto-captures learnings at session exit + critique
    │         tags promote-candidates in registry + Notion queue
    │                │
    ├──► Copy → Project B (Bureau)
    │         Claude auto-captures learnings at session exit + critique
    │         tags promote-candidates in registry + Notion queue
    │                │
    │  ◄─────────────┘
    │  Claude prompts reconciliation
    │  (when threshold or trigger met)
    │
    ▼
Template v.next
    │
    ├──► Upgrade Advisory in changelog
    │    (existing projects review what changed)
    │
    ...
```

---

## Part 1: Automated Learning Capture

The system has three mandatory moments where Claude is already doing structured work. Learning capture hooks into each of these — no new rituals needed.

### Hook 1: Critique Loop Exit

**When:** Every time a critique loop reaches SHIP or ESCALATE.

**What Claude does (automatically, every time):**

After writing the final scorecard, Claude appends a **Learning Signal** section:

```markdown
## Learning Signals

### Template Gap Detected?
- [ ] Yes — describe below
- [x] No

### If Yes:
- **Gap:** [What the template should have covered but didn't]
- **Evidence:** [What happened because of the gap]
- **Generic?** [Would this affect any product, not just this one?]
- **Proposed fix:** [New invariant / law / pattern / dimension]
```

This takes Claude 30 seconds. It's appended to the scorecard that's already being written. If there's nothing to report, it's just a checked "No" box.

**When a gap IS detected:** Claude also:
1. Adds `promote: candidate` to the relevant Decision Registry entry (or creates one)
2. Creates a Notion entry in the **Learning Queue** database (see Part 2)

### Hook 2: Session Exit

**When:** End of every work session (the "Transition" phase in `govern.md`).

The existing session exit already requires:
- Log implementation in Notion
- Document decisions
- Capture learnings in Thinking Log

**What's added — Claude's Session Exit Learning Check:**

Before signing off, Claude asks itself three questions and reports the answers:

```
SESSION EXIT — LEARNING CHECK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Did I work around a template limitation today?
   → [Yes/No. If yes: what, and is it generic?]

2. Did I discover a pattern that should be reusable?
   → [Yes/No. If yes: what pattern?]

3. Did I make a decision that future projects would face?
   → [Yes/No. If yes: which decision?]

Template learnings found: [0/1/2/3]
→ [If >0: Created Notion Learning Queue entries]
```

**This is mandatory.** Claude includes this block at the end of every session summary. If all three answers are "No," it's still printed (it takes 5 seconds and confirms nothing was missed).

### Hook 3: Decision Registry Entry

**When:** Any time a decision is logged in `_decisions/REGISTRY.md`.

**What's added:** The `promote` field becomes a required consideration (not a required value). Claude must explicitly state one of:

```yaml
promote: candidate    # Believed to be generic
promote: local        # Project-specific, not for template
promote: uncertain    # Needs more evidence, revisit later
```

This forces the question "is this just for us, or for everyone?" at the moment the decision is made — when context is freshest.

---

## Part 2: The Learning Queue (Notion)

A new Notion database that collects all promote-candidates across projects in one place.

### Database: Learning Queue

| Field | Type | Description |
|-------|------|-------------|
| Learning | Title | Brief description of what was learned |
| Source Project | Select | Which project discovered this (Blueprint, Bureau, etc.) |
| Category | Select | `law` / `invariant` / `pattern` / `dimension` / `gate` / `process` / `archetype` |
| Decision ID | Text | Link to the project's Decision Registry entry |
| Evidence | Rich text | What happened that surfaced this learning |
| Generic Test | Checkbox | Would this help a brand new project? |
| Status | Select | `captured` / `reviewing` / `approved` / `rejected` / `merged` |
| Urgency | Select | `next-reconciliation` / `when-convenient` / `before-next-project` |
| Captured Date | Date | When Claude logged it |
| Reviewed Date | Date | When human reviewed it |

### Why Notion?

Because you already check Notion for project work. The Learning Queue lives alongside your existing databases. You'll see it. You don't need to remember a separate system.

### Auto-Population

Claude creates entries here whenever it detects a learning via Hook 1, 2, or 3. You never create these manually — Claude does it as part of existing work.

---

## Part 3: Claude-Initiated Reconciliation Prompts

Since you won't remember to run reconciliation, Claude will prompt you. This works through three mechanisms:

### Mechanism A: Threshold Trigger (In-Session)

At the start of any session in the **template project** (this project), Claude checks the Learning Queue:

```
LEARNING QUEUE STATUS
━━━━━━━━━━━━━━━━━━━━
Unreviewed items: 7
Oldest unreviewed: 18 days ago
Source projects: Blueprint (4), Bureau (3)

⚠️ Threshold reached (5+ unreviewed items).
Recommend running reconciliation before continuing.

Run reconciliation now? [You decide]
```

**Threshold triggers:**
- 5+ unreviewed items in Learning Queue
- Any item older than 30 days without review
- Before starting a new project (Claude checks and warns)

### Mechanism B: Periodic Memory Prompt

Claude's memory (this project's context) includes the instruction to periodically prompt:

> **At the start of roughly every 5th session in this project, check the Learning Queue
> for unreviewed items and prompt the human if any exist.**

This is a soft reminder, not a gate. You can say "not now" and Claude moves on. But it ensures the queue doesn't grow silently forever.

### Mechanism C: Pre-Copy Gate

**Before copying the template for a new project**, Claude checks:

```
PRE-COPY CHECKLIST
━━━━━━━━━━━━━━━━━━
- [ ] Learning Queue has 0 unreviewed items
      → Currently: 3 unreviewed ⚠️
- [ ] All approved items have been merged
      → Currently: 1 approved but unmerged ⚠️
- [ ] CHANGELOG.md reflects latest version
      → Currently: v12.7.0 ✓

Recommendation: Merge pending learnings before copying.
This ensures the new project starts from the best possible baseline.
```

---

## Part 4: The Reconciliation Process

When you agree to run reconciliation (prompted by Claude), here's what happens:

### Step 1: Claude Pulls the Queue

Claude reads all `status: captured` items from the Learning Queue and presents them grouped by category:

```
RECONCILIATION: 2026-03-01
━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 7 items to review

INVARIANTS (3):
1. [Blueprint] Empty state guidance — IX-007 candidate
2. [Bureau] Tooltip keyboard access — already covered by XP-004?
3. [Blueprint] Cascade warning for bulk status change

PROCESS (2):
4. [Blueprint] Critique cycle limit 3→4 when visual complexity is high
5. [Bureau] Pre-build should check Design Library before building

PATTERNS (2):
6. [Blueprint] Data table inline editing pattern
7. [Bureau] Filter persistence across navigation
```

### Step 2: You Decide (with Claude's Recommendation)

For each item, Claude provides a recommendation, but **you make the call**:

```
Item 1: Empty state guidance invariant
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Source: Blueprint DEC-003
Evidence: In 3 separate critiques, empty states lacked next-step guidance.
Generic test: ✓ Every product has empty states.

Claude's recommendation: APPROVE
Rationale: This tightens the system (not loosens). Universal applicability.
Proposed implementation: Add IX-007 to _invariants/REGISTRY.md

Your decision: [approve / reject / defer / modify]
```

### Step 3: Claude Implements Approved Items

For each approved item:
1. Creates a Decision Registry entry in the **template's** `_decisions/REGISTRY.md`
2. Implements the change (new invariant, updated loop, etc.)
3. Updates `CHANGELOG.md`
4. Marks the Learning Queue item as `merged`
5. Marks the source project's decision as `promote: merged`

### Step 4: Upgrade Advisory

Claude drafts the Upgrade Advisory for the changelog (you review before committing):

```markdown
## v12.8.0 — [Release Name]

### Upgrade Advisory

**From Learning Queue — merged from active projects:**

**Recommended updates for existing projects:**
- [ ] Add invariant IX-007 (empty state guidance) to `_invariants/REGISTRY.md`
- [ ] Add cascade warning requirement to `_critique/PROMPT.md`

**Optional updates:**
- [ ] Filter persistence pattern in `_model/patterns/data-display.md`

**Rejected (stays project-local):**
- Data table inline editing — too specific to Blueprint's entity model
```

---

## Part 5: The Divergence Ledger

Every project copy maintains a file tracking intentional differences from the template.

### File: `_decisions/DIVERGENCE.md`

```markdown
# Divergence Ledger

> Intentional differences between this project and the canonical template.

## Template Version at Copy

- **Copied from:** v12.7.0
- **Copy date:** 2026-02-01
- **Last synced to:** v12.7.0

## Intentional Divergences

| ID | What Changed | Why | Reversible? |
|----|-------------|-----|-------------|
| DIV-001 | Removed Gate 7 | Not using moat-conscious preset | Yes |
| DIV-002 | Added custom archetype: "canvas" | Creative tool class | No — project-specific |
| DIV-003 | Relaxed P1 threshold to ≤ 3 | Early-stage velocity | Yes — tighten before v1 |
```

### How Projects Consume Upstream Updates

When the template releases a new version:

1. **Claude reads the Upgrade Advisory** (you don't have to find it).
2. **Claude checks the Divergence Ledger** for conflicts.
3. **Claude proposes** which changes to pull in and which to skip.
4. **You approve** the proposed changes.
5. **Claude applies** them and updates the "Last synced to" field.

For those comfortable with Git, a more hands-on approach:
```bash
# Add template as a remote in your project repo
git remote add template <template-repo-url>
git fetch template

# See what changed
git diff HEAD..template/main -- _invariants/ _critique/ _quality/

# Cherry-pick specific files
git checkout template/main -- _invariants/REGISTRY.md
```

---

## Part 6: Measuring Health

### Signals Claude Monitors

| Signal | Healthy | Unhealthy | Claude Action |
|--------|---------|-----------|---------------|
| Queue size | < 5 unreviewed | 5+ unreviewed | Prompt reconciliation |
| Queue age | < 30 days oldest | 30+ days | Escalate urgency |
| Promote rate per project | 3-10 per milestone | 0 or 20+ | Flag in session exit |
| Rejection rate | 30-60% | < 10% or > 80% | Note in reconciliation summary |
| Time to merge | 1-2 cycles | 5+ cycles | Warn of growing backlog |
| New project baseline | Improving | Stagnant | Flag during pre-copy check |

### Quarterly Template Health Report

Claude generates this during system audits (already a periodic activity in `govern.md`):

```markdown
## Template Health: Q1 2026

### Learning Flow
- Items captured: 12
- Items merged: 7
- Items rejected: 3
- Items pending: 2
- Average time to merge: 22 days

### Template Growth
- Version: v12.7.0 → v12.9.0
- New invariants: +3
- New patterns: +1
- Removed/merged: -1 (consolidated duplicate)

### Project Divergence
- Blueprint: 3 intentional divergences, synced to v12.9.0
- Bureau: 5 intentional divergences, synced to v12.8.0 (1 version behind)

### Recommendation
Bureau should sync to v12.9.0 — the empty state invariant (IX-007)
would have prevented 2 critique issues found in last sprint.
```

---

## Summary: Who Does What

| Activity | Who Does It | When |
|----------|-------------|------|
| Detect learnings | **Claude** (automatic) | Critique exit, session exit, decision entry |
| Create Learning Queue entries | **Claude** (automatic) | When learning detected |
| Prompt reconciliation | **Claude** (automatic) | Threshold reached, periodic, pre-copy |
| Decide approve/reject/defer | **You** (human decision) | When Claude prompts |
| Implement approved changes | **Claude** (after your approval) | During reconciliation |
| Draft Upgrade Advisory | **Claude** (automatic) | After template version bump |
| Apply upstream changes to project | **Claude** (proposes, you approve) | When you choose to sync |
| Monitor health signals | **Claude** (automatic) | Ongoing |

**Your only job:** Show up when Claude prompts you and say yes/no/later. Everything else is automated.

---

## Governance

### Authority

| Action | Who Decides |
|--------|-------------|
| Tagging `promote: candidate` | Claude (automatic during hooks) |
| Approving/rejecting during reconciliation | You — human decision |
| Implementing approved changes in template | Claude (after your approval) |
| Consuming upstream changes in a project | You — per-project decision |

### Rules

1. **The template never absorbs project-specific content.** Generic Over Specific is absolute.
2. **Promote decisions follow the same governance as all decisions.** Full Decision Registry entries with context, rationale, and rejected alternatives.
3. **The Tighten First rule applies to promotions.** Candidates that add flexibility must demonstrate tightening was tried first.
4. **Reconciliation outputs are logged.** Every ritual produces a dated record.
5. **Projects are never forced to upgrade.** Downstream notification is advisory.
6. **Claude captures, human decides.** Claude never merges a learning into the template without human approval.

---

## Integration Points

This protocol connects to existing system files:

| Existing File | What Changes |
|---------------|-------------|
| `_critique/LOOP.md` | Add Learning Signal section to scorecard output |
| `_modes/govern.md` | Add Session Exit Learning Check to Transition phase |
| `_decisions/REGISTRY.md` | Add `promote` as a required consideration field |
| `.claude/NOTION.md` | Add Learning Queue database (8th database) |
| `.claude/RUNBOOK.md` | Add learning capture to Task Flow |
| `CHANGELOG.md` | Add Upgrade Advisory format to release sections |
| `_decisions/DIVERGENCE.md` | New file in each project copy |

---

## Quick Reference

| Concept | How It Works |
|---------|-------------|
| Capture a learning | Claude does it automatically at critique exit, session exit, or decision entry |
| See all pending learnings | Check Notion Learning Queue |
| Run reconciliation | Wait for Claude to prompt you, or ask Claude to check the queue |
| Upgrade a project copy | Claude reads advisory, checks divergence, proposes changes, you approve |
| Measure health | Claude reports during quarterly system audits |
