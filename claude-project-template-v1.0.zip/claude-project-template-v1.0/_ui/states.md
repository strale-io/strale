# UI States

> How to handle loading, empty, and error states.

---

## The Law

> **LAW-004:** Every screen handles loading, empty, and error states.

---

## Loading States

### Skeleton Loading
- Show within 100ms
- Match final layout exactly
- Fade content in when ready

### Spinner Loading
- Show after 300ms (longer delay)
- Use for indeterminate duration
- Center in containing area

---

## Empty States

### First-Time Empty
```
[Illustration - optional]
No {entities} yet
{Explanation of what goes here}
[Create First]
```

### Filtered Empty
```
No matching results
Try adjusting your filters.
[Clear Filters]
```

---

## Error States

### Inline Error
- Below field
- Explain how to fix
- Don't just say "Invalid"

### Section Error
```
Couldn't load {section}
[Try Again]
```

### Page Error
```
Something went wrong
We couldn't load this page.
[Try Again] [Go Home]
```

---

## State Transitions

- Skeleton → Content: fade (150ms)
- Skeleton → Empty: fade (150ms)
- Loading → Error: replace (150ms)
- Refresh: keep content, overlay indicator

---

## State Disambiguation

Avoid ambiguous aggregate states like "pending" or "incomplete."

| Ambiguous | Disambiguated |
|-----------|---------------|
| Pending | Not started / In progress / Needs review / Blocked |
| Incomplete | Not started / Partially complete / Blocked |
| In progress | Active / Paused / Waiting on dependency |
| Done | Completed / Approved / Shipped |

**Rule:** If a state could mean multiple things, split it.

Users need to know *why* something isn't done, not just *that* it isn't.

### State Granularity by Context

| Context | Granularity |
|---------|-------------|
| Summary/header | Coarse (3-4 states max) |
| List/table | Medium (show actionable distinctions) |
| Detail view | Fine (full state + history) |

The same entity may show different state granularity depending on where it appears.

---

## ARIA State Patterns

For accessibility, UI states must map to appropriate ARIA attributes.

### Loading States

| UI State | ARIA Pattern |
|----------|--------------|
| Content loading | `aria-busy="true"` on container |
| Skeleton visible | `aria-hidden="true"` on skeleton, live region for content |
| Spinner loading | `role="status"` with `aria-label="Loading"` |
| Progress bar | `role="progressbar"` with `aria-valuenow`, `aria-valuemin`, `aria-valuemax` |

### Empty States

| UI State | ARIA Pattern |
|----------|--------------|
| Empty collection | `aria-label` on container describing empty state |
| Filtered empty | Live region announces "No results" |

### Error States

| UI State | ARIA Pattern |
|----------|--------------|
| Inline field error | `aria-invalid="true"`, `aria-describedby` pointing to error message |
| Section error | `role="alert"` on error container |
| Page error | `role="alert"` or focus management to error |

### Interactive States

| UI State | ARIA Pattern |
|----------|--------------|
| Selected | `aria-selected="true"` |
| Expanded | `aria-expanded="true/false"` |
| Pressed (toggle) | `aria-pressed="true/false"` |
| Checked | `aria-checked="true/false/mixed"` |
| Disabled | `aria-disabled="true"` (with explanation) |
| Current (navigation) | `aria-current="page/step/location"` |

### Live Regions

| Content Type | ARIA Live Setting |
|--------------|-------------------|
| Error messages | `aria-live="assertive"` |
| Status updates | `aria-live="polite"` |
| Progress updates | `aria-live="polite"` with `aria-atomic="true"` |
| Toast notifications | `role="status"` or `role="alert"` |

### Focus Management

| State Change | Focus Behavior |
|--------------|----------------|
| Modal opens | Focus moves to modal (first focusable or heading) |
| Modal closes | Focus returns to trigger element |
| Content loads | Focus stays unless user navigated |
| Error occurs | Focus moves to error (for critical errors) |
| Item deleted | Focus moves to next item or parent |

---

## Related Invariants

- UI-002: Focus is never lost
- XP-004: Tooltips are accessible
- A11Y-001: Focus indicators visible in all color schemes
