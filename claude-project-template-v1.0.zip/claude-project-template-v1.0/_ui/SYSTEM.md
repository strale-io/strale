# UI System

> Principles governing the user interface.

---

## Core Principles

### 1. Function Over Form
Every element serves a purpose. If removing it changes nothing, remove it.

### 2. Consistency Over Cleverness
Use existing patterns before inventing. Users have learned how things work.

### 3. Clarity Over Density
When in doubt, add whitespace. Start clear, add density when justified.

### 4. Feedback Always
Every action gets a response. Silence is confusion.

---

## Visual Hierarchy

### Layer Model
```
Layer 3: Overlays (modals, popovers)
Layer 2: Elevated (cards, panels)
Layer 1: Primary surface
Layer 0: Background
```

### Hierarchy Signals
- Size (larger = more important)
- Weight (bold = more important)
- Color (primary = more important)
- Position (top-left = first)
- Space (more around = more important)

---

## Responsive Breakpoints

| Name | Width | Device |
|------|-------|--------|
| sm | <640px | Mobile |
| md | 640-1024px | Tablet |
| lg | 1024-1440px | Desktop |
| xl | >1440px | Large desktop |

---

## Touch Considerations

- Minimum touch target: 44x44px
- Adequate spacing between targets
- No hover-dependent functionality

---

## Color Usage

### Semantic Colors
- Primary: Main actions, links
- Secondary: Supporting actions
- Success: Confirmations
- Warning: Cautions
- Error: Problems, destructive
- Info: Neutral information

### Contrast Requirements
- Text: 4.5:1 minimum (AA)
- Large text: 3:1 minimum
- UI components: 3:1 minimum

Never use color alone to convey meaning.

---

## Feedback Philosophy

### Silent Success
- Success should feel calm and unsurprising
- If the user notices success, the system may be too loud
- Errors are surfaced clearly; success is understated
- Avoid celebrations, confetti, excessive confirmations
- Progress indicators are factual, not cheerful

### Appropriate Feedback

| Action | Feedback |
|--------|----------|
| Save | Quiet checkmark or "Saved" text |
| Delete | Confirmation before, brief acknowledgment after |
| Error | Clear message with resolution path |
| Long operation | Progress indicator with status |

---

## Feature Gravity

Every element competes for attention. Features have mass.

| Weight | Examples |
|--------|----------|
| Heavy | Hero metrics, primary CTAs, navigation |
| Medium | Secondary actions, status indicators |
| Light | Metadata, tooltips, subtle hints |

**Rule:** Heavy features should be few. Too many heavy elements = visual noise.

### Restraint Principles
- Start with nothing, add what's needed
- Question every addition
- Remove before adding
- Default to less

---

## Time-to-First-Value

The primary surface should deliver value immediately.

| Pattern | Anti-pattern |
|---------|--------------|
| Show data immediately | Require setup before showing value |
| Default to useful view | Show empty state requiring configuration |
| Smart defaults | Require all fields before proceeding |
| Progressive disclosure | Front-load complexity |

**Rule:** 3 clicks or less to first meaningful content.

---

## Output Intent

Every surface has an output intent.

| Type | Purpose | Principles |
|------|---------|------------|
| **Decision** | Enable choice | Options clear, consequences visible |
| **Display** | Show information | Hierarchy clear, scannable |
| **Export** | Package for sharing | Self-contained, no context needed |
| **Narrative** | Tell story | Progressive, interpretable |

### Narrative Output Principles

For surfaces producing narrative outputs (exports, reports):

| Guarantee | Meaning |
|-----------|---------|
| **Intent Explicit** | Purpose stated upfront |
| **Structure Progressive** | Complexity builds |
| **State Interpretable** | Status is meaningful, not numeric |
| **Omission Intentional** | Absence implies confidence |

---

## Signal Hierarchy

When showing multiple signals, declare which is primary.

### Priority Rules
- One primary signal per item
- Secondary signals support, don't compete
- Tertiary signals on demand (hover, expand)

### Anti-patterns
- Multiple badges at same visual level
- Competing progress indicators
- Color overload

---

## Semantic vs Progress States

| State Type | Purpose | Example |
|------------|---------|---------|
| **Semantic** | What it means | "Approved", "Blocked", "Active" |
| **Progress** | How far along | "3/10 complete", "In Progress" |

**Rule:** Don't mix. A state is either semantic OR progress, not both.

### Progress Labels

| Avoid | Prefer |
|-------|--------|
| "25% complete" | "Stabilizing" or "3 of 12 decisions made" |
| "Good" / "Bad" | Specific status |
| "Almost done" | Specific remaining count |

---

## Meaningful Ordering

Default ordering must make sense. User should never ask "why is this first?"

| Pattern | Ordering Logic |
|---------|----------------|
| Tasks | Priority, then due date |
| Notifications | Recency |
| Search results | Relevance |
| Settings | Frequency of use |
| Status list | Requires attention first |

---

## Visual Quality Contract

Users judge visual quality in ~500ms — before reading a word.

### Five Dimensions

| Dimension | User's Question |
|-----------|-----------------|
| **Hierarchy** | Do I know where to look? |
| **Rhythm** | Does this feel measured? |
| **Density** | Does this fit the task? |
| **Consistency** | Does this belong together? |
| **Craft** | Was this designed deliberately? |

### Density Classes

| Class | Purpose | Examples |
|-------|---------|----------|
| Sparse | Reflection, orientation | Landing pages, empty states |
| Balanced | Exploration, comparison | Lists, dashboards |
| Dense | Decision-making, execution | Data tables, editors |

### Visual Invariants

| ID | Requirement |
|----|-------------|
| VQ-001 | Spacing from defined scale only |
| VQ-002 | Colors from token system only |
| VQ-003 | Typography from defined scale only |
| VQ-004 | Icons from single family only |
| VQ-005 | One primary focal point per surface |
| VQ-006 | Density class matches surface purpose |
| VQ-007 | Same semantic elements have same treatment |
| VQ-008 | No arbitrary values |

---

## Vocabulary Comprehension

Users must understand the language the product speaks.

### Core Principle

> A world-class product is not one where users eventually learn the language — it's one where the language teaches itself.

### Vocabulary Levels

| Level | Description | Explanation? |
|-------|-------------|--------------|
| Self-evident | Meaning obvious | No |
| Contextual | Clear from context | No |
| Learnable | Clear after explanation | Tooltip |
| Technical | Domain expertise needed | Inline or linked |
| Opaque | Unclear even with explanation | ❌ Fail |

### Vocabulary Invariants

| ID | Requirement |
|----|-------------|
| VO-001 | Domain terms have in-context explanation |
| VO-002 | Terms are used consistently |
| VO-003 | Explanation doesn't require navigation |
| VO-004 | Language is descriptive, not judgmental |
| VO-005 | Bespoke symbols have explanation |
| VO-006 | Symbols distinguishable without color |
| VO-007 | Progress ratios are labeled |

---

## Symbol Grammar System

Status symbols are a visual language. Languages require grammatical consistency.

### Grammar Rules

| Rule | Requirement |
|------|-------------|
| Single Primitive Family | All symbols use same geometric basis |
| Consistent Optical Weight | Same bounding box and visual mass |
| Single Semantic Axis | One variable changes (fill, weight, or count) |
| Monotonic Progression | Visual order = semantic order |
| No Unintended Directionality | Directional symbols only for directional concepts |

### Primitive Families

| Family | Progression | Example |
|--------|-------------|---------|
| Area-fill | Fill percentage | `○` → `◑` → `●` |
| Line-weight | Stroke weight | `╌` → `─` → `━` |
| Count | Quantity | `·` → `··` → `···` |
| Opacity | Transparency | Light → Medium → Dark |

### Symbol Invariants

| ID | Requirement |
|----|-------------|
| SY-001 | Status symbols use single primitive family |
| SY-002 | Status symbols have consistent optical weight |
| SY-003 | Status progression maps to single visual axis |
| SY-004 | Symbol progression is monotonic |

---

## Progress & Status Semantics

### Signal Hierarchy

When multiple progress indicators appear, one must be declared primary.

### The Progress Sentence Test

> Any progress representation must be expressible as:
> "Of [total], [X] are [state A], [Y] are [state B], and [Z] are [state C]."

If you can't say it plainly, the representation is unclear.

### Status Label Requirements
- Descriptive, not evaluative
- Neutral, not judgmental
- Factual, not encouraging
- State-based, not emotional

### Progress Invariants

| ID | Requirement |
|----|-------------|
| PS-001 | Multiple progress signals have declared hierarchy |
| PS-002 | Progress representations pass Sentence Test |
| PS-003 | Status labels are descriptive, not evaluative |

---

## User Expectation Framework

For complete user expectation framework, see:

| Topic | File |
|-------|------|
| Pre-Build Flow, Feature Classification, EIL | `_expectations/FRAMEWORK.md` (principles), `_expectations/PRE-BUILD.md` (operations) |
| 10 User Contracts (Orientation, Action, etc.) | `_expectations/CONTRACTS.md` |
| Quality Tests (Inner Monologue, Peer, Agency) | `_expectations/TESTS.md` |

### Quick Reference

**Feature Classification:**
- Expected — must build or defer
- Helpful — may defer
- Speculative — reject
- Dangerous — forbidden
- Prevented — actively block

**Key Tests:**
- Inner Monologue Test — simulate user thinking
- Dead Surface Test — can user make progress?
- Peer Test — would this fit in Linear/Notion?
- Agency Test — would premium agency ship this?

**Surface Role Requirements:**
- Index/Hub: Create, open, status, empty state
- Detail: Key info, primary action, back nav
- Editor: Save, undo, exit clarity
- Dashboard: Drill-down, time context, freshness

---

## Exit Awareness

> If the user leaves now, will they feel oriented or abandoned?

### Requirements

Every surface must answer:
- What have I accomplished here?
- What remains to be done?
- Where do I go next?

### Invariants

| ID | Requirement |
|----|-------------|
| EA-001 | User can see what was accomplished |
| EA-002 | Incomplete work is visible |
| EA-003 | Next step is clear |
| EA-004 | Leaving doesn't feel like abandonment |

---

## Reversibility

Prefer reversible actions. Explicitly mark irreversible ones.

| Action Type | Expectation |
|-------------|-------------|
| Reversible | Default — no special marking |
| Soft-reversible | Show undo window |
| Hard-reversible | Warn before action |
| Irreversible | Require explicit confirmation |

### Invariants

| ID | Requirement |
|----|-------------|
| RV-001 | Soft-delete preferred over hard-delete |
| RV-002 | Undo available for reversible actions |
| RV-003 | Hard-reversible actions have warnings |
| RV-004 | Irreversible actions require confirmation |

---

## Artifact-First Design (LAW-013)

> The system is designed backward from the artifacts it must produce, not forward from features.

See `_artifacts/SYNTHESIS.md` for complete principles.

### Core Insight

Instead of "What feature should I build?", ask "What must exist for the artifact to be true?"

### Key Tests

| Test | Question |
|------|----------|
| **Agency Test** | Would a premium agency ship this? |
| **No Verbal Explanation** | Can artifact stand alone? |
| **Honesty Test** | Does artifact show actual state? |

### Related Invariants

| ID | Requirement |
|----|-------------|
| SA-001 | Product features serve artifact sections |
| SA-002 | No false placeholders |
| SA-003 | Undecided areas are marked |
| SA-004 | External delivery requires no apology |
| SA-005 | Artifact shows actual state |
| SA-006 | No verbal explanation needed |

---

## Information Grouping

> Related information should be scannable as a single unit. Users read in chunks; layout must respect those chunks.

### The Principle

Users don't read individual elements — they read groups. A name + role + avatar is one unit. A metric + label + trend is one unit. Layout must ensure that related elements cluster together and unrelated elements separate clearly.

### Grouping Rules

| Rule | Requirement |
|------|-------------|
| **Proximity groups** | Elements that belong together are closer to each other than to unrelated elements |
| **Consistent grouping** | The same type of information group uses the same layout pattern throughout the product |
| **Scannable units** | Each group can be understood without reading every element — the group's meaning is clear from structure |
| **No orphans** | No element floats alone without clear group membership |

### Unit Reading Test

For any data display:

1. Identify each information group (what elements form a "chunk")
2. Verify proximity: is within-group spacing < between-group spacing?
3. Verify consistency: are similar groups laid out identically?
4. Verify scannability: can you understand the group's meaning in one glance?

Inconsistent grouping across same-type data = P1. Orphaned elements in primary views = P1.

---

## Progressive Trust Architecture

> Trust is not binary — it accumulates. Design must earn the right to ask for commitment.

> **Disclosure alignment:** When the `disclosure` capability extension is active, trust stages align with lifecycle stages defined in `_extensions/disclosure/PROTOCOL.md`. First Contact and First Value map to Competence trust. Adoption maps to Honesty and Reliability trust. Proficiency/Mastery map to Care trust.

### Trust Accumulation Order

Trust builds through demonstrated competence in this sequence:

| Stage | Trust Built Through | Earned Right |
|-------|-------------------|--------------|
| 1. **Competence** | Product works correctly, reliably | User trusts data and actions |
| 2. **Honesty** | Product shows limitations, admits uncertainty | User trusts information quality |
| 3. **Reliability** | Product behaves consistently over time | User trusts for important work |
| 4. **Care** | Product anticipates needs, prevents mistakes | User trusts with delegation |

### The Core Question

> "Has this product earned the right to ask the user for this level of commitment at this point in their journey?"

### Trust Budget by Journey Stage

| Journey Stage | Safe to Ask | Too Early |
|--------------|-------------|-----------|
| **First visit** | View data, explore freely | Create content, connect accounts |
| **After first success** | Save preferences, create first item | Bulk operations, automations |
| **After repeated use** | Import data, invite collaborators | Delete data, irreversible actions |
| **After trust established** | Automate workflows, delegate decisions | Share externally, financial actions |

### Trust Violations

| Violation | Impact |
|-----------|--------|
| Asking for account creation before showing value | Kills exploration |
| Requesting permissions not yet justified by use | Erodes trust |
| Showing confidence in uncertain data | Destroys credibility when discovered |
| Removing undo after user expects it | Breaks reliability contract |

Trust violation in onboarding = P0. Trust violation in primary flow = P1. See also Confidence Invariants in `_invariants/REGISTRY.md`.
