# Responsive Behavior Specification

> Guidelines for adapting surfaces across viewport sizes and input modalities.

---

## Purpose

This document defines how surfaces adapt across different contexts:
- Viewport sizes (mobile, tablet, desktop)
- Input modalities (touch, mouse, keyboard)
- Orientation (portrait, landscape)

It references but does not redefine archetypes (see `_quality/archetypes/`).

**Companion:** `_ui/ADAPTIVE.md` — defines content priority, navigation transformation, and touch adaptation. RESPONSIVE.md handles *how things reflow*; ADAPTIVE.md handles *what matters most at each form factor*.

---

## Breakpoint System

### Standard Breakpoints

| Name | Width | Target Devices |
|------|-------|----------------|
| `xs` | < 480px | Small phones |
| `sm` | 480px – 767px | Large phones |
| `md` | 768px – 1023px | Tablets (portrait) |
| `lg` | 1024px – 1279px | Tablets (landscape), small laptops |
| `xl` | 1280px – 1535px | Laptops, small desktops |
| `2xl` | ≥ 1536px | Large desktops, monitors |

### Breakpoint Usage

```yaml
breakpoints:
  mobile: __FILL__  # Which breakpoints constitute "mobile"
  tablet: __FILL__  # Which breakpoints constitute "tablet"
  desktop: __FILL__  # Which breakpoints constitute "desktop"
```

---

## Adaptation Strategies

### Layout Adaptation

| Strategy | When to Use | Example |
|----------|-------------|---------|
| **Reflow** | Content can stack vertically | 3-column → 1-column |
| **Collapse** | Secondary content can hide | Sidebar → hamburger menu |
| **Reduce** | Information can be abbreviated | Full labels → icons only |
| **Remove** | Content is optional | Desktop-only features hidden |
| **Relocate** | Element moves to different zone | FAB replaces toolbar action |

### Per-Archetype Defaults

| Archetype | Mobile Strategy | Tablet Strategy |
|-----------|-----------------|-----------------|
| `workspace` | __FILL__ | __FILL__ |
| `detail` | __FILL__ | __FILL__ |
| `overview` | __FILL__ | __FILL__ |
| `configuration` | __FILL__ | __FILL__ |
| `transient` | __FILL__ | __FILL__ |

---

## Component Adaptation Rules

### Navigation

| Component | Desktop | Tablet | Mobile |
|-----------|---------|--------|--------|
| Primary nav | __FILL__ | __FILL__ | __FILL__ |
| Secondary nav | __FILL__ | __FILL__ | __FILL__ |
| Breadcrumbs | __FILL__ | __FILL__ | __FILL__ |

### Data Display

| Component | Desktop | Tablet | Mobile |
|-----------|---------|--------|--------|
| Data table | Full columns | Priority columns | Card/list view |
| Cards | Grid (3-4 col) | Grid (2 col) | Single column |
| Charts | Full size | Full size | Scrollable or simplified |

### Actions

| Component | Desktop | Tablet | Mobile |
|-----------|---------|--------|--------|
| Primary actions | Toolbar buttons | Toolbar buttons | FAB or bottom bar |
| Secondary actions | Menu dropdown | Menu dropdown | Bottom sheet |
| Bulk actions | Selection bar | Selection bar | Bottom sheet |

### Forms

| Component | Desktop | Tablet | Mobile |
|-----------|---------|--------|--------|
| Form layout | Multi-column | Single column | Single column |
| Labels | Inline or above | Above | Above |
| Help text | Inline | Collapsible | Collapsible |

---

## Touch Adaptation

### Touch Target Sizes

| Target Type | Minimum Size | Recommended |
|-------------|--------------|-------------|
| Primary actions | 44×44px | 48×48px |
| Secondary actions | 44×44px | 44×44px |
| Text links | 44px height | Include padding |
| Icons (tappable) | 44×44px | 48×48px |

### Touch-Specific Patterns

| Pattern | Description | Reference |
|---------|-------------|-----------|
| Swipe actions | Row swipe for quick actions | __FILL__ |
| Pull to refresh | Refresh data lists | __FILL__ |
| Long press | Context menu | __FILL__ |
| Pinch zoom | Image/map zoom | __FILL__ |

---

## Orientation Handling

### Portrait vs Landscape

| Aspect | Portrait | Landscape |
|--------|----------|-----------|
| Primary nav | Bottom or hamburger | Side rail or top |
| Content width | Full viewport | Constrained max-width |
| Media | Stacked | Side-by-side possible |

### Orientation Lock Guidance

- **Lock portrait:** Forms, reading-heavy content
- **Lock landscape:** Video, charts, wide tables
- **Allow both:** Navigation, dashboards

---

## Performance Considerations

### Image Responsiveness

```yaml
images:
  srcset: __FILL__  # Provide multiple sizes
  sizes: __FILL__  # Declare which size for which viewport
  lazy_loading: __FILL__  # Load below-fold images lazily
  placeholders: __FILL__  # LQIP or skeleton
```

### Code Splitting

- Load mobile-specific components only on mobile
- Defer non-critical features on slow connections
- Reduce bundle size for mobile breakpoints

---

## Testing Requirements

### Viewport Testing Matrix

| Surface | xs | sm | md | lg | xl | 2xl |
|---------|----|----|----|----|----|----|
| __FILL__ | [ ] | [ ] | [ ] | [ ] | [ ] | [ ] |

### Device Testing

- [ ] iOS Safari (iPhone)
- [ ] iOS Safari (iPad)
- [ ] Android Chrome (phone)
- [ ] Android Chrome (tablet)
- [ ] Desktop Chrome
- [ ] Desktop Firefox
- [ ] Desktop Safari

### Accessibility at Each Breakpoint

- [ ] Touch targets meet minimums (A11Y-002)
- [ ] Focus indicators visible (A11Y-001)
- [ ] Content reachable without horizontal scroll

---

## Surface Spec Integration

When documenting surface specs (see `_surfaces/SPEC_TEMPLATE.md`), include:

```markdown
## Responsive Behavior

| Breakpoint | Adaptation |
|------------|------------|
| Desktop (≥1024px) | __FILL__ |
| Tablet (768-1023px) | __FILL__ |
| Mobile (<768px) | __FILL__ |
```

---

## Related Documents

- `_quality/archetypes/` — Archetype definitions and budgets
- `_ui/layouts/` — Layout zone definitions
- `_ui/tokens.yaml` — Spacing and sizing tokens
- `_nfr/PERFORMANCE.yaml` — Performance budgets affecting responsive loading
