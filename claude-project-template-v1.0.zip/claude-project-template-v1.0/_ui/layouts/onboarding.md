# Onboarding Layout

> Multi-step wizard flows for setup and guided processes.

**Archetype:** Transient → Configuration
**Compliance:** Must conform to transient archetype budgets per step.

---

## Purpose

Guide users through:
- Initial setup
- Feature configuration
- Complex creation flows
- Multi-step processes

---

## Zones

### Centered Wizard (Default)

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                     [Logo]                                  │
│                                                             │
│              Step 1 of 4 · Account Setup                    │
│              ────●────○────○────○────                       │
│                                                             │
│         ┌─────────────────────────────────┐                 │
│         │                                 │                 │
│         │  Step Title                     │                 │
│         │  Description of this step.      │                 │
│         │                                 │                 │
│         │  ┌───────────────────────────┐  │                 │
│         │  │ Input field               │  │                 │
│         │  └───────────────────────────┘  │                 │
│         │                                 │                 │
│         │  ┌───────────────────────────┐  │                 │
│         │  │ Input field               │  │                 │
│         │  └───────────────────────────┘  │                 │
│         │                                 │                 │
│         └─────────────────────────────────┘                 │
│                                                             │
│              [Back]              [Continue →]               │
│                                                             │
│                     Skip setup →                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Side-Panel Wizard (Complex Steps)

```
┌─────────────────────────┬───────────────────────────────────┐
│                         │                                   │
│  [Logo]                 │  Step Title                       │
│                         │  Description of this step.        │
│  Progress               │                                   │
│  ────────────────────   │  ┌───────────────────────────────┐│
│  ● Account Setup        │  │                               ││
│  ○ Team Details         │  │  Form content                 ││
│  ○ Invite Members       │  │                               ││
│  ○ Preferences          │  │                               ││
│                         │  │                               ││
│                         │  └───────────────────────────────┘│
│  ────────────────────   │                                   │
│                         │                                   │
│  Need help?             │           [Back]  [Continue →]    │
│  Contact support        │                                   │
│                         │                                   │
└─────────────────────────┴───────────────────────────────────┘
```

---

## Progress Indicator

### Dot Progress (≤5 steps)
```
○────●────○────○────○
     ↑ Current step
```

### Numbered Progress (>5 steps or complex)
```
Step 2 of 7 · Team Details
[████████░░░░░░░░░░░░░░░░░░░] 28%
```

### Checklist Progress (Side panel)
```
✓ Account Setup
● Team Details        ← Current
○ Invite Members
○ Preferences
```

**Requirements:**
- Show step count: "Step X of Y"
- Show step name
- Clickable completed steps (go back)
- Disabled future steps

---

## Step Content

### Single-Focus Step (Preferred)
- One decision per step
- Max 3 inputs
- Clear primary action

### Multi-Input Step
- Group related fields
- Max 6 inputs
- Validate before continue

### Selection Step
```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│  What best describes your team?                             │
│                                                             │
│  ┌───────────────────┐  ┌───────────────────┐               │
│  │ [Icon]            │  │ [Icon]            │               │
│  │ Startup           │  │ Agency            │               │
│  │ Small team,       │  │ Client work,      │               │
│  │ moving fast       │  │ multiple projects │               │
│  └───────────────────┘  └───────────────────┘               │
│                                                             │
│  ┌───────────────────┐  ┌───────────────────┐               │
│  │ [Icon]            │  │ [Icon]            │               │
│  │ Enterprise        │  │ Personal          │               │
│  │ Large org,        │  │ Solo use,         │               │
│  │ compliance needs  │  │ side projects     │               │
│  └───────────────────┘  └───────────────────┘               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Confirmation Step (Final)
```
┌─────────────────────────────────────────────────────────────┐
│                         [✓]                                 │
│                                                             │
│              You're all set!                                │
│                                                             │
│  Your workspace "Acme Co" is ready.                         │
│  We've set up your team with 3 members.                     │
│                                                             │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ Quick tips to get started:                              ││
│  │ • Create your first project                             ││
│  │ • Invite more team members                              ││
│  │ • Connect your tools                                    ││
│  └─────────────────────────────────────────────────────────┘│
│                                                             │
│              [Go to Dashboard]                              │
│                                                             │
│              View documentation →                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Navigation

### Footer Actions
```
[Back]                                    [Continue →]
```

- Back: Secondary button or link
- Continue: Primary button
- Disabled Continue until step valid
- Loading state on Continue when processing

### Skip Option
```
                    Skip for now →
```

- Only for optional steps
- Below navigation
- Link style, not button
- Explain what will be skipped

### Exit Option
- Logo links to exit (with confirmation if data entered)
- Or explicit "Save and exit" / "Exit without saving"

---

## Validation

### Per-Step Validation
- Validate on Continue click
- Show inline errors
- Don't advance until valid

### Real-Time Validation
- Format validation as user types
- Async validation (email exists) with debounce
- Clear error when corrected

### Error Display
```
┌─────────────────────────────────────────────────────────────┐
│  Email address                                              │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ invalid@email                                           ││
│  └─────────────────────────────────────────────────────────┘│
│  ⚠️ Please enter a valid email address                      │
└─────────────────────────────────────────────────────────────┘
```

---

## States

### Loading (Step Transition)
- Brief spinner on Continue button
- Or skeleton of next step
- No full-page loader

### Error (Step Failed)
- Keep user on current step
- Show error message
- Allow retry

### Recovery (Session Restored)
- If user returns to incomplete flow
- "Continue where you left off?"
- Show progress summary

---

## Responsive Behavior

| Breakpoint | Behavior |
|------------|----------|
| Desktop (lg+) | Centered card, max-width 560px |
| Tablet (md) | Centered, padding reduced |
| Mobile (sm) | Full width, stacked navigation |

**Mobile Footer:**
```
┌─────────────────────────────────────────┐
│            [Continue →]                 │
│                                         │
│    ← Back          Skip for now →       │
└─────────────────────────────────────────┘
```

---

## Keyboard Navigation

| Key | Action |
|-----|--------|
| `Tab` | Move between inputs |
| `Enter` | Submit step (Continue) |
| `Escape` | Cancel / Exit (with confirmation) |
| `←` | Back to previous step |

---

## Token Dependencies

```yaml
colors:
  - background.base
  - background.subtle
  - brand.primary
  - text.*
  - success.default
  
spacing:
  - semantic.card_padding
  - scale.6
  - scale.8
  
components:
  - button
  - input
  - select
  - checkbox
  - radio
  - progress
  - card
```

---

## Anti-Patterns

- More than 7 steps
- Steps that can't be skipped when optional
- No back navigation
- Full page reload between steps
- Losing data on back navigation
- Required fields not marked
- No progress indicator
- Exit without save confirmation
- Auto-advancing without user action
