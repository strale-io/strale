# Settings Layout

> Configuration pages for user and system preferences.

**Archetype:** Configuration
**Compliance:** Must conform to configuration archetype budgets.

---

## Purpose

Allow users to:
- Configure preferences
- Manage account/profile
- Control integrations
- Set up team/org settings

---

## Zones

```
┌───────────────────────────────────────────────────────────────┐
│ HEADER                                                        │
│ Settings                                                      │
├───────────────┬───────────────────────────────────────────────┤
│               │                                               │
│ NAV           │ CONTENT                                       │
│               │                                               │
│ Profile       │ ┌───────────────────────────────────────────┐ │
│ Account       │ │ Section Title                             │ │
│ Notifications │ │ Description of what this section controls │ │
│ Appearance    │ ├───────────────────────────────────────────┤ │
│ ───────────── │ │                                           │ │
│ Team          │ │ Setting Label          [Control]          │ │
│ Billing       │ │ Helper text                               │ │
│ Integrations  │ │                                           │ │
│               │ │ Setting Label          [Control]          │ │
│               │ │ Helper text                               │ │
│               │ │                                           │ │
│               │ └───────────────────────────────────────────┘ │
│               │                                               │
│               │ ┌───────────────────────────────────────────┐ │
│               │ │ Another Section                           │ │
│               │ └───────────────────────────────────────────┘ │
└───────────────┴───────────────────────────────────────────────┘
```

---

## Navigation Zone

**Structure:**
```
┌─────────────────┐
│ PERSONAL        │  ← Group label
│   Profile       │  ← Active item
│   Account       │
│   Notifications │
│   Appearance    │
├─────────────────┤
│ WORKSPACE       │  ← Group label
│   Team          │
│   Billing       │
│   Integrations  │
│   API           │
├─────────────────┤
│ ADMIN           │  ← Role-restricted
│   Security      │
│   Audit Log     │
└─────────────────┘
```

**Requirements:**
- Width: 200–240px
- Sticky on scroll
- Group labels (uppercase, muted)
- Active state indicator
- Role-based visibility
- Collapsible on mobile → tabs or dropdown

---

## Content Zone

### Section Structure

```
┌─────────────────────────────────────────────────────────────┐
│ Section Title                                               │
│ Brief description of what this section controls and why.    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ Setting Label                              [Switch: ON ]    │
│ Explanation of what this setting does.                      │
│                                                             │
│ ─────────────────────────────────────────────────────────── │
│                                                             │
│ Setting Label                              [Select ▾    ]   │
│ Explanation of what this setting does.                      │
│                                                             │
│ ─────────────────────────────────────────────────────────── │
│                                                             │
│ Setting Label                                               │
│ Explanation of what this setting does.                      │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ Text input or textarea                                  │ │
│ └─────────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Requirements:**
- Max content width: 640–720px
- Section gap: `spacing.semantic.section_gap`
- Setting row padding: `spacing.scale.4` vertical
- Dividers between settings (subtle)

### Setting Row Patterns

**Toggle (Immediate Effect)**
```
Language                                    [English ▾]
Choose your preferred language.
```

**Switch (Boolean, Immediate)**
```
Email notifications                         [====○    ]
Receive email updates about your projects.
```

**Input (Requires Save)**
```
Display name
The name shown to other team members.
┌─────────────────────────────────────────┐
│ Jane Smith                              │
└─────────────────────────────────────────┘
                                    [Save]
```

**Danger Zone**
```
┌─────────────────────────────────────────────────────────────┐
│ ⚠️ Danger Zone                                              │
├─────────────────────────────────────────────────────────────┤
│ Delete Account                                              │
│ Permanently delete your account and all data.               │
│ This action cannot be undone.                               │
│                                          [Delete Account]   │
└─────────────────────────────────────────────────────────────┘
```

---

## Save Behavior

### Auto-Save (Preferred for simple settings)
- Toggle/Switch changes apply immediately
- Toast confirmation: "Setting saved"
- No explicit save button

### Explicit Save (For complex/sensitive changes)
- Save button appears when changes made
- "Unsaved changes" indicator
- Cancel option to revert

### Danger Zone
- Always requires confirmation
- Type confirmation for destructive actions
- Never auto-save

---

## States

### Loading
- Skeleton for each setting row
- Nav can show immediately

### Error (Save Failed)
- Inline error on affected setting
- Retry option
- Don't lose user input

### Success
- Toast: "Settings saved" (auto-dismiss)
- Or inline checkmark animation

---

## Responsive Behavior

| Breakpoint | Behavior |
|------------|----------|
| Desktop (lg+) | Side nav + content |
| Tablet (md) | Collapsible side nav |
| Mobile (sm) | Nav becomes tabs at top or separate page |

**Mobile Settings Navigation:**
```
┌─────────────────────────────────────────┐
│ ← Settings                              │
├─────────────────────────────────────────┤
│ Profile                               → │
│ Account                               → │
│ Notifications                         → │
│ Appearance                            → │
├─────────────────────────────────────────┤
│ Team                                  → │
│ Billing                               → │
└─────────────────────────────────────────┘
```

---

## Keyboard Navigation

| Key | Action |
|-----|--------|
| `↓` `↑` | Move between settings |
| `Enter` | Activate focused control |
| `Tab` | Move to next control |
| `Escape` | Cancel current edit |
| `Cmd+S` | Save (if explicit save mode) |

---

## Token Dependencies

```yaml
colors:
  - background.base
  - background.subtle
  - border.subtle
  - error.*
  
spacing:
  - semantic.page_*
  - semantic.section_gap
  - scale.4
  - scale.6
  
components:
  - input
  - select
  - switch
  - checkbox
  - button
  - toast
  - alert
```

---

## Anti-Patterns

- Auto-save for destructive actions
- Settings without explanation
- Deep nesting (max 2 levels)
- Required save button for simple toggles
- Settings that require page reload
- Mixing personal and team settings
- No confirmation for danger zone actions
- Settings page with horizontal scroll
