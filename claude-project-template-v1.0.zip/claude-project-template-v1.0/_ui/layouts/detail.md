# Detail Layout

> Single entity view for reading and editing.

**Archetype:** Detail
**Compliance:** Must conform to `_quality/archetypes/detail.yaml` budgets.

---

## Purpose

Display a single entity for:
- Reading full content
- Editing properties
- Viewing activity/history
- Taking actions

---

## Zones

### Full-Page Detail (Default)

```
┌─────────────────────────────────────────────────────────────┐
│ HEADER                                                      │
│ [←] Breadcrumb | Entity Name              [Edit] [⋮ More]   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ CONTENT                                                     │
│ ┌─────────────────────────────────┬───────────────────────┐ │
│ │                                 │                       │ │
│ │ Primary Content                 │ Sidebar               │ │
│ │ (Scrollable)                    │ (Properties,          │ │
│ │                                 │  Related, Activity)   │ │
│ │                                 │                       │ │
│ │                                 │                       │ │
│ └─────────────────────────────────┴───────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Drawer Detail (Split View)

```
┌─────────────────────────────────────┬───────────────────────┐
│                                     │ DRAWER                │
│ Collection View                     │ [×]                   │
│ (List/Table stays visible)          │ Entity Name           │
│                                     ├───────────────────────┤
│                                     │                       │
│ ← Active row highlighted            │ Properties            │
│                                     │ Content               │
│                                     │ Activity              │
│                                     │                       │
│                                     │ [Actions]             │
└─────────────────────────────────────┴───────────────────────┘
```

---

## Header Zone

| Element | Required | Notes |
|---------|----------|-------|
| Back/Breadcrumb | Yes | Back to collection or breadcrumb trail |
| Entity name | Yes | H1, editable inline if permitted |
| Primary action | If exists | E.g., "Edit", "Submit", "Complete" |
| More actions | If > 2 actions | Dropdown menu |
| Status badge | If entity has status | Near title |

**Spacing:**
- Header height: 56–64px
- Padding: `spacing.semantic.page_x_desktop`

---

## Content Zone

### Primary Content Area (60-70% width)

Main content varies by entity type:

**Document/Note:**
- Rich text content
- Full width
- Comfortable reading width (max 720px)

**Task/Issue:**
- Title (H1)
- Description (rich text)
- Subtasks/checklist
- Attachments
- Comments/activity

**Profile/Record:**
- Key properties grid
- Related content sections
- Tabbed content if complex

### Sidebar (30-40% width)

**Standard Sections:**

```
┌─────────────────────────┐
│ Properties              │
│ ├─ Status    [Active ▾] │
│ ├─ Owner     [@jane   ] │
│ ├─ Due       [Jan 15  ] │
│ └─ Priority  [High    ] │
├─────────────────────────┤
│ Related                 │
│ ├─ Project: Alpha       │
│ └─ Tags: Design, Q1     │
├─────────────────────────┤
│ Activity                │
│ ├─ Jane edited · 2h ago │
│ └─ Created · Jan 10     │
└─────────────────────────┘
```

**Requirements:**
- Collapsible sections
- Inline editing for properties
- Sticky on scroll (optional)

---

## View/Edit Modes

### View Mode
- Content displayed
- Properties read-only
- Edit button in header

### Edit Mode (In-Place)
- Fields become editable
- Save/Cancel in header or inline
- Unsaved changes warning

### Edit Mode (Modal)
- For complex edits
- Form in modal
- Doesn't change URL

---

## States

### Loading
```
┌─────────────────────────────────────────────────────────────┐
│ ← [████████]                              [████] [███]      │
├─────────────────────────────────────────────────────────────┤
│ [████████████████████]                                      │
│                                                             │
│ [████████████████████████████████████]                      │
│ [████████████████████████████]                              │
│ [████████████████████████████████████████]                  │
└─────────────────────────────────────────────────────────────┘
```
- Skeleton matching expected layout
- Preserve header structure

### Error
- Full-page error if entity fails to load
- "Go back to {Collection}" action
- Show entity ID for debugging

### Not Found
```
┌─────────────────────────────────────────┐
│        {Entity} not found               │
│   This may have been deleted or         │
│   you don't have access.                │
│                                         │
│   [Go to {Collection}]                  │
└─────────────────────────────────────────┘
```

### Permission Denied
- Different from Not Found
- Explain what's needed
- Request access action if applicable

---

## Responsive Behavior

| Breakpoint | Behavior |
|------------|----------|
| Desktop (lg+) | Content + Sidebar side by side |
| Tablet (md) | Sidebar collapses to tabs or accordion |
| Mobile (sm) | Single column, sidebar sections below content |

---

## Keyboard Navigation

| Key | Action |
|-----|--------|
| `E` | Edit mode (if permitted) |
| `Escape` | Exit edit / Close drawer |
| `Cmd+S` | Save changes (in edit mode) |
| `Cmd+Enter` | Primary action |
| `←` `→` | Previous/next entity (if in split view) |

---

## Token Dependencies

```yaml
colors:
  - background.base
  - background.subtle
  - border.subtle
  - text.*
  
spacing:
  - semantic.page_*
  - semantic.section_gap
  - semantic.card_padding
  
components:
  - breadcrumb
  - button
  - badge
  - input
  - select
  - textarea
  - avatar
  - dropdown
```

---

## Anti-Patterns

- Detail view without back navigation
- Edit mode that changes URL
- Sidebar wider than content
- Properties that can't be edited inline
- Activity without timestamps
- Actions scattered instead of grouped
- No unsaved changes warning
- Split view on mobile
