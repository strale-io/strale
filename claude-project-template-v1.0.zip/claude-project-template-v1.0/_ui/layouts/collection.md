# Collection Layout

> List, table, board views for browsing and finding entities.

**Archetype:** Overview
**Compliance:** Must conform to `_quality/archetypes/overview.yaml` budgets.

---

## Purpose

Display a collection of entities for:
- Scanning and finding
- Filtering and sorting
- Bulk operations
- Quick navigation to detail

---

## Zones

```
┌─────────────────────────────────────────────────────────────┐
│ HEADER                                                      │
│ Title + Count | [Filter Bar] | [View Toggle] | [+ Create]   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ CONTENT                                                     │
│                                                             │
│ Table / List / Board / Grid                                 │
│                                                             │
│                                                             │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ FOOTER (if needed)                                          │
│ Pagination | Selection count | Bulk actions                 │
└─────────────────────────────────────────────────────────────┘
```

---

## Header Zone

| Element | Required | Notes |
|---------|----------|-------|
| Title | Yes | Plural noun: "Projects", "Tasks" |
| Count | Yes | Total or "X of Y" when filtered |
| Filter bar | Yes | Omnibox or filter chips |
| View toggle | If multiple views | Table/List/Board/Grid |
| Create action | Yes | Primary button, "+ {Entity}" |

**Spacing:**
- Header height: 56–64px
- Padding: `spacing.semantic.page_x_desktop`
- Gap between elements: `spacing.scale.4`

---

## Content Zone

### Table View (Default for data-dense)

**When to use:**
- Comparing multiple attributes
- Dense information
- Sorting important
- Desktop-first

**Structure:**
```
┌────┬────────────────────┬──────────┬──────────┬─────────┐
│ □  │ Name ▼             │ Status   │ Owner    │ Date    │
├────┼────────────────────┼──────────┼──────────┼─────────┤
│ □  │ Project Alpha      │ Active   │ @jane    │ Jan 15  │
│ □  │ Project Beta       │ Draft    │ @john    │ Jan 12  │
└────┴────────────────────┴──────────┴──────────┴─────────┘
```

**Requirements:**
- Checkbox column if bulk actions exist
- Sticky header on scroll
- Hover state on rows
- Click row → navigate to detail
- Sort indicator on active column
- Virtualization at 100+ rows

### List View (Default for mobile, simple cases)

**When to use:**
- Mobile-first
- Simpler entities
- Quick scanning

**Structure:**
```
┌─────────────────────────────────────────┐
│ [Avatar] Title                    [Badge]│
│          Subtitle / metadata             │
├─────────────────────────────────────────┤
│ [Avatar] Title                    [Badge]│
│          Subtitle / metadata             │
└─────────────────────────────────────────┘
```

**Requirements:**
- Max 2 lines per item
- Avatar or icon for recognition
- One badge max per item

### Board View (Kanban)

**When to use:**
- Status-based workflows
- Drag-and-drop reordering
- Visual pipeline

**Structure:**
```
┌─────────────┐ ┌─────────────┐ ┌─────────────┐
│ To Do (5)   │ │ In Progress │ │ Done (12)   │
├─────────────┤ ├─────────────┤ ├─────────────┤
│ ┌─────────┐ │ │ ┌─────────┐ │ │ ┌─────────┐ │
│ │ Card    │ │ │ │ Card    │ │ │ │ Card    │ │
│ └─────────┘ │ │ └─────────┘ │ │ └─────────┘ │
│ ┌─────────┐ │ │             │ │             │
│ │ Card    │ │ │             │ │             │
│ └─────────┘ │ │             │ │             │
└─────────────┘ └─────────────┘ └─────────────┘
```

**Requirements:**
- Column header with count
- Collapsible columns
- Drag-and-drop with preview
- Keyboard accessible (arrow keys)

### Grid View

**When to use:**
- Visual entities (images, files)
- Browsing over comparing

**Requirements:**
- Responsive columns (2-6)
- Consistent card size
- Selection state visible

---

## Footer Zone

| Element | Required | Notes |
|---------|----------|-------|
| Pagination | If > 25 items | Page numbers or load more |
| Selection count | If bulk actions | "3 selected" |
| Bulk actions | If selection enabled | Appears on selection |

**Bulk Action Bar:**
```
┌─────────────────────────────────────────────────────────────┐
│ 3 selected  [Edit] [Move] [Archive] [Delete]     [× Clear]  │
└─────────────────────────────────────────────────────────────┘
```

- Sticky to bottom
- Appears on first selection
- Clear button to deselect all
- Destructive actions require confirmation

---

## States

### Loading
- Skeleton rows matching expected layout
- Show after 100ms delay
- Keep filter bar interactive

### Empty (No Data)
```
┌─────────────────────────────────────────┐
│           [Illustration]                │
│                                         │
│        No projects yet                  │
│   Create your first project to get      │
│   started with your work.               │
│                                         │
│        [+ Create Project]               │
└─────────────────────────────────────────┘
```

### Empty (No Results)
```
┌─────────────────────────────────────────┐
│        No matching projects             │
│   Try adjusting your filters            │
│                                         │
│        [Clear Filters]                  │
└─────────────────────────────────────────┘
```

### Error
- Inline error with retry button
- Keep filter bar visible
- Don't lose filter state

---

## Responsive Behavior

| Breakpoint | Behavior |
|------------|----------|
| Desktop (lg+) | Full table with all columns |
| Tablet (md) | Collapse to 4-5 columns, hide less important |
| Mobile (sm) | Switch to list view, hide table |

---

## Keyboard Navigation

| Key | Action |
|-----|--------|
| `↓` `↑` | Move selection |
| `Enter` | Open selected item |
| `Space` | Toggle selection (if checkbox) |
| `Cmd+A` | Select all |
| `Escape` | Clear selection |
| `/` or `Cmd+K` | Focus filter/search |

---

## Token Dependencies

```yaml
colors:
  - background.base
  - background.subtle
  - border.subtle
  - interactive.hover
  - interactive.selected
  
spacing:
  - semantic.page_x_*
  - semantic.row_padding_*
  - scale.4
  
dimensions:
  - table.*
  
components:
  - table
  - checkbox
  - badge
  - avatar
  - button
  - pagination
  - empty_state
  - skeleton
```

---

## Anti-Patterns

- Table without sticky header
- Pagination without position indicator
- Bulk actions without confirmation for destructive
- Filter that doesn't update URL
- Inconsistent row height
- More than 8 columns visible
- Actions in every row (use bulk actions)
