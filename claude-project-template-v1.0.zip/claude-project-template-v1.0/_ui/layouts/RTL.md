# RTL Layout Guidance

> How to handle right-to-left language layouts.

---

## Core Principle

> **Layout direction is content-driven, not hardcoded.**

RTL support requires more than CSS `direction: rtl`. The entire visual grammar must flip while preserving meaning.

---

## What Flips

| Element | LTR | RTL |
|---------|-----|-----|
| Text alignment | Left | Right |
| Reading flow | Left → Right | Right → Left |
| Navigation order | Left first | Right first |
| Breadcrumbs | Home > Parent > Child | Child < Parent < Home |
| Progress bars | Fill left to right | Fill right to left |
| Chevrons/arrows | Point right (forward) | Point left (forward) |
| Sidebars | Left | Right |
| Back button | Points left | Points right |
| Form labels | Left of input | Right of input |

---

## What Doesn't Flip

| Element | Reason |
|---------|--------|
| Numbers | Universal reading direction |
| Media playback controls | Universal convention |
| Left/right directional icons (compass) | Semantic meaning |
| Sliders (volume, etc.) | Physical metaphor preserved |
| Timelines | Time flows left to right universally |
| Phone numbers | International format |
| Mathematical operators | Universal |
| Code blocks | Programming is LTR |

---

## Bidirectional Content

When LTR and RTL content mix on the same surface:

| Scenario | Handling |
|----------|----------|
| English word in Arabic text | Inline LTR island within RTL flow |
| Arabic name in English interface | Inline RTL island within LTR flow |
| Mixed-language table columns | Each cell follows its content language |
| Code snippets in RTL docs | Code block is LTR island |

**Rule:** Never break the natural reading direction of content for layout consistency.

---

## Implementation Patterns

### CSS Logical Properties

Use logical properties instead of physical:

| ❌ Physical | ✅ Logical |
|------------|-----------|
| `margin-left` | `margin-inline-start` |
| `margin-right` | `margin-inline-end` |
| `padding-left` | `padding-inline-start` |
| `text-align: left` | `text-align: start` |
| `float: left` | `float: inline-start` |
| `border-left` | `border-inline-start` |
| `left: 0` | `inset-inline-start: 0` |

### Icon Mirroring

| Icon Type | Mirror? |
|-----------|---------|
| Directional (back, forward, arrow) | Yes |
| Structural (menu, grid) | No |
| Symmetric (star, heart, check) | No |
| Time-related (clock, calendar) | No |
| Functional (search, settings) | No |

---

## Testing Checklist

| Check | Pass Criteria |
|-------|---------------|
| Text alignment | All text aligns to reading start |
| Navigation flow | Tab order follows visual order |
| Icons | Directional icons point correctly |
| Forms | Labels and inputs flow correctly |
| Breadcrumbs | Order matches hierarchy (root on reading-start side) |
| Modals | Close button on reading-end corner |
| Toasts | Enter from reading-end side |
| Tables | Header alignment matches content |
| Scroll | Horizontal scroll starts from reading-start |

---

## Common Mistakes

| Mistake | Impact |
|---------|--------|
| Using `text-align: left` | Text doesn't flip in RTL |
| Hardcoded margins with `margin-left` | Spacing breaks in RTL |
| Forgetting to mirror chevrons | Navigation feels backwards |
| Flipping timeline direction | Breaks universal time metaphor |
| Mirroring symmetric icons | Looks broken, wastes effort |
| Ignoring bidirectional content | Creates unreadable mixed text |

---

## Token Integration

RTL layouts use the same tokens as LTR. Direction is handled through:

1. **CSS logical properties** (no directional tokens needed)
2. **Icon variants** (mirror versions where needed)
3. **Layout components** (handle direction internally)

**Rule:** Tokens are direction-agnostic. Layout handles direction.

---

## Related Invariants

- L10N-005: Reading direction is configurable
- L10N-003: Text containers accommodate expansion (150%+)
