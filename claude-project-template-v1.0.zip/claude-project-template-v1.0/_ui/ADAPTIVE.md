# Adaptive Layout Governance

> How content priority, navigation, and interaction models transform across form factors.

**Companion to:** `_ui/RESPONSIVE.md` — which defines breakpoints and reflow strategies.
**This file defines:** What matters most at each form factor, and how the user experience transforms.

---

## Core Principle

> Responsive design asks "does it fit?" Adaptive design asks "does it serve?"

A surface that technically renders on mobile but buries the primary action behind three taps has failed adaptive governance, even if it passes responsive checks.

---

## Content Priority Framework

Every surface must declare content priority — what matters most changes by form factor.

### Priority Declaration
```yaml
content_priority:
  surface: "SURF-__FILL__"
  desktop:
    primary: "__FILL__"    # Most important content/action
    secondary: "__FILL__"  # Supporting content
    tertiary: "__FILL__"   # Nice-to-have, can hide
  tablet:
    primary: "__FILL__"
    secondary: "__FILL__"
    tertiary: "__FILL__ | hidden"
  mobile:
    primary: "__FILL__"
    secondary: "__FILL__ | collapsed"
    tertiary: "hidden"
```

### Priority Rules

| Rule | Requirement |
|------|-------------|
| **Primary is always visible** | Primary content/action must be above the fold on every form factor |
| **Secondary can collapse** | May be behind a tap/toggle on smaller form factors |
| **Tertiary can hide** | May be removed entirely on mobile |
| **Priority can shift** | What's primary may differ by form factor (e.g., desktop: dashboard view; mobile: quick-action view) |

### Priority Mismatch Test

> On mobile, can the user accomplish the primary job without scrolling past the fold?

If no → content priority is wrong for this form factor.

---

## Navigation Transformation

Navigation patterns must transform — not just collapse — across form factors.

### Transformation Patterns

| Desktop Pattern | Tablet Transformation | Mobile Transformation |
|----------------|----------------------|----------------------|
| Sidebar nav | Collapsible rail or overlay | Bottom tab bar or hamburger |
| Top tab bar | Top tab bar (scrollable) | Bottom tabs or swipeable |
| Breadcrumbs | Breadcrumbs (truncated) | Back arrow + page title |
| Multi-level hierarchy | Drill-down with back | Flat navigation + search |
| Secondary nav | Tucked behind toggle | Removed or bottom sheet |

### Navigation Invariants (All Form Factors)

| ID | Rule |
|----|------|
| NAV-A01 | User can always return to the previous screen |
| NAV-A02 | User always knows where they are in the hierarchy |
| NAV-A03 | Primary navigation is reachable within one gesture |
| NAV-A04 | Navigation affordances are touch-sized on touch devices (≥44px) |

---

## Touch Adaptation

Touch is not just "bigger click targets." It's a fundamentally different interaction model.

### Interaction Model Differences

| Desktop (Pointer) | Touch |
|-------------------|-------|
| Hover reveals information | No hover — information must be visible or tappable |
| Right-click for context menu | Long-press or explicit menu button |
| Drag with precision | Drag with gesture (swipe) |
| Keyboard shortcuts | No shortcuts — actions must be on-screen |
| Multi-cursor interactions | Single-touch or limited multi-touch |

### Adaptation Requirements

| Aspect | Requirement |
|--------|-------------|
| **Hover-dependent UI** | Must have a non-hover equivalent on touch. No information should be hover-only. |
| **Context menus** | Replace right-click with long-press OR explicit "more" button |
| **Drag-and-drop** | Provide alternative (reorder buttons, move-to menu) on touch |
| **Keyboard shortcuts** | Surface equivalent actions as on-screen buttons |
| **Dense click targets** | Increase spacing to prevent mis-taps (min 8px between targets) |

### Touch Adaptation Checklist
```yaml
touch_adaptation:
  surface: "SURF-__FILL__"
  hover_dependencies:
    - element: "__FILL__"
      hover_reveals: "__FILL__"
      touch_alternative: "__FILL__"  # How is this info accessed without hover?
  context_menus:
    - trigger: "__FILL__"
      touch_trigger: "long-press | more-button | swipe-action"
  drag_operations:
    - operation: "__FILL__"
      touch_alternative: "__FILL__"
  keyboard_shortcuts:
    - shortcut: "__FILL__"
      on_screen_equivalent: "__FILL__"
```

---

## Form Factor Declaration

Every surface spec must include a form factor declaration.

### Declaration Format
```yaml
form_factor_declaration:
  surface: "SURF-__FILL__"

  supported_form_factors:
    desktop: true
    tablet: true | false
    mobile: true | false

  primary_form_factor: "desktop | tablet | mobile"  # Where is the primary use case?

  adaptation_strategy:
    tablet: "reflow | collapse | dedicated"  # See RESPONSIVE.md
    mobile: "reflow | collapse | dedicated | not-supported"

  if_not_supported:
    message: "__FILL__"  # What the user sees
    alternative: "__FILL__"  # Where they should go instead
```

### "Dedicated" Strategy

When adaptation isn't enough, a form factor may warrant a dedicated layout:

| Use When | Example |
|----------|---------|
| Primary job differs by form factor | Desktop: review data; Mobile: quick capture |
| Information density is too different | Desktop: full dashboard; Mobile: key metrics only |
| Interaction model is fundamentally different | Desktop: drag-and-drop canvas; Mobile: list-based workflow |

**Rule:** Dedicated layouts must still serve the same user jobs. Different layout ≠ different product.

---

## Adaptive Quality Checks

### Gate 0 Addition

Before building, verify:
- [ ] Content priority declared for all target form factors
- [ ] Navigation transformation strategy chosen
- [ ] Touch adaptation plan documented (if supporting touch)
- [ ] Form factor declaration completed

### Critique Dimension Enrichment

When scoring Visual Craft and Interaction on non-desktop form factors:

| Check | Question |
|-------|----------|
| Priority preserved? | Is the primary content/action above the fold? |
| Navigation accessible? | Can user navigate without confusion? |
| Touch targets met? | All interactive elements ≥44px? |
| Hover dependencies removed? | No information locked behind hover? |
| Gesture alternatives? | Drag/keyboard actions have touch equivalents? |

---

## Anti-Patterns

| Anti-Pattern | Problem | Fix |
|--------------|---------|-----|
| Desktop-first only | Mobile users get a squeezed version | Declare priorities per form factor |
| Hiding everything on mobile | User can't do anything | Keep primary job accessible |
| Same nav on all sizes | Desktop sidebar on mobile wastes space | Transform navigation by form factor |
| Hover-only info | Touch users can't access it | Always provide tap alternative |
| "Download the app" | Dismissive of mobile web users | Provide functional experience or explain why |

---

## Related Files

- `_ui/RESPONSIVE.md` — Breakpoints, reflow strategies, component adaptation tables
- `_surfaces/SPEC_TEMPLATE.md` — Surface specs include form factor declaration
- `_quality/QUALITY_PROTOCOL.md` — Gate 0 adaptive checks
- `_critique/PROMPT.md` — Adaptive scoring enrichment
- `_interaction/FOCUS.md` — Focus management across input modalities
