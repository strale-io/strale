# Explore Mode

> Understand the problem, learn from the best, then design the solution.

**Purpose:** Before committing to an approach, understand the problem space, study how excellent products solve it, generate genuine alternatives, and select with documented reasoning.

---

## When to Use

| Trigger | Classification | Required? |
|---------|---------------|-----------|
| New screen or surface | Complex | Yes — always |
| New feature with UI | Standard/Complex | Yes |
| Multiple valid approaches exist | Standard | Yes |
| Unclear requirements | Any | Yes |
| Redesign of existing surface | Standard/Complex | Yes |
| Pure logic/data change with no UI | Standard | No — skip to build |
| Bug fix with known cause | Targeted/Micro | No — skip to build |

**Rule:** If you're unsure whether exploration is needed, it is. The cost of exploring unnecessarily is 30 minutes. The cost of building the wrong thing is hours.

---

## Explore Mode Mindset

| Do | Don't |
|----|-------|
| Study how the best solve this | Assume you know the best approach |
| Generate genuinely different approaches | Generate variations on one idea |
| Evaluate against system constraints | Evaluate in a vacuum |
| Question assumptions | Accept requirements as-is |
| Sketch loosely | Polish prematurely |
| Document rejected approaches | Discard alternatives silently |
| Extract principles, not copy solutions | Clone another product's UI |

---

## The Exploration Process

### Step 0: Reference Analysis

> Before generating your own approaches, understand how excellent products solve this class of problem.

**This is not copying. This is calibration.** The goal is to understand:
- What conventions users have been trained on by products they use daily
- What interaction patterns have proven effective for this problem type
- What common mistakes the best products avoid
- What the current state of the art looks like

**Protocol:** See `_quality/REFERENCE_ANALYSIS.md` for the full process.

**Quick version:**

1. **Identify the pattern type.** What class of problem is this?
   Examples: data table with inline editing, settings page, onboarding flow, dashboard overview, kanban board, notification feed, search with faceted filters, form wizard, detail page with sidebar.

2. **Select 2-3 reference products.** Choose products known for excellence in this specific pattern — not general excellence. A product can be excellent overall but mediocre at settings pages.

   **Selection criteria:**
   - Products your target users actually use (convention source)
   - Products recognized for craft quality in this specific pattern
   - At least one from the archetype reference list (Linear, Notion, Stripe, Figma, etc.)
   - Prefer products with similar data complexity and user sophistication

3. **Analyze each reference.** For each product, examine:
   - How is information structured? (hierarchy, grouping, density)
   - How does the user accomplish the primary task? (interaction pattern, number of steps)
   - How are states handled? (empty, loading, error, populated, edge cases)
   - What's the information density? (how much is shown vs. available on demand)
   - What conventions does it establish that users will expect?

4. **Extract transferable principles.** Not "copy their layout" but "they solve the density problem by progressive disclosure with three levels." Principles are approach-level insights, not implementation details.

5. **Document the analysis.** Brief, structured, focused on principles.

**Output:** Reference Analysis artifact (template in `_quality/REFERENCE_ANALYSIS.md`).

**Time budget:** 15-30 minutes for Standard tasks. 30-60 minutes for Complex tasks.

### Step 1: Frame the Problem

Before generating solutions, ensure the problem is understood.
```yaml
problem_framing:
  what: "[What are we trying to solve? One sentence.]"
  who: "[Who is this for? Which user mindset?]"
  success: "[What does success look like for the user?]"
  constraints: "[What hard constraints exist? (laws, tokens, archetypes, truth model)]"
  assumptions: "[What are we assuming that might not be true?]"
  pattern_type: "[What class of problem is this? (from Step 0)]"
```

**Cross-reference with pre-build:** If Gate 0 pre-build declarations exist (intent modeling, screen intent, outcome declaration), reference them here. Don't repeat them — link to them.

### Step 2: Research
```yaml
research:
  # From pre-build (already done if following Build Conductor)
  pre_build:
    - Screen Intent Declaration (role, primary UI object, dominance)
    - Outcome Declaration (before/after state)
    - Emotional Intent Declaration

  # From Notion (project-specific)
  notion:
    - Product Specs (does a spec exist for this?)
    - Design Library (existing visual references)
    - Decisions database (past decisions on similar surfaces)
    - Open Questions (unresolved related questions)

  # From starter kit (system-wide)
  internal:
    - Relevant patterns in _model/patterns/
    - Existing surfaces in product (consistency check)
    - Relevant archetype definition and budgets
    - Truth model (entities, actions, states this surface involves)

  # From reference analysis (Step 0)
  external:
    - Transferable principles from reference products
    - User conventions to respect
    - Anti-patterns to avoid
```

### Step 3: Generate Approaches

Generate genuinely different structural approaches — not cosmetic variations.
```yaml
approaches:
  minimum: 2
  ideal: 3
  maximum: 5  # More than 5 is analysis paralysis

  what_makes_approaches_different:
    - Different information architecture (what's primary vs. secondary)
    - Different interaction model (inline vs. modal, direct vs. indirect)
    - Different progressive disclosure strategy (everything visible vs. layered)
    - Different composition of existing components
    - Different density level

  what_does_NOT_count_as_different:
    - Same layout with different colors
    - Same structure with different component choices
    - Same approach with minor rearrangement
```

**For each approach, document:**
```yaml
approach:
  name: "[Short descriptive name, e.g., 'Dense Table with Inline Editing']"

  structure: "[2-3 sentences describing the approach]"

  how_it_works: "[Brief walkthrough of primary user flow]"

  strengths:
    - "[What this approach does well]"
    - "[What problems it solves elegantly]"

  weaknesses:
    - "[What this approach sacrifices]"
    - "[Where it might struggle]"

  assumptions:
    - "[What must be true for this approach to work]"

  reference_alignment: "[Which reference product principles does this follow?]"

  constraint_check:
    archetype_budget: "[Within budget? Which archetype?]"
    truth_model_fit: "[Does it represent entities/actions/states correctly?]"
    token_compatibility: "[Can it be built with existing tokens?]"
    law_compliance: "[Any law tensions?]"
```

### Step 4: Evaluate

Evaluate approaches against concrete criteria, not vibes.
```yaml
evaluation:
  criteria:
    # From the system
    - law_compliance: "Does it violate any laws.yaml rules?"
    - truth_model_fit: "Does it correctly represent entities, actions, states?"
    - archetype_budget: "Is it within the archetype's complexity budget?"
    - token_feasibility: "Can it be built with existing tokens and components?"
    - pattern_consistency: "Does it follow established patterns or justify departure?"

    # From the pre-build
    - intent_alignment: "Does it serve the declared screen intent?"
    - outcome_achievement: "Will it achieve the declared user state change?"
    - emotional_match: "Does it match the declared emotional register?"

    # From reference analysis
    - convention_respect: "Does it respect user conventions from reference products?"
    - principle_application: "Does it apply the transferable principles effectively?"

    # From user perspective
    - primary_task_efficiency: "How efficiently can user complete the primary task?"
    - learnability: "How quickly can a new user understand this?"
    - power_user_satisfaction: "Does it serve experienced users well?"

  scoring:
    # For each approach, score each criterion: strong / adequate / weak
    # A single "weak" on a Critical criterion eliminates the approach
    # Critical criteria: law_compliance, truth_model_fit, intent_alignment
```

### Step 5: Select and Document
```yaml
selection:
  chosen: "[Approach name]"

  why_this_wins: "[2-3 sentences — what makes this the best choice for THIS context]"

  why_not_others:
    - approach: "[Rejected approach name]"
      reason: "[Why it was rejected — specific, not 'it wasn't as good']"

  tradeoffs_accepted: "[What we're knowingly giving up with this choice]"

  what_must_be_true: "[Assumptions that, if wrong, would change this selection]"

  open_questions: "[Questions that emerged during exploration]"
```

---

## Exploration Artifacts

### Where to Store
```yaml
exploration_output:
  # For Standard tasks — inline in handoff or critique output
  standard: "Include selection summary in critique card header"

  # For Complex tasks — dedicated artifacts
  complex:
    location: "audit-output/{date}-exploration/"
    files:
      - reference-analysis.md   # Step 0 output
      - approaches.md           # Step 3 output with evaluations
      - selection.md            # Step 5 output
```

### What Persists

| Artifact | Where It Goes | Why |
|----------|--------------|-----|
| Selected approach + reasoning | Decision entry in Notion | Audit trail |
| Rejected approaches | Exploration artifact (audit-output) | Revisit if assumptions change |
| Reference principles | Can inform future builds | Learning |
| Open questions | Notion Open Questions | Resolution tracking |

---

## Exit Criteria

Ready to exit Explore mode when:
```yaml
exit_criteria:
  required:
    - Problem is clearly framed
    - Reference analysis completed (for Standard/Complex)
    - At least 2 approaches generated (for Standard/Complex)
    - Approaches evaluated against system constraints
    - Selection documented with reasoning
    - Rejected approaches preserved
    - Open questions identified

  required_for_complex:
    - Human has approved the selected approach
    - Decision entry created

  not_required:
    - Human approval for Standard tasks (proceed with documented selection)
    - Pixel-level decisions (premature at this stage)
    - Component specifications (premature at this stage)
```

---

## Constraints During Exploration

### Still Apply
- Notion Constitution laws (project-specific)
- Starter kit laws (system-wide)
- Archetype definitions (for evaluation)
- Truth model (for evaluation)
- Preset values (for context)

### Don't Apply Yet
- Detailed UI component rules (premature)
- Token-level specifications (premature)
- Pixel-level spacing decisions (premature)
- Interaction choreography details (premature)

---

## Transition to Build

When exploration is complete:

1. Lock the selected approach (for Complex: requires human approval)
2. Create Decision entry (Notion for product decisions, REGISTRY.md for system decisions)
3. Log any Open Questions to Notion
4. Proceed to BUILD step in the Build Conductor path
5. The exploration artifact becomes an input to the critique loop (Intent Alignment dimension checks against the selected approach)

---

## Anti-Patterns

| Anti-Pattern | Why It Fails | Instead |
|--------------|-------------|---------|
| Skip reference analysis | Build based on assumptions about conventions | Spend 15-30 minutes learning from the best |
| Copy a reference product | No adaptation to your constraints | Extract principles, apply through your system |
| Generate variations, not alternatives | Confirmation bias for first idea | Each approach must have different structure |
| Evaluate without criteria | Vibes-based selection | Use the evaluation criteria from Step 4 |
| Explore forever | Diminishing returns past 3-5 approaches | Time-box exploration, then commit |
| Skip exploration for "obvious" solutions | The obvious solution often has blind spots | At minimum, articulate why it's obvious |
| Explore without pre-build | No intent to evaluate against | Complete pre-build declarations first |
