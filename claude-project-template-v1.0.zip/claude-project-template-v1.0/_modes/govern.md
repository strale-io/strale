# Govern Mode (Execution)

> Convergent execution with full constraints.

**Purpose:** Build the thing right, following all rules.

---

## When to Use

- After exploration is complete
- Recommendation is approved
- Building actual features
- Making real decisions

---

## Govern Mode Mindset

| Do | Don't |
|----|-------|
| Follow constraints | Reinvent patterns |
| Apply existing patterns | Create new ones (propose first) |
| Reference by ID | Restate rules in prose |
| Load minimum context | Load everything |
| Run critique loop | Ship without review |

---

## Context Loading

### From Notion (Project-Specific)

Before any task, check Notion per `.claude/NOTION.md`:
- Constitution database (applicable laws) — always
- Decisions database (past decisions) — always
- Product Specs (what to build) — for features
- Design Library (visual references) — for features
- Deferred database — when uncertain

### From Starter Kit (System-Wide)

See `.claude/DISPATCH.yaml` — it provides exact file lists per task type with reasons, before/after triggers, and applicable quality gates.

Identify your task type in DISPATCH, then follow its `must_read` list.

---

## Decision Flow

For every decision:

```yaml
decision_flow:
  1_check_laws:
    source: _rules/laws.yaml
    question: "Is there a rule for this?"
    if_yes: follow_rule
    if_no: continue
    
  2_check_patterns:
    source: _model/patterns/
    question: "Is there a pattern for this?"
    if_yes: apply_pattern
    if_no: continue
    
  3_check_archetype:
    source: _quality/archetypes/
    question: "Does archetype constrain this?"
    if_yes: follow_archetype
    if_no: continue
    
  4_check_preset:
    source: _presets/{active}.yaml
    question: "What's the default?"
    apply: preset_default
    
  5_decide:
    within: remaining_option_space
    document: if_novel
```

---

## What You Can Do (Autonomous)

From `.claude/RUNBOOK.md`:

- Apply components from `_ui/components.yaml`
- Apply patterns from `_model/patterns/`
- Apply tokens from `_ui/tokens.yaml`
- Implement states per `_ui/states.md`
- Run critique loop

---

## What Requires Approval

From `.claude/RUNBOOK.md`:

- New entities or actions in truth model
- New patterns not in `_model/patterns/`
- Changes to rules or Constitution
- Archetype exceptions
- Navigation structure changes
- Violations of Notion Constitution laws

---

## Execution Process

### 1. Verify Prerequisites

```yaml
prerequisites:
  - Exploration complete
  - Recommendation approved
  - Context loaded
  - Archetype identified
```

### 2. Build

```yaml
build:
  following:
    - Truth model (entities, actions, states)
    - Patterns (navigation, forms, data display)
    - Components (from registry)
    - Tokens (all values)
    
  ensuring:
    - All states handled
    - Keyboard navigation complete
    - Within archetype budget
```

### 3. Critique

```yaml
critique:
  process: See _critique/LOOP.md
  
  required: Always
  max_cycles: 3
  
  stop_when:
    - P0 = 0
    - P1 ≤ 2
    - All scores meet minimums
```

### 4. Ship or Escalate

```yaml
completion:
  if_passing:
    - Document in scorecard
    - Ship the work
    
  if_stuck:
    - Document why stuck
    - Document what's missing
    - Escalate to human
```

---

## Anti-Patterns

| Anti-Pattern | Why It's Wrong |
|--------------|----------------|
| Skip critique | Quality gates exist for reason |
| Ignore constraints | System breaks down |
| Iterate forever | 3 cycles max, then escalate |
| Load everything | Token bloat, slow context |
| Reinvent patterns | Consistency loss |

---

## Artifacts

During execution, create:

```yaml
execution_artifacts:
  code:
    location: codebase
    
  scorecards:
    location: _critique/scorecards/
    format: "{date}-{screen-name}.md"
    
  decisions:
    location: _decisions/REGISTRY.md
    when: novel_decision_made
    
  notion_updates:
    implementation_log: Log session outcome
    decisions_db: Document significant decisions
    thinking_log: Capture valuable learnings
```

---

## Transition

After successful execution:

- Log implementation in Notion Implementation Log
- If issues found in production → Document in Notion Thinking Log
- If constraint changes needed → Propose update
- If pattern emerged → Document for future

### Session Exit Learning Check (mandatory)

Before signing off, Claude runs this check and includes it in the session summary:

```
SESSION EXIT — LEARNING CHECK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Did I work around a template limitation today?
   → [Yes/No. If yes: what, and is it generic?]

2. Did I discover a pattern that should be reusable?
   → [Yes/No. If yes: what pattern?]

3. Did I make a decision that future projects would face?
   → [Yes/No. If yes: which decision?]

Template learnings found: [0/1/2/3]
→ [If >0: Created Notion Learning Queue entries]
```

This block is printed every session, even when all answers are "No."
If learnings are found, Claude creates entries in the Notion Learning Queue
(database ID: a469f116334f49389d28b0004b60366b) with status `captured`.

See `EVOLUTION.md` for the full upstream propagation protocol.

---

## System Audit (Periodic)

Run quarterly or when system feels bloated.

**Purpose:** Prevent system decay by identifying entropy.

### Audit Checklist

```yaml
system_audit:
  identify:
    - Redundant concepts (same idea in two places)
    - Parallel abstractions (two ways to do same thing)
    - Unclear ownership (concept without single home)
    - Dead weight (files never referenced)
    - Scope creep (folders exceeding original purpose)
    
  propose:
    - Deletions only (no additions during audit)
    - Mergers (combine redundant concepts)
    - Clarifications (assign ownership)
    
  forbidden_during_audit:
    - Adding new files
    - Adding new concepts
    - Expanding scope
```

### Audit Questions

1. **Can anything be deleted?** (Always start here)
2. **Can two things become one?** (Merge before extend)
3. **Does every file have one clear owner?**
4. **Is there any parallel path for a capability?**
5. **Has any folder exceeded its stated scope?**

### Audit Output

```yaml
audit_output:
  deletions: List files to remove
  mergers: List concepts to combine
  clarifications: List ownership assignments
  
  never_output:
    - New files
    - New concepts
    - Expanded scope
```

**Tier-1 teams run this constantly. They just don't formalize it.**
