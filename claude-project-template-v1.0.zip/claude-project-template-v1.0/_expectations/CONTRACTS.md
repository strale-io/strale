# User Contracts

> Every surface must satisfy all ten contracts before shipping.

---

## Overview

| Contract | Question | Failure Mode |
|----------|----------|--------------|
| **Orientation** | Where am I? | Lost user |
| **Action** | What can I do? | Blocked user |
| **Information** | What will I learn? | Confused user |
| **Explanation** | How do I understand? | Frustrated user |
| **Confidence** | Can I trust this? | Skeptical user |
| **Freshness** | Is this current? | Uncertain user |
| **Feedback** | Did that work? | Anxious user |
| **Prediction** | What will happen? | Hesitant user |
| **Continuity** | Does it remember me? | Annoyed user |
| **Completion** | When is this done? | Directionless user |

---

## 1. Orientation Contract

> Users must always know where they are in the system.

**Test:** Can user answer "Where am I?" within 2 seconds of arrival?

### Mandatory Signals

Every page must include at least two of:

| Signal | Purpose | Example |
|--------|---------|---------|
| Breadcrumb | Shows path from root | Settings → Integrations → Slack |
| Navigation state | Highlights current location | Active nav item |
| Page title | Names the content | "Project Settings" |
| Context object | Shows what entity is scoped | "For: Acme Corp" |
| Section header | Names subsection | "Authentication" |

### Invariants

| ID | Requirement |
|----|-------------|
| OR-001 | Page has explicit title visible |
| OR-002 | Navigation shows current location |
| OR-003 | Context object is visible when scoped |
| OR-004 | Breadcrumb present for depth > 2 |
| OR-005 | No page has zero orientation signals |

---

## 2. Action Contract

> Users must know what they can do.

**Test:** Can user answer "What actions are available?" within 3 seconds?

### Mandatory Elements

| Surface Type | Must Show |
|--------------|-----------|
| Index/Hub | Create, view items |
| Detail | Primary action, edit, back |
| Editor | Save, cancel, undo |
| Settings | Save, reset |

### The Expectation Principle

Every visible element creates an expectation. If you show it, the user will try to interact with it.

| Element Type | User Expects |
|--------------|--------------|
| Metric/number | Click to drill down |
| Status badge | Click to see breakdown |
| List item | Click to view/edit |
| Progress bar | Click to see composition |
| Card | Click to expand/navigate |

**Rule:** If you display information, enable interaction with it — or explicitly disable with explanation.

### Invariants

| ID | Requirement |
|----|-------------|
| EX-001 | Metrics are navigation (clickable) |
| EX-002 | CTAs are contextual, not generic |
| EX-003 | Primary actions have affordances |
| EX-004 | Interactive-looking elements are interactive |
| EX-005 | Disabled actions explain why |

---

## 3. Information Contract

> Users must learn what they came to learn.

**Test:** Are arrival questions answered without leaving the page?

### Arrival Questions

| Page Title | User Expects to Learn |
|------------|----------------------|
| Overview | Status, what needs attention, where to go next |
| Dashboard | Key metrics, trends, health status |
| [Entity] List | What exists, how much, how to find things |
| [Entity] Detail | Everything about this specific item |
| Settings | What's configured, what options exist |
| History | What happened, when, by whom |

### Raised Questions

Every piece of data raises follow-up questions:

| Shows | Raises Question | Must Also Show |
|-------|-----------------|----------------|
| "8/37" | What's measured? Good or bad? | Label + interpretation |
| "In Progress" | Since when? By whom? | Timestamp, owner |
| "3 errors" | What errors? How severe? | Error list or link |
| "42%" | Of what? What's the target? | Denominator + context |

**Rule:** If you show data, you own the follow-up question.

### Invariants

| ID | Requirement |
|----|-------------|
| IX-001 | Arrival questions are answered |
| IX-002 | Raised questions have paths to answers |
| IX-003 | Progress shows composition |
| IX-004 | Empty states have explanation |
| IX-005 | Metrics have context |
| IX-006 | Status has interpretation |

---

## 4. Explanation Contract

> Users must be able to understand anything shown.

**Test:** Can a client point at any element and get an answer without speaking to the designer?

### The Explanation Ladder

| Rung | Type | Example | Use When |
|------|------|---------|----------|
| 1 | Inline signal | Icon, label | Meaning obvious |
| 2 | Hover/focus hint | Tooltip | Brief clarification |
| 3 | Local explainer | Popover | More context required |
| 4 | Page-level context | Section intro | Applies to many elements |
| 5 | System reference | Glossary, docs | Deep understanding |

**Rule:** Choose the lowest sufficient rung.

### Mandatory Explanation Targets

These MUST have an explanation path:
- Status badges / state labels
- Progress indicators
- Empty states
- Disabled actions
- Counts and metrics
- Color-coded indicators
- Abbreviations and technical terms

### The Tooltip Contract

| Rule | Rationale |
|------|-----------|
| Explains meaning, not instruction | "What this is" not "click here" |
| Neutral tone | No recommendation or pressure |
| ≤ 2 lines | Brevity |
| Keyboard + screen reader accessible | Accessibility |

### Invariants

| ID | Requirement |
|----|-------------|
| XP-001 | Domain terms have explanation |
| XP-002 | Status badges have tooltips |
| XP-003 | Disabled states explain why |
| XP-004 | Empty states have guidance |
| XP-005 | Color-coding has legend/tooltip |
| XP-006 | Explanation doesn't require navigation |

---

## 5. Confidence Contract

> Users must trust what they see.

**Test:** Does the surface avoid implying correctness or quality?

### Requirements

| Principle | Example |
|-----------|---------|
| No implied quality | Don't say "good" or "poor" without criteria |
| Rankings explained | If sorted by score, show the score |
| Uncertainty explicit | If estimated, say so |
| No false precision | Don't show "83.7%" if it's a guess |
| Source visible | Where did this data come from? |

### Anti-Patterns

| Pattern | Problem |
|---------|---------|
| Color-coded scores without legend | Implies judgment |
| "Recommended" without criteria | Manufactured trust |
| Percentages without basis | False precision |
| Rankings without explanation | Hidden logic |

### Invariants

| ID | Requirement |
|----|-------------|
| CF-001 | No implied quality without criteria |
| CF-002 | Rankings have visible explanation |
| CF-003 | Estimates marked as estimates |
| CF-004 | Data sources visible or accessible |
| CF-005 | Uncertainty is explicit |

### Intelligence Extension (Conditional)

> **[When `intelligence` capability extension is active]**

The Confidence Contract extends to cover algorithmic confidence:

| Core Requirement | Intelligence Extension |
|-----------------|----------------------|
| No implied quality without criteria | + Algorithmic suggestions show their reasoning |
| Rankings explained | + ML/heuristic-generated rankings show the model's basis |
| Uncertainty explicit | + Confidence levels are calibrated to evidence strength per `_extensions/intelligence/FRAMEWORK.md` |
| Data sources visible | + Data inputs to intelligence features are disclosed |
| Defaults marked | + Smart defaults are visually distinguished with source tooltip |

---

## 6. Freshness Contract

> Users must know if data is current.

**Test:** Can user answer "Is this current?" without asking?

### Requirements

| Content Type | Show |
|--------------|------|
| Snapshot data | "As of" timestamp |
| Live data | Sync status indicator |
| Cached data | Refresh action + last update |
| User content | Last edited timestamp |

### Staleness Rules

| Age | Indicator |
|-----|-----------|
| < 1 hour | Implicit current (no indicator needed) |
| 1–24 hours | Relative time ("2 hours ago") |
| > 24 hours | Absolute timestamp |
| > 7 days | Warning indicator |

### Invariants

| ID | Requirement |
|----|-------------|
| FR-001 | Snapshot data has timestamp |
| FR-002 | Live data has sync status |
| FR-003 | Stale data has warning |

---

## 7. Feedback Contract

> Users must know their actions worked.

**Test:** Does every action produce visible feedback?

### Feedback Timing

| Action Duration | Feedback |
|-----------------|----------|
| < 500ms | Immediate state change |
| 500ms–2s | Progress indicator |
| > 2s | Progress with status |
| Background | Toast when complete |

### Required Feedback

| Action | Feedback |
|--------|----------|
| Save | State change or "Saved" |
| Delete | Removal + optional undo |
| Submit | Confirmation + next step |
| Error | Message + resolution path |

### Invariants

| ID | Requirement |
|----|-------------|
| FB-001 | All actions have visible feedback |
| FB-002 | Errors have resolution path |
| FB-003 | Long operations show progress |
| FB-004 | Background tasks notify on completion |

---

## 8. Prediction Contract

> Users must know what will happen before acting.

**Test:** Are consequences visible before action?

### Requirements

| Action Type | Show Before |
|-------------|-------------|
| Destructive | What will be deleted, affected count |
| Cascade | What else will be affected |
| Irreversible | Explicit warning |
| Settings change | What will change |

### Cascade Warnings

When action affects multiple items, show:
- Count of affected items
- Preview of consequences
- "Are you sure?" only for irreversible

### Invariants

| ID | Requirement |
|----|-------------|
| PR-001 | Destructive actions show consequences |
| PR-002 | Cascade effects are visible |
| PR-003 | Irreversible actions are marked |
| PR-004 | Affected counts are shown |

---

## 9. Continuity Contract

> The system must remember user context.

**Test:** Does user lose state when navigating away and back?

### Preserve On Return

| State | Requirement |
|-------|-------------|
| Scroll position | Within page, within session |
| Filter/sort | Until explicitly cleared |
| Form data | Until submitted or discarded |
| Expanded/collapsed | Within session |
| Selected items | Until action or navigation |

### Unsaved Work

| Rule | Implementation |
|------|----------------|
| Warn before loss | "You have unsaved changes" |
| Auto-save when possible | Draft state |
| Preserve on navigate | Store in session |
| Recover after error | Restore from local storage |

### Invariants

| ID | Requirement |
|----|-------------|
| CN-001 | Filters persist until cleared |
| CN-002 | Unsaved work prompts before loss |
| CN-003 | Scroll position preserved in session |
| CN-004 | Form data preserved until submitted |

---

## 10. Completion Contract

> Users must know when they're done.

**Test:** Can user answer "Am I done?" at any point?

### Requirements

| Flow Type | Show |
|-----------|------|
| Multi-step | Progress indicator + current step |
| Task list | Completion count + remaining |
| Setup | Required vs optional clearly marked |
| Wizard | Step count + current position |

### Done Signals

| Context | Signal |
|---------|--------|
| Flow complete | Success state + next step |
| Task complete | Checkmark + optional celebration |
| Nothing to do | Empty state with guidance |
| Blocked | What's blocking + resolution |

### Invariants

| ID | Requirement |
|----|-------------|
| CP-001 | Multi-step flows show progress |
| CP-002 | Completion has visible signal |
| CP-003 | Next step is clear after completion |

### Flow-Level Completion (Conditional — if `_flows/REGISTRY.yaml` is populated)

When a surface participates in a registered flow (FLOW-NNN):

| Check | Requirement |
|-------|-------------|
| Progress signal | User knows where they are in the flow |
| Handoff quality | Transition to next surface is smooth or progressive (not jarring without justification) |
| Abandonment path | User can exit the flow without losing work |
| Re-entry support | User can resume the flow from where they left off |
| Emotional coherence | Surface tone matches its position in the flow's emotional arc |

---

## Surface Readiness Gate

Before shipping, verify all 10 contracts:

| Contract | Check | Test |
|----------|-------|------|
| Orientation | User knows location | "Where am I?" in 2s |
| Action | User can act or knows why not | Dead Surface Test |
| Information | Arrival questions answered | Information Completeness Test |
| Explanation | Everything is explainable | "Explain to Client" Test |
| Confidence | No implied quality | No hidden judgments |
| Freshness | Data age is clear | Timestamp visible |
| Feedback | Actions produce response | No silent actions |
| Prediction | Consequences visible | Cascade preview |
| Continuity | State preserved | Navigate-and-return test |
| Completion | Progress visible | "Am I done?" test |

**Failure:** If any contract fails, surface is not ready.

---

## 11. Collaboration Contract (Conditional)

> **[Fires only when `collaboration` capability extension is active]**
> Users must know who else is here and what they're doing.

**Test:** Can the user answer "Who else is working on this?" at any point?

### Requirements

| Layer | Check | Test |
|-------|-------|------|
| **Awareness** | Other users' presence is visible | "Who else is viewing this?" answerable |
| **Communication** | Conversations are contextual, not displaced | Comments and mentions are where the work is |
| **Coordination** | Ownership and handoffs are clear | "Who's responsible for this?" answerable |
| **Co-creation** | Concurrent editing is safe and visible | "Is anyone else editing this right now?" answerable |

### Invariants

See `_extensions/collaboration/INVARIANTS.md` for the full set (CO-001 through CO-019).
