# User Expectation Framework

> Explore widely, build narrowly, explain the gap.

---

## Core Principle

The goal is not to maximize features. The goal is not to minimize features. **The goal is to match user expectations.**

A surface is expectation-complete when:
- Every Expected feature exists or is explicitly deferred
- No Speculative or Dangerous features were added

---

## LAW-012: Bounded Curiosity

> The system must explore more than it builds, and explain what it chooses not to build.

---

## Operational Protocols

Pre-Build operations, templates, and checklists are in `PRE-BUILD.md`.

**What's here:** Principles, classification systems, and conceptual frameworks.

**What's in PRE-BUILD.md:** Flow steps, templates, gates, and operational protocols.

---

## Feature Classification System

| Classification | Definition | Action |
|----------------|------------|--------|
| **Expected** | User would assume this exists | Must build or explicitly defer |
| **Helpful** | Improves experience but not assumed | May defer with explanation |
| **Speculative** | Nice idea, no user expectation | Reject with documented reasoning |
| **Dangerous** | Adds bias, pressure, or false confidence | Forbidden |
| **Prevented** | Assumption that must NOT be true | Actively block in UI |

### Classification Tests

| Classification | Test |
|----------------|------|
| **Expected** | Would user complain if missing? |
| **Helpful** | Would user be delighted if present? |
| **Speculative** | Would user ever ask for this? |
| **Dangerous** | Does this violate restraint principles? |
| **Prevented** | Would user wrongly assume this exists? |

### Prevention Methods

For "Prevented" assumptions:
- Explicit UI copy ("This does not include X")
- Visual constraints (disabled state with explanation)
- Absence of affordance (don't show button that implies capability)
- Onboarding clarification (set expectations early)

> **Intelligence extension refinement:** When the `intelligence` capability extension is active, features with smart functionality are not automatically classified as "Dangerous." Instead, they are evaluated through the Intelligence Restraint Gate (`_extensions/intelligence/GUARDRAILS.md`). Features that pass the gate can be classified as Expected or Helpful. Features that fail remain Dangerous. This creates a path for responsible intelligence design — not a blanket pass.

---

## Expectation Invention Loop (EIL)

**Trigger:** Run when introducing new data, state, or affordances.

### The 5 Steps

```
1. IMMEDIATE EXPECTATIONS → What does existence of this capability imply?
   - What can users now see?
   - What can users now do?
   - What is now tracked/saved/remembered?

2. SECONDARY EXPECTATIONS → What do users expect after using it twice?
   - History (can I see previous uses?)
   - Undo (can I reverse this?)
   - Explanation (can I understand what happened?)
   - Comparison (can I compare instances?)
   - Consistency (does this work the same elsewhere?)

3. TRUST EXPECTATIONS → What must exist so user does not lose confidence?
   - Status indicator
   - Provenance
   - Constraints
   - Error states
   - Definitions

4. NON-GOALS → What must user NOT assume?
   - What is intentionally out of scope?
   - What future capability is NOT promised?
   - What assumptions must be actively prevented?

5. CASCADE DECISION → Classify each expectation:
   - Must Build Now → becomes Expected feature
   - Must Defer → tracked in Expectation Debt
   - Must Prevent → addressed in UI (copy, constraints, absence)
```

### EIL Artifacts

Store in: `_decisions/eil/[capability-name].yaml`

---

## Related Invariants

| ID | Invariant |
|----|-----------|
| UE-001 | Peer context is specified before building |
| UE-002 | Absence detection is performed before building |
| UE-003 | Expected actions are enumerated before building |
| UE-004 | Surface role requirements are satisfied |
| UE-005 | Inner Monologue Test passes |
| UE-006 | Visual interactivity implies actual interactivity |
| UE-007 | Expectation debt is tracked explicitly |
| UE-008 | Candidate features are explored before building |
| UE-009 | Features are classified before implementation |
| UE-010 | Restraint Gate is applied to all features |
| UE-011 | Rejected features are documented |
| EIL-001 | New capabilities run Expectation Invention Loop |
| EIL-002 | Prevented assumptions are documented |
| EIL-003 | Secondary expectations are examined |
| EIL-004 | Trust expectations are examined |
| EIL-005 | EIL outputs feed Pre-Build |

---

## Stickiness Assessment (Optional)

**When active:** If `moat-conscious` preset is enabled.

**Purpose:** Evaluate how features contribute to structural competitive advantage.

### Questions

For each feature, assess:

- [ ] Does this feature create value that compounds with usage?
- [ ] Does this feature increase switching costs (integration, data, workflow)?
- [ ] Does this feature contribute to institutional memory?
- [ ] Does this feature undermine any existing moat? (If yes, justify)

### Moat Contribution Classification

| Classification | Definition |
|----------------|------------|
| **Moat-Building** | Creates structural advantage |
| **Moat-Neutral** | Useful but doesn't affect competitive position |
| **Moat-Undermining** | Makes product easier to leave or replicate |

### Decision Matrix

| Feature Type | Moat-Building | Moat-Neutral | Moat-Undermining |
|--------------|---------------|--------------|------------------|
| **Expected** | ✅ Build (ideal) | ✅ Build | ✅ Build (reconsider design) |
| **Helpful** | ✅ Prioritize | ⚖️ Evaluate | ❌ Reject or redesign |
| **Speculative** | ⚖️ Consider | ❌ Reject | ❌ Reject |

**Key:** Expected features must be built regardless of moat contribution. Moat thinking influences prioritization and design, not whether to build Expected features.

See `_strategy/MOATS.md` for complete moat guidelines.

---

## User Intelligence Graph

> A framework for modeling user understanding across multiple dimensions.

This is not the data itself (which is project-specific) but the structure for how to think about users.

### The Five Layers

| Layer | Question | Informs |
|-------|----------|---------|
| **Functional** | What does the user need to accomplish? | Feature scope, task flows |
| **Cognitive** | What mental models does the user bring? | Terminology, information architecture |
| **Emotional** | What does the user feel before, during, and after? | Tone, emotional intent, copy |
| **Aesthetic** | What quality signals does the user expect? | Visual craft, density, polish level |
| **Behavioral** | How does the user actually behave (vs. how they say they do)? | Defaults, progressive disclosure, shortcuts |

### Reality Simulation

For each layer, simulate by asking:

> "If I were this user, in this context, with this history, what would I actually think/feel/do — not what would I ideally think/feel/do?"

Reality simulation is a technique, not a test. Use it to pressure-check assumptions in the Spec Interrogation Protocol, Pre-Build flow, and Inner Monologue Test.

---

## Continuation Surface & User Momentum

> Every surface either propels the user forward or allows them to observe. Know which one yours is.

### Surface Types

| Type | Purpose | User State After |
|------|---------|-----------------|
| **Continuation Surface** | Propels user to next action | User is mid-flow, moving forward |
| **Dashboard Surface** | Allows user to observe and orient | User is informed, deciding next move |

### Momentum Killers

These patterns break user flow and must be caught during critique:

| Killer | Description |
|--------|-------------|
| **Dead End** | Screen with no clear next action |
| **Unclear Next Step** | User accomplished something but doesn't know what's next |
| **Unnecessary Interruption** | Modal/confirmation that adds friction without value |
| **Context Destruction** | Navigation that loses the user's mental context |
| **Forced Restart** | Completing a task returns user to beginning instead of next logical step |

### Momentum Test

For continuation surfaces: "After completing the primary action, does the user know what to do next without thinking?"

For dashboard surfaces: "Can the user identify the most important thing to attend to within 5 seconds?"

Failing momentum test = P1. Dead ends in primary flows = P0 (already enforced by LAW-007/008).
