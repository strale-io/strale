# Pre-Build Operations

> Operational protocols for the Pre-Build phase. Run before building any surface.

**Parent:** `FRAMEWORK.md` — Principles and conceptual foundation.

---

## Pre-Build Exploration Flow

Run before building any surface:

```
0. EXPECTATION INVENTION LOOP → If new capability, run EIL first
1. PEER CONTEXT → What do comparable products do?
2. CANDIDATE FEATURES → What might users expect?
3. THESIS ALIGNMENT → Does each candidate serve the product thesis?
4. FEATURE MULTIPLICATION → Does each candidate multiply existing features?
5. FEATURE CLASSIFICATION → Expected / Helpful / Speculative / Dangerous / Prevented
6. ABSENCE DETECTION → What's missing by category?
7. EXPECTED ACTIONS → What would user want to do?
8. SURFACE ROLE REQUIREMENTS → What must this surface type include?
9. INNER MONOLOGUE TEST → Simulate user thinking
10. RESTRAINT GATE → Filter through restraint principles
11. ADAPTIVE DECLARATION → Content priority + form factor declaration (see `_ui/ADAPTIVE.md`)
12. SURFACING AUDIT → Information tier assignment for surface (see `_model/patterns/SURFACING.md`)
13. BUILD / DEFER / REJECT / PREVENT LISTS → Document decisions
```

### Peer Context Quality Anchor

> Peer context is a quality judgment, not a feature list.

**Purpose:** When identifying what comparable products do (step 1), judge whether they do it *well*.

For each peer product (max 3 peers):

```yaml
peer_context:
  peer: "[Product name]"
  relevance: "[Why this peer is comparable]"
  what_they_do_well: "[Specific capability that works well, and WHY it works]"
  what_they_do_poorly: "[Specific capability that doesn't work, and WHY]"
  lesson_for_us: "[What this teaches us — to adopt, avoid, or improve]"
```

**Rules:**
1. **Max 3 peers.** More dilutes focus and creates feature pressure.
2. **Quality over features.** "They have X" is worthless. "They have X, and it works because Y" is useful.
3. **Learn from failures.** Bad implementations are as instructive as good ones.
4. **Judgment is mandatory.** If you can't say why something works well or poorly, you haven't done peer context.

Peer context feeds Feature Classification. A feature is more likely "Expected" if well-executed peers have it; less likely if peers struggle with it.

### Thesis Alignment Check

> Every feature candidate is tested against the product thesis before classification.

**Prerequisite:** `config/manifest.yaml` → `thesis.claim` must be filled. If not, skip with warning: "Thesis not declared — directional coherence cannot be verified."

For each candidate feature from step 2:
```yaml
thesis_alignment:
  feature: "[Candidate feature]"
  thesis: "[From manifest.yaml]"
  serves_thesis: "[yes / partially / no]"
  how: "[Specific connection — not vague 'it helps']"
```

Features with `serves_thesis: no` can still proceed but must carry an orphan justification (see `_quality/DIRECTIONAL_COHERENCE.md`).

### Feature Multiplication Check

> Does this feature make at least one existing feature more valuable?

For each candidate that passes thesis alignment:
```yaml
multiplication_check:
  feature: "[Candidate feature]"
  multiplies:
    - existing_feature: "[Which existing feature this strengthens]"
      mechanism: "[How, specifically]"
  multiplied_by:
    - existing_feature: "[Which existing feature strengthens this]"
      mechanism: "[How, specifically]"
  classification: "[load-bearing / amplifier / utility / orphan]"
```

**Rule:** Orphan features (multiply nothing) are not blocked, but must carry explicit justification before proceeding to classification.

**Full framework:** `_quality/DIRECTIONAL_COHERENCE.md`

### Vocabulary Continuity Gate (Multi-Surface)

> Same concept, same term. Every time.

**Trigger:** Multi-surface builds. Check before using any user-facing term.

Before introducing any user-facing term on a surface:

```yaml
vocabulary_check:
  term: "[The term you're about to use]"
  concept: "[What it refers to]"
  existing_usage: "[Where this term/concept already appears in product]"
  action:
    if_existing_term: "Use established term — do not invent synonym"
    if_new_concept: "Add to _model/truth/vocabulary.yaml with definition"
    if_different_term_same_concept: "Reconcile — use existing term, not new one"
```

**Rules:**
1. **Same concept with different terms = P1.** "Project" on one screen and "Workspace" on another is a terminology collision.
2. **New terms require registry entry.** If it's not in vocabulary.yaml, add it before using it.
3. **Check before inventing.** The registry is the source of truth.

**Registry:** `_model/truth/vocabulary.yaml` — the single source for product terminology.

---

## Copy-First Gate (Conditional)

> For surfaces where words matter, write them before designing layout.

**Trigger surfaces:** Empty states, error states, onboarding steps, confirmation dialogs, success states.

### The Rule

For trigger surfaces, draft copy BEFORE committing to layout:

1. **Write** the copy that explains what's happening
2. **Identify** what the user needs to understand
3. **Then** design structure that serves the copy

### Rationale

Copy reveals requirements. "We couldn't find any projects" vs "You haven't created any projects yet" imply different designs. The copy is the spec; the layout serves it.

### Template

```yaml
copy_first:
  surface: "[Which surface]"
  primary_message: "[What user must understand]"
  secondary_message: "[Supporting context if any]"
  action_copy: "[CTA text]"
  layout_committed: false  # Set true only after copy approved
```

**Violation = P1.** Layout committed before copy on trigger surfaces produces contorted copy.

---

## Interpretation Anchors

> Lock your interpretation before building. Check it before merging.

**Trigger:** At the end of Pre-Build, before any building begins.

### The Anchors

Write 3–5 single-sentence anchors that capture your core interpretation:

```yaml
interpretation_anchors:
  - "This screen is [X] because [Y]"
  - "The primary action is [A] because [B]"
  - "We're NOT doing [C] because [D]"
  - "The user arrives here from [E] expecting [F]"
  - "Success means the user can [G]"
```

### Rules

- Anchors are written AFTER Pre-Build, BEFORE building
- Anchors cannot be changed without explicit documentation in `_decisions/REGISTRY.md`
- At Gate 4 (Drift Detection), check: "Do my final decisions still match these anchors?"

### When Anchors Break

If Gate 4 reveals anchor drift:
1. The build drifted (fix it), OR
2. The anchors were wrong (document why and update)

Either way, the gap becomes visible.

---

## Implicit Decision Surfacing

> Decisions made silently are decisions made poorly.

**Trigger:** Run at the end of Pre-Build, after Interpretation Anchors are written.

### The Implicit Decisions

These decisions are often made without acknowledgment. Surface them explicitly:

| Category | Question | Write Your Answer |
|----------|----------|-------------------|
| **Information Density** | How much information per screen? (Dense/moderate/sparse) | |
| **Layout Direction** | Horizontal flow or vertical flow? | |
| **Interaction Complexity** | Click-to-reveal or everything visible? | |
| **Vocabulary Level** | Technical terms or simplified language? | |
| **Scope Boundary** | What's explicitly OUT of scope for this surface? | |
| **Primary User** | Who is this optimized for if users differ? | |

### Template

```yaml
implicit_decisions:
  density: "[dense/moderate/sparse] — because [reason]"
  layout: "[horizontal/vertical/mixed] — because [reason]"
  interaction: "[progressive/immediate] — because [reason]"
  vocabulary: "[technical/simplified/mixed] — because [reason]"
  scope_out: "[What is explicitly NOT in scope]"
  primary_user: "[Who this is optimized for, if users differ]"
```

### Rules

1. **All fields required.** Skipping a field = implicit decision you're not owning.
2. **"Because" is mandatory.** The reason matters more than the choice.
3. **Disagreement is information.** If the team would disagree, the decision needs discussion, not assumption.

### Integration

Implicit decisions feed Interpretation Anchors. If an implicit decision contradicts an anchor, one of them is wrong.

---

## Tradeoff Anticipation

> Identify competing design principles before they become invisible compromises.

**Trigger:** Run at the end of Pre-Build, after Implicit Decision Surfacing.

### The Anticipation

For each surface, identify the 2-3 most likely design tradeoffs:

```yaml
tradeoff_anticipation:
  surface: "__FILL__"
  anticipated_tradeoffs:
    - principles: ["__FILL__", "__FILL__"]     # e.g., ["clarity", "density"]
      context: "__FILL__"                       # Why this tension exists here
      planned_resolution: "__FILL__"            # Which principle wins and why
      priority_ladder_check: __SELECT__         # yes | no — did you consult the ladder?
```

### Rules

1. **Anticipate before building.** Tradeoffs discovered during critique are more expensive than tradeoffs anticipated during planning.
2. **Name both sides.** "We chose clarity" is incomplete. "We chose clarity over density because the audience is non-expert" is a tradeoff.
3. **Reference the ladder.** Use the Priority Ladder in `_quality/HEURISTICS.md` to resolve ambiguous conflicts.

### Integration

Anticipated tradeoffs feed critique. The Tradeoff Evaluation section in `_critique/PROMPT.md` checks whether tradeoffs were acknowledged and resolved correctly.

---

## Classification Challenge Protocol

> Every "Expected" classification must survive a challenge.

Before finalizing any feature as "Expected," apply these challenges:

| Challenge | Question | If Answer is "No" |
|-----------|----------|-------------------|
| **Omission Test** | Would users actively complain if this were missing? | Downgrade to Helpful |
| **Alternative Test** | Could users accomplish their goal without this? | Downgrade to Helpful |
| **Evidence Test** | Is there evidence beyond intuition that users expect this? | Flag as assumption |
| **Scope Test** | Does this belong in THIS surface, or somewhere else? | Reconsider placement |

### The Classification Challenge Log

For features classified as Expected, document:

```yaml
classification_challenge:
  feature: "[Feature name]"
  classification: "Expected"
  challenges_applied:
    omission_test: "[yes/no — would users complain?]"
    alternative_test: "[yes/no — could they work without it?]"
    evidence_test: "[what evidence supports this?]"
    scope_test: "[why this surface?]"
  survives_challenge: "[yes/no]"
  if_no_reclassified_to: "[Helpful/Speculative]"
```

### Purpose

"Expected" is the highest-commitment classification. It drives scope. Challenge ensures that commitment is earned, not assumed.

> **[If `disclosure` extension active]** Before classifying features, check the complexity budget for the target lifecycle stage (`_extensions/disclosure/PROTOCOL.md`). Features that exceed the stage's budget should be deferred to a later stage, not classified as Expected for this surface.

---

## Absence Detection System

> Hunt for absence, not just correctness.

### Feature Category Checklist

| Category | Features to Consider |
|----------|---------------------|
| **Navigation** | Entry to deeper context, way back, hierarchy cue |
| **Creation** | Create new, duplicate/fork, template |
| **Management** | Rename, delete/archive, status change |
| **Understanding** | Page explanation, progress/state, learn more |
| **Continuity** | Resume last action, what changed, what's incomplete |

---

## Surface Role Requirements

| Surface Type | Must Include |
|--------------|--------------|
| **Index/Hub** | Create, open, status summary, empty state, search (if >5) |
| **Detail/Overview** | Key info, primary action, back nav, edit affordance |
| **Workspace/Editor** | Save indication, undo, manipulation affordances, exit clarity |
| **Dashboard/Report** | Metrics with drill-down, time context, freshness signal |
| **Settings/Config** | Current values, save mechanism, reset option |
| **Onboarding/Flow** | Progress indication, current step, forward action |

---

## Restraint Gate

Before implementing any feature, verify it does NOT:

| Restraint Check | Violation Example |
|-----------------|-------------------|
| Recommend without evidence | "You should focus on X" without data |
| Collapse deliberation into convenience | One-click decision for complex choice |
| Hide uncertainty | Presenting estimate as fact |
| Create premature commitment | Locking choice before user understands |
| Look "smart" but reduce trust | Clever but feels manipulative |
| Add bias or pressure | Nudging toward specific outcome |
| Manufacture urgency | False time pressure |

**Rule:** If any check fails, the feature is blocked.

### Intelligence Restraint Gate (Conditional)

> **[Fires only when `intelligence` capability extension is active AND feature includes smart functionality]**

If the feature being evaluated includes intelligence (suggestions, smart defaults, automations, or autonomous behavior), it must also pass the Intelligence Restraint Gate in `_extensions/intelligence/GUARDRAILS.md`.

The Intelligence Restraint Gate is additional to, not a replacement for, the standard Restraint Gate above. Both must pass.

**Features that fail the Intelligence Restraint Gate are classified as "Dangerous."**

---

## Expectation Debt Tracking

| Type | Definition | Tracking |
|------|------------|----------|
| **Missing but expected** | User would expect it; not there | Gap — must address |
| **Intentionally deferred** | Planned for later phase | Debt — track explicitly |
| **Resolved** | Was missing, now implemented | Closed |

**Deferred features must document:**
- Why deferred
- What phase it's planned for
- How user is informed (if at all)

### Mental Model Audit (Multi-Surface Builds)

> **[Required when building a surface that coexists with existing surfaces]**

Before building, audit what the user learned on surfaces they've already seen and verify the new surface honors those learned rules. See `_surfaces/EXPECTATIONS.md` for the full audit template.

**Core question:** "If the user learned the product through existing surfaces, will the new surface feel like the same product?"

- [ ] User arrival paths identified (what surfaces lead here?)
- [ ] Learned rules documented (what did the user internalize from those surfaces?)
- [ ] Conflict detection run (does the new surface violate any learned rules?)
- [ ] Breaking conflicts resolved (no exceptions)
- [ ] Confusing conflicts mitigated or documented

---

## Cross-Surface Decision Chain (Multi-Surface Builds)

> When building surface N, explicitly connect to decisions from surfaces 1 through N-1.

**Trigger:** Required when building 2+ surfaces in the same product. Single-surface builds skip this.

### The Chain

When building any surface after the first, document:

```yaml
cross_surface_chain:
  current_surface: "[Surface being built]"
  prior_surfaces: "[Surfaces already built]"

  decisions_inherited:
    - from_surface: "[Which prior surface]"
      decision: "[What was decided there]"
      how_it_constrains_here: "[How it applies to current surface]"

  decisions_diverging:
    - decision: "[What this surface does differently]"
      diverges_from: "[Which prior surface/decision]"
      why_justified: "[Explicit reason for divergence]"
      coherence_cost: "[What consistency is lost]"
```

### Rules

1. **Empty `decisions_inherited` on surface 3+ is a warning.** You're likely building in isolation.
2. **Divergence without acknowledged `coherence_cost` = P1.** You can diverge, but you must own the cost.
3. **More than 3 divergences = coherence audit required.** Too many exceptions fragment the product.

### Warning Signs

| Signal | Interpretation |
|--------|----------------|
| No inherited decisions | Building in isolation |
| Many small divergences | Optimizing locally, fragmenting globally |
| Can't articulate coherence cost | Divergence is unexamined |
| Every surface is "special case" | No product voice exists |

### Integration

Cross-surface chain feeds coherence checkpoints. At Gate 4, verify that declared divergences match actual divergences — silent drift is worse than acknowledged divergence.

---

## Feedback Interpretation Protocol

> Understand intent, not just instruction. Feedback is signal, not just task.

**Trigger:** When user feedback requests changes to existing work.

### The Protocol

Before implementing user feedback, interpret:

```yaml
feedback_interpretation:
  literal_request: "[What the user explicitly asked for]"
  possible_underlying_issues:
    - "[What this feedback might actually indicate]"
    - "[Alternative interpretation]"
  my_understanding_gap: "[What did I misunderstand that led to this feedback?]"
  ripple_effects: "[What else might be affected by this same misunderstanding?]"
  implementation_scope:
    literal_only: "[Just make the requested change]"
    diagnostic: "[Address the underlying issue, which may be broader]"
  chosen_scope: "[literal/diagnostic]"
  if_diagnostic: "[What else changes beyond the literal request?]"
```

### Rules

1. **"Why" before "what."** Understand why feedback was given before implementing it.
2. **Diagnostic over literal.** If the feedback reveals a broader misunderstanding, address the root cause.
3. **Ripple effects are mandatory.** Every feedback interpretation must trace what else is affected.

### Warning Signs

| Signal | Interpretation |
|--------|----------------|
| Same type of feedback recurring | Systematic misunderstanding, not local issue |
| Feedback contradicts earlier approval | Mental model drift — revisit foundations |
| Can't articulate underlying issue | Treating symptom, not disease |

### Purpose

Feedback is information about misalignment. Treating it as a to-do item misses the signal.

---

## Change Impact Trace

> Trace dependencies before changing, not after breaking.

**Trigger:** Before making any change to existing work.

### The Trace

Before making any change, assess:

```yaml
change_impact:
  change: "[What is being changed]"
  reason: "[Why — feedback, realization, error, improvement]"

  direct_effects:
    - "[Immediate consequence of the change]"

  dependency_check:
    terminology: "[Does this change any user-facing terms? Check vocabulary.yaml]"
    emotional_register: "[Does this affect the screen's emotional tone? Check product voice]"
    visual_patterns: "[Does this change any shared visual patterns?]"
    navigation_role: "[Does this affect IA position or navigation expectations?]"
    cross_surface: "[What other surfaces depend on or reference what I'm changing?]"

  coherence_risk: "[low/medium/high — how likely is this change to fragment coherence?]"

  verification_plan: "[What will I check after making this change?]"
```

### Rules

1. **Trace before change.** Don't apply changes without knowing what else they affect.
2. **High coherence risk requires audit.** If `coherence_risk: high`, run coherence check after change.
3. **Cross-surface changes need extra scrutiny.** Changes affecting multiple surfaces require explicit verification.

### Integration

Change Impact Trace is the pre-change counterpart to `fix_side_effects` in LOOP.md. Impact trace predicts; side effects check verifies.

---

## Contradiction Surfacing Protocol

> Don't silently re-decide. Surface conflicts, then resolve.

**Trigger:** When new input contradicts earlier decisions, the spec, or established patterns.

### Detecting Contradictions

Contradictions arise when:
- User feedback conflicts with earlier user feedback
- New requirements conflict with existing spec
- Implementation choice conflicts with established patterns
- Current request conflicts with interpretation anchors

### The Protocol

When contradiction is detected:

```yaml
contradiction_surface:
  new_input: "[What was just requested or revealed]"
  contradicts: "[What earlier decision, spec statement, or pattern]"

  nature_of_conflict:
    type: "[direct_conflict/tension/ambiguity]"
    severity: "[minor/significant/fundamental]"

  resolution_options:
    - option: "[New input wins]"
      implication: "[What changes, what's lost]"
    - option: "[Earlier decision holds]"
      implication: "[What's preserved, what's sacrificed]"
    - option: "[Synthesis]"
      implication: "[How both could be partially satisfied]"

  resolution_chosen: "[Which option]"
  resolution_rationale: "[Why this resolution]"
  documentation: "[Where this resolution is recorded]"
```

### Rules

1. **Surface contradictions explicitly.** Don't silently re-decide.
2. **Resolve before implementing.** Don't implement contradictory things hoping they'll coexist.
3. **Document resolution.** Record in `_decisions/REGISTRY.md` — resolved contradictions become precedents.

### Purpose

Contradictions are information. Hiding them produces incoherent products. Resolving them produces clarity.

---

## Pivot Assessment

> Make the restart-vs-patch decision explicitly, not through drift.

**Trigger:** Mid-build realization that the current approach may be fundamentally wrong.

### The Assessment

When you suspect the approach is wrong:

```yaml
pivot_assessment:
  realization: "[What you now understand that you didn't before]"
  investment: "[How much work is already done?]"

  honest_evaluation:
    foundation_sound: "[Is the core approach still valid, or fundamentally flawed?]"
    patch_scope: "[How much patching would be needed to make this work?]"
    patch_quality: "[Would patched version be good, or just functional?]"
    restart_cost: "[What would starting over actually cost?]"
    sunk_cost_bias: "[Am I rationalizing continuation to protect my investment?]"

  decision:
    if_patch: "[What specific changes, and what quality ceiling does this create?]"
    if_restart: "[What would the new approach be, and why is it better?]"
    if_continue_unchanged: "[Why is the current approach actually right despite doubts?]"

  chosen_path: "[patch/restart/continue]"
  path_rationale: "[Honest reason — not rationalization]"
```

### Rules

1. **`sunk_cost_bias` is mandatory.** If you can't articulate how it might be affecting you, you haven't evaluated honestly.
2. **`patch_quality` matters.** A patched-to-functional product may be worse than a restarted-to-excellent one.
3. **Continuation requires justification.** "Keep going" isn't default; it's a choice that needs defense.

### Thresholds

| Condition | Recommended Action |
|-----------|-------------------|
| `foundation_sound: no` | Restart — patches won't fix broken foundation |
| `patch_scope: extensive` AND `patch_quality: just functional` | Restart — effort for mediocrity |
| `sunk_cost_bias: high` AND `restart_cost: moderate` | Force external perspective before deciding |

### Purpose

Sunk cost is real. The assessment doesn't eliminate it; it makes it visible so decisions can be conscious.

---

## Pre-Build Honesty Check

> The final gate before building: Was Pre-Build genuine or performative?

**Trigger:** Run after all Pre-Build steps, before building begins.

### The Honesty Check

Answer honestly:

```yaml
pre_build_honesty:
  genuine_peer_research: "[Did I actually evaluate peer quality, or just list features?]"
  genuine_classification: "[Did Expected features survive real challenge, or did I rubber-stamp?]"
  genuine_interrogation: "[Did I find flaws in the spec, or did I confirm what it says?]"
  genuine_failure_modeling: "[Did I imagine real failures, or did I list generic risks?]"
  uncomfortable_insight: "[What did Pre-Build reveal that I didn't want to be true?]"
  changed_my_mind: "[What did I believe before Pre-Build that I no longer believe?]"
```

### Stop Conditions

| Condition | Action |
|-----------|--------|
| `uncomfortable_insight` is empty | Re-run Pre-Build with more skepticism |
| `changed_my_mind` is empty | Pre-Build likely failed — review for confirmation bias |
| All answers are brief/generic | Pre-Build was performative — redo it |

### Purpose

If Pre-Build confirms everything you already believed, it didn't work. Pre-Build should *change* your understanding, not validate it.

### The Discomfort Test

> Good Pre-Build should make you slightly uncomfortable.

If you feel only confidence after Pre-Build, you likely:
- Confirmed existing beliefs instead of challenging them
- Found what you expected instead of what's true
- Did the motions without the thinking

Discomfort is signal. Pure confidence is warning.

---

## Pre-Build Checklist (Summary)

**If New Capability — EIL First:**
- [ ] EIL triggered (new data, state, or affordances)
- [ ] Immediate expectations documented
- [ ] Secondary expectations documented
- [ ] Trust expectations documented
- [ ] Non-goals explicitly stated
- [ ] Cascade decision made (build/defer/prevent)
- [ ] EIL artifact created in `_decisions/eil/`

**All Surfaces — Pre-Build:**
- [ ] Peer context specified
- [ ] Candidate features explored
- [ ] Features classified (including Prevented)
- [ ] Absence detection completed
- [ ] Expected actions enumerated
- [ ] Surface role requirements met
- [ ] Inner Monologue Test passes
- [ ] Visual-implies-interactive verified
- [ ] Restraint Gate applied
- [ ] Expectation debt tracked
- [ ] Rejected features documented
- [ ] Prevented assumptions addressed

**If Moat-Conscious Preset Active:**
- [ ] Stickiness assessment completed
- [ ] Moat contribution classified
- [ ] Moat-undermining features justified (if any)

---

## Spec Interrogation Protocol

> Treat the spec as a hypothesis, not truth.

**Trigger:** Run as Step 0 before Pre-Build Exploration Flow. Mandatory for all builds.

### The Protocol

```
0. EXTRACT EXPLICIT CLAIMS → What does the spec state as fact?
1. INFER IMPLICIT ASSUMPTIONS → What does the spec assume without saying?
2. IDENTIFY MISSING PERSPECTIVES → Whose viewpoint is absent?
3. FLAG UNSUPPORTED CERTAINTY → Where is the spec confident without evidence?
4. EXPAND THE PROBLEM SPACE → What adjacent problems exist that the spec ignores?
```

### Extraction Template

| Category | Question |
|----------|----------|
| Explicit Claims | What does the spec assert will be true? |
| Implicit Assumptions | What must be true for the spec to work, but is never stated? |
| Missing Perspectives | Which user type, edge case, or context is not represented? |
| Unsupported Certainty | Where does the spec say "users want X" without evidence? |
| Problem Space Gaps | What related problems exist that the spec doesn't address? |

### Enforcement

> If the system agrees with everything in the spec, the interrogation has failed.

The interrogation must produce at least one challenge, one missing perspective, and one problem space expansion. If it produces none, re-run with more skepticism.

### Spec Assumption Extraction

> Specs have gaps. What fills those gaps becomes the real spec.

**Purpose:** Surface the assumptions you're making to fill spec gaps before they become invisible requirements.

### The Extraction

For every spec gap you encounter:

```yaml
spec_assumption:
  gap: "[What the spec doesn't say]"
  assumption_made: "[What I'm assuming to fill the gap]"
  confidence: "[high/medium/low]"
  alternative_assumptions: "[What else could be assumed here?]"
  impact_if_wrong: "[What breaks if this assumption is wrong?]"
  verification_needed: "[yes/no — should this be validated before building?]"
```

### Common Gap Categories

| Category | Example Gap | Example Assumption |
|----------|-------------|-------------------|
| **User behavior** | Spec says "users can X" but not how often | "Users do X rarely" |
| **Error handling** | Spec describes happy path only | "Errors are shown inline" |
| **Edge cases** | Spec shows typical case | "Empty state shows message" |
| **Scope boundaries** | Spec doesn't say what's NOT included | "This doesn't include Y" |
| **Data volume** | Spec shows 3 items | "List handles 100+ items" |

### Rules

1. **Extract before building.** Assumptions made during building are harder to surface.
2. **Low confidence = flag.** If you're guessing, say so.
3. **Alternatives matter.** Knowing what else could be assumed reveals your choice.

### Integration

High-impact, low-confidence assumptions should:
1. Be validated before building, OR
2. Be documented prominently for review, OR
3. Be designed for easy change if wrong

---

## Reasoning Trace Protocol

> Make interpretation explicit so errors can be traced to their source.

**Trigger:** Run for every significant decision during Pre-Build and building.

### Trace Structure

For each significant decision, document:

```yaml
reasoning_trace:
  spec_statement: "[What the spec says, verbatim or paraphrased]"
  interpretation: "[What I believe it means]"
  assumptions:
    - "[Assumption 1 — what I'm assuming that isn't stated]"
    - "[Assumption 2]"
  decision: "[What I'm choosing to do based on this interpretation]"
  confidence: "[high/medium/low]"
  confidence_reason: "[Why this confidence level]"
  verification: "[How to test if interpretation was correct]"
```

### Confidence Levels

| Level | Definition | Action |
|-------|------------|--------|
| **High** | Would bet on this; evidence is strong | Proceed |
| **Medium** | Reasonable interpretation; alternatives exist | Flag for review |
| **Low** | Educated guess; needs validation | Pause and ask or document prominently |

### When to Trace

| Decision Type | Trace Required? |
|---------------|-----------------|
| Spec interpretation | Yes |
| Feature scope decision | Yes |
| Layout/hierarchy choice | Yes (for high-leverage surfaces) |
| Component selection | No (unless non-obvious) |
| Token selection | No |

### Using the Trace

1. **During building:** Create traces for significant decisions
2. **During critique:** Review traces alongside output
3. **When something goes wrong:** Trace reveals where interpretation diverged
4. **For learning:** Low-confidence decisions that succeeded become high-confidence patterns

### Integration with Confidence Flagging

Medium/low confidence decisions from traces feed the "Low-Confidence Decisions" section in critique output (see `_critique/PROMPT.md` — Confidence Flagging).

---

## Screen Intent Declaration

> Every screen must declare what it exists to do, before it's built.

### Declaration Template

For each screen, declare:

| Declaration | Description |
|-------------|-------------|
| **Role Intent** | What role does this screen play? (Orientation / Action / Information / Review) |
| **Primary UI Object** | What is the single most important element on this screen? |
| **Dominance Requirement** | What must be visually dominant? (The primary UI object, always.) |
| **Vocabulary Gating** | What terms must this screen use, and which must it avoid? |

### Role Intent Types

| Role | The screen exists to... |
|------|-------------------------|
| Orientation | Help user understand where they are and what's possible |
| Action | Enable user to accomplish a specific task |
| Information | Help user understand or learn something |
| Review | Help user evaluate, compare, or decide |

### Verification

After building, verify:
- The Primary UI Object is the visually dominant element
- The Role Intent is served by the screen's structure
- Vocabulary complies with the gating declaration

**Non-compliance = P1** in critique (see Flow Architecture Compliance dimension in `_critique/PROMPT.md`).

### IA Position Declaration

> Every screen must declare where it sits in the product structure, not just what it does.

For each screen, declare its information architecture position:

```yaml
ia_position:
  parent: "[What surface/area this belongs to]"
  siblings: "[Peer surfaces at same structural level]"
  children: "[Surfaces accessible from here]"
  depth: "[Level in hierarchy: 1/2/3/etc.]"
  navigation_role: "[hub/spoke/detail/flow-step]"
```

### Navigation Roles

| Role | Definition | Examples |
|------|------------|----------|
| **Hub** | Central navigation point with multiple destinations | Dashboard, Home |
| **Spoke** | One of several peer destinations from a hub | Settings sections, entity lists |
| **Detail** | Deep view of a specific entity | Project detail, User profile |
| **Flow-step** | Part of a sequential flow | Onboarding steps, checkout steps |

### IA Rules

1. **Declare before building.** IA position is Pre-Build, not post-build verification.
2. **Changes require documentation.** If IA position changes mid-build, document in `_decisions/REGISTRY.md`.
3. **Orphan surfaces require decision.** A surface with no clear parent/siblings needs structural decision.

### Navigation Integration

IA position feeds navigation design. A surface's navigation options should reflect its IA position — a spoke links back to its hub, a detail links to siblings, a flow-step links forward.

---

## Emotional Intent Declaration

> Every screen communicates an emotional tone, whether intentionally or not. Declare it intentionally.

### Declaration

For each screen, declare the intended emotional register:

| Register | Communicates | Use When |
|----------|-------------|----------|
| **Confident** | "This is reliable and precise" | Data displays, dashboards, reports |
| **Welcoming** | "You belong here, this is easy" | Onboarding, first-run, empty states |
| **Urgent** | "This requires attention now" | Alerts, errors, time-sensitive actions |
| **Neutral** | "Here are the facts" | Settings, configuration, admin |
| **Celebratory** | "You accomplished something" | Completion states, milestones |

### Calibration Test

After building, ask:
- Does the visual weight match the declared register?
- Does the copy tone match the declared register?
- Would a user feel the intended emotion after 5 seconds on this screen?

Mismatch between declared and perceived emotion = P1.

**Product Voice:** Individual screen emotional registers should match the product voice declared in `config/manifest.yaml`. Departures require a declared `contextual_shift` in the manifest.

### Verification Protocol

After building, explicitly verify:

```yaml
emotional_verification:
  declared_register: "[What was declared]"
  actual_effect: "[What it actually feels like after 5 seconds]"
  gap: "[Describe gap, if any]"
  gap_intentional: "[yes/no — if yes, document why]"
```

**Test method:**
1. Open the built surface fresh (clear mental context)
2. Spend exactly 5 seconds
3. Name the emotion you actually feel
4. Compare to declared register

**If gap exists:**
- Unintentional gap = P1 (mismatch)
- Intentional gap = Document why declaration changed

**Integration:** Emotional verification feeds the "Visual Craft" dimension in critique (see `_critique/LOOP.md`).

---

## Outcome Declaration

> Every screen exists to change the user's state. Declare the intended state change.

### Declaration Template

For each screen, declare:

| Before | After |
|--------|-------|
| User does not know X | User knows X |
| User has not decided Y | User has decided Y |
| User has not done Z | User has done Z |

### The 30-Second Test

> If a user spent 30 seconds here, would they leave having accomplished what this screen exists for?

If the answer is "no," either the screen is trying to do too much, or the outcome is unclear.

### User State Modeling

> Model the specific state change, not just the abstract outcome.

**Purpose:** Make the before/after gap concrete and measurable.

### State Model Template

For each screen, model:

```yaml
user_state:
  before:
    knowledge: "[What user knows before]"
    capability: "[What user can do before]"
    feeling: "[What user feels before]"
    context: "[What brought them here]"
  after:
    knowledge: "[What user knows after]"
    capability: "[What user can do after]"
    feeling: "[What user feels after]"
    next_action: "[What user does next]"
  gap:
    knowledge_gap: "[Knowledge before → after]"
    capability_gap: "[Capability before → after]"
    feeling_gap: "[Feeling before → after]"
```

### The Gap Test

For each gap:
- **Is the gap real?** Does the user actually need this state change?
- **Is the gap sized right?** Is the change too small (pointless) or too large (overwhelming)?
- **Does the screen bridge the gap?** Does what we're building actually create this change?

### Rules

1. **Be specific.** "User understands" is too vague. "User knows their project has 3 pending tasks" is specific.
2. **Feelings count.** Emotional state change is real state change.
3. **Next action is test.** If you don't know what user does next, you don't know if the screen worked.

### Integration

User State Model feeds critique. The Intent Alignment dimension asks: "Did the built screen actually achieve the declared state change?"

### Verification

Critique checks whether the built screen actually achieves the declared outcome. The outcome declaration feeds the Intent Alignment dimension in `_critique/PROMPT.md`.

### Journey Context (Multi-Surface)

> For multi-surface builds, extend state modeling to cover transitions between surfaces.

> **Flow integration:** If `_flows/REGISTRY.yaml` is populated, reference the relevant FLOW-NNN for each journey context. Flows provide the emotional arc and handoff design that informs transition quality.

When building surface N in a multi-surface product, add:

```yaml
journey_context:
  arrives_from:
    - surface: "[Origin surface]"
      user_state_on_arrival: "[What they know/feel/expect when they land here]"
      context_carried: "[What mental state transfers from the previous screen]"

  exits_to:
    - surface: "[Destination surface]"
      user_state_on_exit: "[What they know/feel/expect when they leave]"
      transition_quality: "[jarring/smooth/progressive]"

  cumulative_load: "[What has user accumulated mentally across the journey so far?]"
```

### Transition Quality

| Quality | Definition | Design Implication |
|---------|------------|--------------------|
| **Smooth** | Context preserved, no re-orientation needed | Ideal for related screens |
| **Progressive** | Builds on previous context, adds depth | Ideal for drill-down flows |
| **Jarring** | Context lost, user must re-orient | Requires justification |

### Journey Rules

1. **`transition_quality: jarring` requires justification.** If the transition feels like a context switch, design must account for re-orientation.
2. **`cumulative_load` too high = journey restructure.** If user has accumulated too much mental state, consider breaking the journey.
3. **Single-surface builds skip this.** Journey context is for multi-surface coherence.

---

## Failure Scenario Modeling

> Before building, model how things could fail — from both user perspective and implementation perspective.

**Trigger:** Run during Pre-Build, after Feature Classification.

### Part A: User-Perspective Failures

Generate 3–5 realistic failure scenarios from the user's perspective:

| Failure Type | Question |
|-------------|----------|
| **Misinterpretation** | What could the user misunderstand about what this screen does or shows? |
| **Wrong Assumption** | What might the user assume is true that isn't? |
| **Cognitive Overload** | Where might the user feel overwhelmed and abandon the task? |
| **Trust Erosion** | What might make the user doubt the product's reliability or honesty? |
| **Dead End** | Where might the user get stuck with no clear path forward? |

### Part B: Implementation-Risk Failures

Generate 2–3 implementation risks:

| Risk Type | Question |
|-----------|----------|
| **Assumption Risk** | What assumption, if wrong, causes the most rework? |
| **Integration Risk** | What integration point is most fragile? |
| **Scope Risk** | What feature might expand beyond its apparent scope? |
| **Interpretation Risk** | Where might spec interpretation be wrong? |

### For Each Scenario

Ask: "If this happens, what's the recovery path?"

| Recovery Quality | Description |
|-----------------|-------------|
| **Self-Healing** | Product/process detects and guides back |
| **Assisted** | Clear recovery path if issue is noticed |
| **Manual** | Must figure out recovery independently |
| **Stranded** | No recovery path exists |

**Target:** No user scenario should leave them stranded. No implementation risk should go unexamined.

### Risk Mitigation Tracking

For each identified risk, document mitigation:

```yaml
risk:
  type: "[user/implementation]"
  scenario: "[What could go wrong]"
  likelihood: "[high/medium/low]"
  impact: "[high/medium/low]"
  mitigation: "[How we're addressing it]"
  verification: "[How to check it's mitigated]"
```

Check at Gate 3 whether identified risks manifested.
