# Quality Tests

> Tests to verify surfaces are ready for users.

---

## Overview

| Test | Question | Scope |
|------|----------|-------|
| **Inner Monologue** | What would user think landing here? | Single surface |
| **Dead Surface** | Can user make progress? | Single surface |
| **Peer Test** | Would this fit in Linear/Notion? | Visual quality |
| **Agency Test** | Would a premium agency ship this? | Artifact quality |
| **First Encounter** | Can new user understand? | Vocabulary |
| **Screenshot Test** | Would this go in a pitch deck? | Professional quality |

---

## Inner Monologue Test

Simulate a first-time user landing on the surface.

### Questions

| Question | Must Have Confident Answer |
|----------|---------------------------|
| "What is this page?" | Yes — or orientation fails |
| "What can I do here?" | Yes — or purpose unclear |
| "What would I click first?" | Yes — or affordances unclear |
| "What would confuse me?" | Nothing — or fix those things |
| "What would build trust?" | Nothing major missing |

### How to Run

1. Clear your mental state
2. Look at the surface as if for the first time
3. Ask each question aloud
4. If any answer is uncertain, surface fails

### Failure Modes

| Question | Failure Indicators |
|----------|-------------------|
| "What is this page?" | No title, unclear scope, ambiguous content |
| "What can I do?" | No obvious actions, unclear CTAs |
| "What would I click first?" | Too many options, no hierarchy |
| "What would confuse me?" | Unexplained terms, unclear states |
| "What would build trust?" | Missing context, unclear sources |

### Related Invariant

**UE-005:** Inner Monologue Test passes

### Alignment Checks (if Screen Intent Declaration exists)

When a Screen Intent Declaration has been filed (see `_expectations/PRE-BUILD.md`), add these checks to every Inner Monologue pass:

| Check | Question |
|-------|----------|
| Primary UI Object Match | "Is the thing I'm most drawn to the declared Primary UI Object?" |
| Role Intent Match | "Does this screen feel like it's doing what was declared?" (Orientation / Action / Information / Review) |
| Dominance Correct | "Is the most important thing also the most prominent thing?" |
| Vocabulary Compliant | "Are the terms I see consistent with what was declared?" |

If any answer is "no," flag as P1 in critique.

### Multi-Persona Simulation

Run the Inner Monologue Test from at least two of these perspective archetypes:

| Persona | Mindset | Looks For |
|---------|---------|-----------|
| **Anxious First-Timer** | Uncertain, cautious, easily overwhelmed | Clarity, safety, low commitment |
| **Power User in a Hurry** | Confident, impatient, shortcut-oriented | Speed, keyboard access, density |
| **Skeptical Evaluator** | Critical, comparing alternatives, testing claims | Credibility, completeness, honesty |
| **Returning After Absence** | Rusty, needs re-orientation, may have forgotten context | Orientation, state preservation, gentle re-onboarding |

For high-leverage surfaces (onboarding, primary workflows, first impressions), run all four.

---

## Dead Surface Test

A surface that looks complete but blocks user progress.

### Questions

| Check | Question |
|-------|----------|
| Forward motion | Can the user move the system forward from here? |
| Explicit blocking | If not, is the reason explicit on the page? |
| Meaningful actions | Are there at least 2 meaningful actions available? |
| Empowerment test | "If I clicked everything clickable, would I feel blocked or empowered?" |

### Scoring

| Result | Action |
|--------|--------|
| "Empowered" ≥ 3 times | Pass |
| "Blocked" ≥ 2 times | Fail |
| "Confused" any time | Fail |

### Exception

If surface is intentionally read-only (Display type), note explicitly and skip action checks.

### Related Invariants

- **AF-001:** Affordances function
- **EX-003:** Primary actions have affordances

---

## Peer Test

Would this surface exist in a premium product without visual shock?

### Reference Products

| Category | Examples |
|----------|----------|
| B2B SaaS | Linear, Notion, Figma |
| Consumer premium | Stripe Dashboard, Spotify |
| Design tools | Framer, Webflow |

### Questions

| Dimension | Question |
|-----------|----------|
| Hierarchy | Is visual priority as clear as peers? |
| Spacing | Is rhythm as consistent as peers? |
| Typography | Is type system as coherent as peers? |
| Density | Is information density appropriate? |
| Consistency | Are patterns as uniform as peers? |

### How to Run

1. Open reference product to similar surface
2. Place your surface side-by-side
3. Ask: "Would mine feel at home here?"
4. If "no" — identify the gap

### Pass Criteria

Surface could exist in Linear, Notion, or Stripe without:
- Visual jarring
- Apology
- Explanation

### Related Invariants

- **VQ-001 to VQ-008:** Visual quality standards

---

## Agency Test

Would a premium agency ship this artifact to a demanding client?

### Context

This test applies to **Synthesis Artifacts** — the deliverables the system produces (not the UI itself).

### Questions

| Dimension | Question |
|-----------|----------|
| Completeness | Are all sections filled or explicitly marked incomplete? |
| Honesty | Does it show actual state, not aspirational state? |
| Professional | Would it require verbal explanation? |
| Trust | Would client trust this without caveats? |
| Quality | Would senior designer apologize for anything? |

### Pass Criteria

Artifact could be sent to demanding client with:
- No verbal explanation needed
- No apology
- No follow-up clarification required

### Related Invariants

- **SA-001 to SA-006:** Synthesis Artifact standards

---

## First Encounter Test

Can an intelligent, motivated new user understand this term?

### Questions

For any term or symbol on the surface:

1. Can user understand it immediately?
2. If not, can they find explanation without leaving the surface?

If neither → **fail**

### Vocabulary Levels

| Level | Description | Explanation Required? |
|-------|-------------|----------------------|
| Self-evident | Meaning obvious from word | No |
| Contextual | Meaning clear from surrounding context | No |
| Learnable | Meaning clear after one explanation | Yes — tooltip |
| Technical | Domain expertise required | Yes — inline or linked |
| Opaque | Meaning unclear even with explanation | ❌ Fail |

### How to Run

1. List all terms, labels, and symbols on surface
2. Classify each by vocabulary level
3. Verify explanation path for Learnable and Technical
4. Flag any Opaque terms

### Related Invariants

- **VO-001 to VO-007:** Vocabulary comprehension

---

## Screenshot Test

Would you include this in a pitch deck?

### Questions

| Check | Question |
|-------|----------|
| Pride | Would you show this to investors? |
| Confidence | Would you include this in a case study? |
| Quality | Would you tweet this proudly? |
| Craft | Would a designer's portfolio include this? |

### How to Run

1. Take a screenshot
2. Imagine showing it in a professional context
3. If hesitation — identify why

### Pass Criteria

Zero hesitation about including in professional presentation.

---

## Professional Embarrassment Gate

Would a senior professional feel the need to apologize for this?

### The Test

If you would say any of these:
- "This part is still rough"
- "We'll improve this later"
- "Ignore this section"
- "That's a known issue"

**→ The surface fails.**

### Application

Run before shipping any surface or artifact.

---

## Squint Test

Is visual hierarchy clear when blurred?

### How to Run

1. Take a screenshot
2. Apply gaussian blur (or squint)
3. Can you still identify:
   - Primary content area
   - Main heading
   - Primary action
   - Navigation location

### Pass Criteria

All four elements identifiable when squinted.

### Related Invariants

- **VQ-005:** One primary focal point per surface

---

## Demo Test

Would you hide this during a demo?

### Questions

| Check | Question |
|-------|----------|
| Explanation density | Would you explain/apologize for any element? |
| Polish | Would you skip over any section? |
| Confidence | Would you avoid clicking anything? |

### Pass Criteria

Nothing would be hidden, skipped, or explained during a demo.

---

## Progress Sentence Test

Can progress be expressed as a plain sentence?

### Format

> "Of [total], [X] are [state A], [Y] are [state B], and [Z] are [state C]."

### Examples

| Clear | Unclear |
|-------|---------|
| "Of 37 decisions, 8 are approved, 12 are pending, and 17 are draft." | "42% complete" (42% of what?) |
| "5 of 8 required fields filled." | "Progress: Good" |

### Pass Criteria

Any progress indicator can be expressed this way. If you can't say it plainly, the representation is unclear.

### Related Invariants

- **PS-002:** Progress representations pass Sentence Test

---

## Visual-Implies-Interactive Test

If it looks interactive, is it?

### Check Each Element

| Visual Signal | Implied Interaction | Verify |
|---------------|---------------------|--------|
| Card with content | Clickable | Must navigate or expand |
| Metric/number | Drillable | Must link to detail |
| Badge/tag | Explainable | Must have tooltip or click action |
| Progress bar | Explorable | Must show composition |
| Row with chevron | Navigable | Must navigate |
| Button | Actionable | Must perform action |
| Link-styled text | Navigable | Must navigate |

### Pass Criteria

Every element that looks interactive IS interactive.

### Related Invariants

- **UE-006:** Visual interactivity implies actual interactivity
- **AF-003:** Chevrons navigate

---

## Test Summary Checklist

Before shipping any surface:

- [ ] Inner Monologue Test passes
- [ ] Dead Surface Test passes
- [ ] Peer Test passes
- [ ] Screenshot Test passes
- [ ] Professional Embarrassment Gate passes
- [ ] Demo Test passes
- [ ] Squint Test passes
- [ ] Visual-Implies-Interactive verified
- [ ] First Encounter Test passes for all terms

Before shipping any artifact:

- [ ] Agency Test passes
- [ ] No Verbal Explanation required
- [ ] Progress Sentence Test passes

---

## Weight-Importance Alignment Test

> The visually heaviest element should correspond to the most important information.

### The Test

For any screen, ask:

1. "What is the visually heaviest element?" (Largest, boldest, most prominent)
2. "What is the most important information on this screen?"
3. "Are they the same thing?"

If the answers to 1 and 2 are different, the visual hierarchy is misaligned.

### Common Misalignments

| Problem | Symptom |
|---------|---------|
| Decorative elements outweigh content | Illustration is more prominent than the data |
| Navigation dominates workspace | Sidebar draws more attention than the main area |
| Secondary actions look primary | "Cancel" is as prominent as "Save" |
| Status indicators overpower content | A badge is more visually heavy than what it describes |

Misalignment = P1 in Visual Craft dimension.

---

## Purposeful Space Test

> Every element of whitespace serves a function. No accidental or default spacing.

### The Test

For each whitespace region on a screen, identify its purpose:

| Purpose | Function |
|---------|----------|
| **Separation** | Distinguishes unrelated groups |
| **Grouping** | Associates related elements (proximity) |
| **Breathing Room** | Prevents cognitive crowding |
| **Emphasis** | Draws attention through isolation |

If a whitespace region has no identifiable purpose, it's accidental. Either give it a purpose or remove it.

### Diagnostic Questions

- "If I removed this space, would the meaning change?" → If no, the space is decorative.
- "If I increased this space, would the grouping become clearer?" → If yes, the space is insufficient.
- "Is this space here because of a default margin, or because I decided it should be here?" → Defaults are not decisions.

Accidental spacing in primary flows = P2. Spacing that causes grouping confusion = P1.

---

## User State Awareness Test

> Users arrive in different states. Screens must acknowledge the state they serve.

### Universal User States

| State | User Is... | Screen Must... |
|-------|-----------|---------------|
| **Exploring** | Browsing, no specific goal | Show possibilities, invite engagement |
| **Deciding** | Comparing, evaluating options | Provide comparison tools, reduce noise |
| **Executing** | Performing a specific task | Minimize distractions, show progress |
| **Reviewing** | Checking work, verifying results | Show completeness, highlight concerns |
| **Recovering** | Something went wrong | Explain what happened, show recovery path |
| **Returning** | Coming back after time away | Re-orient, show what changed |

### The Test

1. Identify which states this screen serves (usually 1–2 primary, 1–2 secondary)
2. For each primary state, simulate the user's experience using the Inner Monologue Test
3. Verify the screen doesn't actively harm users in non-primary states

A screen that serves "Executing" users should not confuse "Recovering" users. A screen that serves "Exploring" users should not overwhelm "Returning" users.

State-unaware screen in primary flow = P1.

---

## Diminishing Novelty Test

> Design decisions must hold up across the user maturity curve, not just the first visit.

### Two Questions

1. **"Does anything on this screen become friction with repeated use?"**
   - Welcome messages that can't be dismissed
   - Explanatory text that clutters after learning
   - Onboarding prompts that persist
   - Confirmation dialogs for routine actions

2. **"Does this screen offer depth that rewards mastery?"**
   - Keyboard shortcuts for frequent actions
   - Density options for experienced users
   - Batch operations for power workflows
   - Customization that reflects learned preferences

### Maturity Curve

| Visit | User Needs |
|-------|-----------|
| First | Orientation, explanation, safety |
| 5th | Efficiency, fewer interruptions |
| 50th | Speed, density, shortcuts |
| 500th | Customization, automation, trust |

Screens should serve at least the first two stages. High-leverage surfaces should serve all four (via progressive disclosure — see `_interaction/PROGRESSION.md`).

First-visit friction that persists to 50th visit = P1.

---

## Delight Delta Test

> Where can we overdeliver by 5% with zero cognitive cost?

### The Test

After building a screen, ask:

> "Where is there a moment where a tiny additional investment would create disproportionate user delight?"

### Delight Criteria

Delight must be:

| Criterion | Requirement |
|-----------|-------------|
| **Zero cognitive cost** | User doesn't have to think harder |
| **Reinforces trust** | Makes the product feel more competent and caring |
| **Not decorative** | Serves a functional or emotional purpose |
| **Discoverable naturally** | User encounters it through normal use, not a tour |

### Examples of Delight Patterns (Generic)

- Remembering user's last-used settings when they return
- Showing a meaningful empty state instead of a blank page
- Pre-filling fields with intelligent defaults
- Confirming success with specific details ("3 items exported") not generic ("Done!")

### Anti-Patterns

- Animation that slows task completion
- Easter eggs that distract from work
- Playful copy that undermines credibility
- Gamification that patronizes the user

Missed delight opportunity = not a defect (P2 at most). Delight that adds cognitive cost = P1.

---

## Real-Data Stress Test

> Does the design hold up with realistic data, not just happy-path mockups?

### The Test

Evaluate every surface with these data volumes:

| Volume | Test |
|--------|------|
| **0 items** | Empty state: Is it helpful, not just blank? |
| **1 item** | Single item: Does the layout still make sense? |
| **5 items** | Small set: Is the structure clear? |
| **100+ items** | Full load: Does hierarchy, density, and readability hold? |

### Edge Cases

Also test with:

| Edge | Question |
|------|----------|
| **Very long names** | Does text truncate gracefully? Is the full value accessible? |
| **Missing fields** | How do empty/null values display? |
| **Special characters** | Do unusual characters break layout? |
| **Mixed states** | With items in multiple states, is the view still scannable? |
| **Rapid state changes** | If data updates frequently, does the UI remain stable? |

Design that only works with demo data = P1.

---

## Attention & Cognitive Cost Test

> Every surface must justify the mental energy it demands.

### Three Questions

1. **"How many distinct things is the user asked to process here?"**
   Count distinct elements competing for attention. If > 7 (±2), the surface likely needs simplification or progressive disclosure.

2. **"Does this notification/interruption earn its cost?"**
   Every interruption (modal, toast, alert, badge) withdraws from the user's attention budget. Evaluate whether the information justifies the withdrawal.

3. **"Is the product competing with itself for the user's attention?"**
   Multiple sections, widgets, or calls-to-action that all demand attention simultaneously indicate a prioritization failure, not a richness benefit.

### Energy Lens

Some interactions should replenish mental energy, not just avoid draining it:

| Interaction Type | Energy Effect |
|-----------------|--------------|
| Clear progress confirmation | Restores confidence |
| Successful task completion | Provides satisfaction |
| Intelligent defaults that save work | Reduces burden |
| Consistent patterns across screens | Builds automaticity |
| Explanations that resolve confusion | Eliminates anxiety |

Screen that drains without restoring in primary flows = P1. See also the critique dimension in `_critique/PROMPT.md`.

---

## Concept Budget Test

> How many distinct ideas does this product require the user to learn?

### The Test

1. **Inventory** every distinct concept the product requires the user to understand (entities, states, actions, relationships, terminology)
2. **Attempt concept collapse** — identify where two seemingly different concepts are actually the same mental model expressed differently
3. **Count** the remaining distinct concepts

### The Question

> "Could a reasonable person hold all these concepts in their head without reference material?"

### Concept Budget Guidelines

| Concept Count | Assessment |
|--------------|------------|
| ≤ 7 | Manageable — most users can hold these |
| 8–12 | Strained — needs excellent progressive disclosure |
| 13–20 | Overloaded — needs concept collapse or restructuring |
| > 20 | Redesign — the product is asking too much |

This is distinct from visual density (how much is on screen) and cognitive cost (how much processing is required per screen). Concept budget measures the total learning investment the product demands.

Concept count > 12 without progressive disclosure strategy = P1.

---

## Second-Order Consequences Test

> If the design succeeds, what new behaviors emerge?

### The Test

Before finalizing design, ask:

1. **"If users adopt this exactly as intended, what new behaviors emerge?"**
   Success creates habits. What habits does this design create? Are they healthy?

2. **"Does success at the feature level create failure at the product level?"**
   A feature that's individually excellent but collectively harmful indicates a system design issue.

### Example Patterns

| Feature Success | Potential Second-Order Issue |
|----------------|------------------------------|
| Users rely on notifications | Users stop proactively checking, miss non-notified changes |
| Users use filters extensively | Users create overly narrow views, miss important items |
| Automation reduces manual work | Users lose situational awareness of what's happening |
| Dashboard provides quick overview | Users substitute dashboard scanning for deep analysis |

### Evaluation

For each identified second-order consequence:

| Severity | Action |
|----------|--------|
| Benign or positive | Document and proceed |
| Manageable with design | Add mitigation to design (e.g., periodic full-view prompt) |
| Fundamental conflict | Redesign the feature approach |

Unexamined second-order consequences in primary workflows = P2. Identified conflicts left unaddressed = P1.
