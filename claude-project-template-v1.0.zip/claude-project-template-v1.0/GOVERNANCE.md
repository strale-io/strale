# Governance

> Rules for changing the Starter Kit. Enforced by AI agents across all chats.

---

## Core Principle

**This is a generic documentation OS, not a project-specific solution.**

Every change must apply to any product built with this system. Case-specific solutions are forbidden.

---

## The Three Absolutes

### 1. Closed World Assumption

If something is not defined, it is forbidden.

- No inventing components not in `_ui/components.yaml`
- No inventing tokens not in `_ui/tokens.yaml`
- No inventing patterns not in `_model/patterns/`
- No inventing archetypes not in `_quality/archetypes/`

**Expansion requires:** Decision entry in `_decisions/REGISTRY.md`

### 2. Single Source of Truth

Every concept has exactly one home.

| Concept | Home | Never Duplicate In |
|---------|------|-------------------|
| Laws | `_rules/laws.yaml` | Any other file |
| Invariants | `_invariants/REGISTRY.md` | Any other file |
| Configuration | `_presets/*.yaml` | Any other file |
| Decisions | `_decisions/REGISTRY.md` | Code comments |

**Rule:** Reference by ID, never restate.

### 3. Generic Over Specific

All guidance must apply universally.

| ❌ Forbidden | ✅ Allowed |
|--------------|-----------|
| "Add field for client NPS" | "Add guidance for tracking custom metrics" |
| "Our brand uses blue" | "Brand colors defined in tokens.yaml" |
| "For healthcare products..." | "When compliance matters..." (generic) |

---

## Change Classification

### Requires No Approval

- Fixing typos
- Clarifying existing guidance (no semantic change)
- Adding examples that illustrate existing rules

### Requires Decision Entry

| Change Type | Decision Entry Required |
|-------------|------------------------|
| New law | Yes — `_rules/laws.yaml` + `_decisions/REGISTRY.md` |
| New invariant | Yes — `_invariants/REGISTRY.md` + `_decisions/REGISTRY.md` |
| New primitive | Yes |
| New archetype | Yes |
| New component family | Yes |
| New token category | Yes |
| New preset | Yes |
| Structural folder change | Yes |

### Forbidden Changes

| Change | Why Forbidden |
|--------|---------------|
| Case-specific solutions | Violates generic principle |
| Duplicate definitions | Violates single source of truth |
| Parallel patterns | Violates "single path to power" |
| Loosening constraints without justification | System decay |
| Removing laws without migration | Breaking change |

---

## Review Checklist

Before approving any change, verify:

```yaml
governance_review:
  generic:
    - [ ] Does this apply to ANY product?
    - [ ] Is there no project-specific content?
    - [ ] Are placeholders used for project values?
    
  single_source:
    - [ ] Is this concept defined in only one place?
    - [ ] Are cross-references used (not restatements)?
    - [ ] Does this reference laws by ID?
    
  closed_world:
    - [ ] Does this compose from existing elements?
    - [ ] If expanding, is there a decision entry?
    - [ ] Is "silence = prohibition" preserved?
    
  strengthens_system:
    - [ ] Does this clarify, not complicate?
    - [ ] Does this consolidate, not fragment?
    - [ ] Does this tighten, not loosen?
```

---

## Red Flags

Reject changes containing these patterns:

| Red Flag | Example |
|----------|---------|
| "For this specific project..." | Case-specific |
| "Let's add a shortcut that..." | Likely violates negative capability |
| "Duplicate here for convenience..." | Violates single source |
| "Users might want..." (no evidence) | Speculative (LAW-012) |
| "Just hardcode..." | Should be in tokens/presets |
| Removing constraints without rationale | System decay |
| Adding folders without registry | Structural drift |

---

## Response Protocol

When reviewing proposed changes, respond with one of:

| Response | Meaning |
|----------|---------|
| ✅ **APPROVED** | Aligns with all governance rules |
| ⚠️ **NEEDS REVISION** | Good intent, implementation needs adjustment |
| ❌ **REJECTED** | Violates core principles (with explanation) |
| 🤔 **CLARIFICATION NEEDED** | Cannot assess without more context |

---

## Amendment Rule

**Tighten First.**

Before proposing any change that adds flexibility:

1. First attempt to solve by tightening constraints
2. Document why tightening was insufficient
3. Only then propose loosening

Changes that add flexibility without demonstrating tightening was tried first are invalid.

---

## Deprecation Protocol

### Lifecycle

Every system element follows this lifecycle:

```
Active → Deprecated → Removed
```

| State | Meaning | New work? | Existing usage? |
|-------|---------|-----------|-----------------|
| Active | Current, recommended | Yes | Yes |
| Deprecated | Discouraged, replacement exists | Forbidden | Allowed (migrate when touched) |
| Removed | Deleted from system | Forbidden | Forbidden |

### How to Deprecate

1. Add `deprecated: true` and `deprecated_date` to the element's definition
2. Add `replacement` pointing to the successor (or `none` if capability is removed)
3. Add `removal_target` with the version when removal is planned
4. Log in `_decisions/REGISTRY.md` with rationale

### How to Remove

1. Verify no active usage remains
2. Log removal in `_decisions/REGISTRY.md`
3. Remove the element
4. Update `CHANGELOG.md`

### Rules

- Deprecation requires a decision entry
- Removal requires a decision entry AND one version cycle with no new usage
- Deprecated elements must state their replacement
- **"Migrate when touched"** — any file that references a deprecated element must be updated when edited for any reason

---

## Law Reference

All changes must respect laws in `_rules/laws.yaml`.

**Supreme Laws (cannot be violated):** LAW-001 through LAW-008, LAW-011, LAW-012, LAW-013

**Locked Laws (strong preference):** LAW-009, LAW-010

See `_rules/laws.yaml` for definitions. Do not restate here.

---

## Versioning

Changes to the Starter Kit require:

1. Update `CHANGELOG.md` with changes
2. Bump version in `README.md`
3. If breaking: major version bump + migration guide

---

## Enforcement

This governance is enforced:

- ✅ In this Claude Project (via project knowledge)
- ✅ Across all chats with this user (via memory)
- ✅ By any AI agent with access to this file

**Memory trigger:** "Starter kit guardian: enforce GOVERNANCE.md rules"

---

## Stability Declaration

Some system structures have reached maturity and are locked against structural change. They may be refined internally but not restructured.

### Frozen Structures

| Structure | Scope of freeze | What's still allowed |
|-----------|----------------|---------------------|
| Laws (LAW-001 to LAW-013) | No new laws. No renumbering. No tier reclassification. | Refining rule text for clarity. Tightening enforcement criteria. |
| Gate sequence (Gate 0–7) | No new gates. No reordering. No removing gates. | Adding degraded modes. Refining checklist items within a gate. Adding checks to existing gates. |
| Critique loop structure (BUILD → CRITIQUE → PATCH → VERIFY → SHIP/ESCALATE) | No new phases. No reordering. | Adding modes (e.g., Single-Cycle). Refining phase inputs/outputs. |
| Three Absolutes (Closed World, Single Source of Truth, Generic Over Specific) | No modification. No reinterpretation. | N/A — these are definitional. |
| Meta-rules in SYSTEM_CONTRACT.md | No new meta-rules. No removal. | Clarifying existing meta-rule language. |

### Why Freeze

Compounding systems need fixed points. If foundational structures change every release:
- References across 75 files break silently
- Agents cannot build reliable mental models of the system
- Quality improvements never settle into muscle memory
- The system optimizes for evolution instead of execution

### Amendment Process

Unfreezing a frozen structure requires:
1. A written argument that the current structure **cannot accommodate** the need (not just that a change would be nice)
2. Impact analysis: which files reference this structure and what breaks
3. Explicit approval logged in `_decisions/REGISTRY.md` with stability: `amendment`
4. The bar is deliberately high — frozen means frozen

### What Remains Open

Everything not listed above continues to evolve normally under standard governance:
- Invariant categories and IDs (can add new invariants)
- Scoring dimensions (can add, refine, or retire dimensions)
- Expectation framework (can extend contracts and tests)
- Extension system (can add new product classes)
- Presets (can add new presets)
- Primitives, layouts, patterns (can add within closed-world rules)
- Degraded modes and relief valves (can refine operational protocols)

---

## Meta

This file is itself governed by these rules:

- It is the single source of governance rules
- Changes to it require decision entry
- It cannot introduce case-specific exceptions
