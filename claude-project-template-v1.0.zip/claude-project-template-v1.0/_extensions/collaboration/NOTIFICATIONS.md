# Notification Architecture

> How the product communicates events to users across channels.

**Parent:** `_extensions/collaboration/CONTRACT.md`

---

## Why Notifications Get Their Own File

Notifications are the most common source of collaboration UX failure. They sit at the intersection of product design, user psychology, and technical infrastructure. Getting them wrong — too many, too few, or wrong channel — destroys collaboration trust.

---

## The Three Notification Sins

| Sin | What Happens | User Response |
|-----|-------------|---------------|
| **Too many** | Every action triggers a notification | User mutes everything → misses important things |
| **Too few** | Important events happen silently | User doesn't trust the product to keep them informed |
| **Wrong channel** | Urgent things via email; routine things via push | User annoyed by interruptions; misses urgent items in email pile |

The goal is right notification, right channel, right time.

---

## Notification Framework

Every notification event follows this schema:
```yaml
notification:
  event: "__FILL__"                 # What happened (e.g., "comment_added", "task_assigned")
  urgency: __SELECT__               # immediate | soon | eventual | digest

  channels:
    immediate: [push, in_app_banner]  # For time-sensitive events
    soon: [in_app_badge, email]       # For important but not urgent events
    eventual: [email_digest]          # For informational events
    digest: [weekly_summary]          # For low-priority awareness

  content:
    who: "__FILL__"                  # Who triggered this event
    what: "__FILL__"                 # What happened (in plain language)
    where: "__FILL__"               # Deep link to the source context
    why_care: "__FILL__"            # Why this matters to the recipient

  control:
    mutable: true                    # Can user change this notification's settings?
    default: __SELECT__              # on | off — is it on by default?
    granularity: __SELECT__          # per_event | per_type | per_project | global
```

---

## Urgency Framework

| Urgency | Response Expected | Channel | Examples |
|---------|------------------|---------|---------|
| **Immediate** | Within minutes | Push notification, in-app banner | "@mention in active discussion", "build failed", "deadline in 1 hour" |
| **Soon** | Within hours | In-app badge, email | "New comment on your task", "review requested", "assigned to you" |
| **Eventual** | Within days | Email digest | "Team progress update", "new feature announcement" |
| **Digest** | Awareness only | Weekly summary | "Team activity summary", "trending topics" |

### Urgency Rules

| Rule | Description |
|------|-------------|
| **Default to lower urgency** | When unsure, choose lower urgency. Users can upgrade, but can't un-see a push notification. |
| **Context escalates** | A comment is "soon" normally, but "immediate" if it's an @mention during an active discussion. |
| **Urgency decays** | An unacknowledged "soon" notification should not auto-escalate to "immediate." Let it wait. |
| **User overrides respected** | If a user sets a notification type to a different urgency, honor it absolutely. |

---

## Channel Design

### In-App Notifications

| Component | Purpose | Design |
|-----------|---------|--------|
| **Badge** | Unread count on nav item | Number badge (not dot — users need to know magnitude) |
| **Notification center** | Centralized list of notifications | Sorted by recency; grouped by entity when applicable; mark-all-read |
| **Banner** | Transient alert for immediate events | Auto-dismiss after 5–8 seconds; action button; dismiss button |
| **Inline indicator** | Change indicator on specific entity | "Updated 2 min ago by Alice" on entity card or row |

### Email Notifications

| Type | When | Content |
|------|------|---------|
| **Individual** | Soon-urgency events | Full context: who, what, where (deep link), why care. Self-contained. |
| **Digest** | Eventual/digest urgency | Aggregated: "5 new comments, 2 tasks assigned, 1 review requested" with deep links |
| **Summary** | Weekly/monthly | High-level: team activity trends, completion rates, highlights |

### Email Rules

| Rule | Description |
|------|-------------|
| **Self-contained** | Email must be useful without clicking through |
| **Deep link always** | Every email includes a link to the source context |
| **Unsubscribe per type** | Users can unsubscribe from specific notification types, not just all-or-nothing |
| **Aggregate aggressively** | 10 comments on the same entity = 1 email with "10 new comments," not 10 emails |
| **Respect quiet hours** | If the product has quiet hours settings, batch non-immediate emails |

### Push Notifications

| Rule | Description |
|------|-------------|
| **Immediate only** | Push notifications are reserved for immediate-urgency events |
| **Actionable** | Every push notification should lead to a specific action |
| **Tappable** | Tapping opens the relevant context, not the app home screen |
| **Groupable** | OS-level notification grouping for rapid-fire events |
| **Sound/vibration** | Default to silent for "soon" events even if delivered via push |

---

## Notification Content Design

Every notification must answer four questions:

| Question | Field | Example |
|----------|-------|---------|
| **Who?** | `who` | "Sarah Chen" |
| **What?** | `what` | "commented on your task" |
| **Where?** | `where` | "Design Review — Homepage Redesign" (deep link) |
| **Why should I care?** | `why_care` | "You're the assignee" |

### Content Rules

| Rule | Description |
|------|-------------|
| **Actor first** | "[Who] [did what] [to what]" — not "[What] was [done] by [who]" |
| **Specific, not generic** | "Sarah commented on Homepage Redesign" not "New comment on your task" |
| **Truncate thoughtfully** | If content is long, show meaningful preview + "..." |
| **No jargon** | Use the same vocabulary as the product UI |
| **Contextual deep link** | Link to the exact comment/change, not just the parent entity |

---

## User Control

Users must be able to control their notification experience. The key principle: **give control without requiring configuration.**

### Control Levels

| Level | What User Controls | UI |
|-------|-------------------|-----|
| **Global** | All notifications on/off per channel | Settings → Notifications |
| **Per type** | Specific event types on/off | Settings → Notification Preferences |
| **Per entity** | Follow/unfollow specific items | "Follow" toggle on entity detail |
| **Per channel** | Which channels for which types | Settings → Channel Preferences |

### Default Strategy

| Notification Type | Default | Rationale |
|------------------|---------|-----------|
| @mentions | On (immediate) | Explicitly directed at you |
| Assignments | On (soon) | Directly actionable |
| Comments on owned items | On (soon) | Relevant to your work |
| Status changes on owned items | On (eventual) | Informational |
| Team activity | Off (digest available) | Opt-in for awareness |
| System announcements | On (eventual) | Product updates |

### The Follow/Unfollow Model

| Rule | Description |
|------|-------------|
| **Auto-follow on interaction** | Commenting, being assigned, or being mentioned auto-follows the entity |
| **Explicit unfollow** | User can unfollow at any time, stopping all notifications for that entity |
| **Follow without notification** | Some users want to track without being notified — support "watch" without alerts |
| **Unfollow doesn't affect @mentions** | Direct mentions still notify even if unfollowed (user was explicitly called) |

---

## Notification Aggregation

Rapid-fire events must be aggregated to prevent notification fatigue.

### Aggregation Rules

| Rule | Description |
|------|-------------|
| **Time window** | Events within a time window (e.g., 5 minutes) on the same entity are grouped |
| **Actor grouping** | "Alice, Bob, and 2 others commented" rather than 4 separate notifications |
| **Type grouping** | "3 new comments and 1 status change on Homepage Redesign" |
| **Escalation override** | If an aggregated batch includes an immediate-urgency event, the whole batch escalates |

### Aggregation Display
Individual:    "Alice commented on Homepage Redesign"
Aggregated:    "Alice, Bob, and Carol commented on Homepage Redesign (3 new)"
Batch digest:  "Homepage Redesign: 3 comments, 1 status change, 1 assignment"

---

## Notification Anti-Patterns

| Anti-Pattern | Problem | Fix |
|-------------|---------|-----|
| **Your own actions** | "You updated the status" — user already knows | Never notify users about their own actions |
| **Phantom notifications** | Badge shows "3" but nothing is new | Ensure badge count is accurate; clear on view |
| **Notification-only features** | "Check your notifications to see X" | Never gate information behind notifications |
| **Unactionable alerts** | "Something happened" with no path to act | Every notification deep-links to context |
| **All-or-nothing control** | User can only turn ALL notifications on or off | Provide per-type granularity |
| **Notification pile-up** | Returning after vacation to 500 unread | Offer "mark all read" and smart summarization |
| **Silent important events** | Task reassigned but no notification | Audit: every state change that affects another user must notify |

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/collaboration/CONTRACT.md` | Scope, rules, activation |
| `_extensions/collaboration/PATTERNS.md` | Collaboration pattern catalog |
| `_extensions/collaboration/INVARIANTS.md` | Notification-specific invariants |
| `_expectations/CONTRACTS.md` | Feedback Contract (actions produce response) |
