# Collaboration Patterns

> Pattern catalog for multi-user experience design.

**Parent:** `_extensions/collaboration/CONTRACT.md`

---

## Awareness Patterns

Awareness is the foundation of collaboration. Before users can work together, they need to know who else is here and what they're doing.

### Presence Design

| Pattern | Fidelity | Visual Treatment | Use When |
|---------|----------|-----------------|----------|
| **Active indicator** | Low — online/offline | Green dot / grey dot on avatar | User lists, assignee fields, team views |
| **Viewing indicator** | Medium — who's on this page | Avatar stack in page header: "👤👤 +1 viewing" | Document headers, detail pages, entity views |
| **Live position** | High — cursor/selection in real time | Colored cursor with name label | Co-editing surfaces (documents, canvases, forms) |

### Presence Rules

| Rule | Description |
|------|-------------|
| **Stale presence expires** | If presence data can't be refreshed, remove indicators (don't show stale "online" dots) |
| **Self is excluded** | Don't count or show the current user in "viewing" counts |
| **Graceful degradation** | If real-time presence fails, fall back to "recently viewed" rather than showing nothing |
| **Privacy by design** | Some users may not want to broadcast their presence. Provide opt-out if appropriate for the product. |

### Avatar Design

When showing who's present or who did something:

| Element | Requirement |
|---------|-------------|
| **Avatar image** | User photo or generated initial/color |
| **Name accessible** | Full name on hover/tap (never just an image) |
| **Overflow handling** | "+N" for groups larger than display limit (typically 3–5) |
| **Tooltip detail** | On hover: name, role, and how long ago they were active |
| **Empty state** | "No one else is viewing" — not a blank space |

---

## Communication Patterns

Communication is how users exchange information within the product. The key principle: conversations should happen **where the context is**, not in a separate communication tool.

### Commenting

| Pattern | When to Use | Design Requirements |
|---------|-------------|-------------------|
| **Entity comments** | Discussion about a task, document, or object | Thread on entity detail page; newest first or oldest first (declare and stick) |
| **Inline comments** | Feedback on specific content within a document | Anchored to content; highlighted region; side panel or popover |
| **Resolution** | Comments that represent actionable feedback | Resolve/unresolve toggle; resolved comments visually distinct or hidden |

### Comment Design Rules

| Rule | Description |
|------|-------------|
| **Context is king** | A comment should be readable without clicking through to the source — include enough context in the comment itself |
| **Thread, don't sprawl** | Replies belong in threads, not as new top-level comments |
| **Resolve, don't delete** | Resolved comments should be hideable but not deleted (they're part of the decision record) |
| **Mentions create notifications** | @mention always creates a notification for the mentioned user |
| **Edit and delete** | Users can edit/delete their own comments (with visible "edited" indicator) |

### @Mentions

| Element | Design |
|---------|--------|
| **Trigger** | Typing `@` opens user picker |
| **Picker** | Shows team members, recently mentioned, filtered by typing |
| **Display** | Mentioned name styled distinctly (color, weight) and clickable |
| **Notification** | Mention always creates notification for mentioned user |
| **Unresolved mentions** | If mentioned user doesn't exist or left, show graceful fallback |

### Reactions

| Element | Design |
|---------|--------|
| **Purpose** | Lightweight acknowledgment without a full comment |
| **Placement** | On comments, on activity items, on status updates |
| **Limit** | Standard emoji set or curated set (declare which) |
| **Display** | Grouped by emoji with count; click to see who reacted |

---

## Coordination Patterns

Coordination is how users align on who does what. This is where collaboration moves from passive awareness to active teamwork.

### Assignment

| Pattern | Design Requirements |
|---------|-------------------|
| **Single assignee** | Avatar + name; click to change; clear unassigned state |
| **Multiple assignees** | Avatar stack with "assign" button; clear who's primary (if applicable) |
| **Self-assign** | "Assign to me" shortcut — reduces friction for taking ownership |
| **Unassign** | Always possible; creates activity record |

### Activity Feeds

Activity feeds are powerful and commonly abused. The key distinction:

| Feed Type | Purpose | Content | Design |
|-----------|---------|---------|--------|
| **Activity log** | "What happened?" | All entity changes, chronological | Detailed, filterable, complete |
| **Notification center / Inbox** | "What needs my attention?" | Curated, relevant to me | Prioritized, actionable, dismissible |

These are **different surfaces** even if some products combine them. Mixing "everything that happened" with "what needs your attention" creates noise.

### Activity Feed Design Rules

| Rule | Description |
|------|-------------|
| **Aggregate, don't repeat** | "Alice updated status 3 times" not three separate entries |
| **Actor + action + target** | Every activity entry follows: "[Who] [did what] [to what]" |
| **Timestamp always** | Relative for recent ("2 hours ago"), absolute for old ("Jan 15, 2026") |
| **Deep link always** | Every activity item links to the entity it references |
| **Filter by type** | Users can filter activity by type (comments, status changes, assignments, etc.) |
| **Distinguish read/unread** | Visual distinction between items the user has seen and hasn't |

### Handoff Patterns

When work passes from one person to another:

| Pattern | When to Use | Design |
|---------|-------------|--------|
| **Reassignment** | Task changes owner | Previous owner notified; activity record created |
| **Review request** | Work needs approval/feedback | Explicit "request review" action; reviewer sees pending item |
| **Mention handoff** | Informal "take a look" | @mention in comment; lower formality than review request |
| **Status-based** | Workflow state triggers handoff | Moving to "In Review" notifies reviewer automatically |

---

## Co-creation Patterns

Co-creation is working on the same thing simultaneously. This is the most technically complex layer and the most rewarding when done well.

### Conflict Resolution

When two users edit the same thing, what happens?

| Strategy | When to Use | User Experience | Implementation Complexity |
|----------|-------------|-----------------|--------------------------|
| **Last write wins** | Low-stakes, frequent changes (e.g., status toggles) | Silent — user may not notice overwrite | Low |
| **Optimistic locking** | Medium-stakes, form-based editing | "Someone else is editing this" warning before save | Medium |
| **Real-time merge** | High-stakes, document-like content | Google Docs-style live merging with cursors | High |
| **Manual merge** | High-stakes, structured data with schema constraints | "Conflict detected" with side-by-side comparison | High |

### Conflict Resolution Declaration

For each surface with co-creation layer:
```yaml
conflict_resolution:
  surface: SURF-__FILL__
  strategy: __SELECT__  # last_write_wins | optimistic_locking | real_time_merge | manual_merge
  rationale: "__FILL__"

  # Required for optimistic_locking and manual_merge:
  conflict_display: "__FILL__"    # How user sees the conflict
  resolution_path: "__FILL__"     # How user resolves it

  # Required for real_time_merge:
  cursor_sharing: __SELECT__      # yes | no
  selection_sharing: __SELECT__   # yes | no
```

### Co-creation Rules

| Rule | Description |
|------|-------------|
| **Declare strategy** | Every co-creation surface must declare its conflict resolution strategy |
| **Show who's editing** | Users always see who else is currently editing (Awareness layer) |
| **No silent overwrites** | Unless strategy is explicitly "last write wins," user must be informed of conflicts |
| **Undo still works** | Co-creation doesn't break the undo model — each user's undo stack is independent |

---

## Shared vs. Personal State

A critical design decision: which UI state is shared (everyone sees the same thing) and which is personal (my view, my preferences)?

### Decision Matrix

| State Type | Default | Override Allowed | Rationale |
|-----------|---------|-----------------|-----------|
| **Entity data** | Shared | No — data is truth | Everyone must see the same entity state |
| **Sort order** | Shared default, personal override | Yes — saved views | Default ensures consistency; personal sort for power users |
| **Filters** | Personal | Yes — shared saved views | My filter context is mine; team filters are saved views |
| **Layout/view** | Shared default, personal override | Yes — view preferences | Team has a default; individuals can switch |
| **Collapsed/expanded** | Personal | No | UI state preference doesn't affect others |
| **Selection** | Personal | No | My selected items are my context |
| **Scroll position** | Personal | No | Where I am in a list is my state |
| **Notification preferences** | Personal | No | My notification choices are mine |

### Declaring Shared vs. Personal

For each piece of UI state on collaborative surfaces:
```yaml
state_ownership:
  state: "__FILL__"          # e.g., "board column order", "filter preset", "view mode"
  default: __SELECT__        # shared | personal
  override: __SELECT__       # none | personal_override | shared_saved_view
  persistence: __SELECT__    # session | permanent | device
  rationale: "__FILL__"
```

### Anti-Patterns

| Anti-Pattern | Problem | Fix |
|-------------|---------|-----|
| **Everything shared** | User sorts a table → everyone's table changes | Make sort personal by default |
| **Everything personal** | Team can't agree on a shared view → chaos | Provide shared defaults with personal overrides |
| **No indication** | User doesn't know if their change affects others | Label shared state: "This view is shared with your team" |
| **Shared without consent** | User's layout change pushes to everyone silently | Require explicit "Save for team" action for shared state changes |

---

## What This Module Does NOT Do

- **Does not replace permissions.yaml.** That's access control; this is experience design.
- **Does not specify real-time infrastructure.** WebSocket, polling, SSE, CRDT — those are engineering decisions.
- **Does not design specific UI components.** Comment box, activity feed, presence indicator — those use existing `_ui/` components.
- **Does not handle authentication.** Identity verification is covered by `_nfr/SECURITY.yaml`.
- **Does not dictate notification delivery.** Email providers, push notification services — that's infrastructure.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/collaboration/CONTRACT.md` | Scope, rules, activation |
| `_extensions/collaboration/NOTIFICATIONS.md` | Notification architecture |
| `_extensions/collaboration/INVARIANTS.md` | Collaboration-specific invariants |
| `_model/truth/permissions.yaml` | Access control (complementary) |
| `_model/truth/entities.yaml` | Comment, Activity, Notification as entities (when extension active) |
| `_model/truth/actions.yaml` | comment, mention, react, assign as actions (when extension active) |
| `_model/truth/states.yaml` | Notification states (when extension active) |
