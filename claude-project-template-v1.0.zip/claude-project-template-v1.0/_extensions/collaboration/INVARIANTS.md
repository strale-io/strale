# Collaboration Invariants

> Non-negotiable requirements for collaborative features.

**Parent:** `_extensions/collaboration/CONTRACT.md`
**Activation:** These invariants apply only when `collaboration` is in `capability_extensions`.

---

## Awareness Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| CO-001 | **Presence data is never stale.** If real-time presence fails, indicators are removed — not frozen in "online" state. | Stale presence is worse than no presence. | Disconnect real-time → verify indicators clear within timeout. |
| CO-002 | **Self is excluded from "viewing" counts.** The current user is never counted in "N people viewing." | Counting yourself is confusing and inflates numbers. | Open a page → verify you're not in the viewer count. |
| CO-003 | **Avatars always have accessible names.** Every avatar image has a tooltip/aria-label with the user's full name. | Images without names are inaccessible. | Hover/focus every avatar → verify name appears. |

---

## Communication Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| CO-004 | **@mentions always create notifications.** Mentioning a user in a comment always generates a notification, regardless of the mentioned user's general notification settings. | @mentions are explicit requests for attention. | @mention a user → verify notification received. |
| CO-005 | **Comments are never silently deleted.** Resolved comments are hidden/collapsed, not destroyed. Deleted comments show "[deleted]" placeholder. | Comments are part of the decision record. | Resolve a comment → verify it's accessible. Delete → verify placeholder remains. |
| CO-006 | **Threads stay threaded.** Replies to a comment always appear as a thread under the parent, never as new top-level comments. | Sprawling top-level comments are unreadable. | Reply to a comment → verify it nests under parent. |

---

## Coordination Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| CO-007 | **Assignment changes notify both parties.** Reassigning a task notifies the previous assignee (removed) and the new assignee (added). | Both parties need to know about the handoff. | Reassign a task → verify both old and new assignee are notified. |
| CO-008 | **Activity entries follow actor-action-target format.** Every activity feed entry reads as "[Who] [did what] [to what]." | Consistent format enables scanning. | Review any activity feed → verify all entries follow format. |
| CO-009 | **Activity entries deep-link to source.** Every activity item links to the specific entity and state it references. | Activity without context is noise. | Click any activity item → verify it opens the correct context. |

---

## Notification Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| CO-010 | **Every notification deep-links to its source context.** Clicking a notification opens the exact comment, change, or entity — not just the parent page. | Users need to see what triggered the notification. | Click any notification → verify it opens exact source. |
| CO-011 | **Users can control notification frequency per channel.** Users can configure per-type notification preferences for each channel (in-app, email, push). | One-size-fits-all control is insufficient. | Open notification settings → verify per-type, per-channel controls exist. |
| CO-012 | **Notification content is self-sufficient.** A notification must be understandable without clicking through to the source. | Many users read notifications but don't click through. | Read any notification in isolation → verify it makes sense without clicking. |
| CO-013 | **Related notifications are batched.** Multiple events on the same entity within a time window produce one notification, not many. | Rapid-fire events cause notification fatigue. | Generate 5 comments on one entity in 2 minutes → verify they batch into 1 notification. |
| CO-014 | **Users are never notified about their own actions.** A user's own actions never generate notifications for themselves. | Users already know what they did. | Perform an action → verify no self-notification. |

---

## Co-creation Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| CO-015 | **Conflict resolution strategy is declared.** Every co-creation surface has an explicit conflict resolution strategy in the surface spec. | Undeclared conflict handling leads to unpredictable behavior. | Review co-creation surface spec → verify strategy is documented. |
| CO-016 | **No silent data overwrites (unless last-write-wins declared).** Users are informed when their changes conflict with another user's, unless the surface explicitly uses last-write-wins strategy. | Silent overwrites destroy trust. | Simulate concurrent edit → verify conflict notification (unless last-write-wins). |
| CO-017 | **Co-editing shows who else is editing.** When multiple users edit the same entity, all editors see who else is currently editing. | Users need to know they're not alone. | Open entity with two users → verify both see the other. |

---

## Shared State Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| CO-018 | **Shared state changes are labeled.** When a user's action changes state that's visible to others (e.g., board column order), the UI indicates "This change affects everyone." | Users shouldn't accidentally change others' views. | Modify a shared-state setting → verify "affects everyone" indicator. |
| CO-019 | **Personal state never leaks to others.** One user's personal filters, sort order, or view preferences never affect another user's experience. | Personal is personal. | User A applies a filter → verify User B's view is unchanged. |

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/collaboration/CONTRACT.md` | Scope, rules, activation |
| `_extensions/collaboration/PATTERNS.md` | Patterns these invariants enforce |
| `_extensions/collaboration/NOTIFICATIONS.md` | Notification patterns and rules |
| `_invariants/REGISTRY.md` | Core system invariants (these are extension-specific) |
