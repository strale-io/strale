# Collaboration Patterns — Contract

> Experience design for multi-user products.

**Extension Type:** Capability Extension
**Status:** `active`
**Activation:** Add `collaboration` to `capability_extensions` list in `config/manifest.yaml`

---

## What This Extension Does

This extension governs the **experience of working together** — how users know who else is present, how they communicate within the product, how they coordinate work, and how they collaborate in real time.

It operates above `_model/truth/permissions.yaml`, which defines access control (who can do what). This extension defines how multi-user interactions feel.

| Level | Governs | Example |
|-------|---------|---------|
| **Access control** (`permissions.yaml`) | Who can perform which actions | "Editors can update team content" |
| **Collaboration experience** (this extension) | How multi-user interactions work and feel | "Users see who else is viewing this document" |

Both levels are needed. This extension doesn't replace permissions — it designs the experience layer on top of them.

---

## Scope

| Responsible For | Must Not Contain |
|----------------|-----------------|
| Collaboration layer selection per surface | Permission definitions (use `permissions.yaml`) |
| Presence pattern design | WebSocket/polling/SSE technical implementation |
| Activity feed architecture | Specific notification UI components (use `_ui/`) |
| Notification strategy and content rules | Authentication or authorization (use `_nfr/SECURITY.yaml`) |
| Shared vs. personal state decisions | Database schema for activity storage |
| Conflict resolution pattern selection | Real-time sync technical architecture |
| Commenting and mention design | Email delivery infrastructure |

---

## Activation

Add to `config/manifest.yaml`:
```yaml
capability_extensions:
  - collaboration
```

When active, this extension:
- Adds collaboration layer declaration to surface registry (conditional)
- Adds Collaboration Contract to `_expectations/CONTRACTS.md` (conditional)
- Adds collaboration critique dimensions (conditional)
- Requires notification architecture for any surface with Communication or Coordination layers

When inactive, all collaboration-related guidance is ignored. Products default to single-user experience design.

---

## Collaboration Layers

Not every product needs all four layers. This extension helps you choose.

| Layer | What It Adds | Examples | Prerequisites |
|-------|-------------|---------|---------------|
| **Awareness** | Knowing others exist and are active | Presence dots, avatars, "who's viewing" | Basic user identity |
| **Communication** | Exchanging information within the product | Comments, @mentions, reactions, threads | Awareness + notification system |
| **Coordination** | Aligning on who does what | Assignment, handoff, status updates, activity feeds | Communication + entity ownership model |
| **Co-creation** | Working on the same thing simultaneously | Real-time editing, cursor sharing, conflict resolution | Coordination + real-time infrastructure |

### Layer Selection Guide

| Product Type | Typical Layers | Rationale |
|-------------|---------------|-----------|
| **Reporting/analytics tool** | Awareness, Communication | Users review together but don't edit simultaneously |
| **Project management tool** | All four | Full collaboration lifecycle |
| **Content/document tool** | All four | Real-time co-editing is core value |
| **Admin/settings tool** | Awareness only | Coordination via external channels |
| **Single-user tool** | None | Don't activate this extension |

Declare per surface in `_surfaces/REGISTRY.yaml`:
```yaml
collaboration_layer: __SELECT__  # none | awareness | communication | coordination | co-creation
```

Higher layers include lower layers (co-creation includes coordination, communication, and awareness).

---

## Rules

### Extension Rules

| Rule | Description |
|------|-------------|
| **Additive only** | This extension adds patterns; it does not override core system rules or product class extensions |
| **Conditional enforcement** | All checklist items fire only when `collaboration` is in `capability_extensions` |
| **Layer hierarchy** | Higher layers include all lower layers (co-creation ⊃ coordination ⊃ communication ⊃ awareness) |
| **Compatible with all product classes** | Collaboration patterns apply to workflow apps, data platforms, creative tools, etc. |

### Collaboration Rules

| Rule | Description |
|------|-------------|
| **Declare layer per surface** | Every surface must declare its collaboration layer |
| **Notification system required** | Any surface with Communication or higher layer must have notification design |
| **Conflict strategy required** | Any surface with Co-creation layer must declare a conflict resolution strategy |
| **Shared/personal state declared** | For every piece of UI state, declare whether it's shared or personal |

---

## Exceptions to Core Rules

None. This extension adds collaboration patterns without modifying any core constraints.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/collaboration/PATTERNS.md` | Collaboration pattern catalog |
| `_extensions/collaboration/NOTIFICATIONS.md` | Notification architecture |
| `_extensions/collaboration/INVARIANTS.md` | Collaboration-specific invariants |
| `_model/truth/permissions.yaml` | Access control (complementary, not replaced) |
| `_expectations/CONTRACTS.md` | Collaboration Contract (conditional) |
| `_critique/PROMPT.md` | Collaboration critique dimensions (conditional) |
| `config/manifest.yaml` | `capability_extensions` activation |
