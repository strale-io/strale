# Data Platform Contract

> Rules for data-intensive products with time series, schemas, and pipelines.

**Product Class:** `data_platform`

**Status:** `active` — Ready for use with products of this class.

**Examples:** Snowflake UI, Palantir Foundry, Bloomberg terminals, Metabase

---

## Class Definition

A product is a **data platform** when:

1. **Core asset is data itself** — tables, schemas, time series, not entities with workflows
2. **Queries are primary actions** — exploring, filtering, aggregating over creating/updating
3. **Schema is visible** — users interact with structure, not just content
4. **Time is a dimension** — historical analysis, point-in-time queries, revisions
5. **Scale is visible** — row counts, query costs, data sizes are user-facing

**Key mental model difference:** Users are *exploring* data, not *working* items.

---

## Class-Specific Invariants

Primary data platform invariants are in `_invariants/REGISTRY.md` (TS-001 through TS-005).

Additional invariants for this class:

| ID | Invariant | Rationale |
|----|-----------|-----------|
| DP-001 | **Query cost is visible before execution.** Users see estimated time/resources before running expensive queries. | Prevents surprise costs/waits |
| DP-002 | **Schema changes are versioned.** Schema modifications are tracked with timestamps and authors. | Enables schema archaeology |
| DP-003 | **Null is distinct from missing.** Explicit null vs. absent value is visually distinguished. | Prevents false assumptions |
| DP-004 | **Aggregation method is explicit.** Aggregated numbers show how they were computed (sum, avg, count, etc.). | Prevents misinterpretation |
| DP-005 | **Lineage is traceable.** Data provenance can be traced to source. | Enables trust validation |
| DP-006 | **Sample vs. full is indicated.** When showing sampled data, sample size and method are visible. | Prevents false precision |

---

## Class-Specific Patterns

### Data Exploration

| Pattern | Description |
|---------|-------------|
| Schema Browser | Tree/grid view of database structure with expand/collapse |
| Query Builder | Visual or text-based query composition |
| Result Grid | Tabular display with column-type-aware formatting |
| Series Explorer | Time series visualization with range selection |
| Lineage Graph | DAG showing data dependencies and transformations |

### Data Navigation

| Pattern | Description |
|---------|-------------|
| Drill-down | Click aggregates to see component rows |
| Drill-through | Navigate from summary to source tables |
| Pivot | Rearrange dimensions dynamically |
| Cross-filter | Selections in one view filter others |

### Data State Communication

| State | UI Treatment |
|-------|--------------|
| Querying | Progress with estimated completion |
| Partial results | Show available rows with "loading more" |
| Cached | Timestamp of cache, option to refresh |
| Stale | Warning with staleness duration |
| Sample | Badge indicating sample size/method |

---

## Class-Specific Critique Dimensions

When evaluating data platform screens, add these dimensions to the standard critique:

| Dimension | What to Evaluate |
|-----------|------------------|
| **Query Transparency** | Can users understand what data they're seeing? |
| **Scale Communication** | Is data volume, query cost, and time clear? |
| **Schema Learnability** | Can users understand data structure without docs? |
| **Exploration Fluidity** | Can users drill, pivot, and explore without friction? |
| **Trust Calibration** | Are freshness, completeness, and provenance clear? |

---

## Exceptions to Core Rules

| Core Rule | Exception | Rationale |
|-----------|-----------|-----------|
| Single path to power | Multiple query paths allowed (visual, SQL, API) | Different user expertise levels |
| Minimal surfaces | Dense dashboards acceptable | Information density is the value |
| Exit quickly | Extended exploration sessions expected | Discovery is the job |

---

## Preset Integration

To activate this extension:

```yaml
# config/manifest.yaml
product_class: data_platform

presets:
  - _base
  - data-dense          # Recommended companion preset
  - _project
```

Extension files are only loaded when `product_class: data_platform`.

---

## Related Files

- `_invariants/REGISTRY.md` — TS-001 to TS-005 (Time Series Invariants)
- `_presets/data-dense.yaml` — Companion preset for data-heavy UIs
- `_ui/layouts/` — Standard layouts still apply
