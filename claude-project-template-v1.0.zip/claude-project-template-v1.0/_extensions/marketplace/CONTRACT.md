# Marketplace Contract

> Rules for publishing, discovering, and sharing asset products.

**Product Class:** `marketplace`

**Status:** `active` — Ready for use with products of this class.

**Examples:** Figma Community, Notion Templates, Shopify App Store, VS Code Extensions

---

## Class Definition

A product is a **marketplace** when:

1. **Assets are products** — templates, plugins, themes, or components are the inventory
2. **Discovery is primary** — browsing and search are core experiences
3. **Trust is essential** — provenance, reviews, and verification matter
4. **Publishing is a workflow** — creators submit, review, publish, update
5. **Social proof drives decisions** — downloads, ratings, and endorsements influence choice

**Key mental model difference:** Users are *shopping* for solutions, not *building* them.

---

## Class-Specific Invariants

| ID | Invariant | Rationale |
|----|-----------|-----------|
| MK-001 | **Version history is visible.** Users can see asset update history before installing. | Trust and rollback awareness |
| MK-002 | **Compatibility is explicit.** Required platform/version compatibility is shown clearly. | Prevents installation failures |
| MK-003 | **Publisher identity is verifiable.** Creator/company identity is displayed with verification status. | Trust calibration |
| MK-004 | **Preview before commitment.** Users can preview asset before install/purchase. | Reduces bad decisions |
| MK-005 | **Uninstall path is clear.** Removal process is documented before installation. | Reduces installation anxiety |
| MK-006 | **Permissions are explicit.** What the asset can access is disclosed before install. | Security awareness |

---

## Class-Specific Patterns

### Discovery

| Pattern | Description |
|---------|-------------|
| Category Browse | Hierarchical category navigation |
| Search with Filters | Full-text search with facet filtering |
| Featured/Curated | Editor-selected highlights |
| Trending/Popular | Algorithmic or metric-based rankings |
| Similar Items | Related assets based on current selection |

### Asset Detail

| Pattern | Description |
|---------|-------------|
| Gallery/Preview | Screenshots, videos, live preview |
| Description | Rich text description with formatting |
| Metadata | Version, size, compatibility, permissions |
| Reviews | Ratings and text reviews from users |
| Publisher Info | Creator profile, other assets, verification |

### Publishing

| Pattern | Description |
|---------|-------------|
| Submission Form | Guided asset submission with validation |
| Review Status | Pending/approved/rejected with feedback |
| Version Management | Release new versions, deprecate old |
| Analytics | Download counts, ratings, usage metrics |

### Trust Signals

| Signal | UI Treatment |
|--------|--------------|
| Verified Publisher | Badge with verification type |
| Install Count | Numeric with magnitude indicator |
| Rating | Stars plus count of ratings |
| Last Updated | Recency indicator |
| Compatibility | Version badges |

---

## Class-Specific Critique Dimensions

When evaluating marketplace screens, add these dimensions to the standard critique:

| Dimension | What to Evaluate |
|-----------|------------------|
| **Discovery Efficiency** | Can users find relevant assets quickly? |
| **Trust Calibration** | Are trust signals clear and helpful? |
| **Decision Support** | Do detail pages support informed decisions? |
| **Installation Confidence** | Do users feel safe installing? |
| **Publisher Experience** | Is publishing/updating frictionless? |

---

## Exceptions to Core Rules

| Core Rule | Exception | Rationale |
|-----------|-----------|-----------|
| Minimal surfaces | Rich detail pages acceptable | Decision-making needs information |
| Action-oriented | Browse mode is valid | Discovery before action |
| Entity-action model | Assets have browse/install, not CRUD | Different lifecycle |

---

## Preset Integration

To activate this extension:

```yaml
# config/manifest.yaml
product_class: marketplace

presets:
  - _base
  - _project
```

Extension files are only loaded when `product_class: marketplace`.

---

## Related Files

- `_invariants/REGISTRY.md` — PM-001 to PM-004 apply (permissions)
- `_model/patterns/` — May need gallery, card grid patterns
- `_ui/components.yaml` — May need rating, badge, gallery components
