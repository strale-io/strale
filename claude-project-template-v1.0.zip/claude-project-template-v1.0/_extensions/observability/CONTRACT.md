# Observability Tool Contract

> Rules for diagnostics, monitoring, and investigation products.

**Product Class:** `observability_tool`

**Status:** `active` — Ready for use with products of this class.

**Examples:** Datadog, Grafana, Sentry, New Relic, Honeycomb

---

## Class Definition

A product is an **observability tool** when:

1. **Read-heavy, write-rare** — users consume data, rarely create it
2. **Investigation is the job** — finding needles in haystacks, correlating signals
3. **Time is everything** — all data is temporal; time range selection is core
4. **No single path** — exploration requires flexible querying, not prescribed workflows
5. **Alerts bridge to action** — passive monitoring becomes active when thresholds cross

**Key mental model difference:** Users are *investigating* systems, not *managing* work.

---

## Class-Specific Invariants

| ID | Invariant | Rationale |
|----|-----------|-----------|
| OB-001 | **Time range is always visible.** Current time window is shown and easily adjustable. | Temporal orientation |
| OB-002 | **Data resolution matches range.** Zoom in shows finer granularity; zoom out aggregates. | Appropriate detail level |
| OB-003 | **Correlation is supported.** Multiple signals can be viewed at the same time range. | Investigation support |
| OB-004 | **Alert state is visible.** Active alerts are prominently surfaced. | Urgency awareness |
| OB-005 | **Query is shareable.** Current view state can be captured as a URL or saved query. | Collaboration support |
| OB-006 | **Baselines are available.** Anomaly detection needs comparison to normal. | Context for judgment |

---

## Class-Specific Patterns

### Time Navigation

| Pattern | Description |
|---------|-------------|
| Time Range Picker | Preset ranges (1h, 24h, 7d) plus custom |
| Scrubbing | Drag to select time range on chart |
| Zoom to Selection | Select region to zoom in |
| Sync Ranges | Multiple charts share time range |

### Data Exploration

| Pattern | Description |
|---------|-------------|
| Query Builder | Visual or text-based metric/log queries |
| Facet Filtering | Filter by dimensions (host, service, region) |
| Drill-down | Click data point to see underlying events |
| Compare | Side-by-side or overlay of different time ranges |

### Alert Patterns

| Pattern | Description |
|---------|-------------|
| Alert List | All alerts with status, severity, assignee |
| Alert Timeline | Alerts over time showing patterns |
| Mute/Acknowledge | Silence alerts without resolving |
| Escalation | Show escalation path and timing |

### Dashboard Patterns

| Pattern | Description |
|---------|-------------|
| Widget Grid | Configurable layout of charts/metrics |
| Dashboard Variables | Parameterized dashboards (env, service) |
| Fullscreen Mode | Presentation mode for NOC screens |
| Auto-refresh | Configurable refresh interval |

---

## Class-Specific Critique Dimensions

When evaluating observability tool screens, add these dimensions to the standard critique:

| Dimension | What to Evaluate |
|-----------|------------------|
| **Temporal Orientation** | Is time context always clear? |
| **Signal-to-Noise** | Can users find relevant data in the noise? |
| **Correlation Support** | Can users connect related signals? |
| **Investigation Flow** | Can users drill from symptom to cause? |
| **Alert Actionability** | Do alerts lead to resolution? |

---

## Exceptions to Core Rules

| Core Rule | Exception | Rationale |
|-----------|-----------|-----------|
| Single path to power | Multiple exploration paths allowed | Investigation requires flexibility |
| Minimal surfaces | Dense dashboards acceptable | Information density serves monitoring |
| Progressive disclosure | Advanced query UI acceptable upfront | Power users need full capability |
| Single source of truth | Multiple data views of same data | Different lenses for investigation |

---

## Preset Integration

To activate this extension:

```yaml
# config/manifest.yaml
product_class: observability_tool

presets:
  - _base
  - data-dense          # Recommended companion preset
  - _project
```

Extension files are only loaded when `product_class: observability_tool`.

---

## Related Files

- `_invariants/REGISTRY.md` — TS-001 to TS-005 apply (time series data)
- `_presets/data-dense.yaml` — Companion preset for dense displays
- `_ui/layouts/` — May need dashboard layout template
