# Automation Platform Contract

> Rules for DAGs, pipelines, triggers, and orchestration products.

**Product Class:** `automation_platform`

**Status:** `active` — Ready for use with products of this class.

**Examples:** Zapier, Temporal UI, GitHub Actions, Airflow, n8n

---

## Class Definition

A product is an **automation platform** when:

1. **Flows, not entities** — primary objects are workflows/pipelines, not business entities
2. **Execution is the product** — value comes from things running, not from storing data
3. **Failure is normal** — errors are expected, not exceptional; retry/recovery is core UX
4. **Time and triggers** — schedules, events, and dependencies govern execution
5. **Logs are UI** — execution history and logs are primary surfaces, not secondary

**Key mental model difference:** Users are *orchestrating* processes, not *managing* records.

---

## Class-Specific Invariants

Primary automation invariants are in `_invariants/REGISTRY.md` (AU-001 through AU-004).

Additional invariants for this class:

| ID | Invariant | Rationale |
|----|-----------|-----------|
| AP-001 | **Run status is always visible.** Active jobs show current status prominently. | Orchestration awareness |
| AP-002 | **Failure path is clear.** When a step fails, the failure point and error are obvious. | Debugging support |
| AP-003 | **Retry is explicit.** Users know whether and how retries will happen. | Prevents surprise behavior |
| AP-004 | **Schedule interpretation is shown.** Cron expressions or schedules show human-readable next runs. | Prevents schedule confusion |
| AP-005 | **Dependencies are visualized.** Job/step dependencies are shown graphically, not just listed. | Mental model support |
| AP-006 | **Execution history is bounded and visible.** Users know retention policy and can access historical runs. | Audit and debugging |

---

## Class-Specific Patterns

### Flow Visualization

| Pattern | Description |
|---------|-------------|
| DAG View | Directed acyclic graph showing steps and dependencies |
| Timeline View | Gantt-style view of execution over time |
| Tree View | Hierarchical view for nested workflows |
| List View | Flat list of jobs/runs for scanning |

### Run State Communication

| State | UI Treatment |
|-------|--------------|
| Pending | Queued position if applicable |
| Running | Progress, duration so far, current step |
| Succeeded | Duration, output summary |
| Failed | Error message, failure step, retry option |
| Cancelled | Who cancelled, at what point |
| Retrying | Retry count, next retry time |

### Log Patterns

| Pattern | Description |
|---------|-------------|
| Streaming Logs | Live log output during execution |
| Structured Logs | Parsed, searchable log entries |
| Log Levels | Filter by info/warn/error |
| Step-scoped Logs | Logs filtered to specific step |

---

## Class-Specific Critique Dimensions

When evaluating automation platform screens, add these dimensions to the standard critique:

| Dimension | What to Evaluate |
|-----------|------------------|
| **Execution Clarity** | Is it obvious what's running, what's queued, what failed? |
| **Failure Recovery** | Can users diagnose and fix failures efficiently? |
| **Schedule Transparency** | Are triggers and schedules understandable? |
| **Dependency Clarity** | Are workflow dependencies clear? |
| **Log Accessibility** | Can users find relevant logs quickly? |

---

## Exceptions to Core Rules

| Core Rule | Exception | Rationale |
|-----------|-----------|-----------|
| Entities have workflows | Flows *are* the entities | Different domain model |
| Empty states are errors | No running jobs is healthy | Idle is a valid state |
| Refresh on demand | Auto-refresh for active runs | Real-time status is essential |

---

## Preset Integration

To activate this extension:

```yaml
# config/manifest.yaml
product_class: automation_platform

presets:
  - _base
  - _project
```

Extension files are only loaded when `product_class: automation_platform`.

---

## Related Files

- `_invariants/REGISTRY.md` — AU-001 to AU-004 (Automation Invariants)
- `_model/truth/states.yaml` — Run states may extend standard state model
- `_ui/components.yaml` — May need log viewer, DAG, timeline components
