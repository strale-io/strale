# Intelligence Guardrails

> When intelligence helps vs. harms, and the gate every smart feature must pass.

**Parent:** `_extensions/intelligence/CONTRACT.md`

---

## Intelligence Restraint Gate

Before shipping any smart feature, it must pass every item on this checklist. This is the intelligence-specific equivalent of the Restraint Gate in `_expectations/PRE-BUILD.md`.

### The Gate

| # | Check | Requirement | Failure = |
|---|-------|-------------|-----------|
| 1 | **Spectrum position declared** | Feature has an explicit position on the intelligence spectrum (insight / suggestion / smart_default / automation / autonomy) | Cannot ship |
| 2 | **Trust prerequisite documented** | What trust must exist before this feature activates? (First use? After N interactions? After explicit opt-in?) | Cannot ship |
| 3 | **Confidence display calibrated** | Confidence display matches actual confidence level. No overstating. | Cannot ship |
| 4 | **Reasoning visible** | User can understand why the system suggests/does this. "Based on..." is accessible. | Cannot ship |
| 5 | **Dismissal path exists** | User can ignore, dismiss, or disable this feature without consequence. | Cannot ship |
| 6 | **Manual alternative preserved** | User can accomplish the same thing without the intelligence feature. Manual path is equally accessible. | Cannot ship |
| 7 | **Failure mode documented** | What happens when the intelligence is wrong? How does the user recover? | Cannot ship |
| 8 | **Agency Test passes** | Feature makes user more capable, not more dependent. | Cannot ship |
| 9 | **Data source disclosed** | User can find out what data the intelligence uses. | Cannot ship |
| 10 | **Accumulation prevented** | Old suggestions expire. No notification pile-up. No stale recommendations. | Cannot ship |

**All 10 must pass. Failure of any item = feature cannot ship as designed.**

Features that fail the Intelligence Restraint Gate are classified as "Dangerous" per the Feature Classification system. They may be redesigned and re-evaluated.

### Gate Declaration

For each smart feature:
```yaml
intelligence_restraint_gate:
  feature: "__FILL__"
  spectrum_position: __SELECT__  # insight | suggestion | smart_default | automation | autonomy

  checks:
    trust_prerequisite: "__FILL__"
    confidence_calibration: __SELECT__  # pass | fail
    confidence_details: "__FILL__"
    reasoning_visible: __SELECT__       # pass | fail
    reasoning_details: "__FILL__"
    dismissal_path: __SELECT__          # pass | fail
    dismissal_details: "__FILL__"
    manual_alternative: __SELECT__      # pass | fail
    manual_details: "__FILL__"
    failure_mode: "__FILL__"
    agency_test: __SELECT__             # pass | fail
    agency_details: "__FILL__"
    data_source_disclosed: __SELECT__   # pass | fail
    data_source_details: "__FILL__"
    accumulation_prevented: __SELECT__  # pass | fail
    accumulation_details: "__FILL__"

  gate_result: __SELECT__  # pass | fail
  if_fail_action: "__FILL__"  # Redesign plan or "classified as Dangerous"
```

---

## Intelligence Failure Modes

Every smart feature can fail. Understanding the failure modes helps design mitigation before shipping.

### Failure Catalog

| Failure Mode | What Happens | User Impact | Mitigation |
|-------------|-------------|-------------|-----------|
| **Wrong suggestion** | System recommends something incorrect or irrelevant | User wastes time following bad advice; trust erodes | Show reasoning so user can evaluate. Make dismissal easy. Track suggestion acceptance rate. |
| **Overconfident display** | System presents uncertain information as fact | User makes bad decision based on false certainty | Calibrate confidence display. Show uncertainty ranges. Never state as fact without strong evidence. |
| **Alert fatigue** | Too many suggestions; user ignores everything | User misses genuinely important suggestions among the noise | Rate-limit suggestions. Prioritize by relevance. Batch low-priority items. |
| **Creepy precision** | System infers something the user didn't explicitly share | User feels surveilled; trust collapses | Explain data sources. Show what data feeds the intelligence. Give control over what's tracked. |
| **Skill atrophy** | User relies on intelligence and loses ability to do the task manually | User can't function when intelligence is unavailable | Keep manual path equally accessible. Show reasoning so user learns, not just follows. |
| **Stale intelligence** | System's model or data becomes outdated | Suggestions become increasingly wrong; user notices before system does | Show data freshness. Degrade gracefully when data is stale. Don't suggest when confidence is low. |
| **Bias amplification** | System reinforces existing patterns rather than helping user improve | User gets stuck in local optimum; diverse options suppressed | Show diverse options. Explain if suggestions are based on past behavior. Offer "show me something different." |
| **Context mismatch** | System suggests based on wrong context | Suggestion is technically right but irrelevant right now | Make context explicit in reasoning. Let user correct the system's context assumption. |

### Failure Severity Assessment

For each smart feature, assess:
```yaml
failure_assessment:
  feature: "__FILL__"

  failure_modes:
    - mode: "__FILL__"
      likelihood: __SELECT__    # high | medium | low
      impact: __SELECT__        # high | medium | low
      mitigation: "__FILL__"
      recovery_path: "__FILL__" # How user recovers from this failure
```

---

## When Intelligence Helps vs. Harms

### Intelligence Helps When

| Condition | Why It Works | Example |
|-----------|-------------|---------|
| **Repetitive task** | User does it often; automation saves real time | Auto-categorizing recurring expenses |
| **Data-rich context** | System has information the user would have to look up | "This KR is 20% behind pace compared to similar KRs" |
| **Pattern recognition** | System spots patterns humans miss at scale | "3 of your 5 projects follow a similar risk pattern" |
| **Defaults from history** | System learns user's preferences | Pre-selecting the user's usual project when creating a task |
| **Proactive warning** | System notices something the user hasn't checked yet | "Your deadline is tomorrow and this task has no assignee" |

### Intelligence Harms When

| Condition | Why It Fails | Example |
|-----------|-------------|---------|
| **Subjective judgment** | System presents opinion as insight | "This is a good objective" (by whose criteria?) |
| **Low data confidence** | System guesses with insufficient evidence | "You should focus on Q3 goals" (based on what?) |
| **High-stakes decision** | System automates something that needs human judgment | Auto-approving budget requests |
| **Novelty required** | System optimizes for past patterns when user needs new thinking | Always suggesting the same type of KR structure |
| **Trust not established** | Feature appears before user trusts the product | AI suggestions on first use before user has entered any data |

---

## Degradation Rules

Intelligence features must degrade gracefully when conditions aren't met.

| Condition | Behavior |
|-----------|----------|
| **Insufficient data** | Feature hides completely. No "We don't have enough data yet" placeholder. |
| **Low confidence** | Feature shows as possibility, not suggestion. Or hides entirely. |
| **Stale data** | Feature shows staleness warning: "Based on data from [date] — may not reflect recent changes." |
| **System error** | Feature hides. No error message cluttering the UI. Product works without it. |
| **User disabled** | Feature disappears. No "You turned this off" reminders or nag messages. |

### The Core Degradation Principle

> **The product must be fully functional without any intelligence features. Intelligence enhances; it never gates.**

If removing all smart features would break the product, the product has a dependency problem — not an intelligence design problem.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/intelligence/CONTRACT.md` | Scope, rules, activation |
| `_extensions/intelligence/FRAMEWORK.md` | Intelligence spectrum, confidence display, suggestion design |
| `_extensions/intelligence/INVARIANTS.md` | Intelligence-specific invariants |
| `_expectations/PRE-BUILD.md` | Restraint Gate (this extends it) |
| `_expectations/FRAMEWORK.md` | Feature Classification (Dangerous refined) |
