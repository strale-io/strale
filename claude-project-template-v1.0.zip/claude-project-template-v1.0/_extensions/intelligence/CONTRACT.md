# Intelligence Design Framework — Contract

> Designing smart features that enhance user agency, not undermine it.

**Extension Type:** Capability Extension
**Status:** `active`
**Activation:** Add `intelligence` to `capability_extensions` list in `config/manifest.yaml`

---

## What This Extension Does

This extension provides a framework for designing product intelligence — features that use data, heuristics, or algorithms to help users make better decisions or work faster. It governs the experience design of smart features, not the technical implementation.

Without this extension, the system classifies intelligence features as "Dangerous" by default (per Feature Classification in `_expectations/FRAMEWORK.md`). With this extension, intelligence features have a path to prove they're safe through the Intelligence Restraint Gate — a structured evaluation specific to smart features.

| Without Extension | With Extension |
|-------------------|---------------|
| AI suggestions → automatically "Dangerous" | AI suggestions → evaluated through Intelligence Restraint Gate |
| No framework for confidence display | Calibrated confidence display required |
| No guidance on suggestion design | Suggestion design rules enforced |
| "Smart" = risky | "Smart" = designed with guardrails |

---

## Scope

| Responsible For | Must Not Contain |
|----------------|-----------------|
| Intelligence spectrum positioning (insight → autonomy) | ML/AI model architecture or training |
| Confidence display calibration | Statistical methods or algorithms |
| Suggestion design rules | Data pipeline or ETL design |
| Agency preservation testing | A/B testing or experimentation frameworks |
| Intelligence failure mode analysis | Chatbot or copilot conversation design |
| Intelligence Restraint Gate | Ethical AI policy (this is design quality, not ethics) |
| Graceful degradation rules | Performance benchmarking |

---

## Activation

Add to `config/manifest.yaml`:
```yaml
capability_extensions:
  - intelligence
```

When active, this extension:
- Adds Intelligence Restraint Gate to Gate 0 (conditional, for surfaces with smart features)
- Extends the Confidence Contract to cover algorithmic confidence
- Adds intelligence critique dimensions (conditional)
- Refines the "Dangerous" classification: intelligence features are evaluated through the Intelligence Restraint Gate rather than automatically classified as Dangerous

When inactive, intelligence features remain classified as "Dangerous" per the default Feature Classification system.

---

## Rules

### Extension Rules

| Rule | Description |
|------|-------------|
| **Additive only** | This extension adds the Intelligence Restraint Gate; it does not remove or weaken the existing Restraint Gate |
| **Conditional enforcement** | All checklist items fire only when `intelligence` is in `capability_extensions` |
| **No new primitives** | This extension uses existing UI components — it provides design guidance, not building blocks |
| **Compatible with all product classes** | Intelligence features exist in workflow apps, data platforms, creative tools, etc. |

### Intelligence Rules

| Rule | Description |
|------|-------------|
| **Declare spectrum position** | Every smart feature must declare its position on the intelligence spectrum |
| **Confidence calibrated** | Confidence display must match actual confidence level |
| **Agency preserved** | Every smart feature must pass the Agency Test |
| **Manual path exists** | Every automated path must have an equally accessible manual alternative |
| **Reasoning visible** | Users can always see why the system suggests something |
| **Graceful degradation** | When data is insufficient, intelligence hides — it doesn't guess |

---

## The Intelligence Spectrum
Passive ──────────────────────────────────────────── Active
Insight    Suggestion    Default    Automation    Autonomy
"FYI"      "Try this?"   "I set     "I did        "I do
                          this for    this for      this for
                          you, but    you."         you always."
                          change it."

Each position has different design requirements:

| Level | Trust Required | Undo Required | Failure Impact | User Agency |
|-------|---------------|---------------|----------------|-------------|
| **Insight** | Low — just showing data | N/A — nothing changed | Low — ignore it | Highest — user decides everything |
| **Suggestion** | Low-Medium — user decides | N/A — nothing changed until accepted | Low — dismiss it | High — user chooses whether to accept |
| **Smart Default** | Medium — user trusts reasonable start | Yes — must be changeable | Medium — wrong start wastes time | Medium — user must notice and change |
| **Automation** | High — user trusts system to act | Yes — must be reversible | High — wrong action creates mess | Low — user must undo if wrong |
| **Autonomy** | Very High — user delegates | Must be disableable | Very High — cascading wrong actions | Lowest — user out of the loop |

**Rule of thumb:** Start at the passive end. Move toward active only when trust is established and the stakes justify it.

---

## Exceptions to Core Rules

| Core Rule | Exception | Rationale |
|-----------|-----------|-----------|
| "Dangerous" classification for intelligence features | Intelligence features go through Intelligence Restraint Gate instead of automatic "Dangerous" classification | The existing classification is too blunt — some intelligence is genuinely valuable. The Intelligence Restraint Gate is stricter than automatic classification because it requires proof of safety, not just absence of concern. |

**Constraint:** This exception only applies when the `intelligence` capability extension is active. When inactive, the default "Dangerous" classification applies. Features that fail the Intelligence Restraint Gate are still classified as "Dangerous" — the gate is a path to prove safety, not a blanket pass.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/intelligence/FRAMEWORK.md` | Intelligence design framework |
| `_extensions/intelligence/GUARDRAILS.md` | Intelligence Restraint Gate and failure modes |
| `_extensions/intelligence/INVARIANTS.md` | Intelligence-specific invariants |
| `_expectations/FRAMEWORK.md` | Feature Classification (Dangerous category refined) |
| `_expectations/PRE-BUILD.md` | Restraint Gate (extended for intelligence) |
| `_expectations/CONTRACTS.md` | Confidence Contract (extended for algorithmic confidence) |
| `config/manifest.yaml` | `capability_extensions` activation |
