# Intelligence Design Framework

> How to design smart features that make users more capable, not more dependent.

**Parent:** `_extensions/intelligence/CONTRACT.md`

---

## The Agency Test

The fundamental question for every intelligence feature:

> **"Does this feature make the user more capable, or does it make the user more dependent?"**

| Outcome | Characteristics | Examples |
|---------|----------------|---------|
| **Agency-enhancing** | User learns, gets faster, makes better decisions, understands the domain better | "Based on your last 50 check-ins, this KR typically falls behind at this point" (user learns a pattern) |
| **Agency-reducing** | User stops thinking, defers to the machine, can't function without it | "We recommend setting your target to 85%" (user doesn't understand why) |

This test applies at every level of the intelligence spectrum. Even an Insight can be agency-reducing if it presents conclusions without reasoning.

---

## Confidence Display

Smart features must communicate their confidence level honestly. The display treatment must match the actual confidence — never show certainty you don't have.

### Confidence Levels

| Level | Confidence | Display Treatment | Language Pattern | Example |
|-------|-----------|-------------------|-----------------|---------|
| **High** | >80% — strong evidence | State as fact with source | "[Specific evidence] shows [conclusion]" | "3 of 5 KRs are behind their target pace" |
| **Medium** | 50–80% — reasonable evidence | Suggest with evidence | "[This] may [conclusion] — [evidence]" | "This objective may be at risk — 2 KRs missed their last check-in" |
| **Low** | <50% — weak signal | Offer as possibility | "You might want to [action] — [similar pattern]" | "You might want to check on this — similar objectives have struggled at this point" |
| **Unknown** | Insufficient data | Don't show anything | Silence | (Feature doesn't appear) |

### Confidence Rules

| Rule | Description |
|------|-------------|
| **Never overstate** | Display confidence must be ≤ actual confidence. Understating is acceptable; overstating is forbidden. |
| **Source always available** | User can always find out why the system believes something — "Based on..." must be accessible. |
| **Unknown = silent** | If confidence is unknown, the feature hides. Silence is better than guessing. |
| **Confidence is per-item** | A system might have high confidence about one prediction and low about another. Display each accurately. |
| **Calibration over time** | If the system learns, confidence display should improve. But initial releases should be conservative. |

### Alignment with Confidence Contract

This framework extends the existing Confidence Contract (`_expectations/CONTRACTS.md`):

| Confidence Contract (Core) | Intelligence Extension |
|---------------------------|----------------------|
| No implied quality without criteria | + Algorithmic suggestions show their reasoning |
| Rankings explained | + ML-generated rankings show the model's basis |
| Uncertainty explicit | + Confidence levels are calibrated to evidence strength |
| Data sources visible | + Data inputs to intelligence features are disclosed |

---

## Suggestion Design

Suggestions are the most common intelligence feature. They're powerful when done well and corrosive when done poorly.

### The Five Rules

| Rule | Requirement | Rationale |
|------|-------------|-----------|
| **1. Always dismissible** | Suggestions are never modal or blocking. User can ignore them completely. | Suggestions are help, not gates. |
| **2. Show reasoning** | Suggestions explain why they're being made, not just what they recommend. | Opaque suggestions erode trust. |
| **3. Don't accumulate** | Old, unacted suggestions expire. No pile-up of stale recommendations. | Accumulation creates noise and guilt. |
| **4. Contextual timing** | Suggestions appear when relevant to the user's current task, not in a notification dump. | Right time = helpful. Wrong time = interruption. |
| **5. Respect expertise** | Don't explain the obvious to expert users. Adjust suggestion depth to user's demonstrated proficiency. | Patronizing suggestions are dismissed and ignored. |

### Suggestion Lifecycle

TRIGGER    → Condition that activates the suggestion
DISPLAY    → How and where the suggestion appears
REASONING  → Why the system suggests this (visible on demand)
ACCEPT     → User takes the suggestion → action occurs
DISMISS    → User rejects the suggestion → it goes away
EXPIRE     → Unacted suggestion disappears after time/relevance window


### Suggestion Declaration

For each intelligence feature that makes suggestions:
```yaml
suggestion:
  name: "__FILL__"
  trigger: "__FILL__"                    # What condition activates this suggestion
  spectrum_level: __SELECT__             # insight | suggestion | smart_default | automation | autonomy
  confidence_source: "__FILL__"          # Where does confidence come from

  display:
    location: "__FILL__"                 # Where in the UI does this appear
    format: __SELECT__                   # inline_hint | card | banner | popover | badge
    dismissible: true                    # Must be true for suggestions

  reasoning:
    visible_by_default: __SELECT__       # yes | no (if no, available on demand)
    reasoning_text: "__FILL__"           # Template: "Based on [source], [conclusion]"

  lifecycle:
    expiry: "__FILL__"                   # When does the suggestion expire if not acted on
    frequency: __SELECT__                # once | until_acted | periodic
    max_concurrent: __FILL__             # How many suggestions of this type visible at once

  agency_test:
    user_learns: "__FILL__"              # What does the user learn from this suggestion
    manual_alternative: "__FILL__"       # How would the user accomplish this without the suggestion
    dependency_risk: __SELECT__          # none | low | medium | high
```

---

## Smart Default Design

Smart defaults pre-fill values based on context, history, or heuristics. They save time when right and create confusion when wrong.

### Smart Default Rules

| Rule | Description |
|------|-------------|
| **Always changeable** | Smart defaults are starting points, never locked values |
| **Visually marked** | Smart defaults are visually distinguishable from user-entered values (aligns with CF-004) |
| **Source disclosed** | "Suggested based on..." tooltip explains why this default was chosen |
| **Conservative** | When uncertain, use a generic default rather than a smart one. Wrong smart defaults are worse than blank fields. |

### Smart Default Declaration
```yaml
smart_default:
  field: "__FILL__"
  source: "__FILL__"                     # What data/heuristic drives this default
  confidence: __SELECT__                 # high | medium | low
  visual_treatment: "__FILL__"           # How it's distinguished from user-entered
  fallback: "__FILL__"                   # What happens if smart default can't be determined
```

---

## Automation Design

Automations perform actions on behalf of the user. They're the second-highest level on the spectrum and require high trust.

### Automation Rules

| Rule | Description |
|------|-------------|
| **Always reversible** | Every automated action must have an undo path |
| **Notification required** | User must be informed when an automation acts (even if they configured it) |
| **Scope visible** | User can see exactly what the automation will affect before enabling |
| **Disableable** | User can turn off any automation at any time |
| **Audit trail** | Automated actions are logged and distinguishable from manual actions |

### Automation Declaration
```yaml
automation:
  name: "__FILL__"
  trigger: "__FILL__"                    # What activates this automation
  action: "__FILL__"                     # What the automation does
  scope: "__FILL__"                      # What entities/data are affected

  safeguards:
    reversible: true                     # Must be true
    notification: __SELECT__             # before_action | after_action | both
    disable_path: "__FILL__"             # How user turns this off
    audit_log: true                      # Must be true

  failure_handling:
    on_error: __SELECT__                 # retry | skip_and_notify | halt_and_notify
    user_notification: "__FILL__"        # What user sees when automation fails
```

---

## Autonomy Design

Autonomy is the highest level — the system acts permanently on the user's behalf. This requires the highest trust and the strongest safeguards.

### When Autonomy Is Appropriate

Autonomy is only appropriate when:
- The task is repetitive and well-understood
- The consequences of errors are reversible
- The user has demonstrated trust through lower-level intelligence features
- The time savings are substantial

### Autonomy Rules

| Rule | Description |
|------|-------------|
| **Opt-in only** | Autonomy is never the default. User must explicitly enable it. |
| **Trial period** | Before going fully autonomous, show what the system would do (shadow mode). |
| **Override always** | Manual control is always one click away. |
| **Reporting** | Regular summary of autonomous actions (daily/weekly digest). |
| **Kill switch** | One-click disable that immediately stops all autonomous behavior. |

---

## What This Framework Does NOT Do

- **Does not prescribe ML/AI techniques.** Model architecture, training data, and algorithm selection are engineering decisions.
- **Does not cover chatbots or copilots.** Conversational AI is a different product class entirely.
- **Does not make ethical judgments.** This framework evaluates design quality of intelligence UX, not the ethics of AI use.
- **Does not require machine learning.** "Intelligence" includes simple heuristics, rules-based logic, and data-driven defaults — not just ML/AI.
- **Does not mandate intelligence.** Products with no smart features should not activate this extension.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/intelligence/CONTRACT.md` | Scope, rules, activation |
| `_extensions/intelligence/GUARDRAILS.md` | Intelligence Restraint Gate, failure modes |
| `_extensions/intelligence/INVARIANTS.md` | Intelligence-specific invariants |
| `_expectations/CONTRACTS.md` | Confidence Contract (extended) |
| `_expectations/PRE-BUILD.md` | Restraint Gate (extended) |
| `_expectations/FRAMEWORK.md` | Feature Classification (Dangerous refined) |
