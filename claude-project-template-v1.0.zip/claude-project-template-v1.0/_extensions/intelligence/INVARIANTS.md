# Intelligence Invariants

> Non-negotiable requirements for smart features.

**Parent:** `_extensions/intelligence/CONTRACT.md`
**Activation:** These invariants apply only when `intelligence` is in `capability_extensions`.

---

## Suggestion Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| IN-001 | **Suggestions are always dismissible without consequence.** Dismissing a suggestion never triggers a negative outcome, nag message, or repeated prompt. | Suggestions are help, not pressure. | Dismiss a suggestion → verify no negative feedback, no re-prompt, no "Are you sure?" |
| IN-002 | **Suggestions show reasoning on demand.** Every suggestion has accessible reasoning: "Based on [source], [conclusion]." | Opaque suggestions erode trust. | Click/hover reasoning affordance on any suggestion → verify reasoning is displayed. |
| IN-003 | **Suggestions don't accumulate.** Unacted suggestions expire within their defined relevance window. No stale suggestion pile-up. | Stale suggestions create noise and guilt. | Leave suggestions unacted for the defined window → verify they disappear. |

---

## Confidence Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| IN-004 | **Confidence display matches actual confidence.** High-confidence insights are stated as facts with sources. Low-confidence insights are framed as possibilities. Unknown confidence = silence. | Overstating confidence causes bad decisions. | Review each intelligence feature → verify display treatment matches confidence level per FRAMEWORK.md table. |
| IN-005 | **Smart defaults are visually distinguished from user-entered values.** Pre-filled values from intelligence are styled differently and have "Suggested based on..." tooltip. | Users must know what they entered vs. what the system guessed. | Inspect any form with smart defaults → verify visual distinction and source tooltip. |

---

## Agency Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| IN-006 | **Manual path exists for every automated path.** Every task that intelligence can perform automatically has an equally accessible manual alternative. | Users must be able to function without intelligence. | For each automation → verify the manual path exists and is no more than 1 extra click away. |
| IN-007 | **Intelligence features degrade gracefully.** When data is insufficient, the feature hides — it doesn't guess or show a placeholder. | Guessing is worse than silence. | Simulate insufficient data → verify feature disappears without error messages or empty states. |
| IN-008 | **Automated actions are always reversible.** Every action performed by intelligence on behalf of the user can be undone. | Wrong automated actions shouldn't create permanent damage. | Trigger an automation → verify undo is available. |

---

## Transparency Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| IN-009 | **Data sources are disclosed.** Users can find out what data feeds each intelligence feature. | Users deserve to know what's being used to make suggestions. | Navigate to any intelligence feature → verify data source disclosure is accessible. |
| IN-010 | **Automated actions are logged and distinguishable.** Activity feeds and audit trails mark automated actions distinctly from manual ones. | Users need to know what the system did vs. what they did. | Review activity feed → verify automated actions have distinct visual treatment and "automated" label. |
| IN-011 | **Intelligence never gates functionality.** Removing all intelligence features leaves a fully functional product. Smart features enhance — they never block core workflows. | Products must work without intelligence. | Mentally remove all intelligence features → verify all core flows still work. |

---

## Control Invariants

| ID | Invariant | Rationale | Test |
|----|-----------|-----------|------|
| IN-012 | **Users can disable any intelligence feature.** Every smart feature has an off switch. Disabling is immediate and persistent. | User control is paramount. | Find every intelligence feature → verify each has a disable option. |
| IN-013 | **Disabled intelligence stays disabled.** Once a user turns off an intelligence feature, it doesn't re-enable after updates, resets, or time. No nag messages about re-enabling. | Respecting user choices builds trust. | Disable a feature → update the product → verify feature remains disabled. No "Try again?" prompts. |

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/intelligence/CONTRACT.md` | Scope, rules, activation |
| `_extensions/intelligence/FRAMEWORK.md` | Framework these invariants enforce |
| `_extensions/intelligence/GUARDRAILS.md` | Intelligence Restraint Gate |
| `_invariants/REGISTRY.md` | Core system invariants (these are extension-specific) |
| `_expectations/CONTRACTS.md` | Confidence Contract (CF-001 through CF-005) |
