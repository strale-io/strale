# Progressive Disclosure Protocol

> How a product reveals its capabilities across the user's lifecycle.

**Parent:** `_extensions/disclosure/CONTRACT.md`

---

## Why This Exists

Products that feel "simple on day 1 and powerful on day 30" didn't get there by accident. They designed their disclosure arc — what's visible when, what triggers reveals, and how complexity grows over time.

The core system has within-surface disclosure (`_interaction/PROGRESSION.md` — expand/collapse, tabs, hover reveal). This protocol adds the strategic layer: across the user's entire relationship with the product, how does complexity grow?

---

## Lifecycle Stages

Every product has users at different stages of familiarity. Each stage has a goal, a complexity budget, and a set of features that should be visible.

| Stage | Timeframe | Goal | Complexity Budget |
|-------|-----------|------|-------------------|
| **First Contact** | 0–30 seconds | Understand what this product is and does | Minimal — one core concept |
| **First Value** | 1–5 minutes | Experience the product's core value once | Low — one primary flow |
| **Adoption** | Day 1–7 | Integrate into routine, complete core flows | Medium — core flows + navigation |
| **Proficiency** | Week 2–4 | Use all expected features effectively | Full — all expected features |
| **Mastery** | Month 2+ | Use power features, customize, optimize | Full + expert features |

### Stage Properties

For each stage, declare:
```yaml
lifecycle_stage:
  stage: __SELECT__  # first_contact | first_value | adoption | proficiency | mastery

  visible_features:
    - "__FILL__"      # Features actively surfaced at this stage

  hidden_features:
    - "__FILL__"      # Features available but not promoted

  locked_features:
    - "__FILL__"      # Features not available until a later stage (if applicable)

  advancement_trigger: "__FILL__"  # What moves the user to the next stage

  complexity_budget:
    max_navigation_items: __FILL__   # How many top-level nav items visible
    max_actions_per_surface: __FILL__ # How many primary/secondary actions
    max_concepts_introduced: __FILL__ # How many new concepts at this stage
```

### Timeframes Are Approximate

The timeframes above are guidelines, not mandates. A simple product might compress First Contact through Adoption into a single session. A complex enterprise product might have a First Value stage that takes a full onboarding week. Declare your product's actual timeframes.

---

## The Aha Moment

Every product has a moment where the user "gets it" — they understand why this product exists and what it can do for them. Designing the shortest path to that moment is the single most important disclosure decision.

### Identifying the Aha Moment
```yaml
aha_moment:
  statement: "__FILL__"        # What the user realizes (be specific)
  trigger: "__FILL__"          # What event/action causes the realization
  evidence: "__FILL__"         # How you know the user "got it" (observable behavior)
  time_target: "__FILL__"      # How quickly should a new user reach this?

  path_to_aha:
    - step: 1
      action: "__FILL__"
      obstacle: "__FILL__"     # What might prevent the user from taking this step
      mitigation: "__FILL__"   # How the product helps overcome the obstacle
```

### Aha Moment Examples (Generic)

| Product Type | Aha Moment | Path |
|-------------|-----------|------|
| **Project management tool** | "My whole team can see what's due this week" | Create project → Add tasks → Invite teammate → View shared board |
| **Note-taking app** | "I can structure this however I want" | Open page → Add a heading → Drag blocks → See flexible layout |
| **Analytics dashboard** | "I can answer my own questions without asking engineering" | Open dashboard → Apply filter → See updated chart → Export insight |
| **OKR tracker** | "I can see at a glance which objectives are at risk" | Create objective → Add KRs → Record check-in → View dashboard with status |

### The Aha Path Test

> "What is the minimum number of steps from sign-up to aha moment?"

If the answer is more than 5 steps, look for ways to shortcut (templates, sample data, guided creation). If it's more than 10, the onboarding needs fundamental rethinking.

---

## Complexity Budget

At each lifecycle stage, the product has a "budget" for how much complexity it can show. Exceeding the budget overwhelms users at that stage.

### Budget Principles

| Principle | Description |
|-----------|-------------|
| **Budget grows with trust** | First Contact has the smallest budget. Mastery has the largest. This mirrors the Progressive Trust Architecture in `_ui/SYSTEM.md`. |
| **Budget is per-surface** | A dashboard at First Value stage shows less than the same dashboard at Proficiency stage. |
| **Over-budget requires justification** | If a surface exceeds its stage's complexity budget, document why in `_decisions/REGISTRY.md`. |
| **Under-budget is fine** | Simpler is always acceptable. |

### Budget Guidelines

| Stage | Nav Items | Actions per Surface | New Concepts | Feature Depth |
|-------|-----------|-------------------|--------------|---------------|
| **First Contact** | 1–2 | 1 primary | 1 | Core only |
| **First Value** | 2–3 | 1 primary + 1 secondary | 2–3 | Core flow |
| **Adoption** | 3–5 | 2 primary + 2 secondary | 3–5 | Core + common |
| **Proficiency** | Full nav | Full action set | All expected | Full product |
| **Mastery** | Full nav + shortcuts | Full + power actions | All + expert | Full + advanced |

These are guidelines. Adjust for your product's complexity. A simple product might use Proficiency budgets at Adoption. A complex product might need stricter budgets.

---

## Starter Content Strategy

Empty products are hostile to new users. A brand-new user who sees a blank dashboard with "No data yet — get started!" has learned nothing about the product's value. The product should demonstrate its value before asking the user to create it.

### Strategy Options

| Strategy | How It Works | Best For | Risk |
|----------|-------------|----------|------|
| **Template gallery** | User picks a pre-built starting point | Products with diverse use cases (Notion, Airtable) | User picks wrong template, gets confused |
| **Sample data** | Product comes with realistic demo data | Products where value comes from seeing data (dashboards, analytics) | User can't distinguish sample from real data |
| **Guided creation** | Product walks user through creating their first item | Products with a clear first action (Asana: create project) | User feels forced, skips, misses value |
| **Smart defaults** | Product pre-configures based on signup context | Products with predictable setups (industry-specific tools) | Wrong defaults create mistrust |
| **Empty with purpose** | Intentionally empty, but the empty state teaches | Products where the empty state is the starting canvas (Figma) | User doesn't know what to create |

### Declaring Your Strategy
```yaml
starter_content:
  strategy: __SELECT__  # template_gallery | sample_data | guided_creation | smart_defaults | empty_with_purpose
  rationale: "__FILL__"

  what_user_sees_first: "__FILL__"    # Describe the first-run experience
  aha_moment_supported: "__FILL__"    # How this strategy helps reach the aha moment
  cleanup_path: "__FILL__"            # How user removes starter content when ready (if applicable)
```

### The First-Run Principle

> **Show the product doing its job before asking the user to make it do the job.**

A dashboard with sample data teaches the user what the dashboard will look like with their data. A project management tool with a sample project shows how tasks, statuses, and assignments work together. The user learns by seeing, then recreates with their own content.

---

## Feature Discovery Mechanisms

As the user advances through lifecycle stages, new features become relevant. How do they learn about these features?

### Discovery Mechanisms

| Mechanism | What It Is | When to Use | Risk | Mitigation |
|-----------|-----------|-------------|------|-----------|
| **Contextual hints** | Subtle suggestion when a feature would help right now | User is doing something that a hidden feature would improve | Distracting if wrong or poorly timed | Only trigger when confidence is high; dismiss permanently |
| **Empty state CTAs** | Call to action when user reaches a feature's space but hasn't used it | User navigates to an unused area | Wasted if user doesn't need the feature | Make the CTA informative, not just "Try this!" |
| **Progressive menus** | Menu items appear as usage patterns warrant | User's behavior suggests readiness for a feature | Unpredictable — user may be confused by new items | Announce additions: "New: [Feature] now available" |
| **Milestone reveals** | Feature unlocked/shown after user accomplishes something | User has demonstrated readiness through behavior | Gamification risk — feels patronizing | Frame as capability, not reward |
| **Tooltip tours** | Guided walkthrough highlighting new features | Major product updates or first-time encounters | Dismissed without reading; annoying on repeat | Allow skip, don't repeat, keep extremely short |
| **Inline education** | Brief explanation embedded where the feature lives | Complex features that need context | Clutters the interface for experienced users | Progressive disclosure — show once, collapse after |

### Choosing Mechanisms
```yaml
feature_discovery:
  feature: "__FILL__"
  target_stage: __SELECT__  # adoption | proficiency | mastery
  mechanism: __SELECT__     # contextual_hint | empty_state_cta | progressive_menu | milestone_reveal | tooltip_tour | inline_education
  trigger: "__FILL__"       # What event/behavior triggers the discovery
  dismissal: __SELECT__     # permanent | session | reset_after_period
  frequency: __SELECT__     # once | until_used | periodic
```

### Anti-Patterns

| Anti-Pattern | Problem | Alternative |
|-------------|---------|------------|
| **Feature dump on first run** | Overwhelms; user remembers nothing | Stage reveals across lifecycle |
| **Mandatory tour** | Users skip, resent being forced | Optional, dismissible, focused |
| **"Did you know?" popups** | Interruptive, patronizing | Contextual hints tied to user's current task |
| **Badge spam** | "New!" on everything trains user to ignore badges | Reserve for genuinely new, relevant features |
| **Changelog as discovery** | Users don't read changelogs | In-product contextual reveals |

---

## Lifecycle-Aware Surface Design

When the disclosure extension is active, every surface should consider which lifecycle stages it serves.

### Single-Stage Surfaces

Some surfaces exist only for certain stages:
- **Onboarding wizard** → First Contact / First Value only
- **Advanced settings** → Proficiency / Mastery only
- **Getting started guide** → First Value / Adoption only

These surfaces can be aggressively simple because they serve a narrow audience.

### Multi-Stage Surfaces

Most surfaces serve users across multiple stages. A dashboard is seen by Day 1 users and Day 100 users. Multi-stage surfaces need disclosure strategies:
```yaml
surface_disclosure:
  surface: SURF-__FILL__
  stages_served: [__FILL__]  # e.g., [first_value, adoption, proficiency, mastery]

  disclosure_strategy:
    first_value:
      visible: ["__FILL__"]     # What this surface shows at First Value
      hidden: ["__FILL__"]      # What's available but not promoted
    adoption:
      visible: ["__FILL__"]
      hidden: ["__FILL__"]
    proficiency:
      visible: ["__FILL__"]     # Likely: everything
```

### Integration with PROGRESSION.md

The disclosure protocol determines **what** to show at each stage. `_interaction/PROGRESSION.md` determines **how** to show/hide it (expand/collapse, tabs, hover reveal, etc.).

| This Protocol Decides | PROGRESSION.md Implements |
|----------------------|--------------------------|
| "Advanced filters should be hidden at Adoption stage" | "Use expand/collapse with 'Advanced Filters' label" |
| "Power actions should appear at Mastery" | "Add to Level 3 disclosure (behind 'More')" |
| "All features visible at Proficiency" | "Promote from Level 2 to Level 1" |

---

## What This Protocol Does NOT Do

- **Does not replace PROGRESSION.md.** That handles within-surface mechanics. This handles lifecycle strategy.
- **Does not require user analytics.** It works with design review and product judgment, not behavioral data.
- **Does not mandate a specific onboarding style.** Wizard, empty-state, template gallery — the protocol helps you choose, not choose for you.
- **Does not dictate specific UI.** Stepper components, progress indicators, coach marks — those are implementation decisions using existing `_ui/` components.
- **Does not prescribe feature gating.** "Locked until Proficiency" is one option, but most disclosure is about visibility, not access control.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/disclosure/CONTRACT.md` | Scope, rules, activation |
| `_extensions/disclosure/TEMPLATES.md` | First-run audit, complexity staging worksheet |
| `_interaction/PROGRESSION.md` | Within-surface disclosure (complementary) |
| `_ui/SYSTEM.md` | Progressive Trust Architecture (aligned lifecycle) |
| `_expectations/PRE-BUILD.md` | Feature classification considers complexity budget |
| `_flows/FRAMEWORK.md` | Flows may be stage-specific (e.g., onboarding flow for First Value) |
