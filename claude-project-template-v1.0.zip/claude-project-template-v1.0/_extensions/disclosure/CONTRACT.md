# Progressive Disclosure Protocol — Contract

> Strategic framework for staging complexity across the user's lifecycle.

**Extension Type:** Capability Extension
**Status:** `active`
**Activation:** Add `disclosure` to `capability_extensions` list in `config/manifest.yaml`

---

## What This Extension Does

This extension governs **lifecycle-level disclosure** — how a product reveals its capabilities over time, from first contact to mastery. It operates at a higher level than `_interaction/PROGRESSION.md`, which governs within-surface disclosure (expand/collapse, hover reveal, tabs).

| Level | Governs | Example |
|-------|---------|---------|
| **Within-surface** (`_interaction/PROGRESSION.md`) | Which elements are visible vs. hidden on a single screen | "Advanced Options" behind an expand chevron |
| **Across-lifecycle** (this extension) | Which features are visible at first use vs. after 20 uses | New users see 3 menu items; power users see 12 |

Both levels are needed. This extension doesn't replace PROGRESSION.md — it gives it strategic direction.

---

## Scope

| Responsible For | Must Not Contain |
|----------------|-----------------|
| Lifecycle stage definitions | Specific UI components (use `_ui/`) |
| Aha moment identification | Analytics implementation (that's engineering) |
| Complexity budgeting per stage | User tracking or behavioral data models |
| Starter content strategy guidance | Specific onboarding copy or content |
| Feature discovery mechanism selection | Animation or motion specs (use `_interaction/PHYSICS.md`) |
| First-run audit framework | A/B testing or experimentation frameworks |

---

## Activation

Add to `config/manifest.yaml`:
```yaml
capability_extensions:
  - disclosure
```

When active, this extension:
- Adds lifecycle stage analysis to Pre-Build (conditional)
- Adds First-Run Audit template to Gate 0 (conditional, for first-run surfaces only)
- Adds complexity budget check to feature classification
- Cross-references with `_interaction/PROGRESSION.md` disclosure levels

When inactive, all disclosure-related guidance is ignored. Existing within-surface disclosure (`PROGRESSION.md`) continues to function normally.

---

## Rules

### Extension Rules

| Rule | Description |
|------|-------------|
| **Additive only** | This extension adds guidance; it does not override core system rules or product class extensions |
| **Conditional enforcement** | All checklist items from this extension fire only when `disclosure` is in `capability_extensions` |
| **No new primitives** | This extension uses existing UI components and patterns — it provides strategic direction, not new building blocks |
| **Compatible with all product classes** | Disclosure strategy applies to workflow apps, data platforms, creative tools, etc. |

### Disclosure Rules

| Rule | Description |
|------|-------------|
| **Declare lifecycle stage** | Every surface must declare which lifecycle stage(s) it targets |
| **Complexity budget enforced** | Features visible at a given stage must fit within that stage's complexity budget |
| **Aha moment designed** | The product must have a documented aha moment with a designed path to reach it |
| **Starter content required** | Products must declare their empty-state strategy (no blank-page-on-first-use without justification) |
| **Discovery mechanisms chosen** | Feature discovery must use declared mechanisms, not ad-hoc reveals |

---

## Exceptions to Core Rules

None. This extension adds strategic guidance without modifying any core constraints.

---

## Loading Order
Core System → Product Class Extension → Capability Extensions → Project Overrides

Capability extensions load after product class extensions. They cannot override core or product class rules. Multiple capability extensions can be active simultaneously.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/disclosure/PROTOCOL.md` | Strategic disclosure framework |
| `_extensions/disclosure/TEMPLATES.md` | First-run audit and complexity staging tools |
| `_interaction/PROGRESSION.md` | Within-surface disclosure (complementary, not replaced) |
| `_ui/SYSTEM.md` | Progressive Trust Architecture (aligned with lifecycle stages) |
| `_expectations/PRE-BUILD.md` | Complexity budget check during feature classification |
| `config/manifest.yaml` | `capability_extensions` activation |
