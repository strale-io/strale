# Progressive Disclosure Templates

> Tools for designing and auditing lifecycle disclosure. Use these to implement the strategic framework in `PROTOCOL.md`.

---

## When to Use These Templates

| Situation | Template |
|-----------|----------|
| Auditing a new user's first experience | First-Run Audit |
| Deciding what to show at each lifecycle stage | Complexity Staging Worksheet |
| Identifying and designing the aha moment path | Aha Moment Design |
| Choosing discovery mechanisms for features | Feature Discovery Plan |

---

## First-Run Audit

A structured review of what a brand-new user sees, does, and feels in their first session. This is the disclosure equivalent of a critique cycle — but focused on the onboarding experience specifically.

### When to Run

Run this audit:
- Before shipping any first-run surface (onboarding, welcome screen, empty states)
- After significant changes to the product's navigation or core flow
- When user feedback suggests confusion during early use

### The Audit

Walk through the product as a brand-new user. For each step:
```yaml
first_run_audit:
  product: "__FILL__"
  date: "__FILL__"
  auditor: "__FILL__"

  steps:
    - step: 1
      what_user_sees: "__FILL__"
      what_user_does: "__FILL__"
      what_user_learns: "__FILL__"
      what_user_feels: "__FILL__"
      time_spent: "__FILL__"        # Estimated seconds
      confusion_risk: __SELECT__    # none | low | medium | high
      if_confused: "__FILL__"       # What specifically might confuse them?

    # Continue for each step until user reaches aha moment or quits

  summary:
    total_steps_to_aha: __FILL__
    total_time_to_aha: "__FILL__"
    highest_confusion_risk: "__FILL__"  # Which step is most likely to lose the user?
    biggest_improvement: "__FILL__"     # Single highest-impact change
```

### First-Run Scoring

| Dimension | Question | Score (1–5) |
|-----------|----------|-------------|
| **Time to Value** | How quickly does user experience the core value? | |
| **Cognitive Load** | How much mental effort does the first session demand? | |
| **Clarity of Next Action** | At every step, does the user know what to do next? | |
| **Aha Moment Reached** | Does the user "get it" in the first session? | |
| **Emotional Arc** | Does the user leave the first session feeling positive? | |

**Scoring guide:**
- **5:** Best-in-class (Notion, Figma-level first run)
- **4:** Good — user succeeds with minimal confusion
- **3:** Acceptable — user succeeds but with some friction
- **2:** Below bar — user may not reach aha moment
- **1:** Poor — user likely abandons

**Target:** All dimensions 4+. Any dimension below 3 = redesign required.

---

## Complexity Staging Worksheet

Use when deciding what features to show at each lifecycle stage.

### Step 1: List All Features

Start by listing every feature/capability in the product:
```yaml
feature_inventory:
  - feature: "__FILL__"
    category: __SELECT__  # core | common | advanced | expert
    stage_required: __SELECT__  # first_contact | first_value | adoption | proficiency | mastery
    justification: "__FILL__"   # Why this stage?
```

### Step 2: Apply the Stage Test

For each feature, ask:

| Question | If Yes | If No |
|----------|--------|-------|
| Does a brand-new user need this in the first 30 seconds? | First Contact | → Next question |
| Does a user need this to experience core value? | First Value | → Next question |
| Does a user need this in their first week? | Adoption | → Next question |
| Does a regular user need this? | Proficiency | → Next question |
| Is this a power-user feature? | Mastery | → Reconsider if needed at all |

### Step 3: Check Budget Compliance

For each stage, count:
```yaml
stage_budget_check:
  stage: __SELECT__

  nav_items_visible: __FILL__     # Count
  nav_budget: __FILL__            # From PROTOCOL.md guidelines
  nav_over_budget: __SELECT__     # yes | no

  actions_per_surface: __FILL__   # Count (average across surfaces at this stage)
  action_budget: __FILL__
  action_over_budget: __SELECT__

  new_concepts: __FILL__          # Count of concepts introduced at this stage
  concept_budget: __FILL__
  concept_over_budget: __SELECT__

  if_over_budget: "__FILL__"      # What to defer or hide
```

### Step 4: Design Transitions

For features that move from hidden to visible between stages:
```yaml
feature_transition:
  feature: "__FILL__"
  from_stage: __SELECT__
  to_stage: __SELECT__
  transition_mechanism: __SELECT__  # contextual_hint | empty_state_cta | progressive_menu | milestone_reveal | tooltip_tour | inline_education
  trigger: "__FILL__"               # What triggers the reveal
```

---

## Aha Moment Design

Use when identifying and optimizing the path to the product's aha moment.

### Step 1: Candidate Aha Moments

List 2–3 candidate aha moments:
```yaml
aha_candidates:
  - statement: "__FILL__"     # What the user realizes
    requires: "__FILL__"      # What must happen for the user to have this realization
    steps_from_signup: __FILL__  # Minimum steps to get there
    likelihood: __SELECT__    # high | medium | low — how likely is a new user to reach this?
```

### Step 2: Select and Validate

| Test | Question | Pass? |
|------|----------|-------|
| **Value Test** | Does this moment demonstrate the product's core value? | |
| **Recall Test** | Would the user tell a friend about this moment? | |
| **Motivation Test** | Does this moment make the user want to continue using the product? | |
| **Reachability Test** | Can a new user reach this in under 5 minutes? | |
| **Universality Test** | Does this apply to most users, not just a niche? | |

### Step 3: Optimize the Path

For each step on the path to the aha moment:
```yaml
path_optimization:
  step: __FILL__
  current_action: "__FILL__"
  is_essential: __SELECT__    # yes | no — could this step be skipped or combined?
  friction_level: __SELECT__  # none | low | medium | high
  if_high_friction: "__FILL__" # How to reduce (pre-fill, template, skip, combine)
```

**Goal:** Minimize steps. Eliminate friction. Every step should feel like progress toward the aha moment, not bureaucratic setup.

---

## Feature Discovery Plan

Use when planning how users will learn about features beyond the initial set.

### Discovery Map

For each feature that's hidden at early stages:
```yaml
discovery_plan:
  feature: "__FILL__"
  current_stage_visibility: __SELECT__  # hidden | locked
  target_stage: __SELECT__              # adoption | proficiency | mastery

  discovery:
    mechanism: __SELECT__  # contextual_hint | empty_state_cta | progressive_menu | milestone_reveal | tooltip_tour | inline_education
    trigger: "__FILL__"    # What event/behavior triggers the reveal
    content: "__FILL__"    # What the user sees (brief description)
    dismissal: __SELECT__  # permanent | session | reset_after_period

  success_criteria: "__FILL__"  # How you know the user discovered and understood the feature
```

### Discovery Sequencing

Plot features on a timeline to ensure users aren't hit with too many discoveries at once:
```yaml
discovery_sequence:
  week_1:
    - feature: "__FILL__"
    - feature: "__FILL__"
  week_2:
    - feature: "__FILL__"
  week_3_4:
    - feature: "__FILL__"
    - feature: "__FILL__"
  month_2_plus:
    - feature: "__FILL__"
```

**Rule:** Maximum 2 new feature discoveries per week during Adoption stage. Users need time to integrate each feature before the next one appears.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_extensions/disclosure/CONTRACT.md` | Scope, rules, activation |
| `_extensions/disclosure/PROTOCOL.md` | Strategic framework these templates implement |
| `_interaction/PROGRESSION.md` | Within-surface disclosure mechanics |
| `_expectations/PRE-BUILD.md` | Feature classification uses complexity budget |
| `_flows/FRAMEWORK.md` | Onboarding flows serve First Contact / First Value stages |
