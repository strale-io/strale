# Extensions

> Closed-world modules for product classes beyond workflow apps.

---

## Why Extensions Exist

The core system is optimized for **workflow applications** (Asana/Linear/Stripe-style products):
- Entity → Action → State workflows
- Data-dense UIs (tables, filters, bulk actions)
- Permission-scoped interactions
- Deterministic correctness

Other product types need additional primitives and rules that would pollute the core system if added directly.

---

## Extension Model

Each extension:

1. **Has its own CONTRACT.md** defining scope and rules
2. **Adds primitives** specific to its product class
3. **Does not weaken** core system constraints
4. **Is only loaded** when `product_class` in manifest.yaml matches
5. **Maintains closed-world assumption** within its scope

---

## Planned Extensions

### `data/` — Data Platform Extension

**For:** Products with complex data structures, time series, pipelines

**Examples:** Snowflake UI, Palantir Foundry, Bloomberg terminals

**Will include:**
- Time series periodization rules (daily/weekly/monthly/quarterly)
- Vintage and revision handling
- Provenance and lineage tracking
- Schema evolution patterns
- Data-specific UI primitives (series explorer, schema browser, lineage view)

---

### `creative/` — Creative Tool Extension

**For:** Products with canvas editors, generative workflows, creative surfaces

**Examples:** Figma, Canva, Photoshop

**Will include:**
- Canvas physics (zoom, pan, selection, layering)
- Coordinate system rules
- Undo/redo semantics (command-based, lossless)
- Direct manipulation patterns
- Creative-specific UI primitives (canvas shell, inspector panel, asset library)

**Special rule:** Multiple invocation paths permitted, but must share one command model.

---

### `automation/` — Automation Platform Extension

**For:** Products with DAGs, pipelines, triggers, orchestration

**Examples:** Zapier, Temporal UI, GitHub Actions, Airflow

**Will include:**
- Job/pipeline model
- Trigger and schedule semantics
- DAG visualization patterns
- Logs-as-UI primitives
- Failure and retry UX (failure is expected, not exceptional)

**Key difference:** Flows ≠ entities. Logs ≠ tables. Different mental model than workflow apps.

---

### `observability/` — Observability Tool Extension

**For:** Products focused on diagnostics, monitoring, investigation

**Examples:** Datadog, Grafana, Sentry

**Will include:**
- Event and metric models
- Time-based navigation patterns
- Correlation and drill-down UX
- Investigative workflows
- Dashboard and alert primitives

**Key difference:** Exploration > efficiency. Read-only but powerful. No "single path to action."

---

### `marketplace/` — Marketplace Extension

**For:** Products for publishing, discovering, and sharing assets

**Examples:** Figma Community, Notion Templates, Shopify App Store

**Will include:**
- Asset model (templates, plugins, components)
- Versioned publishing rules
- Discovery and search patterns
- Preview and trust UX
- Permissions and licensing

**Key difference:** Browsing > efficiency. Trust and social proof matter. Assets are products.

---

## Extension Structure

When built, each extension follows this structure:

```
_extensions/
  {extension}/
    CONTRACT.md           ← Scope, rules, exceptions
    primitives/           ← Extension-specific primitives
      {primitive}/
        SPEC.md
    model/                ← Extension-specific truth (if needed)
    interaction/          ← Extension-specific behavior laws (if needed)
```

---

## Rules for Building Extensions

1. **Do not pre-build.** Extensions are created when the first product of that class begins.
2. **Start minimal.** Begin with CONTRACT.md and one primitive. Add as needed.
3. **No core pollution.** Extension concepts never leak into core system.
4. **Closed world within extension.** Undefined = forbidden applies within each extension.
5. **Document in REGISTRY.md.** Creating an extension requires a decision entry.

---

## Loading Order

```
Core System → Extension (if product_class matches) → Project Overrides
```

Extension rules can add to core rules but cannot override them.

---

## Capability Extensions

> Cross-cutting capabilities that apply to any product class.

Unlike product class extensions (one at a time, loaded by `product_class`), capability extensions are activated independently and multiple can be active simultaneously. They are enabled via `capability_extensions` in `config/manifest.yaml`.

### Available Capability Extensions

| Extension | Purpose | Location | Status |
|-----------|---------|----------|--------|
| `disclosure` | Progressive disclosure lifecycle design | `_extensions/disclosure/` | Active |
| `collaboration` | Multi-user experience patterns | `_extensions/collaboration/` | Active |
| `intelligence` | Smart feature design framework | `_extensions/intelligence/` | Active |

### Rules for Capability Extensions

1. **Additive only.** Capability extensions add guidance; they cannot override core or product class rules.
2. **Conditional enforcement.** All checklist items fire only when the extension is activated.
3. **Cross-compatible.** Any capability extension works with any product class.
4. **Independent activation.** Each capability extension is activated separately. No dependencies between capability extensions.
5. **Document in REGISTRY.md.** Creating a capability extension requires a decision entry.

### Loading Order
Core System → Product Class Extension → Capability Extensions → Project Overrides

Capability extensions load after product class extensions but before project overrides.
