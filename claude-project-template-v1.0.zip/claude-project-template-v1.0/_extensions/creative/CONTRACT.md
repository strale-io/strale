# Creative Tool Contract

> Rules for canvas editors, generative workflows, and creative surfaces.

**Product Class:** `creative_tool`

**Status:** `active` — Ready for use with products of this class.

**Examples:** Figma, Canva, Photoshop, Framer, Tldraw

---

## Class Definition

A product is a **creative tool** when:

1. **Canvas is the interface** — primary surface is a zoomable, pannable 2D space
2. **Direct manipulation** — users create by interacting directly with objects
3. **Undo is sacred** — non-destructive editing and deep undo history
4. **Multiple invocation paths** — same action reachable via menu, shortcut, toolbar, context menu
5. **Visual output is the artifact** — product creates something visual to export/share

**Key mental model difference:** Users are *making* something, not *managing* something.

---

## Class-Specific Invariants

Primary creative tool invariants are in `_invariants/REGISTRY.md` (CR-001 through CR-005).

Additional invariants for this class:

| ID | Invariant | Rationale |
|----|-----------|-----------|
| CT-001 | **Zoom level is always visible.** Users know current zoom percentage. | Spatial orientation |
| CT-002 | **Selection count is visible.** When multiple items selected, count is shown. | Batch operation awareness |
| CT-003 | **Canvas coordinates are available.** Position/size values are inspectable. | Precision work |
| CT-004 | **Artboard boundaries are clear.** Export boundaries are visually distinct from infinite canvas. | Output clarity |
| CT-005 | **Layer order is explicit.** Z-order is visible and manipulable. | Composition control |
| CT-006 | **Tool state persists appropriately.** Active tool remains active until explicitly changed. | Flow preservation |

---

## Class-Specific Patterns

### Canvas Interaction

| Pattern | Description |
|---------|-------------|
| Pan & Zoom | Space+drag to pan, scroll/pinch to zoom, zoom controls visible |
| Selection | Click to select, shift+click to add, marquee for multiple |
| Transform | Handles for resize, rotate, with modifier keys for constraints |
| Alignment | Snap to grid, smart guides, alignment distribution |

### Tool Modes

| Pattern | Description |
|---------|-------------|
| Persistent Tool | Selected tool stays active across operations |
| Spring-loaded Tool | Modifier key temporarily activates tool |
| Quick Actions | Single-use tool that returns to previous |

### Object Manipulation

| Pattern | Description |
|---------|-------------|
| Properties Panel | Inspector showing selected object attributes |
| Layer Panel | Hierarchical view of all objects |
| Transform Handles | Visual handles for direct manipulation |
| Context Menu | Right-click for object-specific actions |

---

## Class-Specific Critique Dimensions

When evaluating creative tool screens, add these dimensions to the standard critique:

| Dimension | What to Evaluate |
|-----------|------------------|
| **Canvas Fluidity** | Is pan/zoom/select friction-free? |
| **Tool Discoverability** | Can users find capabilities without docs? |
| **Precision Support** | Can users achieve exact positioning/sizing? |
| **Undo Confidence** | Do users feel safe to experiment? |
| **Export Clarity** | Is it clear what will be exported and how? |

---

## Exceptions to Core Rules

| Core Rule | Exception | Rationale |
|-----------|-----------|-----------|
| Single path to power | Multiple invocation paths allowed | Power users need shortcuts, beginners need menus |
| Minimal motion | Animation in response to manipulation allowed | Direct manipulation requires visual feedback |
| Focused surfaces | Floating panels acceptable | Tools need persistent access during canvas work |

**Constraint:** Multiple invocation paths must share one underlying command model. This ensures learnability despite multiple paths. Workflow UI (settings, export, permissions) follows core single-path rules.

---

## Preset Integration

To activate this extension:

```yaml
# config/manifest.yaml
product_class: creative_tool

presets:
  - _base
  - _project
```

Extension files are only loaded when `product_class: creative_tool`.

---

## Related Files

- `_invariants/REGISTRY.md` — CR-001 to CR-005 (Creative Tool Invariants)
- `_interaction/PHYSICS.md` — Motion and timing (canvas needs faster response)
- `_ui/components.yaml` — May need canvas-specific components
