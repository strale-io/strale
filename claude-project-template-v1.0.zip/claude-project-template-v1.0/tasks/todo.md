# Build Todo

> Task tracking for the current build. Ephemeral — reset per task.

## Current Task

_No active task._

## Checklist

- [ ] _Add items when entering plan mode_

## Review

_Completed after build — notes on what was built, verified, remaining._
