# Build Lessons

> Append-only mistake log with prevention rules.
> Scope: build-level learning (how to execute better).
> For session-level logging, use Notion Journal and `/handoff/` per PROTOCOL.md.

## Lessons

_No lessons captured yet. After any correction from user, add entry below._

<!-- Template:
### YYYY-MM-DD: [Brief description]
**Mistake:** What went wrong
**Prevention:** Rule to prevent recurrence
**Category:** [execution | quality | process | communication]
-->
