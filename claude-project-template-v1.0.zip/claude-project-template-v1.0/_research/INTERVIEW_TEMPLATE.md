# User Interview: __FILL__

> **Interview ID:** INT-__FILL__
> **Date:** __FILL__
> **Interviewer:** __FILL__
> **Participant ID:** __FILL__ (anonymized)

---

## Interview Context

| Field | Value |
|-------|-------|
| **Research Goal** | __FILL__ |
| **Target Segment** | __FILL__ |
| **Interview Duration** | __FILL__ |
| **Interview Method** | __FILL__ (in-person | video | phone) |
| **Recording Consent** | __FILL__ (yes | no) |

---

## Participant Profile

| Field | Value |
|-------|-------|
| **Role/Title** | __FILL__ |
| **Experience Level** | __FILL__ (novice | intermediate | expert) |
| **Current Tools** | __FILL__ |
| **Frequency of Relevant Task** | __FILL__ |

---

## Key Questions Asked

### 1. __FILL__: [Question Topic]

**Question:** __FILL__

**Response Summary:**
__FILL__

**Notable Quotes:**
> "__FILL__"

---

### 2. __FILL__: [Question Topic]

**Question:** __FILL__

**Response Summary:**
__FILL__

**Notable Quotes:**
> "__FILL__"

---

### 3. __FILL__: [Question Topic]

**Question:** __FILL__

**Response Summary:**
__FILL__

**Notable Quotes:**
> "__FILL__"

---

## Observed Pain Points

| Pain Point | Severity | Frequency | Current Workaround |
|------------|----------|-----------|-------------------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Unmet Needs Identified

| Need | Evidence | Priority |
|------|----------|----------|
| __FILL__ | __FILL__ | __FILL__ |

---

## Feature Reactions (if shown prototypes/concepts)

| Feature/Concept | Reaction | Concerns | Suggestions |
|-----------------|----------|----------|-------------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Synthesis

### Key Insights

1. __FILL__
2. __FILL__
3. __FILL__

### Surprises/Unexpected Findings

__FILL__

### Implications for Product

__FILL__

---

## Follow-up Actions

| Action | Owner | Deadline |
|--------|-------|----------|
| __FILL__ | __FILL__ | __FILL__ |

---

## Raw Notes

(Detailed notes from interview — kept separate from synthesis)

__FILL__
