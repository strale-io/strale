# Competitive Analysis: __FILL__

> **Analysis ID:** CA-__FILL__
> **Date:** __FILL__
> **Author:** __FILL__
> **Focus Area:** __FILL__

---

## Analysis Scope

| Field | Value |
|-------|-------|
| **Purpose** | __FILL__ |
| **Competitors Analyzed** | __FILL__ |
| **Features/Surfaces Compared** | __FILL__ |
| **User Segment Focus** | __FILL__ |

---

## Competitor Overview

### Competitor 1: __FILL__

| Attribute | Value |
|-----------|-------|
| **Product** | __FILL__ |
| **Target Market** | __FILL__ |
| **Pricing Model** | __FILL__ |
| **Market Position** | __FILL__ |
| **Strengths** | __FILL__ |
| **Weaknesses** | __FILL__ |

---

### Competitor 2: __FILL__

| Attribute | Value |
|-----------|-------|
| **Product** | __FILL__ |
| **Target Market** | __FILL__ |
| **Pricing Model** | __FILL__ |
| **Market Position** | __FILL__ |
| **Strengths** | __FILL__ |
| **Weaknesses** | __FILL__ |

---

### Competitor 3: __FILL__

| Attribute | Value |
|-----------|-------|
| **Product** | __FILL__ |
| **Target Market** | __FILL__ |
| **Pricing Model** | __FILL__ |
| **Market Position** | __FILL__ |
| **Strengths** | __FILL__ |
| **Weaknesses** | __FILL__ |

---

## Feature Comparison Matrix

| Feature | Our Product | Competitor 1 | Competitor 2 | Competitor 3 |
|---------|-------------|--------------|--------------|--------------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ |

**Legend:** ✓ = Has feature | ✗ = Missing | ◐ = Partial | ? = Unknown

---

## UX Pattern Analysis

### Pattern: __FILL__

| Product | Implementation | Pros | Cons |
|---------|----------------|------|------|
| Competitor 1 | __FILL__ | __FILL__ | __FILL__ |
| Competitor 2 | __FILL__ | __FILL__ | __FILL__ |
| Competitor 3 | __FILL__ | __FILL__ | __FILL__ |

**Recommendation for Our Product:** __FILL__

---

## Patterns to Adopt

| Pattern | Source | Rationale | Surface to Apply |
|---------|--------|-----------|------------------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Patterns to Avoid

| Pattern | Source | Rationale |
|---------|--------|-----------|
| __FILL__ | __FILL__ | __FILL__ |

---

## Differentiation Opportunities

| Opportunity | Gap Identified | Our Approach | Competitive Advantage |
|-------------|----------------|--------------|----------------------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Key Insights

1. __FILL__
2. __FILL__
3. __FILL__

---

## Screenshots/Evidence

(Reference screenshots stored in `_research/evidence/CA-__FILL__/`)

| Competitor | Surface | Screenshot | Notes |
|------------|---------|------------|-------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Follow-up Actions

| Action | Owner | Deadline |
|--------|-------|----------|
| __FILL__ | __FILL__ | __FILL__ |
