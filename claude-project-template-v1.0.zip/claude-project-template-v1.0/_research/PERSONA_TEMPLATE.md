# Persona: __FILL__

> **Persona ID:** PER-__FILL__
> **Version:** __FILL__
> **Last Updated:** __FILL__
> **Based on:** __FILL__ interviews, __FILL__ survey responses

---

## Overview

| Field | Value |
|-------|-------|
| **Name** | __FILL__ (representative name) |
| **Role/Title** | __FILL__ |
| **Segment** | __FILL__ |
| **Priority** | __FILL__ (primary | secondary | edge case) |

---

## Demographics

| Attribute | Value |
|-----------|-------|
| **Age Range** | __FILL__ |
| **Location** | __FILL__ |
| **Education** | __FILL__ |
| **Technical Proficiency** | __FILL__ (low | medium | high) |
| **Industry** | __FILL__ |
| **Company Size** | __FILL__ |

---

## Motivations & Goals

### Primary Goals

1. __FILL__
2. __FILL__
3. __FILL__

### Secondary Goals

1. __FILL__
2. __FILL__

### What Success Looks Like

__FILL__

---

## Pain Points & Frustrations

| Pain Point | Severity | Frequency | Impact |
|------------|----------|-----------|--------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Current Workflow

### Tools Currently Used

| Tool | Purpose | Satisfaction |
|------|---------|--------------|
| __FILL__ | __FILL__ | __FILL__ |

### Typical Day/Week

__FILL__

### Workarounds Used

__FILL__

---

## Behaviors & Preferences

### Decision-Making Style

__FILL__ (deliberate | quick | consensus-driven | data-driven)

### Information Consumption

__FILL__ (prefers details | prefers summaries | visual learner | hands-on learner)

### Risk Tolerance

__FILL__ (risk-averse | calculated risks | early adopter)

### Communication Preferences

__FILL__

---

## Objections & Concerns

| Concern | Response Strategy |
|---------|-------------------|
| __FILL__ | __FILL__ |
| __FILL__ | __FILL__ |

---

## Representative Quotes

> "__FILL__"

> "__FILL__"

---

## Scenario: Day in the Life

__FILL__: Narrative describing how this persona would interact with the product during a typical day.

---

## Product Implications

### Features This Persona Needs

| Feature | Priority | Rationale |
|---------|----------|-----------|
| __FILL__ | __FILL__ | __FILL__ |

### Features This Persona Does NOT Need

| Feature | Rationale |
|---------|-----------|
| __FILL__ | __FILL__ |

### UX Considerations

__FILL__

---

## Validation

| Validation Method | Date | Findings |
|-------------------|------|----------|
| __FILL__ | __FILL__ | __FILL__ |

---

## Related Personas

| Persona | Relationship |
|---------|--------------|
| PER-__FILL__ | __FILL__ |

---

## Revision History

| Date | Change | Author |
|------|--------|--------|
| __FILL__ | Initial creation | __FILL__ |
