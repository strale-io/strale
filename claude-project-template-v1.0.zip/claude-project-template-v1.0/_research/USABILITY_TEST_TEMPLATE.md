# Usability Test: __FILL__

> **Test ID:** UT-__FILL__
> **Date:** __FILL__
> **Facilitator:** __FILL__
> **Surface(s) Tested:** __FILL__

---

## Test Overview

| Field | Value |
|-------|-------|
| **Test Goal** | __FILL__ |
| **Test Type** | __FILL__ (moderated | unmoderated) |
| **Test Method** | __FILL__ (think-aloud | task-based | A/B comparison) |
| **Prototype Fidelity** | __FILL__ (wireframe | low-fi | high-fi | production) |
| **Duration per Participant** | __FILL__ |

---

## Success Criteria

| Metric | Target | Measurement Method |
|--------|--------|-------------------|
| Task completion rate | __FILL__ | __FILL__ |
| Time on task | __FILL__ | __FILL__ |
| Error rate | __FILL__ | __FILL__ |
| Satisfaction score | __FILL__ | __FILL__ |

---

## Tasks

### Task 1: __FILL__

**Scenario:** __FILL__

**Expected Path:**
1. __FILL__
2. __FILL__
3. __FILL__

**Success Definition:** __FILL__

---

### Task 2: __FILL__

**Scenario:** __FILL__

**Expected Path:**
1. __FILL__
2. __FILL__
3. __FILL__

**Success Definition:** __FILL__

---

### Task 3: __FILL__

**Scenario:** __FILL__

**Expected Path:**
1. __FILL__
2. __FILL__
3. __FILL__

**Success Definition:** __FILL__

---

## Participant Results

### Participant __FILL__

| Task | Completed | Time | Errors | Path Deviation | Notes |
|------|-----------|------|--------|----------------|-------|
| Task 1 | __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| Task 2 | __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| Task 3 | __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ |

**Post-task Feedback:**
__FILL__

**Satisfaction Rating:** __FILL__ / 5

---

## Aggregate Results

| Task | Completion Rate | Avg Time | Avg Errors | Common Issues |
|------|-----------------|----------|------------|---------------|
| Task 1 | __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| Task 2 | __FILL__ | __FILL__ | __FILL__ | __FILL__ |
| Task 3 | __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Issues Found

| ID | Severity | Task | Description | Observed Behavior | Expected Behavior |
|----|----------|------|-------------|-------------------|-------------------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Recommendations

| Priority | Issue | Recommendation | Effort |
|----------|-------|----------------|--------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |

---

## Key Quotes

> "__FILL__" — Participant __FILL__

---

## Follow-up Actions

| Action | Owner | Deadline | Status |
|--------|-------|----------|--------|
| __FILL__ | __FILL__ | __FILL__ | __FILL__ |
