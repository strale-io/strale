# Starter Kit v2.0.0

> Documentation OS for AI-assisted product development.

---

## What's New

**v2.0.0 — Structural Expansion**

16 amendments adding new directories and capabilities for enterprise-grade documentation systems.

- **Surface Registry:** `_surfaces/` with SURF-NNN tracking, spec template
- **Traceability:** `_quality/TRACE.yaml` maps REQ → DEC → SURF → TEST
- **NFRs:** `_nfr/` for performance, reliability, security, privacy targets
- **Automation:** Gate output templates, build run logs, coherence automation
- **Resilience:** `_resilience/FAILURE_MODES.md` for cross-cutting failure scenarios
- **Research:** `_research/` templates for interviews, usability tests, personas
- **UI Expansion:** `_ui/RESPONSIVE.md` and `_ui/I18N.md`
- **Quick Access:** `QUICKREF.md` navigation card, `MIGRATION_TEMPLATE.md`

See `CHANGELOG.md` for full version history.

---

## Bootstrap Order

Read in this order:

1. **`SYSTEM_CONTRACT.md`** — Operating agreement, meta-rules, glossary
2. **`config/manifest.yaml`** — Project identity, preset chain
3. **`config/tech-foundation.yaml`** — Architectural decisions
4. **`.claude/RUNBOOK.md`** — AI entry point
5. **`.claude/DISPATCH.yaml`** — Task routing: what to read per task type
6. **`.claude/BUILD.md`** — Build sequencing by complexity tier
7. **`.claude/WORKFLOW.md`** — Workflow orchestration
8. **`.claude/NOTION.md`** — Project context in Notion
9. **`_modes/explore.md`** or **`_modes/govern.md`** — Current mode

---

## Quick Setup

```bash
# 1. Edit project identity
config/manifest.yaml

# 2. Choose preset chain (in manifest.yaml)
presets:
  - _base           # Always first
  - b2b-saas        # Your choice: b2b-saas | data-dense
  - moat-conscious  # Optional: enables stickiness guidelines
  - _project        # Always last (your overrides)

# 3. Fill tech foundation (BEFORE building persistence/auth/sync)
config/tech-foundation.yaml   # Set status: active when filled

# 4. Fill in your design tokens
_ui/tokens.yaml           # Copy structure, fill __FILL__ sections
_ui/tokens.example.yaml   # Reference example (delete when done)

# 5. Define your model
_model/truth/entities.yaml
_model/truth/actions.yaml
_model/truth/states.yaml

# 6. If moat-conscious: define moat priorities
_strategy/priorities.yaml   # Set status: active when filled
```

---

## Tech Foundation

Architectural decisions that must be explicit before building.

| File | Purpose |
|------|---------|
| `config/tech-foundation.yaml` | Persistence, auth, sync, export decisions |

**Guardrail:** Claude cannot implement persistence, auth, sync, or export until this file has `status: active`.

---

## Token System

| File | Purpose |
|------|---------|
| `tokens.yaml` | Template with schema, constraints, placeholders |
| `tokens.example.yaml` | Filled example (for reference only) |

**Setup:**
1. Fill `__FILL__` sections in `tokens.yaml`
2. Delete `tokens.example.yaml` when done

---

## Resolution Order

```
Notion Constitution → _rules/laws.yaml → _base.yaml → {preset}.yaml → _project.yaml
```

Higher always wins. Presets are the only configuration mechanism.

---

## Structure

```
├── README.md                    # You are here
├── CHANGELOG.md                 # Version history
├── DESIGN_ROUTER.yaml           # Surface-type → design file routing
├── SYSTEM_CONTRACT.md           # Operating agreement
├── QUICKREF.md                  # Quick reference navigation card (v2.0)
├── GOVERNANCE.md                 # System evolution governance
├── EVOLUTION.md                  # Upstream propagation protocol
├── CONSTRAINTS_INDEX.yaml        # Constraint locator (reference-only index)
├── MIGRATION_TEMPLATE.md        # Version migration guide template (v2.0)
├── config/
│   ├── manifest.yaml            # Project identity + preset chain
│   ├── tech-foundation.yaml     # Architectural decisions
│   └── TOOLING.md               # Design tooling governance
├── .claude/
│   ├── RUNBOOK.md               # AI entry point
│   ├── WORKFLOW.md              # Execution guidance
│   ├── NOTION.md                # Notion database references
│   └── PROTOCOL.md              # Workflow protocol + bootstrap
├── CLAUDE.md                    # Project-specific config (stub until Bootstrap)
├── docs/
│   └── CONSTITUTION.md          # Project laws (human-readable)
├── _rules/
│   └── laws.yaml                # Single source of law
├── _invariants/
│   └── REGISTRY.md              # Absolute correctness rules
├── _jobs/                       # Jobs architecture (v12.14.0)
│   ├── FRAMEWORK.md             # Job hierarchy, traceability, completeness
│   ├── VALUE_LOOPS.md           # Value loop types and audit
│   ├── REGISTRY.yaml            # JOB-NNN entries
│   └── TEMPLATES.md             # Discovery tools and interview prompts
├── _flows/                      # Flow design (v12.14.0)
│   ├── FRAMEWORK.md             # Flow anatomy, types, emotional arc, handoffs
│   ├── REGISTRY.yaml            # FLOW-NNN entries
│   ├── QUALITY.md               # Flow Gate checklist and critique dimensions
│   └── TEMPLATES.md             # Flow mapping and review tools
├── _surfaces/                   # Surface registry (v2.0)
│   ├── REGISTRY.yaml            # SURF-NNN tracking
│   ├── SPEC_TEMPLATE.md         # Surface specification template
│   ├── EXPECTATIONS.md          # Cross-surface expectation propagation
├── _nfr/                        # Non-functional requirements (v2.0)
│   ├── PERFORMANCE.yaml         # Performance targets
│   ├── RELIABILITY.yaml         # Reliability targets
│   ├── SECURITY.yaml            # Security requirements
│   └── PRIVACY.yaml             # Privacy requirements
├── _artifacts/
│   ├── SYNTHESIS.md             # Artifact-first design (LAW-013)
│   ├── DELIVERY.md              # Client presentation protocol (v2.0)
│   ├── README.md                # Artifact organization guide (v2.0)
│   ├── gates/                   # Quality gate outputs (v2.0)
│   ├── critique/                # Critique scorecards (v2.0)
│   ├── synthesis/               # Final artifacts (v2.0)
│   └── specs/                   # Detailed specifications (v2.0)
├── _runs/                       # Immutable build logs (v2.0)
│   ├── README.md                # Build run guidance
│   └── RUN_TEMPLATE.yaml        # Run log template
├── _resilience/                 # System resilience (v2.0)
│   └── FAILURE_MODES.md         # Cross-cutting failure scenarios
├── _research/                   # User research (v2.0)
│   ├── INTERVIEW_TEMPLATE.md    # User interview template
│   ├── USABILITY_TEST_TEMPLATE.md
│   ├── COMPETITIVE_ANALYSIS_TEMPLATE.md
│   └── PERSONA_TEMPLATE.md
├── _expectations/               # User expectation framework
│   ├── FRAMEWORK.md             # Principles and classification
│   ├── PRE-BUILD.md             # Operational protocols
│   ├── CONTRACTS.md             # All 10 user contracts
│   └── TESTS.md                 # Quality tests
├── _strategy/                   # Competitive advantage (optional)
│   ├── MOATS.md                 # Moat guidelines
│   └── priorities.yaml          # Project moat priorities
├── _presets/
│   ├── _base.yaml               # Mandatory defaults
│   ├── b2b-saas.yaml            # Preset option
│   ├── data-dense.yaml          # Preset option
│   ├── moat-conscious.yaml      # Moat awareness (optional)
│   └── _project.yaml            # Project overrides
├── _design-systems/              # Visual identity systems
│   ├── professional/             # Professional design system
│   │   ├── _contract.yaml        # Visual language rules and token scope
│   │   ├── components.yaml       # Component specs
│   │   ├── tokens.yaml           # Design system token definitions
│   │   ├── patterns.md           # Layout patterns for data views
│   │   ├── states.md             # State-specific visual rules
│   │   └── IDENTITY_PROFESSIONAL.html  # Visual identity reference
│   └── publishing/               # Publishing design system
│       ├── _contract.yaml        # Visual language rules and token scope
│       ├── components.md         # Component specs
│       ├── tokens.yaml           # Design system token definitions
│       ├── patterns.md           # Layout patterns
│       ├── states.md             # State-specific visual rules
│       └── IDENTITY_PUBLISHING.html    # Visual identity reference
├── _model/
│   ├── truth/                   # Entities, actions, states
│   └── patterns/                # Navigation, forms, data display, overview, surfacing
├── _ui/
│   ├── SYSTEM.md                # UI system principles
│   ├── tokens.yaml              # Token schema
│   ├── components.yaml          # Component registry
│   ├── RESPONSIVE.md            # Responsive behavior spec (v2.0)
│   ├── ADAPTIVE.md              # Adaptive layout governance
│   ├── I18N.md                  # Internationalization guidance (v2.0)
│   └── layouts/                 # Layout templates
├── _content/
│   ├── SYSTEM.md                    # Content design rules and voice execution
│   └── PATTERNS.md                  # Reusable writing patterns
├── _interaction/                # Physics, focus, progression
├── _primitives/                 # Reference implementations (frozen)
├── _quality/
│   ├── QUALITY_PROTOCOL.md      # Gates + verification
│   ├── TRACE.yaml               # Traceability graph (v2.0)
│   ├── LEARNING.md              # Build intelligence patterns
│   ├── HEURISTICS.md            # Design tradeoff heuristics
│   ├── DIRECTIONAL_COHERENCE.md # Feature multiplication & thesis alignment
│   └── archetypes/              # Screen type budgets (5: workspace, detail, overview, configuration, transient)
├── _critique/
│   ├── LOOP.md                  # Critique orchestration
│   ├── PROMPT.md                # What to check
│   └── RUBRIC.md                # How to score
├── _decisions/
│   ├── REGISTRY.md              # Decision log
│   └── eil/                     # Expectation Invention Loop artifacts
├── _examples/                   # Worked examples (reference only)
│   ├── README.md                # Overview — fictional B2B SaaS "Beacon"
│   ├── REGISTRY.example.yaml    # Surface Registry with 5 surfaces
│   ├── DECISIONS.example.md     # Decision Registry with 5 decisions
│   ├── GATE-0.example.md        # Completed Gate 0 for OKR Board
│   ├── CRITIQUE.example.md      # Failing Cycle 1 critique scorecard
│   ├── JOBS.example.yaml        # Jobs architecture for Beacon
│   └── FLOWS.example.yaml       # Flow design for Beacon
├── _guides/                     # Guided walkthroughs
│   ├── ONBOARDING.md            # Entity → surface → archetype → pre-build → critique
│   ├── LIGHTWEIGHT_PATH.md      # Quick + Micro/Targeted + Single-Cycle fast lane
│   └── IMPLEMENTATION_MAP.md    # Artifact → implementation question reference map
├── _extensions/                 # Product class + capability extensions
│   ├── disclosure/              # Progressive Disclosure Protocol (capability extension)
│   │   ├── CONTRACT.md          # Scope, rules, activation
│   │   ├── PROTOCOL.md          # Lifecycle stages, aha moments, complexity budget
│   │   └── TEMPLATES.md         # First-run audit, complexity staging
│   ├── collaboration/           # Collaboration Patterns (capability extension)
│   │   ├── CONTRACT.md          # Scope, rules, activation
│   │   ├── PATTERNS.md          # Presence, communication, coordination, co-creation
│   │   ├── NOTIFICATIONS.md     # Notification architecture
│   │   └── INVARIANTS.md        # Collaboration invariants (CO-NNN)
│   ├── intelligence/            # Intelligence Design Framework (capability extension)
│   │   ├── CONTRACT.md          # Scope, rules, activation, intelligence spectrum
│   │   ├── FRAMEWORK.md         # Confidence display, suggestion design, automation design
│   │   ├── GUARDRAILS.md        # Intelligence Restraint Gate, failure modes
│   │   └── INVARIANTS.md        # Intelligence invariants (IN-NNN)
├── handoff/                     # Cross-actor session handoffs
│   ├── README.md                # Handoff format and rules
│   ├── _general/                # Cross-cutting handoffs
│   └── _archive/                # Completed handoffs
├── tasks/                       # Build-level task tracking (ephemeral)
│   ├── todo.md                  # Current build checklist
│   └── lessons.md               # Mistake log with prevention rules
└── _modes/                      # Explore vs govern
```

---

## Key Concepts

| Concept | Location | Purpose |
|---------|----------|---------|
| **Laws** | `_rules/laws.yaml` | Non-negotiable rules (LAW-001 to LAW-013) |
| **Invariants** | `_invariants/REGISTRY.md` | Absolute correctness constraints |
| **Gates** | `_quality/QUALITY_PROTOCOL.md` | Quality checkpoints (0-8) |
| **Dimensions** | `_critique/RUBRIC.md` | 14 core + 1 optional scoring dimensions |
| **Presets** | `_presets/` | Configuration inheritance |
| **Expectations** | `_expectations/` | User expectation framework |
| **Artifacts** | `_artifacts/SYNTHESIS.md` | Artifact-first design |
| **Value Loops** | `_jobs/VALUE_LOOPS.md` | How usage creates compounding value |
| **Moats** | `_strategy/MOATS.md` | Structural competitive advantage (optional) |

---

## Quick Reference

| Task | File |
|------|------|
| Define what to build | `_model/truth/*.yaml` |
| Configure appearance | `_ui/tokens.yaml` |
| Set constraints | `_rules/laws.yaml` |
| Add invariants | `_invariants/REGISTRY.md` |
| Log decisions | `_decisions/REGISTRY.md` |
| Check quality | `_critique/LOOP.md` |
| Verify expectations | `_expectations/FRAMEWORK.md` (principles), `_expectations/PRE-BUILD.md` (operations) |
| Define artifact | `_artifacts/SYNTHESIS.md` |
| Define moat priorities | `_strategy/priorities.yaml` |
