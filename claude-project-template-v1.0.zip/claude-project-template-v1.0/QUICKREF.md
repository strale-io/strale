# Quick Reference Card

> Fast lookup for common tasks. This is a navigation aid — definitions live in source files.

---

## Entry Points

| Purpose | File |
|---------|------|
| Start here | `.claude/RUNBOOK.md` |
| Task routing | `.claude/DISPATCH.yaml` |
| Constraint lookup | `CONSTRAINTS_INDEX.yaml` |
| Understand formats | `_examples/README.md` |
| AI workflow | `.claude/WORKFLOW.md` |
| Notion integration | `.claude/NOTION.md` |
| Bootstrap new project | `.claude/PROTOCOL.md` |

---

## Core Governance

| Purpose | File |
|---------|------|
| Non-negotiable laws | `_rules/laws.yaml` |
| System contract | `SYSTEM_CONTRACT.md` |
| Three Absolutes | `SYSTEM_CONTRACT.md` |
| Decision registry | `_decisions/REGISTRY.md` |
| Invariants | `_invariants/REGISTRY.md` |
| System evolution | `GOVERNANCE.md` |
| Upstream propagation | `EVOLUTION.md` |

---

## Quality Gates

| Gate | Purpose | File |
|------|---------|------|
| Gate 0 | Pre-Creation | `_quality/QUALITY_PROTOCOL.md` |
| Gate 1 | Self-Review | `_quality/QUALITY_PROTOCOL.md` |
| Gate 2 | Critique Loop | `_critique/LOOP.md` |
| Gate 3 | Accessibility | `_quality/QUALITY_PROTOCOL.md` |
| Gate 4 | Drift Detection | `_quality/QUALITY_PROTOCOL.md` |
| Gate 5 | Completeness | `_quality/QUALITY_PROTOCOL.md` |
| Gate 6 | Artifact Readiness | `_quality/QUALITY_PROTOCOL.md` |
| Gate 7 | Stickiness (Optional) | `_quality/QUALITY_PROTOCOL.md` |
| Gate 8 | Cross-Surface Coherence | `_quality/QUALITY_PROTOCOL.md` |

---

## Build Flow

```
Spec → Gate 0 → Build → Gate 1 → Critique Loop → Gates 3-8 → Ship
              ↓                    ↓
           EIL (if new)        Cycle until pass
```

---

## File Lookup by Topic

### Product Definition

| Topic | File |
|-------|------|
| Product identity | `config/manifest.yaml` |
| Tech foundation | `config/tech-foundation.yaml` |
| Presets | `_presets/{preset}.yaml` |
| Design tooling | `config/TOOLING.md` |

### Jobs & Flows

| Topic | File |
|-------|------|
| Jobs framework | `_jobs/FRAMEWORK.md` |
| Value loops | `_jobs/VALUE_LOOPS.md` |
| Jobs registry | `_jobs/REGISTRY.yaml` |
| Jobs discovery tools | `_jobs/TEMPLATES.md` |
| Flows framework | `_flows/FRAMEWORK.md` |
| Flows registry | `_flows/REGISTRY.yaml` |
| Flow Gate | `_flows/QUALITY.md` |
| Flow templates | `_flows/TEMPLATES.md` |

### UI System

| Topic | File |
|-------|------|
| Components | `_ui/components.yaml` |
| Tokens | `_ui/tokens.yaml` |
| Layouts | `_ui/layouts/` |
| Responsive | `_ui/RESPONSIVE.md` |
| Adaptive layout | `_ui/ADAPTIVE.md` |
| Design routing | `DESIGN_ROUTER.yaml` |
| i18n | `_ui/I18N.md` |
| RTL | `_ui/layouts/RTL.md` |

### Truth Model

| Topic | File |
|-------|------|
| Entities | `_model/truth/entities.yaml` |
| Actions | `_model/truth/actions.yaml` |
| States | `_model/truth/states.yaml` |
| Information surfacing | `_model/patterns/SURFACING.md` |

### Quality & Critique

| Topic | File |
|-------|------|
| Critique loop | `_critique/LOOP.md` |
| Critique prompt | `_critique/PROMPT.md` |
| Rubric | `_critique/RUBRIC.md` |
| Archetypes | `_quality/archetypes/` |
| Coherence (visual) | `_quality/COHERENCE.md` |
| Coherence (directional) | `_quality/DIRECTIONAL_COHERENCE.md` |
| Learning | `_quality/LEARNING.md` |
| Traceability | `_quality/TRACE.yaml` |
| Tradeoff heuristics | `_quality/HEURISTICS.md` |
| Critique calibration | `_critique/CALIBRATION.md` |
| Visual verification | `_quality/VISUAL_VERIFICATION.md` |
| Reference analysis | `_quality/REFERENCE_ANALYSIS.md` |
| Release review | `_quality/RELEASE_REVIEW.md` |
| Exemplars | `_quality/exemplars/` |

### New Directories (v2.0)

| Topic | File |
|-------|------|
| Surface registry | `_surfaces/REGISTRY.yaml` |
| Surface spec template | `_surfaces/SPEC_TEMPLATE.md` |
| Cross-surface expectations | `_surfaces/EXPECTATIONS.md` |

### Content & Writing

| Topic | File |
|-------|------|
| Writing rules | `_content/SYSTEM.md` |
| Content patterns | `_content/PATTERNS.md` |
| Vocabulary registry | `_model/truth/vocabulary.yaml` |
| Copy-First Gate | `_expectations/PRE-BUILD.md` |
| NFR: Performance | `_nfr/PERFORMANCE.yaml` |
| NFR: Reliability | `_nfr/RELIABILITY.yaml` |
| NFR: Security | `_nfr/SECURITY.yaml` |
| NFR: Privacy | `_nfr/PRIVACY.yaml` |
| Gate outputs | `_artifacts/gates/` |
| Build runs | `_runs/` |
| Failure modes | `_resilience/FAILURE_MODES.md` |
| Research templates | `_research/` |
| Artifact delivery | `_artifacts/DELIVERY.md` |

### Extensions

| Topic | File |
|-------|------|
| Disclosure contract | `_extensions/disclosure/CONTRACT.md` |
| Disclosure protocol | `_extensions/disclosure/PROTOCOL.md` |
| Disclosure templates | `_extensions/disclosure/TEMPLATES.md` |
| Collaboration contract | `_extensions/collaboration/CONTRACT.md` |
| Collaboration patterns | `_extensions/collaboration/PATTERNS.md` |
| Notification architecture | `_extensions/collaboration/NOTIFICATIONS.md` |
| Collaboration invariants | `_extensions/collaboration/INVARIANTS.md` |
| Intelligence contract | `_extensions/intelligence/CONTRACT.md` |
| Intelligence framework | `_extensions/intelligence/FRAMEWORK.md` |
| Intelligence guardrails | `_extensions/intelligence/GUARDRAILS.md` |
| Intelligence invariants | `_extensions/intelligence/INVARIANTS.md` |

---

## ID Schemes

| Prefix | Source | Example |
|--------|--------|---------|
| `LAW-` | Laws | `_rules/laws.yaml` |
| `DEC-` | Decisions | `_decisions/REGISTRY.md` |
| `JOB-` | Jobs | `_jobs/REGISTRY.yaml` |
| `FLOW-` | Flows | `_flows/REGISTRY.yaml` |
| `CO-` | Collaboration invariants | `_extensions/collaboration/INVARIANTS.md` |
| `IN-` | Intelligence invariants | `_extensions/intelligence/INVARIANTS.md` |
| `SURF-` | Surfaces | `_surfaces/REGISTRY.yaml` |
| `RUN-` | Build runs | `_runs/` |
| `REQ-` | Requirements | External source |

### Invariant Prefixes

| Prefix | Category |
|--------|----------|
| `ID-` | Identity |
| `HIE-` | Hierarchy |
| `TS-` | Time Series |
| `ST-` | State |
| `UI-` | UI Behavior |
| `AF-` | Affordance |
| `EX-` | Expectation |
| `IX-` | Information |
| `XP-` | Explanation |
| `OR-` | Orientation |
| `CF-` | Confidence |
| `FR-` | Freshness |
| `FB-` | Feedback |
| `PR-` | Prediction |
| `RV-` | Reversibility |
| `CN-` | Continuity |
| `CP-` | Completion |
| `EA-` | Exit Awareness |
| `DD-` | Data Display |
| `PM-` | Permission |
| `CR-` | Creative Tool |
| `AU-` | Automation |
| `TK-` | Token |
| `TF-` | Tech Foundation |
| `CS-` | Cross-Surface |
| `L10N-` | Localization |
| `A11Y-` | Accessibility |

---

## Workflow Modes

| Mode | File | Purpose |
|------|------|---------|
| Exploration | `_modes/explore.md` | Divergent thinking, reference analysis, approach generation |
| Govern | `_modes/govern.md` | Structured build, quality gates, compliance |

---

## Routing & Dispatch

| Purpose | File |
|---------|------|
| Task-aware routing | `.claude/DISPATCH.yaml` |
| Constraint locator | `CONSTRAINTS_INDEX.yaml` |
| Surface-type design routing | `DESIGN_ROUTER.yaml` |

---

## Common Commands

### Before Building

1. Check `config/manifest.yaml` filled
2. Check `config/tech-foundation.yaml` filled
3. Run Gate 0 checklist
4. Create EIL artifact if new capability

### Before Merging

1. Run Drift Detection checklist
2. Verify no invariant violations
3. Check Decision Registry if loosening constraints

### Before Release

1. Run Gate 5 Completeness
2. Run Gate 6 Artifact Readiness
3. Run Gate 8 Cross-Surface Coherence (multi-surface)
4. Verify Professional Embarrassment Gate

---

## Severity Levels

| Level | Meaning | Blocks Ship? |
|-------|---------|--------------|
| P0 | Critical | Yes |
| P1 | Important | If >2 |
| P2 | Minor | No |

---

## Mode Reference

| Mode | Trigger | Behavior |
|------|---------|----------|
| Normal | Default | All gates, full process |
| Degraded | Late requirements | EIL-Lite, abbreviated checks |
| Single-Cycle | Time pressure | One critique cycle only |

---

## Key Principles (From Laws)

1. **Closed World** — If not defined, forbidden
2. **Single Source of Truth** — One home per concept
3. **Generic Over Specific** — Use `__FILL__` placeholders
4. **Tighten First** — Constrain before expanding
5. **Artifact First** — Build what the artifact needs
6. **Feature Multiplication** — Features must strengthen each other, not just coexist
