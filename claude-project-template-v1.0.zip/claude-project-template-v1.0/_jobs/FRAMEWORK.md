# Jobs Architecture

> Why this product exists, expressed as the progress users are trying to make.

**Gravity:** Strategy
**Scope:**
  - RESPONSIBLE FOR: Job hierarchy, job-to-surface traceability, completeness analysis
  - MUST NOT CONTAIN: Implementation details, surface specs, flow sequences
  - DECISIONS ALLOWED: Which jobs the product serves, job hierarchy structure
  - DECISIONS DEFERRED: How jobs become flows (`_flows/`), how flows become surfaces (`_surfaces/`)

---

## Why Jobs Exist in This System

The system's unit of quality is the surface. Gate 0 evaluates a surface. Critique scores a surface. But surfaces are *means*, not *ends*. A surface exists to help a user make progress on something — and that "something" is a job.

Without jobs, you can build five excellent surfaces that don't add up to solving the user's actual problem. You can pass every gate, score 5 on every critique dimension, and still ship a product that nobody needs.

Jobs sit above everything else:
Jobs → "Why does this product exist?"
↓
Flows → "How does the user accomplish the job?" (_flows/)
↓
Surfaces → "Where does each step happen?" (_surfaces/)
↓
Components → "What does the user interact with?" (_ui/)

---

## What Is a Job?

A **job** is the progress a user is trying to make in a specific circumstance. Jobs are:

- **Solution-independent.** The job exists whether or not your product exists. Users were trying to coordinate team work before Asana, before email, before writing.
- **Stable over time.** Technology changes; jobs don't. "Align my team on priorities" has been a job for centuries. The solutions evolve.
- **Hierarchical.** A core job decomposes into sub-jobs. Sub-jobs map to flows. Flows map to surfaces.

Jobs are not:

- **User stories.** "As a user, I want to..." describes a feature request, not a job. Jobs don't reference your product.
- **Tasks.** "Click the create button" is an action. Jobs describe the *why* behind actions.
- **Personas.** "Marketing manager" is a role. The same role may have multiple jobs; the same job may span roles.

---

## Job Statement Format

Every job follows a three-part structure:

> **"When** [situation], **I want to** [motivation], **so I can** [desired outcome]."

| Part | What It Captures | Test |
|------|------------------|------|
| **Situation** | The circumstance that triggers the need | Is this specific enough to distinguish from other jobs? |
| **Motivation** | The progress the user wants to make | Is this about the user's goal, not your feature? |
| **Outcome** | The desired end state | Can you tell if the user succeeded? |

### Writing Good Job Statements

**Good:** "When starting a new quarter, I want to define clear priorities for my team, so I can ensure effort goes toward outcomes, not just activity."

**Bad:** "When using the OKR Board, I want to create objectives." ← This describes a feature interaction, not a job. It references the product and has no outcome.

**Bad:** "I want to manage my team better." ← Too vague. No situation. No measurable outcome.

**Bad:** "When opening the app, I want to see a dashboard." ← This is a UI preference, not progress the user is trying to make.

### The Product-Removal Test

> If your product disappeared tomorrow, would the user still have this job?

If yes → it's a real job.
If no → it's a feature request disguised as a job.

---

## Job Hierarchy

Every product has exactly one **core job** — the primary progress users hire the product to make. The core job decomposes into **sub-jobs**, which are the distinct progress steps required to accomplish the core job.
Core Job (1 per product)
├── Sub-Job A
│   ├── Flow 1 → Surfaces
│   └── Flow 2 → Surfaces
├── Sub-Job B
│   └── Flow 3 → Surfaces
└── Sub-Job C
├── Flow 4 → Surfaces
└── Flow 5 → Surfaces

### Hierarchy Rules

| Rule | Description |
|------|-------------|
| **One core job** | A product that tries to serve multiple core jobs serves none well. If you have two core jobs, you may have two products. |
| **Sub-jobs are necessary steps** | Each sub-job is a required or common step toward accomplishing the core job. If removing a sub-job doesn't affect the core job, it's not a real sub-job. |
| **Sub-jobs map to flows** | Each sub-job should map to one or more flows in `_flows/REGISTRY.yaml`. A sub-job with no flow is an unserved gap. |
| **Depth limit: 2 levels** | Core → Sub. No sub-sub-jobs. If you need deeper hierarchy, you're probably modeling features, not jobs. |

### The Necessity Test

For each sub-job, ask:

> "Can the user accomplish the core job without completing this sub-job?"

If yes → it's a supporting job, not a sub-job. It may still matter, but it's not structurally required.
If no → it's a genuine sub-job.

---

## Competing Jobs

Users rarely have a single job in isolation. Jobs compete with each other — and these tensions determine which trade-offs your surfaces make.

| Tension Type | Example | Design Implication |
|-------------|---------|-------------------|
| **Speed vs. Thoroughness** | "Move fast" vs. "Be precise" | Progressive disclosure: quick path by default, detail available |
| **Individual vs. Team** | "Track my work" vs. "Align the team" | Personal vs. shared views |
| **Create vs. Review** | "Make new things" vs. "Evaluate existing things" | Workspace vs. overview archetypes |
| **Autonomy vs. Compliance** | "Do it my way" vs. "Follow the process" | Flexible vs. structured flows |

### Documenting Competing Jobs

Every core job should declare its primary tension:
```yaml
competing_jobs:
  - job: "__FILL__"
    tension: "__FILL__"
    resolution: "__FILL__"  # How the product handles the tension
```

The resolution is a design strategy, not a compromise. Notion resolves "structure vs. freedom" by making structure optional (databases are powerful but pages work without them). Asana resolves "individual vs. team" by making personal views (My Tasks) equally prominent to shared views (project boards).

---

## Job Completeness

### The Completeness Test

> "Does this product solve the complete core job, or just part of it?"

| Coverage | Meaning | Risk |
|----------|---------|------|
| **Fully served** | User can accomplish the entire job within the product | Low — product is self-sufficient |
| **Partially served** | User needs external tools for some sub-jobs | Medium — dependency on tools you don't control |
| **Unserved** | Job exists but no surfaces address it | High — gap in value proposition |

Partial coverage isn't always wrong — it may reflect deliberate scope. But it must be *documented*, not accidental. Every sub-job marked `partially` or `unserved` should have a note explaining why.

### The Export Test

> "Where does the user go when they leave your product to accomplish the rest of the job?"

If the answer is "spreadsheet," "email," or "Slack" — those are completeness gaps. Whether to fill them is a product strategy decision, but the gaps should be visible.

---

## Job-to-Surface Traceability

Every surface (SURF-NNN) should trace back to at least one job (JOB-NNN). This traceability flows through the hierarchy:
JOB-NNN → FLOW-NNN → SURF-NNN

### Traceability Rules

| Rule | Description |
|------|-------------|
| **Orphaned surfaces** | A surface with no job mapping is a candidate for removal. If it exists, justify why. |
| **Unserved jobs** | A job with no flow mapping is a gap in the product. Document whether this is intentional scope limitation or a missing capability. |
| **Multi-job surfaces** | A surface may serve multiple jobs (e.g., a dashboard serves both "understand current state" and "identify what needs attention"). This is fine — but the primary job should be declared. |

### Integration with Existing System

| System Component | How Jobs Connect |
|-----------------|-----------------|
| **Surface Registry** (`_surfaces/REGISTRY.yaml`) | Each surface optionally lists `jobs: [JOB-NNN]` |
| **Gate 0** (`_quality/QUALITY_PROTOCOL.md`) | Conditional checklist: "Surface traces to a JOB-NNN (if jobs registry is populated)" |
| **Gate 5** (`_quality/QUALITY_PROTOCOL.md`) | Conditional: "Orphaned surface check — any SURF-NNN with no JOB-NNN mapping requires justification (if jobs registry is populated)" |
| **Critique — Intent Alignment** (`_critique/PROMPT.md`) | Add: "Does this surface advance a documented job?" |
| **EIL** (`_expectations/FRAMEWORK.md`) | Before EIL, verify the new capability serves a documented job. If no job exists, the job may be missing from the registry, or the feature may not be needed. |
| **Flow Registry** (`_flows/REGISTRY.yaml`) | Each flow declares `job: JOB-NNN` |

**Soft enforcement:** Job traceability is encouraged but not gated. The checklist items are conditional on the jobs registry being populated. Teams can adopt jobs gradually. But once the registry has entries, traceability is expected.

---

## When to Write Jobs

### Early and Imperfect

Jobs don't need to be perfect before building starts. The registry is a living document:

| Product Stage | Jobs Expectation |
|--------------|-----------------|
| **Exploration** | Core job drafted, sub-jobs emerging. Back-fill as understanding grows. |
| **Definition** | Core job stable, 3-5 sub-jobs documented. Flows beginning to map. |
| **Build** | Job hierarchy complete. All surfaces trace to jobs. Competing jobs explicit. |
| **Mature** | Job completeness evaluated. Gaps documented. Hierarchy stable. |

### Triggers for Job Review

| Trigger | Action |
|---------|--------|
| New feature proposed | Check: which job does this serve? |
| Surface feels disconnected | Check: does this surface map to a job? |
| User research reveals unmet need | Check: is there an unserved sub-job? |
| Product feels unfocused | Check: are there multiple core jobs? (There should be one.) |
| Competitor comparison | Check: do they serve jobs we don't? |

---

## What This Module Does NOT Do

- **Does not replace user research.** It structures findings, doesn't generate them. Jobs come from understanding users, not from filling templates.
- **Does not prescribe how to discover jobs.** See `_jobs/TEMPLATES.md` for interview prompts and discovery exercises, but discovery is outside the system's scope.
- **Does not map to revenue or business model.** That's strategy, not design governance. A job's value is in the progress it enables, not the revenue it generates.
- **Does not require completion before building.** You can start building and back-fill jobs as understanding grows. But the registry must exist and the core job should be drafted before committing to major surface investments.
- **Does not model features.** "Export to PDF" is not a job. "Share progress with stakeholders outside my team" might be.

---

## Related Files

| File | Relationship |
|------|-------------|
| `_jobs/REGISTRY.yaml` | Job entries and hierarchy |
| `_jobs/TEMPLATES.md` | Discovery tools and interview prompts |
| `_flows/FRAMEWORK.md` | How jobs become flows |
| `_flows/REGISTRY.yaml` | Flow entries reference JOB-NNN |
| `_surfaces/REGISTRY.yaml` | Surface entries optionally reference JOB-NNN |
| `_expectations/FRAMEWORK.md` | EIL verifies capabilities serve jobs |
| `_quality/QUALITY_PROTOCOL.md` | Gate 0 and Gate 5 job traceability checks |
| `_critique/PROMPT.md` | Intent Alignment references jobs |
| `_examples/JOBS.example.yaml` | Beacon worked example |
