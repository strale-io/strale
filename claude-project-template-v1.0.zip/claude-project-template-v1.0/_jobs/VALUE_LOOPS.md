# Value Loop Mapping

> How product usage creates compounding value.

**Purpose:** Map the feedback loops that make a product more valuable with continued use. Value loops are the engine behind retention — they explain *why* users come back, not just *what* they do.

---

## Core Principle

> Every product action should either create future value or consume past value. Actions that do neither are features without gravity.

---

## The Four Loop Types

### 1. Data Loop

**Definition:** User adds data → product becomes more useful → user adds more data.

**Mechanism:** The product's utility increases as the dataset grows. Empty products are useless; populated products are indispensable.

| Signal | Example |
|--------|---------|
| Growing dataset | More entries → better search, smarter defaults |
| Historical context | Past decisions inform future recommendations |
| Pattern recognition | System learns from accumulated data |

**Template:**
```yaml
data_loop:
  user_action: "__FILL__"
  value_created: "__FILL__"
  how_it_feeds_back: "__FILL__"
  empty_state_pain: "__FILL__"  # Why the product is useless when empty
  critical_mass: "__FILL__"     # When does the loop start compounding?
```

**Test:** Would losing this data make the product significantly less useful?

---

### 2. Learning Loop

**Definition:** User makes decisions → product captures rationale → future decisions are faster/better.

**Mechanism:** The product accumulates institutional knowledge. Decisions aren't just recorded — their *reasoning* is preserved, making future similar decisions faster.

| Signal | Example |
|--------|---------|
| Decision memory | "Last time we chose X because Y" |
| Calibrated defaults | System suggests based on past choices |
| Error prevention | Warns about past mistakes |

**Template:**
```yaml
learning_loop:
  decision_type: "__FILL__"
  rationale_captured: "__FILL__"
  how_it_accelerates: "__FILL__"
  knowledge_at_risk: "__FILL__"  # What's lost if user leaves
```

**Test:** Does the product get smarter with use, or just fuller?

---

### 3. Integration Loop

**Definition:** User connects external systems → product becomes workflow hub → more systems connect.

**Mechanism:** The product becomes structurally central. Other tools depend on its outputs or feed its inputs. Replacing it requires coordinated migration across systems.

| Signal | Example |
|--------|---------|
| Downstream consumers | Other tools read product's outputs |
| Upstream feeders | External data flows into product |
| Workflow centrality | Product sits at a decision point |

**Template:**
```yaml
integration_loop:
  connected_system: "__FILL__"
  data_direction: "inbound | outbound | bidirectional"
  dependency_strength: "convenience | workflow | structural"
  migration_cost: "__FILL__"  # What breaks if disconnected
```

**Test:** How many other systems would need to change if this product disappeared?

---

### 4. Network Loop

**Definition:** More users → more value per user → attracts more users.

**Mechanism:** The product's value scales with its user base. Each new user makes the product better for existing users.

| Signal | Example |
|--------|---------|
| Shared context | Team members see each other's work |
| Collaborative features | Comments, reviews, approvals |
| Collective intelligence | Aggregated insights across users |

**Template:**
```yaml
network_loop:
  value_per_user: "__FILL__"
  how_more_users_help: "__FILL__"
  minimum_viable_network: "__FILL__"  # How many users before loop activates
  solo_value: "__FILL__"  # Is product useful with one user?
```

**Test:** Is this product better with 10 users than 1? How specifically?

---

## Loop-to-Job Mapping

Every Job-to-be-Done should map to at least one value loop. If a job doesn't create compounding value, it's a utility — useful but not sticky.
```yaml
loop_mapping:
  job: "__FILL__"         # From Pre-Build expected actions
  primary_loop: "__FILL__"  # Which loop type does this feed?
  value_created: "__FILL__" # What specific value does completion create?
  feeds_back_via: "__FILL__" # How does that value improve future use?
  if_no_loop: "utility | one-time | table-stakes"
```

**Classification:**

| Category | Loop Contribution | Implication |
|----------|-------------------|-------------|
| **Loop-feeding** | Directly feeds a value loop | Prioritize, design for compounding |
| **Utility** | Useful but doesn't compound | Build efficiently, don't over-invest |
| **One-time** | Value consumed immediately | Build once, move on |
| **Table-stakes** | Expected regardless of loops | Must have, but not differentiating |

---

## Visibility Guidelines

Value loops are invisible unless surfaced. Users don't inherently know their data is becoming more valuable. The product must communicate loop progress.

### What to Surface

| Loop Type | What to Show |
|-----------|-------------|
| Data | Dataset growth, coverage completeness, "X decisions informed by your data" |
| Learning | "Based on your past choices...", decision history, pattern detection |
| Integration | Connected system count, data flow status, sync health |
| Network | Team activity, shared contributions, collaborative moments |

### What NOT to Surface

| Anti-Pattern | Why |
|--------------|-----|
| Gamification metrics | Engagement theater, not genuine value |
| Artificial milestones | "Congratulations on 100 entries!" without real value change |
| Guilt signals | "You haven't logged in for 3 days" — manufactured urgency |
| Vanity metrics | Numbers that look impressive but don't reflect real value |

### Surfacing Test

> For each value loop signal you display, ask:
> "Does seeing this genuinely help the user, or does it just make us feel like the product is working?"

If the answer is the latter, remove it.

---

## Value Loop Audit

Run during Pre-Build to evaluate loop health:
```yaml
value_loop_audit:
  surface: "__FILL__"
  loops_fed:
    - loop_type: "__FILL__"
      mechanism: "__FILL__"
      visibility: "surfaced | implicit | hidden"
  loops_consumed:
    - loop_type: "__FILL__"
      value_used: "__FILL__"
  dead_actions:  # Actions that don't feed or consume any loop
    - action: "__FILL__"
      classification: "utility | one-time | table-stakes | unnecessary"
```

**Red flag:** If a surface has zero loop-feeding actions, it's a utility screen. Not necessarily bad, but worth questioning whether it deserves the investment.

---

## Connection to Existing Frameworks

| Framework | Connection |
|-----------|-----------|
| **Moats** (`_strategy/MOATS.md`) | Value loops ARE the mechanism behind moats. Data loops → Special Know-how. Integration loops → System Rigidity. Network loops → Scale. |
| **Stickiness Assessment** (`_expectations/FRAMEWORK.md`) | Stickiness questions map directly to loop types |
| **Feature Classification** (`_expectations/FRAMEWORK.md`) | Loop-feeding features should be prioritized in Expected/Helpful classification |
| **Synthesis Artifacts** (`_artifacts/SYNTHESIS.md`) | Artifacts are outputs of value loops — they embody accumulated value |

---

## When to Apply

- **Always:** Map value loops during Pre-Build for any multi-use surface
- **Optional:** Skip for one-time flows (onboarding, setup, migration)
- **Required:** When `moat-conscious` preset is active, value loop audit is mandatory

---

## Severity Levels

| Severity | Condition |
|----------|-----------|
| **P1** | Primary workflow has no loop-feeding actions |
| **P2** | Value loop exists but is not surfaced to user |
| **P2** | Loop visibility uses anti-patterns (gamification, guilt) |

---

## Related Files

- `_strategy/MOATS.md` — Moat types and tests
- `_expectations/FRAMEWORK.md` — Stickiness Assessment
- `_expectations/PRE-BUILD.md` — Pre-Build Flow
- `_artifacts/SYNTHESIS.md` — Artifact-first design
