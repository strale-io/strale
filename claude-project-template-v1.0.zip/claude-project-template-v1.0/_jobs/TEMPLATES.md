# Jobs Discovery Templates

> Tools for identifying and validating jobs. Use these to populate `_jobs/REGISTRY.yaml`.

---

## When to Use These Templates

| Situation | Template |
|-----------|----------|
| Starting a new product — need to identify the core job | Core Job Discovery |
| Core job exists — need to find sub-jobs | Sub-Job Decomposition |
| Validating whether a proposed feature serves a real job | Feature-to-Job Validation |
| Interviewing users to discover jobs | Interview Question Bank |
| Reviewing completeness of job coverage | Completeness Audit |

---

## Core Job Discovery

Use when the product's core job hasn't been defined yet, or when the existing statement feels vague.

### Step 1: List Candidate Jobs

Brainstorm what progress users are trying to make. Don't filter yet.
```yaml
candidates:
  - statement: "__FILL__"
    evidence: "__FILL__"  # How do you know users want this?
  - statement: "__FILL__"
    evidence: "__FILL__"
  - statement: "__FILL__"
    evidence: "__FILL__"
```

### Step 2: Apply the Core Job Tests

For each candidate, answer:

| Test | Question | Pass/Fail |
|------|----------|-----------|
| **Product-Removal** | If this product disappeared, would users still have this job? | Must pass |
| **Stability** | Will this job exist in 5 years regardless of technology changes? | Must pass |
| **Singularity** | Is this one job or multiple jobs bundled together? | Must be one |
| **Scope** | Is this broad enough to justify a product, not just a feature? | Must pass |
| **Specificity** | Is this specific enough to guide design decisions? | Must pass |

### Step 3: Write the Core Job Statement

Using the surviving candidate:
```yaml
core_job:
  statement: "When __FILL__, I want to __FILL__, so I can __FILL__."
  situation: "__FILL__"
  motivation: "__FILL__"
  outcome: "__FILL__"
```

### Step 4: Verify with the Inversion Test

Write the opposite of the core job:

> "When [situation], I want to [opposite of motivation], so I can [opposite of outcome]."

If the inversion sounds absurd, your job statement may be too obvious (everyone wants "better outcomes"). If the inversion sounds like a legitimate competing priority, your statement has teeth.

**Example:**
- Core job: "When leading a team, I want to align everyone on priorities, so effort goes toward outcomes."
- Inversion: "When leading a team, I want everyone to choose their own priorities, so effort goes toward individual interests."
- Verdict: The inversion is a real tension (autonomy vs. alignment). The core job has teeth. ✓

---

## Sub-Job Decomposition

Use after the core job is defined to identify the sub-jobs required to accomplish it.

### Step 1: Map the Job Timeline

Walk through how a user accomplishes the core job from start to finish. What are the distinct phases?
```yaml
timeline:
  - phase: "__FILL__"
    what_happens: "__FILL__"
    when: "__FILL__"  # e.g., "start of quarter", "weekly", "when problems arise"
  - phase: "__FILL__"
    what_happens: "__FILL__"
    when: "__FILL__"
  - phase: "__FILL__"
    what_happens: "__FILL__"
    when: "__FILL__"
```

### Step 2: Convert Phases to Job Statements

Each phase that represents distinct progress becomes a sub-job:
```yaml
sub_jobs:
  - statement: "When __FILL__, I want to __FILL__, so I can __FILL__."
    phase: "__FILL__"  # Which timeline phase this maps to
    frequency: __SELECT__  # once | per-cycle | weekly | daily | on-demand
    necessity: __SELECT__  # required | common | occasional
```

### Step 3: Apply the Necessity Test

For each sub-job:

> "Can the user accomplish the core job without completing this sub-job?"

| Answer | Classification |
|--------|---------------|
| No — core job fails without it | Required sub-job → include in hierarchy |
| Usually no, but workarounds exist | Common sub-job → include in hierarchy |
| Yes — it helps but isn't necessary | Supporting job → document but don't include as sub-job |

### Step 4: Check for Gaps

| Question | If Yes |
|----------|--------|
| Are there phases where the user leaves your product to use another tool? | Potential unserved sub-job |
| Are there phases that feel like chores rather than progress? | Automation or simplification opportunity |
| Are there phases that only some users need? | May not be a sub-job of the core job |

---

## Feature-to-Job Validation

Use when a feature has been proposed and you need to verify it serves a real job. This is especially useful during Gate 0 when evaluating whether a new capability belongs.

### The Validation Chain

For the proposed feature, trace upward:
```yaml
validation:
  feature: "__FILL__"

  # Level 1: What surface does this feature appear on?
  surface: "__FILL__"  # SURF-NNN

  # Level 2: What flow does this surface participate in?
  flow: "__FILL__"  # FLOW-NNN

  # Level 3: What job does this flow serve?
  job: "__FILL__"  # JOB-NNN

  # If any level is blank, investigate:
  missing_link: "__FILL__"
  interpretation:
    - "Job exists but flow/surface mapping is incomplete" # → Update registry
    - "Job doesn't exist — feature may not be needed"     # → Challenge the feature
    - "Job exists but is unserved — this is a new flow"    # → Create the flow first
```

### Quick Validation Questions

| Question | Good Answer | Warning Sign |
|----------|-------------|-------------|
| What job does this feature help accomplish? | Specific JOB-NNN reference | "It's useful" or "Users asked for it" |
| Would the core job suffer without this feature? | Clear connection to progress | "Not really, but it's nice" |
| Is this the right surface for this feature? | Matches flow step | "It could go anywhere" |
| Does this feature already exist in another form? | No, or deliberately different | Duplication risk |

---

## Interview Question Bank

Questions for discovering jobs through user conversations. These are starting points — follow the user's thread, don't interrogate.

### Opening Questions (Discover the Job)

| Question | What You're Learning |
|----------|---------------------|
| "Walk me through the last time you [relevant activity]. Start from the very beginning." | The actual workflow, not the idealized one |
| "What were you trying to accomplish? Not the task — the bigger goal." | The job behind the task |
| "What prompted you to start? What was the trigger?" | The situation |
| "How did you know you were done?" | The desired outcome |

### Depth Questions (Understand the Struggle)

| Question | What You're Learning |
|----------|---------------------|
| "What was the hardest part?" | Where current solutions fail |
| "What did you try before finding your current approach?" | Competing solutions and switching triggers |
| "Where did you get stuck or have to switch tools?" | Completeness gaps |
| "What would have made this easier?" | Unserved sub-jobs |
| "How often do you do this? Has the frequency changed?" | Job importance and trends |

### Validation Questions (Test Your Hypotheses)

| Question | What You're Learning |
|----------|---------------------|
| "If [proposed core job] disappeared as a need, what would change for you?" | Whether the job is real |
| "Would you say [sub-job A] or [sub-job B] matters more to you?" | Job priority |
| "What's the worst that happens if you skip [sub-job]?" | Necessity |
| "When [competing job] conflicts with [core job], which wins?" | Tension resolution |

### Anti-Patterns in Job Interviews

| Anti-Pattern | Why It Fails | Instead |
|-------------|-------------|---------|
| "Would you use a feature that does X?" | Hypothetical questions get hypothetical answers | "Tell me about the last time you needed to X" |
| "What features do you wish existed?" | Users design solutions, not jobs | "What's frustrating about your current process?" |
| "Do you agree that [job statement]?" | Leading question, confirmation bias | "In your own words, what are you trying to accomplish?" |
| Asking about future behavior | People predict poorly | Ask about past behavior and current struggles |

---

## Completeness Audit

Use periodically to evaluate whether the jobs registry reflects reality.

### Audit Checklist
```yaml
completeness_audit:
  date: "__FILL__"

  core_job:
    - exists: __SELECT__  # yes | no
    - still_accurate: __SELECT__  # yes | needs_revision | no
    - evidence: "__FILL__"  # What confirms this is still the core job?

  sub_jobs:
    - total_count: __FILL__
    - fully_served: __FILL__
    - partially_served: __FILL__
    - unserved: __FILL__
    - new_gaps_found: __FILL__  # Sub-jobs that should exist but don't

  traceability:
    - surfaces_with_job_mapping: __FILL__  # Count
    - surfaces_without_job_mapping: __FILL__  # Count (orphan candidates)
    - jobs_without_flows: __FILL__  # Count (unserved gaps)

  competing_jobs:
    - documented: __SELECT__  # yes | no
    - resolutions_still_valid: __SELECT__  # yes | needs_revision

  actions:
    # List specific actions from this audit
    - action: "__FILL__"
      priority: __SELECT__  # high | medium | low
```

---

## Related Files

| File | Relationship |
|------|-------------|
| `_jobs/FRAMEWORK.md` | Concepts and rules |
| `_jobs/REGISTRY.yaml` | Where discoveries are recorded |
| `_research/INTERVIEW_TEMPLATE.md` | General interview framework (jobs questions complement these) |
| `_examples/JOBS.example.yaml` | Beacon worked example |
