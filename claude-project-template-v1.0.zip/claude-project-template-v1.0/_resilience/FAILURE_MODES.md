# Failure Mode Catalog

> Cross-cutting failure scenarios and their designed responses.

---

## Purpose

This catalog documents system-level failure modes — scenarios where things go wrong in ways that affect multiple surfaces or the entire product. Unlike per-surface edge cases (documented in surface specs), these are cross-cutting concerns.

Use this catalog to:
- Design consistent failure handling across surfaces
- Ensure graceful degradation is planned, not improvised
- Train QA on what to test
- Guide incident response

---

## Failure Mode Categories

### Network Failures

| ID | Mode | User Experience | System Response |
|----|------|-----------------|-----------------|
| NET-001 | **Complete offline** | __FILL__ | __FILL__ |
| NET-002 | **Intermittent connectivity** | __FILL__ | __FILL__ |
| NET-003 | **Slow connection (<1Mbps)** | __FILL__ | __FILL__ |
| NET-004 | **Request timeout** | __FILL__ | __FILL__ |
| NET-005 | **Partial response** | __FILL__ | __FILL__ |

### Data Failures

| ID | Mode | User Experience | System Response |
|----|------|-----------------|-----------------|
| DATA-001 | **Empty dataset** | __FILL__ | __FILL__ |
| DATA-002 | **Corrupted data** | __FILL__ | __FILL__ |
| DATA-003 | **Stale data (cache invalid)** | __FILL__ | __FILL__ |
| DATA-004 | **Concurrent modification conflict** | __FILL__ | __FILL__ |
| DATA-005 | **Data validation failure** | __FILL__ | __FILL__ |
| DATA-006 | **Missing required fields** | __FILL__ | __FILL__ |

### Authentication Failures

| ID | Mode | User Experience | System Response |
|----|------|-----------------|-----------------|
| AUTH-001 | **Session expired** | __FILL__ | __FILL__ |
| AUTH-002 | **Invalid credentials** | __FILL__ | __FILL__ |
| AUTH-003 | **Permissions revoked mid-session** | __FILL__ | __FILL__ |
| AUTH-004 | **OAuth token refresh failure** | __FILL__ | __FILL__ |
| AUTH-005 | **Multi-session conflict** | __FILL__ | __FILL__ |

### External Service Failures

| ID | Mode | User Experience | System Response |
|----|------|-----------------|-----------------|
| EXT-001 | **Third-party API down** | __FILL__ | __FILL__ |
| EXT-002 | **Third-party rate limited** | __FILL__ | __FILL__ |
| EXT-003 | **Third-party response malformed** | __FILL__ | __FILL__ |
| EXT-004 | **Third-party timeout** | __FILL__ | __FILL__ |
| EXT-005 | **Third-party auth failure** | __FILL__ | __FILL__ |

### State Failures

| ID | Mode | User Experience | System Response |
|----|------|-----------------|-----------------|
| STATE-001 | **Invalid state transition** | __FILL__ | __FILL__ |
| STATE-002 | **Orphaned entity** | __FILL__ | __FILL__ |
| STATE-003 | **Circular reference detected** | __FILL__ | __FILL__ |
| STATE-004 | **Version mismatch** | __FILL__ | __FILL__ |
| STATE-005 | **State machine deadlock** | __FILL__ | __FILL__ |

### Resource Failures

| ID | Mode | User Experience | System Response |
|----|------|-----------------|-----------------|
| RES-001 | **Storage quota exceeded** | __FILL__ | __FILL__ |
| RES-002 | **Memory exhaustion (client)** | __FILL__ | __FILL__ |
| RES-003 | **File too large** | __FILL__ | __FILL__ |
| RES-004 | **Rate limit exceeded** | __FILL__ | __FILL__ |
| RES-005 | **Concurrent operation limit** | __FILL__ | __FILL__ |

---

## Graceful Degradation Patterns

### Pattern: Stale-While-Revalidate
**When:** Network failure during data fetch
**Behavior:** Show cached data with staleness indicator; attempt refresh in background
**User sees:** Data with "Last updated X ago" warning
**References:** FR-001, FR-003

### Pattern: Optimistic Update with Rollback
**When:** Network failure during mutation
**Behavior:** Apply change locally; queue for sync; rollback if sync fails
**User sees:** Immediate feedback; error toast if rollback needed
**References:** FB-001, FB-002

### Pattern: Progressive Enhancement
**When:** Feature requires capability that may not be available
**Behavior:** Core functionality works; enhanced features hidden if unavailable
**User sees:** Working core; no broken/disabled features visible
**References:** PM-001

### Pattern: Circuit Breaker
**When:** Repeated failures to external service
**Behavior:** Stop attempting calls; show service unavailable; auto-retry after cooldown
**User sees:** Clear explanation of limited functionality; no hanging requests
**References:** UI-003, FB-002

### Pattern: Graceful Timeout
**When:** Operation exceeds expected duration
**Behavior:** Show progress; offer cancel; continue in background if appropriate
**User sees:** Progress indicator; ability to cancel; notification when complete
**References:** FB-004, UI-003

---

## Error Communication Guidelines

### Error Message Template

```
[What happened] + [Why it matters] + [What to do]
```

**Good:** "Couldn't save your changes because the network is unavailable. Your work is saved locally and will sync when you're back online."

**Bad:** "Error 500: Internal Server Error"

### Error Severity Display

| Severity | Display | Persistence | Action Required |
|----------|---------|-------------|-----------------|
| **Blocking** | Modal or full-page | Until resolved | Yes |
| **Warning** | Banner or toast | Until dismissed or resolved | Optional |
| **Info** | Toast | Auto-dismiss | No |

### Error Recovery Actions

Every error should offer at least one of:
1. **Retry** — If operation might succeed on retry
2. **Alternative** — If there's another way to accomplish the goal
3. **Report** — If user should contact support
4. **Dismiss** — If error is informational only

---

## Testing Checklist

For each failure mode:
- [ ] Unit test simulating the failure
- [ ] Integration test for recovery behavior
- [ ] E2E test for user experience
- [ ] Manual verification of error messaging

---

## Adding New Failure Modes

1. Identify the category (Network, Data, Auth, External, State, Resource)
2. Assign next ID in sequence (e.g., NET-006)
3. Document user experience and system response
4. Identify graceful degradation pattern (or create new one)
5. Add tests
6. Update affected surface specs
