# Invariants Registry

> Truths that must never break, even during refactoring.

**Authority:** This registry defines system-wide invariants. Violation of any invariant is a P0 bug.

---

## What Are Invariants?

Invariants are **absolute constraints** that must hold true at all times, across all product classes. They are not preferences or guidelines — they are laws of the system.

Use this registry to:
- Verify changes don't break fundamental truths
- Guide agent reasoning about correctness
- Establish non-negotiable quality bars

---

## Identity Invariants

These govern how entities are identified and referenced.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| ID-001 | **IDs are never reused.** Once an ID is assigned, it permanently refers to that entity, even after deletion. | Prevents ghost references, audit corruption |
| ID-002 | **IDs are immutable.** An entity's ID cannot change after creation. | Prevents broken links, cache invalidation chaos |
| ID-003 | **Every entity has exactly one canonical ID.** No entity may have multiple primary identifiers. | Prevents identity confusion |
| ID-004 | **Referential integrity is enforced.** A reference to an entity must point to an existing entity or be explicitly null. | Prevents dangling pointers |
| ID-005 | **Deletion is soft by default.** Entities are marked deleted, not physically removed, unless explicitly purged. | Preserves audit trail, enables undo |

---

## Hierarchy Invariants

These govern parent-child and tree structures.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| HIE-001 | **No cycles in strict hierarchies.** A node cannot be its own ancestor. | Prevents infinite loops |
| HIE-002 | **Orphan nodes are forbidden.** Every non-root node must have a parent. | Prevents unreachable data |
| HIE-003 | **Root is always accessible.** Navigation to root must always be possible. | Ensures "sense of place" |
| HIE-004 | **Depth limits are enforced.** Hierarchies must respect declared max depth. | Prevents UI/performance degradation |
| HIE-005 | **Move preserves identity.** Moving a node to a new parent does not change its ID. | Preserves references |

---

## Time Series Invariants

These govern temporal data (applies especially to `data_platform` class).

| ID | Invariant | Rationale |
|----|-----------|-----------|
| TS-001 | **Timestamps are monotonic within a series.** Later observations have later timestamps. | Prevents temporal paradoxes |
| TS-002 | **Timezone is always explicit.** No timestamp is stored or displayed without timezone context. | Prevents silent misinterpretation |
| TS-003 | **Missing values are explicit.** Gaps in series are represented explicitly, not as absent records. | Prevents false zero/null assumptions |
| TS-004 | **Periodization is declared.** Every series has an explicit period (daily, weekly, monthly, etc.). | Prevents aggregation errors |
| TS-005 | **Revisions preserve history.** When data is revised, prior values remain accessible with vintage timestamps. | Enables point-in-time reproducibility |

---

## State Invariants

These govern entity state machines.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| ST-001 | **States are mutually exclusive.** An entity is in exactly one state at a time. | Prevents ambiguous behavior |
| ST-002 | **Transitions are explicit.** State changes occur only through declared transitions. | Prevents impossible states |
| ST-003 | **Terminal states are final.** Once in a terminal state, no transitions are possible. | Prevents zombie entities |
| ST-004 | **Initial state is defined.** Every entity type has exactly one initial state. | Ensures deterministic creation |
| ST-005 | **State is never inferred.** State is stored explicitly, not computed from other fields. | Prevents drift, enables audit |

---

## UI Invariants

These govern user interface behavior.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| UI-001 | **Selection is always visible.** Selected items must have visible indication. | Prevents user confusion |
| UI-002 | **Focus is never lost.** Keyboard focus always has a valid target. | Ensures keyboard accessibility |
| UI-003 | **Loading states are explicit.** Async operations show loading indication within 100ms. | Prevents perceived freezing |
| UI-004 | **Errors are surfaced.** Failed operations show error feedback, never fail silently. | Prevents silent data loss |
| UI-005 | **Destructive actions require confirmation.** Delete, discard, and irreversible actions require explicit confirmation. | Prevents accidental loss |
| UI-006 | **Empty states are designed.** Every collection view has an explicit empty state. | Prevents confusion ("is it loading or empty?") |
| UI-007 | **Scroll position is preserved.** Returning to a view restores scroll position where possible. | Preserves user context |
| UI-008 | **Disabled states are explained.** Disabled controls indicate why they're disabled. | Prevents frustration |

---

## Affordance Invariants

These govern interactive element integrity. See LAW-007 (Affordance Integrity).

| ID | Invariant | Rationale |
|----|-----------|-----------|
| AF-001 | **Buttons perform actions.** Every button triggers a real action or is explicitly disabled with explanation. | Prevents hollow UI |
| AF-002 | **Links navigate.** Every link navigates to a real destination. | Prevents dead ends |
| AF-003 | **Chevrons navigate.** Row chevrons indicate and perform navigation. | Prevents fake affordances |
| AF-004 | **Breadcrumbs are functional.** Every breadcrumb segment is clickable and navigates. | Ensures navigation works |
| AF-005 | **Disabled states are explained.** Disabled elements show why via tooltip or inline text. | Prevents user confusion |
| AF-006 | **Progress indicators are clear.** Progress bars/indicators explain what they measure (e.g., "3 of 5 approved"). | Prevents ambiguity |
| AF-007 | **Primary flows are complete.** Top user tasks work end-to-end before secondary surfaces ship. | Prevents hollow products |

---

## Expectation Invariants

These govern user action expectations. See User Expectation Framework in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| EX-001 | **Metrics are navigation.** Any number/count displayed must link to details or filtered list. | Prevents dead data |
| EX-002 | **Smart CTAs are contextual.** Primary CTAs must specify where/why, not just "Continue" or "Next". | Prevents confusion |
| EX-003 | **Navigation surfaces enable forward motion.** User can always progress or explicitly understands why not. | Prevents dead ends |
| EX-004 | **Visible elements are interactive.** If it looks clickable (card, metric, badge), it must be clickable or styled as non-interactive. | Prevents false affordances |
| EX-005 | **Surface type matches actions.** Navigation surfaces have navigation; manipulation surfaces have CRUD. | Prevents expectation mismatch |

---

## Information Invariants

These govern user information expectations. See User Expectation Framework in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| IX-001 | **Metrics include context.** Numbers show what they measure and whether value is good/bad (or how to tell). | Prevents uninterpretable data |
| IX-002 | **Status indicators explain meaning.** Not just color/label — what the status means. | Prevents confusion |
| IX-003 | **Progress shows composition.** Progress indicators show what's measured, not just percentage. | Prevents ambiguity |
| IX-004 | **Empty states explain why.** Not just "No items" — why empty and what to do. | Prevents confusion |
| IX-005 | **Errors explain resolution.** Not just what's wrong — how to fix it. | Prevents frustration |
| IX-006 | **Raised questions are answered.** If displayed data raises a follow-up question, answer is on-page or path is clear. | Prevents confusion |

---

## Explanation Invariants

These govern how understanding is delivered. See Explanation System in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| XP-001 | **State indicators have explanation path.** Status badges, progress bars, maturity labels must be explainable at some rung. | Ensures comprehension |
| XP-002 | **Disabled elements explain constraint.** Why it's unavailable, not just that it is. | Prevents frustration |
| XP-003 | **Counts explain composition.** What the numbers measure (e.g., "5/12 approved" not just "5/12"). | Prevents ambiguity |
| XP-004 | **Tooltips are accessible.** Keyboard and screen reader accessible. | Accessibility requirement |
| XP-005 | **Tooltips are not sole source.** Tooltips must have backup explanation rung (never the only way to learn). | Progressive disclosure |
| XP-006 | **Explanation matches type.** Definition explains "what"; Interpretation explains "how to read"; Constraint explains "why locked". | Semantic clarity |

---

## Orientation Invariants

These govern user awareness of location. See Orientation Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| OR-001 | **Page title matches navigation.** The page title must match the navigation item that leads to it. | Prevents confusion |
| OR-002 | **Deep pages have breadcrumbs.** Any page more than one level deep must have functional breadcrumbs. | Enables navigation up |
| OR-003 | **Current location is visually indicated.** Active navigation item must be visually distinct. | Confirms user location |
| OR-004 | **Deep links are self-sufficient.** Pages accessible via direct URL must provide enough context to orient the user. | Prevents disorientation |
| OR-005 | **Modals indicate origin.** Modals/drawers must show what they're editing or where they came from. | Preserves context |

---

## Confidence Invariants

These govern trust preservation. See Confidence Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| CF-001 | **Color does not imply quality.** Green/red/yellow must not suggest good/bad without explicit explanation. | Prevents false judgment |
| CF-002 | **Rankings explain criteria.** Any ranked or sorted-by-importance list must explain the ranking basis. | Prevents hidden inference |
| CF-003 | **Incompleteness is visible.** If data is partial or filtered, this must be indicated. | Prevents false completeness |
| CF-004 | **Defaults are marked.** Pre-filled or system-suggested values must be distinguishable from user-entered. | Prevents silent inference |
| CF-005 | **Uncertainty is explicit.** Estimates, projections, or low-confidence data must be marked as such. | Prevents false certainty |

---

## Freshness Invariants

These govern data currency signals. See Freshness Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| FR-001 | **Stale-able data shows freshness.** Any data that can become outdated must show when it was last updated. | Prevents stale assumptions |
| FR-002 | **Synced data shows sync status.** Data from external sources must show sync state and last sync time. | Enables trust assessment |
| FR-003 | **Staleness is warned.** Data older than expected threshold must show staleness warning. | Prevents decisions on old data |

---

## Feedback Invariants

These govern action response. See Feedback Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| FB-001 | **Actions produce feedback.** Every user action must produce visible response within 100ms. | Confirms action registered |
| FB-002 | **Errors explain recovery.** Error messages must include what went wrong and how to fix it. | Enables recovery |
| FB-003 | **Success is confirmed.** Successful actions must show explicit confirmation, not just absence of error. | Prevents uncertainty |
| FB-004 | **Async operations show progress.** Operations taking >1 second must show progress indication. | Prevents perceived freeze |

---

## Prediction Invariants

These govern consequence visibility. See Prediction Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| PR-001 | **Destructive actions show consequences.** Delete/remove/clear actions must state what will be affected. | Prevents accidental loss |
| PR-002 | **Bulk actions show count.** Operations affecting multiple items must show the count before execution. | Prevents scope surprise |
| PR-003 | **Confirmations include context.** "Are you sure?" dialogs must state what the user is confirming. | Enables informed consent |
| PR-004 | **Cascading effects are warned.** Actions that affect related items must warn about cascading changes. | Prevents unintended consequences |

---

## Reversibility Invariants

These govern action reversibility. See Reversibility Principle in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| RV-001 | **Irreversible actions are marked.** Actions that cannot be undone must explicitly state this. | Prevents regret |
| RV-002 | **Soft-delete is preferred.** Destructive actions should use soft-delete with restore option where possible. | Enables recovery |
| RV-003 | **Undo is available for reversible actions.** When an action can be undone, undo must be offered. | Enables exploration |
| RV-004 | **Time-limited reversibility is shown.** If undo has a window, the window must be visible. | Sets expectations |

---

## Continuity Invariants

These govern context preservation. See Continuity Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| CN-001 | **Scroll position is preserved.** Returning to a list view restores scroll position where possible. | Preserves user context |
| CN-002 | **Unsaved changes are warned.** Navigating away from unsaved work must prompt confirmation. | Prevents data loss |
| CN-003 | **Form data survives navigation.** Back button should not lose form data already entered. | Prevents re-entry frustration |
| CN-004 | **Filters are preservable.** Filter/sort state must be preserved in URL or session, or easily restorable. | Prevents re-filtering |

---

## Completion Invariants

These govern progress and done-ness. See Completion Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| CP-001 | **Progress is visible.** Multi-step flows must show progress indication. | Enables estimation |
| CP-002 | **Completion is signaled.** When a flow or task is complete, this must be explicitly indicated. | Confirms done-ness |
| CP-003 | **Next step is clear.** After completing something, the next action or destination must be obvious. | Enables forward motion |

---

## Exit Awareness Invariants

These govern user departure confidence. See Exit Awareness Check in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| EA-001 | **Accomplishment is visible.** User can see what they've done on this surface. | Confirms progress |
| EA-002 | **Remaining work is clear.** If incomplete, user knows what's left. | Prevents abandonment anxiety |
| EA-003 | **Next destination is obvious.** User knows where to go after this surface. | Enables forward motion |
| EA-004 | **Save state is unambiguous.** User knows if work is saved before leaving. | Prevents loss anxiety |

---

## Data Display Invariants

These govern how data is presented.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| DD-001 | **Numbers are never truncated silently.** If a number is rounded or truncated, it's indicated. | Prevents false precision |
| DD-002 | **Aggregates equal sum of parts.** Displayed totals must match the sum of displayed items. | Prevents reconciliation failures |
| DD-003 | **Labels come from authoritative source.** Display labels are not derived or computed locally. | Prevents inconsistency |
| DD-004 | **Currency and units are explicit.** Numeric values always display their unit. | Prevents misinterpretation |
| DD-005 | **Relative time has absolute fallback.** "2 hours ago" must reveal exact time on hover/click. | Enables precision when needed |

---

## Permission Invariants

These govern access control.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| PM-001 | **UI reflects permissions.** Users never see actions they cannot perform. | Prevents permission errors |
| PM-002 | **Permissions are checked on action.** Server validates permissions, not just UI. | Defense in depth |
| PM-003 | **Escalation requires approval.** Gaining higher permissions requires explicit grant. | Prevents privilege creep |
| PM-004 | **Audit trail is immutable.** Permission changes are logged and cannot be deleted. | Enables compliance |

---

## Creative Tool Invariants

These apply when `product_class: creative_tool` (extension-specific).

| ID | Invariant | Rationale |
|----|-----------|-----------|
| CR-001 | **Undo is lossless.** Undo restores exact previous state, not an approximation. | Enables fearless exploration |
| CR-002 | **Undo history survives save.** Saving does not clear undo stack. | Prevents unexpected loss |
| CR-003 | **Export is reproducible.** Same input + same settings = identical output. | Enables reliable workflows |
| CR-004 | **Canvas state is always valid.** No operation leaves canvas in unrenderable state. | Prevents corruption |
| CR-005 | **Selection is preserved across operations.** Operations don't arbitrarily clear selection. | Enables flow |

---

## Automation Invariants

These apply when `product_class: automation_platform` (extension-specific).

| ID | Invariant | Rationale |
|----|-----------|-----------|
| AU-001 | **Jobs are idempotent where declared.** Idempotent jobs produce same result on re-run. | Enables safe retries |
| AU-002 | **Failure is visible.** Failed jobs are prominently surfaced, not buried. | Prevents silent rot |
| AU-003 | **Logs are retained.** Job logs are kept for declared retention period. | Enables debugging |
| AU-004 | **Dependencies are explicit.** Job dependencies are declared, not inferred. | Prevents mysterious failures |

---

## Token Invariants

These govern design token usage.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| TK-001 | **All visual values from tokens.** No hardcoded colors, spacing, typography, shadows, radii. | Prevents drift, enables theming |
| TK-002 | **Token combinations satisfy capability matrix.** Only valid sentiment/usage/interaction combinations per `tokens.yaml` constraints. | Prevents nonsense tokens |
| TK-003 | **Forbidden patterns are never generated.** `text-hover`, `icon-hover`, `ring-default`, `focus/background` are invalid. | Maintains semantic integrity |
| TK-004 | **Component tokens reference semantic tokens.** Component-level tokens must map to semantic layer, not primitives directly. | Preserves abstraction layers |

---

## Tech Foundation Invariants

These govern architectural decisions.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| TF-001 | **Tech foundation filled before building.** Cannot implement persistence, auth, sync, or export until `config/tech-foundation.yaml` status is "active". | Prevents accidental architecture |
| TF-002 | **Persistence matches declared mode.** Implementation must match `data.persistence_mode` in tech-foundation. | Prevents mode drift |
| TF-003 | **Auth matches declared model.** Implementation must match `auth.mode` and `auth.tenancy` in tech-foundation. | Prevents auth sprawl |
| TF-004 | **Sync matches declared mode.** Implementation must match `sync.mode` in tech-foundation. | Prevents collaboration debt |
| TF-005 | **Non-goals are respected.** Features listed in `non_goals_v1` must not be implemented. | Prevents scope creep |
| TF-006 | **Performance budgets are met.** Implementation must respect budgets declared in `performance.*`. | Ensures user experience |

---

## Visual Quality Invariants

These govern visual perception and professional quality. See Visual Quality Contract in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| VQ-001 | **Spacing uses defined scale only.** No arbitrary spacing values; all spacing from token system. | Prevents assembled feel |
| VQ-002 | **Colors from token system only.** No hardcoded colors; all colors from defined tokens. | Ensures brand coherence |
| VQ-003 | **Typography uses defined styles only.** No arbitrary font sizes, weights, or line heights. | Maintains type hierarchy |
| VQ-004 | **Icons from single family only.** All icons from one consistent icon set per product. | Prevents visual noise |
| VQ-005 | **One primary focal point per surface.** No competing visual emphasis; clear hierarchy. | Enables immediate orientation |
| VQ-006 | **Density class matches surface purpose.** Sparse/Balanced/Dense appropriate for task. | Prevents mismatch anxiety |
| VQ-007 | **Same semantic elements have same treatment.** Visual consistency for same-type elements. | Builds pattern trust |
| VQ-008 | **No arbitrary values.** All visual values (spacing, sizes, radii) from defined scales. | Signals intentionality |

---

## Vocabulary Comprehension Invariants

These govern vocabulary legibility and discoverability. See Vocabulary Comprehension in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| VO-001 | **Domain terms have in-context explanation.** Non-obvious terms explainable via hover/click without navigation. | Prevents learning friction |
| VO-002 | **Terms are used consistently.** Same word means same thing throughout product; same concept uses same term. | Prevents concept drift |
| VO-003 | **Explanation doesn't require navigation.** User learns term meaning without leaving current surface. | Preserves flow |
| VO-004 | **Language is descriptive, not judgmental.** Terms describe state factually; no implied criticism or pressure. | Preserves trust |
| VO-005 | **Bespoke symbols have in-context explanation.** Custom status icons have tooltips or visible legend at point of use. | Prevents visual vocabulary confusion |
| VO-006 | **Symbols are distinguishable without color.** Status icons work in grayscale; color is enhancement, not sole differentiator. | Accessibility + printability |
| VO-007 | **Progress ratios are labeled.** Fractions like "3/12" include what numerator and denominator represent. | Prevents ambiguous progress signals |

---

## Symbol Grammar Invariants

These govern the structural consistency of status symbol systems. See Symbol Grammar System in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| SY-001 | **Status symbols use single primitive family.** All symbols in a status set share same geometric basis (area, line, or count). | Prevents grammar mixing |
| SY-002 | **Status symbols have consistent optical weight.** Same bounding box and visual mass across all states. | Prevents false hierarchy |
| SY-003 | **Status progression maps to single visual axis.** One variable changes (fill, weight, or count), not multiple. | Makes progression learnable |
| SY-004 | **Symbol progression is monotonic.** Visual change direction is consistent throughout status sequence. | Prevents ordering confusion |

---

## Progress & Status Invariants

These govern how progress indicators and status labels are displayed. See Progress & Status Semantics in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| PS-001 | **Multiple progress signals have declared hierarchy.** When 2+ progress indicators appear, one is visually primary. | Prevents competing signals |
| PS-002 | **Progress representations pass Sentence Test.** Any progress display is expressible as plain sentence with subject, count, and state. | Ensures clarity |
| PS-003 | **Status labels are descriptive, not evaluative.** Labels describe state factually; no judgment words like "healthy", "behind", "good". | Preserves neutrality |

---

## User Expectation Invariants

These govern pre-build expectation discovery and feature completeness. See User Expectation Framework in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| UE-001 | **Peer context is specified before building.** Comparable products and their equivalent features are documented. | Sets expectation baseline |
| UE-002 | **Absence detection is performed before building.** Feature Category Checklist is completed with absence classification. | Hunts for missing features |
| UE-003 | **Expected actions are enumerated before building.** Primary and secondary actions are listed with affordance mapping. | Prevents hollow surfaces |
| UE-004 | **Surface role requirements are satisfied.** Surface includes all must-have features for its type. | Enforces completeness |
| UE-005 | **Inner Monologue Test passes.** All five user simulation questions have confident answers. | Validates user-centric design |
| UE-006 | **Visual interactivity implies actual interactivity.** If it looks clickable, it is clickable. | Prevents false affordances |
| UE-007 | **Expectation debt is tracked explicitly.** Intentionally deferred features are documented, not forgotten. | Prevents amnesia |
| UE-008 | **Candidate features are explored before building.** Every surface has documented feature exploration. | Ensures curiosity is exercised |
| UE-009 | **Features are classified before implementation.** Every feature is marked Expected/Helpful/Speculative/Dangerous/Prevented. | Ensures filtering happens |
| UE-010 | **Restraint Gate is applied to all features.** No feature ships without passing restraint checks. | Ensures bounded curiosity |
| UE-011 | **Rejected features are documented.** Speculative features are logged with rejection reasoning. | Explains what wasn't built |

---

## Expectation Invention Loop Invariants

These govern cascade thinking when introducing new capabilities. See Expectation Invention Loop in `_ui/SYSTEM.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| EIL-001 | **New capabilities run Expectation Invention Loop.** Capability introduction without EIL artifact is P1. | Forces cascade thinking |
| EIL-002 | **Prevented assumptions are documented.** Every capability has explicit non-goals stating what users must NOT assume. | Prevents false expectations |
| EIL-003 | **Secondary expectations are examined.** "If used twice" expectations (history, undo, comparison, consistency) are documented. | Catches post-first-use gaps |
| EIL-004 | **Trust expectations are examined.** Status, provenance, constraints, errors, definitions are documented. | Prevents trust erosion |
| EIL-005 | **EIL outputs feed Pre-Build.** Must-build items become Expected; must-defer items populate Expectation Debt; must-prevent items inform Restraint Gate. | Ensures loop integration |

---

## Synthesis Artifact Invariants

These govern artifact-first design and reverse engineering. See `_artifacts/SYNTHESIS.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| SA-001 | **Product features must serve artifact sections.** Features not traceable to artifact sections require explicit justification. | Prevents feature drift |
| SA-002 | **Artifact sections must be renderable without false placeholders.** If a section cannot be truthfully rendered, it must show what's missing. | Ensures artifact honesty |
| SA-003 | **Undecided areas are explicitly marked.** The artifact never presents uncertainty as decision. | Prevents false confidence |
| SA-004 | **External delivery requires no apology.** If any section would cause embarrassment, the artifact is not ready. | Quality gate |
| SA-005 | **Artifact reflects actual state, not aspirational state.** The artifact shows what is, not what is hoped. | Prevents agency theater |
| SA-006 | **Artifact requires no verbal explanation.** If a section needs explaining when shared externally, the section fails. | Self-sufficiency test |

---

## Moat Invariants (Optional)

These govern structural competitive advantage. **Only active when `moat-conscious` preset is enabled.** See `_strategy/MOATS.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| MT-001 | **Features undermining existing moats require explicit justification.** A feature that makes the product easier to leave or replicate must document why. | Prevents accidental moat erosion |
| MT-002 | **Moat-building claims are testable, not marketing.** Assertions about moats must be verifiable through specific tests (Compounding, Replaceability, Integration, Memory). | Ensures honesty |
| MT-003 | **Export formats are treated as contracts.** Breaking changes to export schemas require migration paths and version bumps. | System Rigidity moat |
| MT-004 | **Decision rationale is captured.** Significant decisions include documented reasoning (institutional memory). | Special Know-how moat |

**Note:** These are P1/P2 severity when preset is active, not P0. Moat considerations guide prioritization, not block shipping.

---

## Cross-Surface Coherence Invariants

These govern consistency across multiple surfaces. See Gate 8 in `_quality/QUALITY_PROTOCOL.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| CS-001 | **Same entity, same name everywhere.** An entity's display name must not vary across surfaces unless explicitly scoped (e.g., abbreviated in navigation). | Prevents identity confusion |
| CS-002 | **Same status, same label everywhere.** A status value must use identical terminology on every surface where it appears. | Prevents interpretation drift |
| CS-003 | **Navigation promises are fulfilled.** If Surface A offers a path to "see X," the destination surface must actually show X. | Prevents trust erosion |
| CS-004 | **Counts reconcile across surfaces.** A count shown on a dashboard must equal the count shown on the corresponding list. | Prevents data distrust |
| CS-005 | **Permission visibility is consistent.** Elements hidden by permissions on one surface must not appear on another surface at the same permission level. | Prevents security confusion |

---

## Flow Architecture Invariants

These are conditional — they become enforceable when a Product Spec declares Screen Intent Declarations. See `_expectations/PRE-BUILD.md`.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| FA-001 | **Primary UI Object is visually dominant.** The declared Primary UI Object must be the most visually prominent element on the screen. | Prevents intent/execution mismatch |
| FA-002 | **Role Intent matches structure.** A screen declared as "Action" must be structured for task completion; "Information" for comprehension; "Orientation" for wayfinding; "Review" for evaluation. | Prevents structural mismatch |
| FA-003 | **Vocabulary complies with gating.** Terms used on screen must comply with the Vocabulary Gating declaration. Forbidden terms must not appear. | Prevents terminology drift |
| FA-004 | **Outcome is achievable.** The declared Outcome (user state change) must be achievable within the screen's current implementation. | Prevents hollow declarations |

---

## Affordance State Invariants

These govern interactive control clarity.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| AS-001 | **Toggle controls communicate current state.** A toggle/switch must clearly indicate its current state (on/off, enabled/disabled) through visual treatment, not just label. | Prevents action ambiguity |
| AS-002 | **Toggle controls communicate action consequence.** It must be clear what will happen when the toggle is activated — the result, not just the opposite state. | Prevents surprise behavior |
| AS-003 | **Toggle labels describe the setting, not the action.** Labels describe the capability being controlled, not the toggle action. "Email notifications" not "Turn on emails." | Prevents label/state confusion |

---

## Localization Invariants

These govern content internationalization and locale handling.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| L10N-001 | **Text content is externalized, not hardcoded.** All user-visible strings come from resource files, not inline code. | Enables translation without code changes |
| L10N-002 | **Date/time/number formats respect locale.** Dates, times, numbers, and currency display according to user's locale settings. | Prevents confusion from format mismatch |
| L10N-003 | **Text containers accommodate expansion (150%+).** UI layouts don't break when text expands (German is ~30% longer than English). | Prevents layout breakage in translation |
| L10N-004 | **Icons/symbols are culturally neutral or localized.** Symbols with cultural meaning are either universal or have locale variants. | Prevents misinterpretation |
| L10N-005 | **Reading direction is configurable.** Layout supports both LTR and RTL languages. See `_ui/layouts/RTL.md`. | Enables RTL language support |

---

## Accessibility Invariants (Extended)

These extend core accessibility beyond WCAG AA baseline. See also UI-001 through UI-008.

| ID | Invariant | Rationale |
|----|-----------|-----------|
| A11Y-001 | **Focus indicators visible in all color schemes.** Focus rings are visible in light mode, dark mode, and high contrast modes. | Ensures keyboard navigation in all themes |
| A11Y-002 | **Touch targets ≥44px on touch devices.** Tappable areas meet minimum size even if visual element is smaller. | Prevents mis-taps, supports motor impairment |
| A11Y-003 | **Motion respects prefers-reduced-motion.** Animations are disabled or reduced when user preference is set. | Prevents vestibular discomfort |
| A11Y-004 | **Text spacing adjustable without breaking layout.** Layout survives 1.5× line height, 2× letter spacing, 2× word spacing. | Supports reading disabilities |
| A11Y-005 | **Error identification includes suggestion for correction.** Error messages don't just say what's wrong — they suggest how to fix it. | Enables recovery for all users |

---

## Adding New Invariants

To add an invariant:

1. Assign next ID in category (e.g., UI-009)
2. State invariant as an absolute ("X must always Y")
3. Provide rationale
4. Log in `_decisions/REGISTRY.md`

Invariants cannot be "soft" or "preferred" — they are absolute.

---

## Checking Invariants

Before any change:

1. Review relevant invariant categories
2. Verify change doesn't violate any invariant
3. If invariant seems wrong, propose amendment (requires decision entry)
4. Never silently violate — either fix or amend

**Invariant violation = P0 bug. No exceptions.**
